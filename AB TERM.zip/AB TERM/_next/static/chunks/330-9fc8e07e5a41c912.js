(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [330], {
        293: (e, t, r) => {
            "use strict";
            r.d(t, {
                zo: () => a
            });
            var n = r(6797),
                i = r(4312),
                o = r(8789);
            let s = e => e === Object(e) && !Array.isArray(e) && "function" != typeof e;

            function a(e, t) {
                let r = (0, o.A)(e => e.gl),
                    a = (0, o.F)(i.Tap, s(e) ? Object.values(e) : e);
                return (0, n.useLayoutEffect)(() => {
                    null == t || t(a)
                }, [t]), (0, n.useEffect)(() => {
                    if ("initTexture" in r) {
                        let e = [];
                        Array.isArray(a) ? e = a : a instanceof i.gPd ? e = [a] : s(a) && (e = Object.values(a)), e.forEach(e => {
                            e instanceof i.gPd && r.initTexture(e)
                        })
                    }
                }, [r, a]), (0, n.useMemo)(() => {
                    if (!s(e)) return a; {
                        let t = {},
                            r = 0;
                        for (let n in e) t[n] = a[r++];
                        return t
                    }
                }, [e, a])
            }
            a.preload = e => o.F.preload(i.Tap, e), a.clear = e => o.F.clear(i.Tap, e)
        },
        655: (e, t, r) => {
            "use strict";
            r.d(t, {
                Xu: () => h,
                mx: () => u
            });
            var n = r(4312),
                i = r(1759),
                o = Object.defineProperty,
                s = (e, t, r) => t in e ? o(e, t, {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: r
                }) : e[t] = r,
                a = (e, t, r) => (s(e, "symbol" != typeof t ? t + "" : t, r), r);

            function l(e, t, r, n, i) {
                let o;
                if (e = e.subarray || e.slice ? e : e.buffer, r = r.subarray || r.slice ? r : r.buffer, e = t ? e.subarray ? e.subarray(t, i && t + i) : e.slice(t, i && t + i) : e, r.set) r.set(e, n);
                else
                    for (o = 0; o < e.length; o++) r[o + n] = e[o];
                return r
            }
            class u extends n.LoY {
                constructor() {
                    super(), a(this, "type", "MeshLine"), a(this, "isMeshLine", !0), a(this, "positions", []), a(this, "previous", []), a(this, "next", []), a(this, "side", []), a(this, "width", []), a(this, "indices_array", []), a(this, "uvs", []), a(this, "counters", []), a(this, "widthCallback", null), a(this, "_attributes"), a(this, "_points", []), a(this, "points"), a(this, "matrixWorld", new n.kn4), Object.defineProperties(this, {
                        points: {
                            enumerable: !0,
                            get() {
                                return this._points
                            },
                            set(e) {
                                this.setPoints(e, this.widthCallback)
                            }
                        }
                    })
                }
                setMatrixWorld(e) {
                    this.matrixWorld = e
                }
                setPoints(e, t) {
                    var r;
                    if (e = (r = e) instanceof Float32Array ? r : r instanceof n.LoY ? r.getAttribute("position").array : r.map(e => {
                            let t = Array.isArray(e);
                            return e instanceof n.Pq0 ? [e.x, e.y, e.z] : e instanceof n.I9Y ? [e.x, e.y, 0] : t && 3 === e.length ? [e[0], e[1], e[2]] : t && 2 === e.length ? [e[0], e[1], 0] : e
                        }).flat(), this._points = e, this.widthCallback = null != t ? t : null, this.positions = [], this.counters = [], e.length && e[0] instanceof n.Pq0)
                        for (let t = 0; t < e.length; t++) {
                            let r = e[t],
                                n = t / (e.length - 1);
                            this.positions.push(r.x, r.y, r.z), this.positions.push(r.x, r.y, r.z), this.counters.push(n), this.counters.push(n)
                        } else
                            for (let t = 0; t < e.length; t += 3) {
                                let r = t / (e.length - 1);
                                this.positions.push(e[t], e[t + 1], e[t + 2]), this.positions.push(e[t], e[t + 1], e[t + 2]), this.counters.push(r), this.counters.push(r)
                            }
                    this.process()
                }
                compareV3(e, t) {
                    let r = 6 * e,
                        n = 6 * t;
                    return this.positions[r] === this.positions[n] && this.positions[r + 1] === this.positions[n + 1] && this.positions[r + 2] === this.positions[n + 2]
                }
                copyV3(e) {
                    let t = 6 * e;
                    return [this.positions[t], this.positions[t + 1], this.positions[t + 2]]
                }
                process() {
                    let e, t, r = this.positions.length / 6;
                    this.previous = [], this.next = [], this.side = [], this.width = [], this.indices_array = [], this.uvs = [], t = this.compareV3(0, r - 1) ? this.copyV3(r - 2) : this.copyV3(0), this.previous.push(t[0], t[1], t[2]), this.previous.push(t[0], t[1], t[2]);
                    for (let n = 0; n < r; n++) {
                        if (this.side.push(1), this.side.push(-1), e = this.widthCallback ? this.widthCallback(n / (r - 1)) : 1, this.width.push(e), this.width.push(e), this.uvs.push(n / (r - 1), 0), this.uvs.push(n / (r - 1), 1), n < r - 1) {
                            t = this.copyV3(n), this.previous.push(t[0], t[1], t[2]), this.previous.push(t[0], t[1], t[2]);
                            let e = 2 * n;
                            this.indices_array.push(e, e + 1, e + 2), this.indices_array.push(e + 2, e + 1, e + 3)
                        }
                        n > 0 && (t = this.copyV3(n), this.next.push(t[0], t[1], t[2]), this.next.push(t[0], t[1], t[2]))
                    }
                    t = this.compareV3(r - 1, 0) ? this.copyV3(1) : this.copyV3(r - 1), this.next.push(t[0], t[1], t[2]), this.next.push(t[0], t[1], t[2]), this._attributes && this._attributes.position.count === this.counters.length ? (this._attributes.position.copyArray(new Float32Array(this.positions)), this._attributes.position.needsUpdate = !0, this._attributes.previous.copyArray(new Float32Array(this.previous)), this._attributes.previous.needsUpdate = !0, this._attributes.next.copyArray(new Float32Array(this.next)), this._attributes.next.needsUpdate = !0, this._attributes.side.copyArray(new Float32Array(this.side)), this._attributes.side.needsUpdate = !0, this._attributes.width.copyArray(new Float32Array(this.width)), this._attributes.width.needsUpdate = !0, this._attributes.uv.copyArray(new Float32Array(this.uvs)), this._attributes.uv.needsUpdate = !0, this._attributes.index.copyArray(new Uint16Array(this.indices_array)), this._attributes.index.needsUpdate = !0) : this._attributes = {
                        position: new n.THS(new Float32Array(this.positions), 3),
                        previous: new n.THS(new Float32Array(this.previous), 3),
                        next: new n.THS(new Float32Array(this.next), 3),
                        side: new n.THS(new Float32Array(this.side), 1),
                        width: new n.THS(new Float32Array(this.width), 1),
                        uv: new n.THS(new Float32Array(this.uvs), 2),
                        index: new n.THS(new Uint16Array(this.indices_array), 1),
                        counters: new n.THS(new Float32Array(this.counters), 1)
                    }, this.setAttribute("position", this._attributes.position), this.setAttribute("previous", this._attributes.previous), this.setAttribute("next", this._attributes.next), this.setAttribute("side", this._attributes.side), this.setAttribute("width", this._attributes.width), this.setAttribute("uv", this._attributes.uv), this.setAttribute("counters", this._attributes.counters), this.setAttribute("position", this._attributes.position), this.setAttribute("previous", this._attributes.previous), this.setAttribute("next", this._attributes.next), this.setAttribute("side", this._attributes.side), this.setAttribute("width", this._attributes.width), this.setAttribute("uv", this._attributes.uv), this.setAttribute("counters", this._attributes.counters), this.setIndex(this._attributes.index), this.computeBoundingSphere(), this.computeBoundingBox()
                }
                advance({
                    x: e,
                    y: t,
                    z: r
                }) {
                    let n = this._attributes.position.array,
                        i = this._attributes.previous.array,
                        o = this._attributes.next.array,
                        s = n.length;
                    l(n, 0, i, 0, s), l(n, 6, n, 0, s - 6), n[s - 6] = e, n[s - 5] = t, n[s - 4] = r, n[s - 3] = e, n[s - 2] = t, n[s - 1] = r, l(n, 6, o, 0, s - 6), o[s - 6] = e, o[s - 5] = t, o[s - 4] = r, o[s - 3] = e, o[s - 2] = t, o[s - 1] = r, this._attributes.position.needsUpdate = !0, this._attributes.previous.needsUpdate = !0, this._attributes.next.needsUpdate = !0
                }
            }
            let c = `
  #include <common>
  #include <logdepthbuf_pars_vertex>
  #include <fog_pars_vertex>
  #include <clipping_planes_pars_vertex>

  attribute vec3 previous;
  attribute vec3 next;
  attribute float side;
  attribute float width;
  attribute float counters;
  
  uniform vec2 resolution;
  uniform float lineWidth;
  uniform vec3 color;
  uniform float opacity;
  uniform float sizeAttenuation;
  
  varying vec2 vUV;
  varying vec4 vColor;
  varying float vCounters;
  
  vec2 fix(vec4 i, float aspect) {
    vec2 res = i.xy / i.w;
    res.x *= aspect;
    return res;
  }
  
  void main() {
    float aspect = resolution.x / resolution.y;
    vColor = vec4(color, opacity);
    vUV = uv;
    vCounters = counters;
  
    mat4 m = projectionMatrix * modelViewMatrix;
    vec4 finalPosition = m * vec4(position, 1.0) * aspect;
    vec4 prevPos = m * vec4(previous, 1.0);
    vec4 nextPos = m * vec4(next, 1.0);
  
    vec2 currentP = fix(finalPosition, aspect);
    vec2 prevP = fix(prevPos, aspect);
    vec2 nextP = fix(nextPos, aspect);
  
    float w = lineWidth * width;
  
    vec2 dir;
    if (nextP == currentP) dir = normalize(currentP - prevP);
    else if (prevP == currentP) dir = normalize(nextP - currentP);
    else {
      vec2 dir1 = normalize(currentP - prevP);
      vec2 dir2 = normalize(nextP - currentP);
      dir = normalize(dir1 + dir2);
  
      vec2 perp = vec2(-dir1.y, dir1.x);
      vec2 miter = vec2(-dir.y, dir.x);
      //w = clamp(w / dot(miter, perp), 0., 4. * lineWidth * width);
    }
  
    //vec2 normal = (cross(vec3(dir, 0.), vec3(0., 0., 1.))).xy;
    vec4 normal = vec4(-dir.y, dir.x, 0., 1.);
    normal.xy *= .5 * w;
    //normal *= projectionMatrix;
    if (sizeAttenuation == 0.) {
      normal.xy *= finalPosition.w;
      normal.xy /= (vec4(resolution, 0., 1.) * projectionMatrix).xy * aspect;
    }
  
    finalPosition.xy += normal.xy * side;
    gl_Position = finalPosition;
    #include <logdepthbuf_vertex>
    #include <fog_vertex>
    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
    #include <clipping_planes_vertex>
    #include <fog_vertex>
  }
`,
                f = parseInt(n.sPf.replace(/\D+/g, "")),
                d = `
  #include <fog_pars_fragment>
  #include <logdepthbuf_pars_fragment>
  #include <clipping_planes_pars_fragment>
  
  uniform sampler2D map;
  uniform sampler2D alphaMap;
  uniform float useGradient;
  uniform float useMap;
  uniform float useAlphaMap;
  uniform float useDash;
  uniform float dashArray;
  uniform float dashOffset;
  uniform float dashRatio;
  uniform float visibility;
  uniform float alphaTest;
  uniform vec2 repeat;
  uniform vec3 gradient[2];
  
  varying vec2 vUV;
  varying vec4 vColor;
  varying float vCounters;
  
  void main() {
    #include <logdepthbuf_fragment>
    vec4 diffuseColor = vColor;
    if (useGradient == 1.) diffuseColor = vec4(mix(gradient[0], gradient[1], vCounters), 1.0);
    if (useMap == 1.) diffuseColor *= texture2D(map, vUV * repeat);
    if (useAlphaMap == 1.) diffuseColor.a *= texture2D(alphaMap, vUV * repeat).a;
    if (diffuseColor.a < alphaTest) discard;
    if (useDash == 1.) diffuseColor.a *= ceil(mod(vCounters + dashOffset, dashArray) - (dashArray * dashRatio));
    diffuseColor.a *= step(vCounters, visibility);
    #include <clipping_planes_fragment>
    gl_FragColor = diffuseColor;     
    #include <fog_fragment>
    #include <tonemapping_fragment>
    #include <${f>=154?"colorspace_fragment":"encodings_fragment"}>
  }
`;
            class h extends n.BKk {
                constructor(e) {
                    super({
                        uniforms: { ...i.UniformsLib.fog,
                            lineWidth: {
                                value: 1
                            },
                            map: {
                                value: null
                            },
                            useMap: {
                                value: 0
                            },
                            alphaMap: {
                                value: null
                            },
                            useAlphaMap: {
                                value: 0
                            },
                            color: {
                                value: new n.Q1f(0xffffff)
                            },
                            gradient: {
                                value: [new n.Q1f(0xff0000), new n.Q1f(65280)]
                            },
                            opacity: {
                                value: 1
                            },
                            resolution: {
                                value: new n.I9Y(1, 1)
                            },
                            sizeAttenuation: {
                                value: 1
                            },
                            dashArray: {
                                value: 0
                            },
                            dashOffset: {
                                value: 0
                            },
                            dashRatio: {
                                value: .5
                            },
                            useDash: {
                                value: 0
                            },
                            useGradient: {
                                value: 0
                            },
                            visibility: {
                                value: 1
                            },
                            alphaTest: {
                                value: 0
                            },
                            repeat: {
                                value: new n.I9Y(1, 1)
                            }
                        },
                        vertexShader: c,
                        fragmentShader: d
                    }), a(this, "lineWidth"), a(this, "map"), a(this, "useMap"), a(this, "alphaMap"), a(this, "useAlphaMap"), a(this, "color"), a(this, "gradient"), a(this, "resolution"), a(this, "sizeAttenuation"), a(this, "dashArray"), a(this, "dashOffset"), a(this, "dashRatio"), a(this, "useDash"), a(this, "useGradient"), a(this, "visibility"), a(this, "repeat"), this.type = "MeshLineMaterial", Object.defineProperties(this, {
                        lineWidth: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.lineWidth.value
                            },
                            set(e) {
                                this.uniforms.lineWidth.value = e
                            }
                        },
                        map: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.map.value
                            },
                            set(e) {
                                this.uniforms.map.value = e
                            }
                        },
                        useMap: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.useMap.value
                            },
                            set(e) {
                                this.uniforms.useMap.value = e
                            }
                        },
                        alphaMap: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.alphaMap.value
                            },
                            set(e) {
                                this.uniforms.alphaMap.value = e
                            }
                        },
                        useAlphaMap: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.useAlphaMap.value
                            },
                            set(e) {
                                this.uniforms.useAlphaMap.value = e
                            }
                        },
                        color: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.color.value
                            },
                            set(e) {
                                this.uniforms.color.value = e
                            }
                        },
                        gradient: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.gradient.value
                            },
                            set(e) {
                                this.uniforms.gradient.value = e
                            }
                        },
                        opacity: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.opacity.value
                            },
                            set(e) {
                                this.uniforms.opacity.value = e
                            }
                        },
                        resolution: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.resolution.value
                            },
                            set(e) {
                                this.uniforms.resolution.value.copy(e)
                            }
                        },
                        sizeAttenuation: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.sizeAttenuation.value
                            },
                            set(e) {
                                this.uniforms.sizeAttenuation.value = e
                            }
                        },
                        dashArray: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.dashArray.value
                            },
                            set(e) {
                                this.uniforms.dashArray.value = e, this.useDash = +(0 !== e)
                            }
                        },
                        dashOffset: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.dashOffset.value
                            },
                            set(e) {
                                this.uniforms.dashOffset.value = e
                            }
                        },
                        dashRatio: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.dashRatio.value
                            },
                            set(e) {
                                this.uniforms.dashRatio.value = e
                            }
                        },
                        useDash: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.useDash.value
                            },
                            set(e) {
                                this.uniforms.useDash.value = e
                            }
                        },
                        useGradient: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.useGradient.value
                            },
                            set(e) {
                                this.uniforms.useGradient.value = e
                            }
                        },
                        visibility: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.visibility.value
                            },
                            set(e) {
                                this.uniforms.visibility.value = e
                            }
                        },
                        alphaTest: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.alphaTest.value
                            },
                            set(e) {
                                this.uniforms.alphaTest.value = e
                            }
                        },
                        repeat: {
                            enumerable: !0,
                            get() {
                                return this.uniforms.repeat.value
                            },
                            set(e) {
                                this.uniforms.repeat.value.copy(e)
                            }
                        }
                    }), this.setValues(e)
                }
                copy(e) {
                    return super.copy(e), this.lineWidth = e.lineWidth, this.map = e.map, this.useMap = e.useMap, this.alphaMap = e.alphaMap, this.useAlphaMap = e.useAlphaMap, this.color.copy(e.color), this.gradient = e.gradient, this.opacity = e.opacity, this.resolution.copy(e.resolution), this.sizeAttenuation = e.sizeAttenuation, this.dashArray = e.dashArray, this.dashOffset = e.dashOffset, this.dashRatio = e.dashRatio, this.useDash = e.useDash, this.useGradient = e.useGradient, this.visibility = e.visibility, this.alphaTest = e.alphaTest, this.repeat.copy(e.repeat), this
                }
            }
        },
        1119: (e, t) => {
            "use strict";
            t.byteLength = function(e) {
                var t = l(e),
                    r = t[0],
                    n = t[1];
                return (r + n) * 3 / 4 - n
            }, t.toByteArray = function(e) {
                var t, r, o = l(e),
                    s = o[0],
                    a = o[1],
                    u = new i((s + a) * 3 / 4 - a),
                    c = 0,
                    f = a > 0 ? s - 4 : s;
                for (r = 0; r < f; r += 4) t = n[e.charCodeAt(r)] << 18 | n[e.charCodeAt(r + 1)] << 12 | n[e.charCodeAt(r + 2)] << 6 | n[e.charCodeAt(r + 3)], u[c++] = t >> 16 & 255, u[c++] = t >> 8 & 255, u[c++] = 255 & t;
                return 2 === a && (t = n[e.charCodeAt(r)] << 2 | n[e.charCodeAt(r + 1)] >> 4, u[c++] = 255 & t), 1 === a && (t = n[e.charCodeAt(r)] << 10 | n[e.charCodeAt(r + 1)] << 4 | n[e.charCodeAt(r + 2)] >> 2, u[c++] = t >> 8 & 255, u[c++] = 255 & t), u
            }, t.fromByteArray = function(e) {
                for (var t, n = e.length, i = n % 3, o = [], s = 0, a = n - i; s < a; s += 16383) o.push(function(e, t, n) {
                    for (var i, o = [], s = t; s < n; s += 3) i = (e[s] << 16 & 0xff0000) + (e[s + 1] << 8 & 65280) + (255 & e[s + 2]), o.push(r[i >> 18 & 63] + r[i >> 12 & 63] + r[i >> 6 & 63] + r[63 & i]);
                    return o.join("")
                }(e, s, s + 16383 > a ? a : s + 16383));
                return 1 === i ? o.push(r[(t = e[n - 1]) >> 2] + r[t << 4 & 63] + "==") : 2 === i && o.push(r[(t = (e[n - 2] << 8) + e[n - 1]) >> 10] + r[t >> 4 & 63] + r[t << 2 & 63] + "="), o.join("")
            };
            for (var r = [], n = [], i = "undefined" != typeof Uint8Array ? Uint8Array : Array, o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", s = 0, a = o.length; s < a; ++s) r[s] = o[s], n[o.charCodeAt(s)] = s;

            function l(e) {
                var t = e.length;
                if (t % 4 > 0) throw Error("Invalid string. Length must be a multiple of 4");
                var r = e.indexOf("="); - 1 === r && (r = t);
                var n = r === t ? 0 : 4 - r % 4;
                return [r, n]
            }
            n[45] = 62, n[95] = 63
        },
        1305: (e, t, r) => {
            "use strict";
            e.exports = r(9581)
        },
        2087: (e, t, r) => {
            "use strict";
            r.d(t, {
                Af: () => a,
                Nz: () => i,
                u5: () => l,
                y3: () => f
            });
            var n = r(6797);

            function i(e, t, r) {
                if (!e) return;
                if (!0 === r(e)) return e;
                let n = t ? e.return : e.child;
                for (; n;) {
                    let e = i(n, t, r);
                    if (e) return e;
                    n = t ? null : n.sibling
                }
            }

            function o(e) {
                try {
                    return Object.defineProperties(e, {
                        _currentRenderer: {
                            get: () => null,
                            set() {}
                        },
                        _currentRenderer2: {
                            get: () => null,
                            set() {}
                        }
                    })
                } catch (t) {
                    return e
                }
            }(() => {
                var e, t;
                return "undefined" != typeof window && ((null == (e = window.document) ? void 0 : e.createElement) || (null == (t = window.navigator) ? void 0 : t.product) === "ReactNative")
            })() ? n.useLayoutEffect: n.useEffect;
            let s = o(n.createContext(null));
            class a extends n.Component {
                render() {
                    return n.createElement(s.Provider, {
                        value: this._reactInternals
                    }, this.props.children)
                }
            }

            function l() {
                let e = n.useContext(s);
                if (null === e) throw Error("its-fine: useFiber must be called within a <FiberProvider />!");
                let t = n.useId();
                return n.useMemo(() => {
                    for (let r of [e, null == e ? void 0 : e.alternate]) {
                        if (!r) continue;
                        let e = i(r, !1, e => {
                            let r = e.memoizedState;
                            for (; r;) {
                                if (r.memoizedState === t) return !0;
                                r = r.next
                            }
                        });
                        if (e) return e
                    }
                }, [e, t])
            }
            let u = Symbol.for("react.context"),
                c = e => null !== e && "object" == typeof e && "$$typeof" in e && e.$$typeof === u;

            function f() {
                let e = function() {
                    let e = l(),
                        [t] = n.useState(() => new Map);
                    t.clear();
                    let r = e;
                    for (; r;) {
                        let e = r.type;
                        c(e) && e !== s && !t.has(e) && t.set(e, n.use(o(e))), r = r.return
                    }
                    return t
                }();
                return n.useMemo(() => Array.from(e.keys()).reduce((t, r) => i => n.createElement(t, null, n.createElement(r.Provider, { ...i,
                    value: e.get(r)
                })), e => n.createElement(a, { ...e
                })), [e])
            }
        },
        2839: (e, t, r) => {
            "use strict";
            e.exports = r(9663)
        },
        3299: (e, t, r) => {
            "use strict";
            let n;
            r.d(t, {
                OH: () => e7
            });
            var i = r(9585),
                o = r(6797),
                s = r(8789),
                a = r(4312),
                l = r(7338);
            let u = e => e && e.isCubeTexture;
            class c extends a.eaF {
                constructor(e, t) {
                    var r, n;
                    let i = u(e),
                        o = Math.floor(Math.log2((null != (n = i ? null == (r = e.image[0]) ? void 0 : r.width : e.image.width) ? n : 1024) / 4)),
                        s = Math.pow(2, o),
                        c = 3 * Math.max(s, 112),
                        f = `
        varying vec3 vWorldPosition;
        void main() 
        {
            vec4 worldPosition = ( modelMatrix * vec4( position, 1.0 ) );
            vWorldPosition = worldPosition.xyz;
            
            gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
        }
        `,
                        d = [i ? "#define ENVMAP_TYPE_CUBE" : "", `#define CUBEUV_TEXEL_WIDTH ${1/c}`, `#define CUBEUV_TEXEL_HEIGHT ${1/(4*s)}`, `#define CUBEUV_MAX_MIP ${o}.0`].join("\n") + `
        #define ENVMAP_TYPE_CUBE_UV
        varying vec3 vWorldPosition;
        uniform float radius;
        uniform float height;
        uniform float angle;
        #ifdef ENVMAP_TYPE_CUBE
            uniform samplerCube map;
        #else
            uniform sampler2D map;
        #endif
        // From: https://www.shadertoy.com/view/4tsBD7
        float diskIntersectWithBackFaceCulling( vec3 ro, vec3 rd, vec3 c, vec3 n, float r ) 
        {
            float d = dot ( rd, n );
            
            if( d > 0.0 ) { return 1e6; }
            
            vec3  o = ro - c;
            float t = - dot( n, o ) / d;
            vec3  q = o + rd * t;
            
            return ( dot( q, q ) < r * r ) ? t : 1e6;
        }
        // From: https://www.iquilezles.org/www/articles/intersectors/intersectors.htm
        float sphereIntersect( vec3 ro, vec3 rd, vec3 ce, float ra ) 
        {
            vec3 oc = ro - ce;
            float b = dot( oc, rd );
            float c = dot( oc, oc ) - ra * ra;
            float h = b * b - c;
            
            if( h < 0.0 ) { return -1.0; }
            
            h = sqrt( h );
            
            return - b + h;
        }
        vec3 project() 
        {
            vec3 p = normalize( vWorldPosition );
            vec3 camPos = cameraPosition;
            camPos.y -= height;
            float intersection = sphereIntersect( camPos, p, vec3( 0.0 ), radius );
            if( intersection > 0.0 ) {
                
                vec3 h = vec3( 0.0, - height, 0.0 );
                float intersection2 = diskIntersectWithBackFaceCulling( camPos, p, h, vec3( 0.0, 1.0, 0.0 ), radius );
                p = ( camPos + min( intersection, intersection2 ) * p ) / radius;
            } else {
                p = vec3( 0.0, 1.0, 0.0 );
            }
            return p;
        }
        #include <common>
        #include <cube_uv_reflection_fragment>
        void main() 
        {
            vec3 projectedWorldPosition = project();
            
            #ifdef ENVMAP_TYPE_CUBE
                vec3 outcolor = textureCube( map, projectedWorldPosition ).rgb;
            #else
                vec3 direction = normalize( projectedWorldPosition );
                vec2 uv = equirectUv( direction );
                vec3 outcolor = texture2D( map, uv ).rgb;
            #endif
            gl_FragColor = vec4( outcolor, 1.0 );
            #include <tonemapping_fragment>
            #include <${l.r>=154?"colorspace_fragment":"encodings_fragment"}>
        }
        `,
                        h = {
                            map: {
                                value: e
                            },
                            height: {
                                value: (null == t ? void 0 : t.height) || 15
                            },
                            radius: {
                                value: (null == t ? void 0 : t.radius) || 100
                            }
                        };
                    super(new a.WBB(1, 16), new a.BKk({
                        uniforms: h,
                        fragmentShader: d,
                        vertexShader: f,
                        side: a.$EB
                    }))
                }
                set radius(e) {
                    this.material.uniforms.radius.value = e
                }
                get radius() {
                    return this.material.uniforms.radius.value
                }
                set height(e) {
                    this.material.uniforms.height.value = e
                }
                get height() {
                    return this.material.uniforms.height.value
                }
            }
            class f extends a.BRH {
                constructor(e) {
                    super(e), this.type = a.ix0
                }
                parse(e) {
                    let t, r, n, i = function(e, t) {
                            switch (e) {
                                case 1:
                                    throw Error("THREE.RGBELoader: Read Error: " + (t || ""));
                                case 2:
                                    throw Error("THREE.RGBELoader: Write Error: " + (t || ""));
                                case 3:
                                    throw Error("THREE.RGBELoader: Bad File Format: " + (t || ""));
                                default:
                                    throw Error("THREE.RGBELoader: Memory Error: " + (t || ""))
                            }
                        },
                        o = function(e, t, r) {
                            t = t || 1024;
                            let n = e.pos,
                                i = -1,
                                o = 0,
                                s = "",
                                a = String.fromCharCode.apply(null, new Uint16Array(e.subarray(n, n + 128)));
                            for (; 0 > (i = a.indexOf("\n")) && o < t && n < e.byteLength;) s += a, o += a.length, n += 128, a += String.fromCharCode.apply(null, new Uint16Array(e.subarray(n, n + 128)));
                            return -1 < i && (!1 !== r && (e.pos += o + i + 1), s + a.slice(0, i))
                        },
                        s = new Uint8Array(e);
                    s.pos = 0;
                    let l = function(e) {
                            let t, r, n = /^\s*GAMMA\s*=\s*(\d+(\.\d+)?)\s*$/,
                                s = /^\s*EXPOSURE\s*=\s*(\d+(\.\d+)?)\s*$/,
                                a = /^\s*FORMAT=(\S+)\s*$/,
                                l = /^\s*\-Y\s+(\d+)\s+\+X\s+(\d+)\s*$/,
                                u = {
                                    valid: 0,
                                    string: "",
                                    comments: "",
                                    programtype: "RGBE",
                                    format: "",
                                    gamma: 1,
                                    exposure: 1,
                                    width: 0,
                                    height: 0
                                };
                            for (!(e.pos >= e.byteLength) && (t = o(e)) || i(1, "no header found"), (r = t.match(/^#\?(\S+)/)) || i(3, "bad initial token"), u.valid |= 1, u.programtype = r[1], u.string += t + "\n"; !1 !== (t = o(e));) {
                                if (u.string += t + "\n", "#" === t.charAt(0)) {
                                    u.comments += t + "\n";
                                    continue
                                }
                                if ((r = t.match(n)) && (u.gamma = parseFloat(r[1])), (r = t.match(s)) && (u.exposure = parseFloat(r[1])), (r = t.match(a)) && (u.valid |= 2, u.format = r[1]), (r = t.match(l)) && (u.valid |= 4, u.height = parseInt(r[1], 10), u.width = parseInt(r[2], 10)), 2 & u.valid && 4 & u.valid) break
                            }
                            return 2 & u.valid || i(3, "missing format specifier"), 4 & u.valid || i(3, "missing image size specifier"), u
                        }(s),
                        u = l.width,
                        c = l.height,
                        f = function(e, t, r) {
                            if (t < 8 || t > 32767 || 2 !== e[0] || 2 !== e[1] || 128 & e[2]) return new Uint8Array(e);
                            t !== (e[2] << 8 | e[3]) && i(3, "wrong scanline width");
                            let n = new Uint8Array(4 * t * r);
                            n.length || i(4, "unable to allocate buffer space");
                            let o = 0,
                                s = 0,
                                a = 4 * t,
                                l = new Uint8Array(4),
                                u = new Uint8Array(a),
                                c = r;
                            for (; c > 0 && s < e.byteLength;) {
                                s + 4 > e.byteLength && i(1), l[0] = e[s++], l[1] = e[s++], l[2] = e[s++], l[3] = e[s++], (2 != l[0] || 2 != l[1] || (l[2] << 8 | l[3]) != t) && i(3, "bad rgbe scanline format");
                                let r = 0,
                                    f;
                                for (; r < a && s < e.byteLength;) {
                                    let t = (f = e[s++]) > 128;
                                    if (t && (f -= 128), (0 === f || r + f > a) && i(3, "bad scanline data"), t) {
                                        let t = e[s++];
                                        for (let e = 0; e < f; e++) u[r++] = t
                                    } else u.set(e.subarray(s, s + f), r), r += f, s += f
                                }
                                for (let e = 0; e < t; e++) {
                                    let r = 0;
                                    n[o] = u[e + r], r += t, n[o + 1] = u[e + r], r += t, n[o + 2] = u[e + r], r += t, n[o + 3] = u[e + r], o += 4
                                }
                                c--
                            }
                            return n
                        }(s.subarray(s.pos), u, c);
                    switch (this.type) {
                        case a.RQf:
                            let d = new Float32Array(4 * (n = f.length / 4));
                            for (let e = 0; e < n; e++) ! function(e, t, r, n) {
                                let i = Math.pow(2, e[t + 3] - 128) / 255;
                                r[n + 0] = e[t + 0] * i, r[n + 1] = e[t + 1] * i, r[n + 2] = e[t + 2] * i, r[n + 3] = 1
                            }(f, 4 * e, d, 4 * e);
                            t = d, r = a.RQf;
                            break;
                        case a.ix0:
                            let h = new Uint16Array(4 * (n = f.length / 4));
                            for (let e = 0; e < n; e++) ! function(e, t, r, n) {
                                let i = Math.pow(2, e[t + 3] - 128) / 255;
                                r[n + 0] = a.GxU.toHalfFloat(Math.min(e[t + 0] * i, 65504)), r[n + 1] = a.GxU.toHalfFloat(Math.min(e[t + 1] * i, 65504)), r[n + 2] = a.GxU.toHalfFloat(Math.min(e[t + 2] * i, 65504)), r[n + 3] = a.GxU.toHalfFloat(1)
                            }(f, 4 * e, h, 4 * e);
                            t = h, r = a.ix0;
                            break;
                        default:
                            throw Error("THREE.RGBELoader: Unsupported type: " + this.type)
                    }
                    return {
                        width: u,
                        height: c,
                        data: t,
                        header: l.string,
                        gamma: l.gamma,
                        exposure: l.exposure,
                        type: r
                    }
                }
                setDataType(e) {
                    return this.type = e, this
                }
                load(e, t, r, n) {
                    return super.load(e, function(e, r) {
                        switch (e.type) {
                            case a.RQf:
                            case a.ix0:
                                "colorSpace" in e ? e.colorSpace = "srgb-linear" : e.encoding = 3e3, e.minFilter = a.k6q, e.magFilter = a.k6q, e.generateMipmaps = !1, e.flipY = !0
                        }
                        t && t(e, r)
                    }, r, n)
                }
            }
            var d = {},
                h = function(e, t, r, n, i) {
                    var o = new Worker(d[t] || (d[t] = URL.createObjectURL(new Blob([e], {
                        type: "text/javascript"
                    }))));
                    return o.onerror = function(e) {
                        return i(e.error, null)
                    }, o.onmessage = function(e) {
                        return i(null, e.data)
                    }, o.postMessage(r, n), o
                },
                p = Uint8Array,
                A = Uint16Array,
                m = Uint32Array,
                g = new p([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0]),
                B = new p([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0]),
                v = new p([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
                y = function(e, t) {
                    for (var r = new A(31), n = 0; n < 31; ++n) r[n] = t += 1 << e[n - 1];
                    for (var i = new m(r[30]), n = 1; n < 30; ++n)
                        for (var o = r[n]; o < r[n + 1]; ++o) i[o] = o - r[n] << 5 | n;
                    return [r, i]
                },
                C = y(g, 2),
                b = C[0],
                E = C[1];
            b[28] = 258, E[258] = 28;
            for (var w = y(B, 0), M = w[0], R = w[1], F = new A(32768), x = 0; x < 32768; ++x) {
                var I = (43690 & x) >>> 1 | (21845 & x) << 1;
                I = (61680 & (I = (52428 & I) >>> 2 | (13107 & I) << 2)) >>> 4 | (3855 & I) << 4, F[x] = ((65280 & I) >>> 8 | (255 & I) << 8) >>> 1
            }
            for (var T = function(e, t, r) {
                    for (var n, i = e.length, o = 0, s = new A(t); o < i; ++o) ++s[e[o] - 1];
                    var a = new A(t);
                    for (o = 0; o < t; ++o) a[o] = a[o - 1] + s[o - 1] << 1;
                    if (r) {
                        n = new A(1 << t);
                        var l = 15 - t;
                        for (o = 0; o < i; ++o)
                            if (e[o])
                                for (var u = o << 4 | e[o], c = t - e[o], f = a[e[o] - 1]++ << c, d = f | (1 << c) - 1; f <= d; ++f) n[F[f] >>> l] = u
                    } else
                        for (o = 0, n = new A(i); o < i; ++o) e[o] && (n[o] = F[a[e[o] - 1]++] >>> 15 - e[o]);
                    return n
                }, S = new p(288), x = 0; x < 144; ++x) S[x] = 8;
            for (var x = 144; x < 256; ++x) S[x] = 9;
            for (var x = 256; x < 280; ++x) S[x] = 7;
            for (var x = 280; x < 288; ++x) S[x] = 8;
            for (var D = new p(32), x = 0; x < 32; ++x) D[x] = 5;
            var O = T(S, 9, 1),
                G = T(D, 5, 1),
                P = function(e) {
                    for (var t = e[0], r = 1; r < e.length; ++r) e[r] > t && (t = e[r]);
                    return t
                },
                H = function(e, t, r) {
                    var n = t / 8 | 0;
                    return (e[n] | e[n + 1] << 8) >> (7 & t) & r
                },
                U = function(e, t) {
                    var r = t / 8 | 0;
                    return (e[r] | e[r + 1] << 8 | e[r + 2] << 16) >> (7 & t)
                },
                _ = function(e) {
                    return (e / 8 | 0) + (7 & e && 1)
                },
                L = function(e, t, r) {
                    (null == t || t < 0) && (t = 0), (null == r || r > e.length) && (r = e.length);
                    var n = new(e instanceof A ? A : e instanceof m ? m : p)(r - t);
                    return n.set(e.subarray(t, r)), n
                },
                J = function(e, t, r) {
                    var n = e.length;
                    if (!n || r && !r.l && n < 5) return t || new p(0);
                    var i = !t || r,
                        o = !r || r.i;
                    r || (r = {}), t || (t = new p(3 * n));
                    var s = function(e) {
                            var r = t.length;
                            if (e > r) {
                                var n = new p(Math.max(2 * r, e));
                                n.set(t), t = n
                            }
                        },
                        a = r.f || 0,
                        l = r.p || 0,
                        u = r.b || 0,
                        c = r.l,
                        f = r.d,
                        d = r.m,
                        h = r.n,
                        A = 8 * n;
                    do {
                        if (!c) {
                            r.f = a = H(e, l, 1);
                            var m = H(e, l + 1, 3);
                            if (l += 3, m)
                                if (1 == m) c = O, f = G, d = 9, h = 5;
                                else if (2 == m) {
                                var y = H(e, l, 31) + 257,
                                    C = H(e, l + 10, 15) + 4,
                                    E = y + H(e, l + 5, 31) + 1;
                                l += 14;
                                for (var w = new p(E), R = new p(19), F = 0; F < C; ++F) R[v[F]] = H(e, l + 3 * F, 7);
                                l += 3 * C;
                                for (var x = P(R), I = (1 << x) - 1, S = T(R, x, 1), F = 0; F < E;) {
                                    var D = S[H(e, l, I)];
                                    l += 15 & D;
                                    var J = D >>> 4;
                                    if (J < 16) w[F++] = J;
                                    else {
                                        var j = 0,
                                            k = 0;
                                        for (16 == J ? (k = 3 + H(e, l, 3), l += 2, j = w[F - 1]) : 17 == J ? (k = 3 + H(e, l, 7), l += 3) : 18 == J && (k = 11 + H(e, l, 127), l += 7); k--;) w[F++] = j
                                    }
                                }
                                var N = w.subarray(0, y),
                                    K = w.subarray(y);
                                d = P(N), h = P(K), c = T(N, d, 1), f = T(K, h, 1)
                            } else throw "invalid block type";
                            else {
                                var J = _(l) + 4,
                                    Q = e[J - 4] | e[J - 3] << 8,
                                    X = J + Q;
                                if (X > n) {
                                    if (o) throw "unexpected EOF";
                                    break
                                }
                                i && s(u + Q), t.set(e.subarray(J, X), u), r.b = u += Q, r.p = l = 8 * X;
                                continue
                            }
                            if (l > A) {
                                if (o) throw "unexpected EOF";
                                break
                            }
                        }
                        i && s(u + 131072);
                        for (var Y = (1 << d) - 1, W = (1 << h) - 1, z = l;; z = l) {
                            var j = c[U(e, l) & Y],
                                q = j >>> 4;
                            if ((l += 15 & j) > A) {
                                if (o) throw "unexpected EOF";
                                break
                            }
                            if (!j) throw "invalid length/literal";
                            if (q < 256) t[u++] = q;
                            else if (256 == q) {
                                z = l, c = null;
                                break
                            } else {
                                var Z = q - 254;
                                if (q > 264) {
                                    var F = q - 257,
                                        V = g[F];
                                    Z = H(e, l, (1 << V) - 1) + b[F], l += V
                                }
                                var $ = f[U(e, l) & W],
                                    ee = $ >>> 4;
                                if (!$) throw "invalid distance";
                                l += 15 & $;
                                var K = M[ee];
                                if (ee > 3) {
                                    var V = B[ee];
                                    K += U(e, l) & (1 << V) - 1, l += V
                                }
                                if (l > A) {
                                    if (o) throw "unexpected EOF";
                                    break
                                }
                                i && s(u + 131072);
                                for (var et = u + Z; u < et; u += 4) t[u] = t[u - K], t[u + 1] = t[u + 1 - K], t[u + 2] = t[u + 2 - K], t[u + 3] = t[u + 3 - K];
                                u = et
                            }
                        }
                        r.l = c, r.p = z, r.b = u, c && (a = 1, r.m = d, r.d = f, r.n = h)
                    } while (!a);
                    return u == t.length ? t : L(t, 0, u)
                },
                j = function(e, t, r) {
                    r <<= 7 & t;
                    var n = t / 8 | 0;
                    e[n] |= r, e[n + 1] |= r >>> 8
                },
                k = function(e, t, r) {
                    r <<= 7 & t;
                    var n = t / 8 | 0;
                    e[n] |= r, e[n + 1] |= r >>> 8, e[n + 2] |= r >>> 16
                },
                N = function(e, t) {
                    for (var r = [], n = 0; n < e.length; ++n) e[n] && r.push({
                        s: n,
                        f: e[n]
                    });
                    var i = r.length,
                        o = r.slice();
                    if (!i) return [q, 0];
                    if (1 == i) {
                        var s = new p(r[0].s + 1);
                        return s[r[0].s] = 1, [s, 1]
                    }
                    r.sort(function(e, t) {
                        return e.f - t.f
                    }), r.push({
                        s: -1,
                        f: 25001
                    });
                    var a = r[0],
                        l = r[1],
                        u = 0,
                        c = 1,
                        f = 2;
                    for (r[0] = {
                            s: -1,
                            f: a.f + l.f,
                            l: a,
                            r: l
                        }; c != i - 1;) a = r[r[u].f < r[f].f ? u++ : f++], l = r[u != c && r[u].f < r[f].f ? u++ : f++], r[c++] = {
                        s: -1,
                        f: a.f + l.f,
                        l: a,
                        r: l
                    };
                    for (var d = o[0].s, n = 1; n < i; ++n) o[n].s > d && (d = o[n].s);
                    var h = new A(d + 1),
                        m = K(r[c - 1], h, 0);
                    if (m > t) {
                        var n = 0,
                            g = 0,
                            B = m - t,
                            v = 1 << B;
                        for (o.sort(function(e, t) {
                                return h[t.s] - h[e.s] || e.f - t.f
                            }); n < i; ++n) {
                            var y = o[n].s;
                            if (h[y] > t) g += v - (1 << m - h[y]), h[y] = t;
                            else break
                        }
                        for (g >>>= B; g > 0;) {
                            var C = o[n].s;
                            h[C] < t ? g -= 1 << t - h[C]++ - 1 : ++n
                        }
                        for (; n >= 0 && g; --n) {
                            var b = o[n].s;
                            h[b] == t && (--h[b], ++g)
                        }
                        m = t
                    }
                    return [new p(h), m]
                },
                K = function(e, t, r) {
                    return -1 == e.s ? Math.max(K(e.l, t, r + 1), K(e.r, t, r + 1)) : t[e.s] = r
                },
                Q = function(e) {
                    for (var t = e.length; t && !e[--t];);
                    for (var r = new A(++t), n = 0, i = e[0], o = 1, s = function(e) {
                            r[n++] = e
                        }, a = 1; a <= t; ++a)
                        if (e[a] == i && a != t) ++o;
                        else {
                            if (!i && o > 2) {
                                for (; o > 138; o -= 138) s(32754);
                                o > 2 && (s(o > 10 ? o - 11 << 5 | 28690 : o - 3 << 5 | 12305), o = 0)
                            } else if (o > 3) {
                                for (s(i), --o; o > 6; o -= 6) s(8304);
                                o > 2 && (s(o - 3 << 5 | 8208), o = 0)
                            }
                            for (; o--;) s(i);
                            o = 1, i = e[a]
                        }
                    return [r.subarray(0, n), t]
                },
                X = function(e, t) {
                    for (var r = 0, n = 0; n < t.length; ++n) r += e[n] * t[n];
                    return r
                },
                Y = function(e, t, r) {
                    var n = r.length,
                        i = _(t + 2);
                    e[i] = 255 & n, e[i + 1] = n >>> 8, e[i + 2] = 255 ^ e[i], e[i + 3] = 255 ^ e[i + 1];
                    for (var o = 0; o < n; ++o) e[i + o + 4] = r[o];
                    return (i + 4 + n) * 8
                },
                W = function(e, t, r, n, i, o, s, a, l, u, c) {
                    j(t, c++, r), ++i[256];
                    for (var f, d, h, p, m = N(i, 15), y = m[0], C = m[1], b = N(o, 15), E = b[0], w = b[1], M = Q(y), R = M[0], F = M[1], x = Q(E), I = x[0], O = x[1], G = new A(19), P = 0; P < R.length; ++P) G[31 & R[P]]++;
                    for (var P = 0; P < I.length; ++P) G[31 & I[P]]++;
                    for (var H = N(G, 7), U = H[0], _ = H[1], L = 19; L > 4 && !U[v[L - 1]]; --L);
                    var J = u + 5 << 3,
                        K = X(i, S) + X(o, D) + s,
                        W = X(i, y) + X(o, E) + s + 14 + 3 * L + X(G, U) + (2 * G[16] + 3 * G[17] + 7 * G[18]);
                    if (J <= K && J <= W) return Y(t, c, e.subarray(l, l + u));
                    if (j(t, c, 1 + (W < K)), c += 2, W < K) {
                        f = T(y, C, 0), d = y, h = T(E, w, 0), p = E;
                        var z = T(U, _, 0);
                        j(t, c, F - 257), j(t, c + 5, O - 1), j(t, c + 10, L - 4), c += 14;
                        for (var P = 0; P < L; ++P) j(t, c + 3 * P, U[v[P]]);
                        c += 3 * L;
                        for (var q = [R, I], Z = 0; Z < 2; ++Z)
                            for (var V = q[Z], P = 0; P < V.length; ++P) {
                                var $ = 31 & V[P];
                                j(t, c, z[$]), c += U[$], $ > 15 && (j(t, c, V[P] >>> 5 & 127), c += V[P] >>> 12)
                            }
                    } else f = null, d = S, h = null, p = D;
                    for (var P = 0; P < a; ++P)
                        if (n[P] > 255) {
                            var $ = n[P] >>> 18 & 31;
                            k(t, c, f[$ + 257]), c += d[$ + 257], $ > 7 && (j(t, c, n[P] >>> 23 & 31), c += g[$]);
                            var ee = 31 & n[P];
                            k(t, c, h[ee]), c += p[ee], ee > 3 && (k(t, c, n[P] >>> 5 & 8191), c += B[ee])
                        } else k(t, c, f[n[P]]), c += d[n[P]];
                    return k(t, c, f[256]), c + d[256]
                },
                z = new m([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]),
                q = new p(0),
                Z = function(e, t, r, n, i, o) {
                    var s = e.length,
                        a = new p(n + s + 5 * (1 + Math.ceil(s / 7e3)) + i),
                        l = a.subarray(n, a.length - i),
                        u = 0;
                    if (!t || s < 8)
                        for (var c = 0; c <= s; c += 65535) {
                            var f = c + 65535;
                            f < s ? u = Y(l, u, e.subarray(c, f)) : (l[c] = o, u = Y(l, u, e.subarray(c, s)))
                        } else {
                            for (var d = z[t - 1], h = d >>> 13, v = 8191 & d, y = (1 << r) - 1, C = new A(32768), b = new A(y + 1), w = Math.ceil(r / 3), M = 2 * w, F = function(t) {
                                    return (e[t] ^ e[t + 1] << w ^ e[t + 2] << M) & y
                                }, x = new m(25e3), I = new A(288), T = new A(32), S = 0, D = 0, c = 0, O = 0, G = 0, P = 0; c < s; ++c) {
                                var H = F(c),
                                    U = 32767 & c,
                                    J = b[H];
                                if (C[U] = J, b[H] = U, G <= c) {
                                    var j = s - c;
                                    if ((S > 7e3 || O > 24576) && j > 423) {
                                        u = W(e, l, 0, x, I, T, D, O, P, c - P, u), O = S = D = 0, P = c;
                                        for (var k = 0; k < 286; ++k) I[k] = 0;
                                        for (var k = 0; k < 30; ++k) T[k] = 0
                                    }
                                    var N = 2,
                                        K = 0,
                                        Q = v,
                                        X = U - J & 32767;
                                    if (j > 2 && H == F(c - X))
                                        for (var Z = Math.min(h, j) - 1, V = Math.min(32767, c), $ = Math.min(258, j); X <= V && --Q && U != J;) {
                                            if (e[c + N] == e[c + N - X]) {
                                                for (var ee = 0; ee < $ && e[c + ee] == e[c + ee - X]; ++ee);
                                                if (ee > N) {
                                                    if (N = ee, K = X, ee > Z) break;
                                                    for (var et = Math.min(X, ee - 2), er = 0, k = 0; k < et; ++k) {
                                                        var en = c - X + k + 32768 & 32767,
                                                            ei = C[en],
                                                            eo = en - ei + 32768 & 32767;
                                                        eo > er && (er = eo, J = en)
                                                    }
                                                }
                                            }
                                            J = C[U = J], X += U - J + 32768 & 32767
                                        }
                                    if (K) {
                                        x[O++] = 0x10000000 | E[N] << 18 | R[K];
                                        var es = 31 & E[N],
                                            ea = 31 & R[K];
                                        D += g[es] + B[ea], ++I[257 + es], ++T[ea], G = c + N, ++S
                                    } else x[O++] = e[c], ++I[e[c]]
                                }
                            }
                            u = W(e, l, o, x, I, T, D, O, P, c - P, u), !o && 7 & u && (u = Y(l, u + 1, q))
                        }
                    return L(a, 0, n + _(u) + i)
                },
                V = function() {
                    var e = -1;
                    return {
                        p: function(t) {
                            for (var r = e, n = 0; n < t.length; ++n) r = null[255 & r ^ t[n]] ^ r >>> 8;
                            e = r
                        },
                        d: function() {
                            return ~e
                        }
                    }
                },
                $ = function() {
                    var e = 1,
                        t = 0;
                    return {
                        p: function(r) {
                            for (var n = e, i = t, o = r.length, s = 0; s != o;) {
                                for (var a = Math.min(s + 2655, o); s < a; ++s) i += n += r[s];
                                n = (65535 & n) + 15 * (n >> 16), i = (65535 & i) + 15 * (i >> 16)
                            }
                            e = n, t = i
                        },
                        d: function() {
                            return e %= 65521, t %= 65521, (255 & e) << 24 | e >>> 8 << 16 | (255 & t) << 8 | t >>> 8
                        }
                    }
                },
                ee = function(e, t, r, n, i) {
                    return Z(e, null == t.level ? 6 : t.level, null == t.mem ? Math.ceil(1.5 * Math.max(8, Math.min(13, Math.log(e.length)))) : 12 + t.mem, r, n, !i)
                },
                et = function(e, t) {
                    var r = {};
                    for (var n in e) r[n] = e[n];
                    for (var n in t) r[n] = t[n];
                    return r
                },
                er = function(e, t, r) {
                    for (var n = e(), i = e.toString(), o = i.slice(i.indexOf("[") + 1, i.lastIndexOf("]")).replace(/ /g, "").split(","), s = 0; s < n.length; ++s) {
                        var a = n[s],
                            l = o[s];
                        if ("function" == typeof a) {
                            t += ";" + l + "=";
                            var u = a.toString();
                            if (a.prototype)
                                if (-1 != u.indexOf("[native code]")) {
                                    var c = u.indexOf(" ", 8) + 1;
                                    t += u.slice(c, u.indexOf("(", c))
                                } else
                                    for (var f in t += u, a.prototype) t += ";" + l + ".prototype." + f + "=" + a.prototype[f].toString();
                            else t += u
                        } else r[l] = a
                    }
                    return [t, r]
                },
                en = function(e) {
                    var t = [];
                    for (var r in e)(e[r] instanceof p || e[r] instanceof A || e[r] instanceof m) && t.push((e[r] = new e[r].constructor(e[r])).buffer);
                    return t
                },
                ei = function(e, t, r, n) {
                    if (!null[r]) {
                        for (var i, o = "", s = {}, a = e.length - 1, l = 0; l < a; ++l) o = (i = er(e[l], o, s))[0], s = i[1];
                        null[r] = er(e[a], o, s)
                    }
                    var u = et({}, null[r][1]);
                    return h(null[r][0] + ";onmessage=function(e){for(var k in e.data)self[k]=e.data[k];onmessage=" + t.toString() + "}", r, u, en(u), n)
                },
                eo = function() {
                    return [p, A, m, g, B, v, b, M, O, G, F, T, P, H, U, _, L, J, ey, es, ea]
                },
                es = function(e) {
                    return postMessage(e, [e.buffer])
                },
                ea = function(e) {
                    return e && e.size && new p(e.size)
                },
                el = function(e, t, r, n, i, o) {
                    var s = ei(r, n, i, function(e, t) {
                        s.terminate(), o(e, t)
                    });
                    return s.postMessage([e, t], t.consume ? [e.buffer] : []),
                        function() {
                            s.terminate()
                        }
                },
                eu = function(e, t) {
                    return e[t] | e[t + 1] << 8
                },
                ec = function(e, t) {
                    return (e[t] | e[t + 1] << 8 | e[t + 2] << 16 | e[t + 3] << 24) >>> 0
                },
                ef = function(e, t) {
                    return ec(e, t) + 0x100000000 * ec(e, t + 4)
                },
                ed = function(e, t, r) {
                    for (; r; ++t) e[t] = r, r >>>= 8
                },
                eh = function(e, t) {
                    var r = t.filename;
                    if (e[0] = 31, e[1] = 139, e[2] = 8, e[8] = t.level < 2 ? 4 : 2 * (9 == t.level), e[9] = 3, 0 != t.mtime && ed(e, 4, Math.floor(new Date(t.mtime || Date.now()) / 1e3)), r) {
                        e[3] = 8;
                        for (var n = 0; n <= r.length; ++n) e[n + 10] = r.charCodeAt(n)
                    }
                },
                ep = function(e) {
                    if (31 != e[0] || 139 != e[1] || 8 != e[2]) throw "invalid gzip data";
                    var t = e[3],
                        r = 10;
                    4 & t && (r += e[10] | (e[11] << 8) + 2);
                    for (var n = (t >> 3 & 1) + (t >> 4 & 1); n > 0; n -= !e[r++]);
                    return r + (2 & t)
                },
                eA = function(e) {
                    var t = e.length;
                    return (e[t - 4] | e[t - 3] << 8 | e[t - 2] << 16 | e[t - 1] << 24) >>> 0
                },
                em = function(e) {
                    return 10 + (e.filename && e.filename.length + 1 || 0)
                },
                eg = function(e, t) {
                    var r = t.level,
                        n = 0 == r ? 0 : r < 6 ? 1 : 9 == r ? 3 : 2;
                    e[0] = 120, e[1] = n << 6 | (n ? 32 - 2 * n : 1)
                },
                eB = function(e) {
                    if ((15 & e[0]) != 8 || e[0] >>> 4 > 7 || (e[0] << 8 | e[1]) % 31) throw "invalid zlib data";
                    if (32 & e[1]) throw "invalid zlib data: preset dictionaries not supported"
                };

            function ev(e, t) {
                return ee(e, t || {}, 0, 0)
            }

            function ey(e, t) {
                return J(e, t)
            }

            function eC(e, t) {
                return J((eB(e), e.subarray(2, -4)), t)
            }
            var eb = "undefined" != typeof TextEncoder && new TextEncoder,
                eE = "undefined" != typeof TextDecoder && new TextDecoder;
            try {
                eE.decode(q, {
                    stream: !0
                })
            } catch (e) {}
            var ew = function(e) {
                    for (var t = "", r = 0;;) {
                        var n = e[r++],
                            i = (n > 127) + (n > 223) + (n > 239);
                        if (r + i > e.length) return [t, L(e, r - 1)];
                        i ? 3 == i ? t += String.fromCharCode(55296 | (n = ((15 & n) << 18 | (63 & e[r++]) << 12 | (63 & e[r++]) << 6 | 63 & e[r++]) - 65536) >> 10, 56320 | 1023 & n) : 1 & i ? t += String.fromCharCode((31 & n) << 6 | 63 & e[r++]) : t += String.fromCharCode((15 & n) << 12 | (63 & e[r++]) << 6 | 63 & e[r++]) : t += String.fromCharCode(n)
                    }
                },
                eM = function(e, t) {
                    for (; 1 != eu(e, t); t += 4 + eu(e, t + 2));
                    return [ef(e, t + 12), ef(e, t + 4), ef(e, t + 20)]
                },
                eR = function(e) {
                    var t = 0;
                    if (e)
                        for (var r in e) {
                            var n = e[r].length;
                            if (n > 65535) throw "extra field too long";
                            t += n + 4
                        }
                    return t
                };
            let eF = l.r >= 152;
            class ex extends a.BRH {
                constructor(e) {
                    super(e), this.type = a.ix0
                }
                parse(e) {
                    let t = {
                        l: 0,
                        c: 0,
                        lc: 0
                    };

                    function r(e, r, n, i, o) {
                        for (; n < e;) r = r << 8 | R(i, o), n += 8;
                        t.l = r >> (n -= e) & (1 << e) - 1, t.c = r, t.lc = n
                    }
                    let n = Array(59),
                        i = {
                            c: 0,
                            lc: 0
                        };

                    function o(e, t, r, n) {
                        e = e << 8 | R(r, n), t += 8, i.c = e, i.lc = t
                    }
                    let s = {
                        c: 0,
                        lc: 0
                    };

                    function l(e, t, r, n, a, l, u, c, f, d) {
                        if (e == t) {
                            n < 8 && (o(r, n, a, u), r = i.c, n = i.lc);
                            var h = r >> (n -= 8),
                                h = new Uint8Array([h])[0];
                            if (f.value + h > d) return !1;
                            for (var p = c[f.value - 1]; h-- > 0;) c[f.value++] = p
                        } else {
                            if (!(f.value < d)) return !1;
                            c[f.value++] = e
                        }
                        s.c = r, s.lc = n
                    }

                    function u(e) {
                        var t = 65535 & e;
                        return t > 32767 ? t - 65536 : t
                    }
                    let c = {
                        a: 0,
                        b: 0
                    };

                    function f(e, t) {
                        var r = u(e),
                            n = u(t),
                            i = r + (1 & n) + (n >> 1),
                            o = i - n;
                        c.a = i, c.b = o
                    }

                    function d(e, t) {
                        var r = 65535 & t,
                            n = (65535 & e) - (r >> 1) & 65535;
                        c.a = r + n - 32768 & 65535, c.b = n
                    }

                    function h(e, a, u, c, f, d) {
                        var h = u.value,
                            p = M(a, u),
                            A = M(a, u);
                        u.value += 4;
                        var m = M(a, u);
                        if (u.value += 4, p < 0 || p >= 65537 || A < 0 || A >= 65537) throw "Something wrong with HUF_ENCSIZE";
                        for (var g = Array(65537), B = Array(16384), v = 0; v < 16384; v++) B[v] = {}, B[v].len = 0, B[v].lit = 0, B[v].p = null;
                        var y = c - (u.value - h);
                        if (! function(e, i, o, s, a, l, u) {
                                for (var c = 0, f = 0; a <= l; a++) {
                                    if (o.value - o.value > s) return !1;
                                    r(6, c, f, e, o);
                                    var d = t.l;
                                    if (c = t.c, f = t.lc, u[a] = d, 63 == d) {
                                        if (o.value - o.value > s) throw "Something wrong with hufUnpackEncTable";
                                        r(8, c, f, e, o);
                                        var h = t.l + 6;
                                        if (c = t.c, f = t.lc, a + h > l + 1) throw "Something wrong with hufUnpackEncTable";
                                        for (; h--;) u[a++] = 0;
                                        a--
                                    } else if (d >= 59) {
                                        var h = d - 59 + 2;
                                        if (a + h > l + 1) throw "Something wrong with hufUnpackEncTable";
                                        for (; h--;) u[a++] = 0;
                                        a--
                                    }
                                }! function(e) {
                                    for (var t = 0; t <= 58; ++t) n[t] = 0;
                                    for (var t = 0; t < 65537; ++t) n[e[t]] += 1;
                                    for (var r = 0, t = 58; t > 0; --t) {
                                        var i = r + n[t] >> 1;
                                        n[t] = r, r = i
                                    }
                                    for (var t = 0; t < 65537; ++t) {
                                        var o = e[t];
                                        o > 0 && (e[t] = o | n[o]++ << 6)
                                    }
                                }(u)
                            }(e, 0, u, y, p, A, g), m > 8 * (c - (u.value - h))) throw "Something wrong with hufUncompress";
                        ! function(e, t, r, n) {
                            for (; t <= r; t++) {
                                var i = e[t] >> 6,
                                    o = 63 & e[t];
                                if (i >> o) throw "Invalid table entry";
                                if (o > 14) {
                                    var s = n[i >> o - 14];
                                    if (s.len) throw "Invalid table entry";
                                    if (s.lit++, s.p) {
                                        var a = s.p;
                                        s.p = Array(s.lit);
                                        for (var l = 0; l < s.lit - 1; ++l) s.p[l] = a[l]
                                    } else s.p = [, ];
                                    s.p[s.lit - 1] = t
                                } else if (o)
                                    for (var u = 0, l = 1 << 14 - o; l > 0; l--) {
                                        var s = n[(i << 14 - o) + u];
                                        if (s.len || s.p) throw "Invalid table entry";
                                        s.len = o, s.lit = t, u++
                                    }
                            }
                        }(g, p, A, B),
                        function(e, t, r, n, a, u, c, f, d, h) {
                            for (var p = 0, A = 0, m = Math.trunc(a.value + (u + 7) / 8); a.value < m;)
                                for (o(p, A, r, a), p = i.c, A = i.lc; A >= 14;) {
                                    var g = t[p >> A - 14 & 16383];
                                    if (g.len) A -= g.len, l(g.lit, c, p, A, r, n, a, d, h, f), p = s.c, A = s.lc;
                                    else {
                                        if (!g.p) throw "hufDecode issues";
                                        for (B = 0; B < g.lit; B++) {
                                            for (var B, v = 63 & e[g.p[B]]; A < v && a.value < m;) o(p, A, r, a), p = i.c, A = i.lc;
                                            if (A >= v && e[g.p[B]] >> 6 == (p >> A - v & (1 << v) - 1)) {
                                                A -= v, l(g.p[B], c, p, A, r, n, a, d, h, f), p = s.c, A = s.lc;
                                                break
                                            }
                                        }
                                        if (B == g.lit) throw "hufDecode issues"
                                    }
                                }
                            var y = 8 - u & 7;
                            for (p >>= y, A -= y; A > 0;) {
                                var g = t[p << 14 - A & 16383];
                                if (g.len) A -= g.len, l(g.lit, c, p, A, r, n, a, d, h, f), p = s.c, A = s.lc;
                                else throw "hufDecode issues"
                            }
                        }(g, B, e, a, u, m, A, d, f, {
                            value: 0
                        })
                    }

                    function p(e) {
                        for (var t = 1; t < e.length; t++) {
                            var r = e[t - 1] + e[t] - 128;
                            e[t] = r
                        }
                    }

                    function A(e, t) {
                        for (var r = 0, n = Math.floor((e.length + 1) / 2), i = 0, o = e.length - 1; !(i > o) && (t[i++] = e[r++], !(i > o));) {;
                            t[i++] = e[n++]
                        }
                    }

                    function m(e) {
                        for (var t = e.byteLength, r = [], n = 0, i = new DataView(e); t > 0;) {
                            var o = i.getInt8(n++);
                            if (o < 0) {
                                var s = -o;
                                t -= s + 1;
                                for (var a = 0; a < s; a++) r.push(i.getUint8(n++))
                            } else {
                                var s = o;
                                t -= 2;
                                for (var l = i.getUint8(n++), a = 0; a < s + 1; a++) r.push(l)
                            }
                        }
                        return r
                    }

                    function g(e) {
                        return new DataView(e.array.buffer, e.offset.value, e.size)
                    }

                    function B(e) {
                        var t = new Uint8Array(m(e.viewer.buffer.slice(e.offset.value, e.offset.value + e.size))),
                            r = new Uint8Array(t.length);
                        return p(t), A(t, r), new DataView(r.buffer)
                    }

                    function v(e) {
                        var t = eC(e.array.slice(e.offset.value, e.offset.value + e.size)),
                            r = new Uint8Array(t.length);
                        return p(t), A(t, r), new DataView(r.buffer)
                    }

                    function y(e) {
                        for (var t = e.viewer, r = {
                                value: e.offset.value
                            }, n = new Uint16Array(e.width * e.scanlineBlockSize * (e.channels * e.type)), i = new Uint8Array(8192), o = 0, s = Array(e.channels), a = 0; a < e.channels; a++) s[a] = {}, s[a].start = o, s[a].end = s[a].start, s[a].nx = e.width, s[a].ny = e.lines, s[a].size = e.type, o += s[a].nx * s[a].ny * s[a].size;
                        var l = D(t, r),
                            u = D(t, r);
                        if (u >= 8192) throw "Something is wrong with PIZ_COMPRESSION BITMAP_SIZE";
                        if (l <= u)
                            for (var a = 0; a < u - l + 1; a++) i[a + l] = F(t, r);
                        var p = new Uint16Array(65536),
                            A = function(e, t) {
                                for (var r = 0, n = 0; n < 65536; ++n)(0 == n || e[n >> 3] & 1 << (7 & n)) && (t[r++] = n);
                                for (var i = r - 1; r < 65536;) t[r++] = 0;
                                return i
                            }(i, p),
                            m = M(t, r);
                        h(e.array, t, r, m, n, o);
                        for (var a = 0; a < e.channels; ++a)
                            for (var g = s[a], B = 0; B < s[a].size; ++B) ! function(e, t, r, n, i, o, s) {
                                for (var a = s < 16384, l = r > i ? i : r, u = 1; u <= l;) u <<= 1;
                                for (u >>= 1, h = u, u >>= 1; u >= 1;) {
                                    for (var h, p, A, m, g, B = 0, v = 0 + o * (i - h), y = o * u, C = o * h, b = n * u, E = n * h; B <= v; B += C) {
                                        for (var w = B, M = B + n * (r - h); w <= M; w += E) {
                                            var R = w + b,
                                                F = w + y,
                                                x = F + b;
                                            a ? (f(e[w + t], e[F + t]), p = c.a, m = c.b, f(e[R + t], e[x + t]), A = c.a, g = c.b, f(p, A), e[w + t] = c.a, e[R + t] = c.b, f(m, g)) : (d(e[w + t], e[F + t]), p = c.a, m = c.b, d(e[R + t], e[x + t]), A = c.a, g = c.b, d(p, A), e[w + t] = c.a, e[R + t] = c.b, d(m, g)), e[F + t] = c.a, e[x + t] = c.b
                                        }
                                        if (r & u) {
                                            var F = w + y;
                                            a ? f(e[w + t], e[F + t]) : d(e[w + t], e[F + t]), p = c.a, e[F + t] = c.b, e[w + t] = p
                                        }
                                    }
                                    if (i & u)
                                        for (var w = B, M = B + n * (r - h); w <= M; w += E) {
                                            var R = w + b;
                                            a ? f(e[w + t], e[R + t]) : d(e[w + t], e[R + t]), p = c.a, e[R + t] = c.b, e[w + t] = p
                                        }
                                    h = u, u >>= 1
                                }
                            }(n, g.start + B, g.nx, g.size, g.ny, g.nx * g.size, A);
                        for (var v = o, y = 0; y < v; ++y) n[y] = p[n[y]];
                        for (var C = 0, b = new Uint8Array(n.buffer.byteLength), E = 0; E < e.lines; E++)
                            for (var w = 0; w < e.channels; w++) {
                                var g = s[w],
                                    R = g.nx * g.size,
                                    x = new Uint8Array(n.buffer, 2 * g.end, 2 * R);
                                b.set(x, C), C += 2 * R, g.end += R
                            }
                        return new DataView(b.buffer)
                    }

                    function C(e) {
                        var t = eC(e.array.slice(e.offset.value, e.offset.value + e.size));
                        let r = e.lines * e.channels * e.width,
                            n = 1 == e.type ? new Uint16Array(r) : new Uint32Array(r),
                            i = 0,
                            o = 0,
                            s = [, , , , ];
                        for (let r = 0; r < e.lines; r++)
                            for (let r = 0; r < e.channels; r++) {
                                let r = 0;
                                switch (e.type) {
                                    case 1:
                                        s[0] = i, s[1] = s[0] + e.width, i = s[1] + e.width;
                                        for (let i = 0; i < e.width; ++i) r += t[s[0]++] << 8 | t[s[1]++], n[o] = r, o++;
                                        break;
                                    case 2:
                                        s[0] = i, s[1] = s[0] + e.width, s[2] = s[1] + e.width, i = s[2] + e.width;
                                        for (let i = 0; i < e.width; ++i) r += t[s[0]++] << 24 | t[s[1]++] << 16 | t[s[2]++] << 8, n[o] = r, o++
                                }
                            }
                        return new DataView(n.buffer)
                    }

                    function b(e) {
                        var t = e.viewer,
                            r = {
                                value: e.offset.value
                            },
                            n = new Uint8Array(e.width * e.lines * (e.channels * e.type * 2)),
                            i = {
                                version: x(t, r),
                                unknownUncompressedSize: x(t, r),
                                unknownCompressedSize: x(t, r),
                                acCompressedSize: x(t, r),
                                dcCompressedSize: x(t, r),
                                rleCompressedSize: x(t, r),
                                rleUncompressedSize: x(t, r),
                                rleRawSize: x(t, r),
                                totalAcUncompressedCount: x(t, r),
                                totalDcUncompressedCount: x(t, r),
                                acCompression: x(t, r)
                            };
                        if (i.version < 2) throw "EXRLoader.parse: " + U.compression + " version " + i.version + " is unsupported";
                        for (var o = [], s = D(t, r) - 2; s > 0;) {
                            var l = E(t.buffer, r),
                                u = F(t, r),
                                c = u >> 2 & 3,
                                f = new Int8Array([(u >> 4) - 1])[0],
                                d = F(t, r);
                            o.push({
                                name: l,
                                index: f,
                                type: d,
                                compression: c
                            }), s -= l.length + 3
                        }
                        for (var p = U.channels, A = Array(e.channels), g = 0; g < e.channels; ++g) {
                            var B = A[g] = {},
                                y = p[g];
                            B.name = y.name, B.compression = 0, B.decoded = !1, B.type = y.pixelType, B.pLinear = y.pLinear, B.width = e.width, B.height = e.lines
                        }
                        for (var C = {
                                idx: [, , , ]
                            }, b = 0; b < e.channels; ++b)
                            for (var B = A[b], g = 0; g < o.length; ++g) {
                                var w = o[g];
                                B.name == w.name && (B.compression = w.compression, w.index >= 0 && (C.idx[w.index] = b), B.offset = b)
                            }
                        if (i.acCompressedSize > 0) switch (i.acCompression) {
                            case 0:
                                var M = new Uint16Array(i.totalAcUncompressedCount);
                                h(e.array, t, r, i.acCompressedSize, M, i.totalAcUncompressedCount);
                                break;
                            case 1:
                                var R = e.array.slice(r.value, r.value + i.totalAcUncompressedCount),
                                    I = eC(R),
                                    M = new Uint16Array(I.buffer);
                                r.value += i.totalAcUncompressedCount
                        }
                        if (i.dcCompressedSize > 0) {
                            var T = new Uint16Array(v({
                                array: e.array,
                                offset: r,
                                size: i.dcCompressedSize
                            }).buffer);
                            r.value += i.dcCompressedSize
                        }
                        if (i.rleRawSize > 0) {
                            var R = e.array.slice(r.value, r.value + i.rleCompressedSize),
                                I = eC(R),
                                O = m(I.buffer);
                            r.value += i.rleCompressedSize
                        }
                        for (var G = 0, P = Array(A.length), g = 0; g < P.length; ++g) P[g] = [];
                        for (var H = 0; H < e.lines; ++H)
                            for (var _ = 0; _ < A.length; ++_) P[_].push(G), G += A[_].width * e.type * 2;
                        ! function(e, t, r, n, i, o) {
                            var s = new DataView(o.buffer),
                                l = r[e.idx[0]].width,
                                u = r[e.idx[0]].height,
                                c = Math.floor(l / 8),
                                f = Math.ceil(l / 8),
                                d = Math.ceil(u / 8),
                                h = l - (f - 1) * 8,
                                p = u - (d - 1) * 8,
                                A = {
                                    value: 0
                                },
                                m = [, , , ],
                                g = [, , , ],
                                B = [, , , ],
                                v = [, , , ],
                                y = [, , , ];
                            for (let r = 0; r < 3; ++r) y[r] = t[e.idx[r]], m[r] = r < 1 ? 0 : m[r - 1] + f * d, g[r] = new Float32Array(64), B[r] = new Uint16Array(64), v[r] = new Uint16Array(64 * f);
                            for (let t = 0; t < d; ++t) {
                                var C, b, E = 8;
                                t == d - 1 && (E = p);
                                var w = 8;
                                for (let e = 0; e < f; ++e) {
                                    e == f - 1 && (w = h);
                                    for (let e = 0; e < 3; ++e) {
                                        B[e].fill(0), B[e][0] = i[m[e]++],
                                            function(e, t, r) {
                                                for (var n, i = 1; i < 64;) 65280 == (n = t[e.value]) ? i = 64 : n >> 8 == 255 ? i += 255 & n : (r[i] = n, i++), e.value++
                                            }(A, n, B[e]), C = B[e], (b = g[e])[0] = S(C[0]), b[1] = S(C[1]), b[2] = S(C[5]), b[3] = S(C[6]), b[4] = S(C[14]), b[5] = S(C[15]), b[6] = S(C[27]), b[7] = S(C[28]), b[8] = S(C[2]), b[9] = S(C[4]), b[10] = S(C[7]), b[11] = S(C[13]), b[12] = S(C[16]), b[13] = S(C[26]), b[14] = S(C[29]), b[15] = S(C[42]), b[16] = S(C[3]), b[17] = S(C[8]), b[18] = S(C[12]), b[19] = S(C[17]), b[20] = S(C[25]), b[21] = S(C[30]), b[22] = S(C[41]), b[23] = S(C[43]), b[24] = S(C[9]), b[25] = S(C[11]), b[26] = S(C[18]), b[27] = S(C[24]), b[28] = S(C[31]), b[29] = S(C[40]), b[30] = S(C[44]), b[31] = S(C[53]), b[32] = S(C[10]), b[33] = S(C[19]), b[34] = S(C[23]), b[35] = S(C[32]), b[36] = S(C[39]), b[37] = S(C[45]), b[38] = S(C[52]), b[39] = S(C[54]), b[40] = S(C[20]), b[41] = S(C[22]), b[42] = S(C[33]), b[43] = S(C[38]), b[44] = S(C[46]), b[45] = S(C[51]), b[46] = S(C[55]), b[47] = S(C[60]), b[48] = S(C[21]), b[49] = S(C[34]), b[50] = S(C[37]), b[51] = S(C[47]), b[52] = S(C[50]), b[53] = S(C[56]), b[54] = S(C[59]), b[55] = S(C[61]), b[56] = S(C[35]), b[57] = S(C[36]), b[58] = S(C[48]), b[59] = S(C[49]), b[60] = S(C[57]), b[61] = S(C[58]), b[62] = S(C[62]), b[63] = S(C[63]),
                                            function(e) {
                                                let t = .5 * Math.cos(3.14159 / 16),
                                                    r = .5 * Math.cos(3.14159 / 8),
                                                    n = .5 * Math.cos(3 * 3.14159 / 16),
                                                    i = .5 * Math.cos(3 * 3.14159 / 8);
                                                for (var o = [, , , , ], s = [, , , , ], a = [, , , , ], l = [, , , , ], u = 0; u < 8; ++u) {
                                                    var c = 8 * u;
                                                    o[0] = r * e[c + 2], o[1] = i * e[c + 2], o[2] = r * e[c + 6], o[3] = i * e[c + 6], s[0] = t * e[c + 1] + n * e[c + 3] + .2777854612564676 * e[c + 5] + .09754573032714427 * e[c + 7], s[1] = n * e[c + 1] - .09754573032714427 * e[c + 3] - t * e[c + 5] - .2777854612564676 * e[c + 7], s[2] = .2777854612564676 * e[c + 1] - t * e[c + 3] + .09754573032714427 * e[c + 5] + n * e[c + 7], s[3] = .09754573032714427 * e[c + 1] - .2777854612564676 * e[c + 3] + n * e[c + 5] - t * e[c + 7], a[0] = .35355362513961314 * (e[c + 0] + e[c + 4]), a[3] = .35355362513961314 * (e[c + 0] - e[c + 4]), a[1] = o[0] + o[3], a[2] = o[1] - o[2], l[0] = a[0] + a[1], l[1] = a[3] + a[2], l[2] = a[3] - a[2], l[3] = a[0] - a[1], e[c + 0] = l[0] + s[0], e[c + 1] = l[1] + s[1], e[c + 2] = l[2] + s[2], e[c + 3] = l[3] + s[3], e[c + 4] = l[3] - s[3], e[c + 5] = l[2] - s[2], e[c + 6] = l[1] - s[1], e[c + 7] = l[0] - s[0]
                                                }
                                                for (var f = 0; f < 8; ++f) o[0] = r * e[16 + f], o[1] = i * e[16 + f], o[2] = r * e[48 + f], o[3] = i * e[48 + f], s[0] = t * e[8 + f] + n * e[24 + f] + .2777854612564676 * e[40 + f] + .09754573032714427 * e[56 + f], s[1] = n * e[8 + f] - .09754573032714427 * e[24 + f] - t * e[40 + f] - .2777854612564676 * e[56 + f], s[2] = .2777854612564676 * e[8 + f] - t * e[24 + f] + .09754573032714427 * e[40 + f] + n * e[56 + f], s[3] = .09754573032714427 * e[8 + f] - .2777854612564676 * e[24 + f] + n * e[40 + f] - t * e[56 + f], a[0] = .35355362513961314 * (e[f] + e[32 + f]), a[3] = .35355362513961314 * (e[f] - e[32 + f]), a[1] = o[0] + o[3], a[2] = o[1] - o[2], l[0] = a[0] + a[1], l[1] = a[3] + a[2], l[2] = a[3] - a[2], l[3] = a[0] - a[1], e[0 + f] = l[0] + s[0], e[8 + f] = l[1] + s[1], e[16 + f] = l[2] + s[2], e[24 + f] = l[3] + s[3], e[32 + f] = l[3] - s[3], e[40 + f] = l[2] - s[2], e[48 + f] = l[1] - s[1], e[56 + f] = l[0] - s[0]
                                            }(g[e])
                                    }
                                    for (var M = g, R = 0; R < 64; ++R) {
                                        var F = M[0][R],
                                            x = M[1][R],
                                            I = M[2][R];
                                        M[0][R] = F + 1.5747 * I, M[1][R] = F - .1873 * x - .4682 * I, M[2][R] = F + 1.8556 * x
                                    }
                                    for (let t = 0; t < 3; ++t) ! function(e, t, r) {
                                        for (var n, i = 0; i < 64; ++i) {
                                            t[r + i] = a.GxU.toHalfFloat((n = e[i]) <= 1 ? Math.sign(n) * Math.pow(Math.abs(n), 2.2) : Math.sign(n) * Math.pow(9.025013291561939, Math.abs(n) - 1))
                                        }
                                    }(g[t], v[t], 64 * e)
                                }
                                let o = 0;
                                for (let n = 0; n < 3; ++n) {
                                    let i = r[e.idx[n]].type;
                                    for (let e = 8 * t; e < 8 * t + E; ++e) {
                                        o = y[n][e];
                                        for (let t = 0; t < c; ++t) {
                                            let r = 64 * t + (7 & e) * 8;
                                            s.setUint16(o + 0 * i, v[n][r + 0], !0), s.setUint16(o + 2 * i, v[n][r + 1], !0), s.setUint16(o + 4 * i, v[n][r + 2], !0), s.setUint16(o + 6 * i, v[n][r + 3], !0), s.setUint16(o + 8 * i, v[n][r + 4], !0), s.setUint16(o + 10 * i, v[n][r + 5], !0), s.setUint16(o + 12 * i, v[n][r + 6], !0), s.setUint16(o + 14 * i, v[n][r + 7], !0), o += 16 * i
                                        }
                                    }
                                    if (c != f)
                                        for (let e = 8 * t; e < 8 * t + E; ++e) {
                                            let t = y[n][e] + 8 * c * 2 * i,
                                                r = 64 * c + (7 & e) * 8;
                                            for (let e = 0; e < w; ++e) s.setUint16(t + 2 * e * i, v[n][r + e], !0)
                                        }
                                }
                            }
                            for (var T = new Uint16Array(l), s = new DataView(o.buffer), D = 0; D < 3; ++D) {
                                r[e.idx[D]].decoded = !0;
                                var O = r[e.idx[D]].type;
                                if (2 == r[D].type)
                                    for (var G = 0; G < u; ++G) {
                                        let e = y[D][G];
                                        for (var P = 0; P < l; ++P) T[P] = s.getUint16(e + 2 * P * O, !0);
                                        for (var P = 0; P < l; ++P) s.setFloat32(e + 2 * P * O, S(T[P]), !0)
                                    }
                            }
                        }(C, P, A, M, T, n);
                        for (var g = 0; g < A.length; ++g) {
                            var B = A[g];
                            if (!B.decoded)
                                if (2 === B.compression)
                                    for (var L = 0, J = 0, H = 0; H < e.lines; ++H) {
                                        for (var j = P[g][L], k = 0; k < B.width; ++k) {
                                            for (var N = 0; N < 2 * B.type; ++N) n[j++] = O[J + N * B.width * B.height];
                                            J++
                                        }
                                        L++
                                    } else throw "EXRLoader.parse: unsupported channel compression"
                        }
                        return new DataView(n.buffer)
                    }

                    function E(e, t) {
                        for (var r = new Uint8Array(e), n = 0; 0 != r[t.value + n];) n += 1;
                        var i = new TextDecoder().decode(r.slice(t.value, t.value + n));
                        return t.value = t.value + n + 1, i
                    }

                    function w(e, t) {
                        var r = e.getInt32(t.value, !0);
                        return t.value = t.value + 4, r
                    }

                    function M(e, t) {
                        var r = e.getUint32(t.value, !0);
                        return t.value = t.value + 4, r
                    }

                    function R(e, t) {
                        var r = e[t.value];
                        return t.value = t.value + 1, r
                    }

                    function F(e, t) {
                        var r = e.getUint8(t.value);
                        return t.value = t.value + 1, r
                    }
                    let x = function(e, t) {
                        let r;
                        return r = "getBigInt64" in DataView.prototype ? Number(e.getBigInt64(t.value, !0)) : e.getUint32(t.value + 4, !0) + Number(e.getUint32(t.value, !0) << 32), t.value += 8, r
                    };

                    function I(e, t) {
                        var r = e.getFloat32(t.value, !0);
                        return t.value += 4, r
                    }

                    function T(e, t) {
                        return a.GxU.toHalfFloat(I(e, t))
                    }

                    function S(e) {
                        var t = (31744 & e) >> 10,
                            r = 1023 & e;
                        return (e >> 15 ? -1 : 1) * (t ? 31 === t ? r ? NaN : 1 / 0 : Math.pow(2, t - 15) * (1 + r / 1024) : r / 1024 * 6103515625e-14)
                    }

                    function D(e, t) {
                        var r = e.getUint16(t.value, !0);
                        return t.value += 2, r
                    }

                    function O(e, t) {
                        return S(D(e, t))
                    }
                    let G = new DataView(e),
                        P = new Uint8Array(e),
                        H = {
                            value: 0
                        },
                        U = function(e, t, r) {
                            let n = {};
                            if (0x1312f76 != e.getUint32(0, !0)) throw "THREE.EXRLoader: provided file doesn't appear to be in OpenEXR format.";
                            n.version = e.getUint8(4);
                            let i = e.getUint8(5);
                            n.spec = {
                                singleTile: !!(2 & i),
                                longName: !!(4 & i),
                                deepFormat: !!(8 & i),
                                multiPart: !!(16 & i)
                            }, r.value = 8;
                            for (var o = !0; o;) {
                                var s = E(t, r);
                                if (0 == s) o = !1;
                                else {
                                    var a = E(t, r),
                                        l = M(e, r),
                                        u = function(e, t, r, n, i) {
                                            var o, s, a, l, u, c, f;
                                            if ("string" === n || "stringvector" === n || "iccProfile" === n) return o = new TextDecoder().decode(new Uint8Array(t).slice(r.value, r.value + i)), r.value = r.value + i, o;
                                            if ("chlist" === n) return function(e, t, r, n) {
                                                for (var i = r.value, o = []; r.value < i + n - 1;) {
                                                    var s = E(t, r),
                                                        a = w(e, r),
                                                        l = F(e, r);
                                                    r.value += 3;
                                                    var u = w(e, r),
                                                        c = w(e, r);
                                                    o.push({
                                                        name: s,
                                                        pixelType: a,
                                                        pLinear: l,
                                                        xSampling: u,
                                                        ySampling: c
                                                    })
                                                }
                                                return r.value += 1, o
                                            }(e, t, r, i);
                                            if ("chromaticities" === n) return s = I(e, r), a = I(e, r), l = I(e, r), u = I(e, r), c = I(e, r), {
                                                redX: s,
                                                redY: a,
                                                greenX: l,
                                                greenY: u,
                                                blueX: c,
                                                blueY: I(e, r),
                                                whiteX: I(e, r),
                                                whiteY: I(e, r)
                                            };
                                            if ("compression" === n) return ["NO_COMPRESSION", "RLE_COMPRESSION", "ZIPS_COMPRESSION", "ZIP_COMPRESSION", "PIZ_COMPRESSION", "PXR24_COMPRESSION", "B44_COMPRESSION", "B44A_COMPRESSION", "DWAA_COMPRESSION", "DWAB_COMPRESSION"][F(e, r)];
                                            if ("box2i" === n) return f = M(e, r), {
                                                xMin: f,
                                                yMin: M(e, r),
                                                xMax: M(e, r),
                                                yMax: M(e, r)
                                            };
                                            else if ("lineOrder" === n) return ["INCREASING_Y"][F(e, r)];
                                            else if ("float" === n) return I(e, r);
                                            else if ("v2f" === n) return [I(e, r), I(e, r)];
                                            else if ("v3f" === n) return [I(e, r), I(e, r), I(e, r)];
                                            else if ("int" === n) return w(e, r);
                                            else if ("rational" === n) return [w(e, r), M(e, r)];
                                            else if ("timecode" === n) return [M(e, r), M(e, r)];
                                            else return "preview" === n ? (r.value += i, "skipped") : (r.value += i, void 0)
                                        }(e, t, r, a, l);
                                    void 0 === u ? console.warn(`EXRLoader.parse: skipped unknown header attribute type '${a}'.`) : n[s] = u
                                }
                            }
                            if ((-5 & i) != 0) throw console.error("EXRHeader:", n), "THREE.EXRLoader: provided file is currently unsupported.";
                            return n
                        }(G, e, H),
                        _ = function(e, t, r, n, i) {
                            let o = {
                                size: 0,
                                viewer: t,
                                array: r,
                                offset: n,
                                width: e.dataWindow.xMax - e.dataWindow.xMin + 1,
                                height: e.dataWindow.yMax - e.dataWindow.yMin + 1,
                                channels: e.channels.length,
                                bytesPerLine: null,
                                lines: null,
                                inputSize: null,
                                type: e.channels[0].pixelType,
                                uncompress: null,
                                getter: null,
                                format: null,
                                [eF ? "colorSpace" : "encoding"]: null
                            };
                            switch (e.compression) {
                                case "NO_COMPRESSION":
                                    o.lines = 1, o.uncompress = g;
                                    break;
                                case "RLE_COMPRESSION":
                                    o.lines = 1, o.uncompress = B;
                                    break;
                                case "ZIPS_COMPRESSION":
                                    o.lines = 1, o.uncompress = v;
                                    break;
                                case "ZIP_COMPRESSION":
                                    o.lines = 16, o.uncompress = v;
                                    break;
                                case "PIZ_COMPRESSION":
                                    o.lines = 32, o.uncompress = y;
                                    break;
                                case "PXR24_COMPRESSION":
                                    o.lines = 16, o.uncompress = C;
                                    break;
                                case "DWAA_COMPRESSION":
                                    o.lines = 32, o.uncompress = b;
                                    break;
                                case "DWAB_COMPRESSION":
                                    o.lines = 256, o.uncompress = b;
                                    break;
                                default:
                                    throw "EXRLoader.parse: " + e.compression + " is unsupported"
                            }
                            if (o.scanlineBlockSize = o.lines, 1 == o.type) switch (i) {
                                case a.RQf:
                                    o.getter = O, o.inputSize = 2;
                                    break;
                                case a.ix0:
                                    o.getter = D, o.inputSize = 2
                            } else if (2 == o.type) switch (i) {
                                case a.RQf:
                                    o.getter = I, o.inputSize = 4;
                                    break;
                                case a.ix0:
                                    o.getter = T, o.inputSize = 4
                            } else throw "EXRLoader.parse: unsupported pixelType " + o.type + " for " + e.compression + ".";
                            o.blockCount = (e.dataWindow.yMax + 1) / o.scanlineBlockSize;
                            for (var s = 0; s < o.blockCount; s++) x(t, n);
                            o.outputChannels = 3 == o.channels ? 4 : o.channels;
                            let l = o.width * o.height * o.outputChannels;
                            switch (i) {
                                case a.RQf:
                                    o.byteArray = new Float32Array(l), o.channels < o.outputChannels && o.byteArray.fill(1, 0, l);
                                    break;
                                case a.ix0:
                                    o.byteArray = new Uint16Array(l), o.channels < o.outputChannels && o.byteArray.fill(15360, 0, l);
                                    break;
                                default:
                                    console.error("THREE.EXRLoader: unsupported type: ", i)
                            }
                            return o.bytesPerLine = o.width * o.inputSize * o.channels, 4 == o.outputChannels ? o.format = a.GWd : o.format = a.VT0, eF ? o.colorSpace = "srgb-linear" : o.encoding = 3e3, o
                        }(U, G, P, H, this.type),
                        L = {
                            value: 0
                        },
                        J = {
                            R: 0,
                            G: 1,
                            B: 2,
                            A: 3,
                            Y: 0
                        };
                    for (let e = 0; e < _.height / _.scanlineBlockSize; e++) {
                        let t = M(G, H);
                        _.size = M(G, H), _.lines = t + _.scanlineBlockSize > _.height ? _.height - t : _.scanlineBlockSize;
                        let r = _.size < _.lines * _.bytesPerLine ? _.uncompress(_) : g(_);
                        H.value += _.size;
                        for (let t = 0; t < _.scanlineBlockSize; t++) {
                            let n = t + e * _.scanlineBlockSize;
                            if (n >= _.height) break;
                            for (let e = 0; e < _.channels; e++) {
                                let i = J[U.channels[e].name];
                                for (let o = 0; o < _.width; o++) {
                                    L.value = (t * (_.channels * _.width) + e * _.width + o) * _.inputSize;
                                    let s = (_.height - 1 - n) * (_.width * _.outputChannels) + o * _.outputChannels + i;
                                    _.byteArray[s] = _.getter(r, L)
                                }
                            }
                        }
                    }
                    return {
                        header: U,
                        width: _.width,
                        height: _.height,
                        data: _.byteArray,
                        format: _.format,
                        [eF ? "colorSpace" : "encoding"]: _[eF ? "colorSpace" : "encoding"],
                        type: this.type
                    }
                }
                setDataType(e) {
                    return this.type = e, this
                }
                load(e, t, r, n) {
                    return super.load(e, function(e, r) {
                        eF ? e.colorSpace = r.colorSpace : e.encoding = r.encoding, e.minFilter = a.k6q, e.magFilter = a.k6q, e.generateMipmaps = !1, e.flipY = !1, t && t(e, r)
                    }, r, n)
                }
            }
            var eI = r(1759);
            let eT = (e, t, r) => {
                    let n;
                    switch (e) {
                        case a.OUM:
                            n = new Uint8ClampedArray(t * r * 4);
                            break;
                        case a.ix0:
                            n = new Uint16Array(t * r * 4);
                            break;
                        case a.bkx:
                            n = new Uint32Array(t * r * 4);
                            break;
                        case a.tJf:
                            n = new Int8Array(t * r * 4);
                            break;
                        case a.fBL:
                            n = new Int16Array(t * r * 4);
                            break;
                        case a.Yuy:
                            n = new Int32Array(t * r * 4);
                            break;
                        case a.RQf:
                            n = new Float32Array(t * r * 4);
                            break;
                        default:
                            throw Error("Unsupported data type")
                    }
                    return n
                },
                eS = (e, t, r, i) => {
                    if (void 0 !== n) return n;
                    let o = new a.nWS(1, 1, i);
                    t.setRenderTarget(o);
                    let s = new a.eaF(new a.bdM, new a.V9B({
                        color: 0xffffff
                    }));
                    t.render(s, r), t.setRenderTarget(null);
                    let l = eT(e, o.width, o.height);
                    return t.readRenderTargetPixels(o, 0, 0, o.width, o.height, l), o.dispose(), s.geometry.dispose(), s.material.dispose(), n = 0 !== l[0]
                };
            class eD {
                constructor(e) {
                    var t, r, n, i, o, s, l, u, c, f, d, h, p, A, m, g;
                    this._rendererIsDisposable = !1, this._supportsReadPixels = !0, this.render = () => {
                        this._renderer.setRenderTarget(this._renderTarget);
                        try {
                            this._renderer.render(this._scene, this._camera)
                        } catch (e) {
                            throw this._renderer.setRenderTarget(null), e
                        }
                        this._renderer.setRenderTarget(null)
                    }, this._width = e.width, this._height = e.height, this._type = e.type, this._colorSpace = e.colorSpace;
                    let B = {
                        format: a.GWd,
                        depthBuffer: !1,
                        stencilBuffer: !1,
                        type: this._type,
                        colorSpace: this._colorSpace,
                        anisotropy: (null == (t = e.renderTargetOptions) ? void 0 : t.anisotropy) !== void 0 ? null == (r = e.renderTargetOptions) ? void 0 : r.anisotropy : 1,
                        generateMipmaps: (null == (n = e.renderTargetOptions) ? void 0 : n.generateMipmaps) !== void 0 && (null == (i = e.renderTargetOptions) ? void 0 : i.generateMipmaps),
                        magFilter: (null == (o = e.renderTargetOptions) ? void 0 : o.magFilter) !== void 0 ? null == (s = e.renderTargetOptions) ? void 0 : s.magFilter : a.k6q,
                        minFilter: (null == (l = e.renderTargetOptions) ? void 0 : l.minFilter) !== void 0 ? null == (u = e.renderTargetOptions) ? void 0 : u.minFilter : a.k6q,
                        samples: (null == (c = e.renderTargetOptions) ? void 0 : c.samples) !== void 0 ? null == (f = e.renderTargetOptions) ? void 0 : f.samples : void 0,
                        wrapS: (null == (d = e.renderTargetOptions) ? void 0 : d.wrapS) !== void 0 ? null == (h = e.renderTargetOptions) ? void 0 : h.wrapS : a.ghU,
                        wrapT: (null == (p = e.renderTargetOptions) ? void 0 : p.wrapT) !== void 0 ? null == (A = e.renderTargetOptions) ? void 0 : A.wrapT : a.ghU
                    };
                    if (this._material = e.material, e.renderer ? this._renderer = e.renderer : (this._renderer = eD.instantiateRenderer(), this._rendererIsDisposable = !0), this._scene = new a.Z58, this._camera = new a.qUd, this._camera.position.set(0, 0, 10), this._camera.left = -.5, this._camera.right = .5, this._camera.top = .5, this._camera.bottom = -.5, this._camera.updateProjectionMatrix(), !eS(this._type, this._renderer, this._camera, B)) {
                        let e;
                        this._type === a.ix0 && (e = this._renderer.extensions.has("EXT_color_buffer_float") ? a.RQf : void 0), void 0 !== e ? (console.warn(`This browser does not support reading pixels from ${this._type} RenderTargets, switching to ${a.RQf}`), this._type = e) : (this._supportsReadPixels = !1, console.warn("This browser dos not support toArray or toDataTexture, calls to those methods will result in an error thrown"))
                    }
                    this._quad = new a.eaF(new a.bdM, this._material), this._quad.geometry.computeBoundingBox(), this._scene.add(this._quad), this._renderTarget = new a.nWS(this.width, this.height, B), this._renderTarget.texture.mapping = (null == (m = e.renderTargetOptions) ? void 0 : m.mapping) !== void 0 ? null == (g = e.renderTargetOptions) ? void 0 : g.mapping : a.UTZ
                }
                static instantiateRenderer() {
                    let e = new eI.WebGLRenderer;
                    return e.setSize(128, 128), e
                }
                toArray() {
                    if (!this._supportsReadPixels) throw Error("Can't read pixels in this browser");
                    let e = eT(this._type, this._width, this._height);
                    return this._renderer.readRenderTargetPixels(this._renderTarget, 0, 0, this._width, this._height, e), e
                }
                toDataTexture(e) {
                    let t = new a.GYF(this.toArray(), this.width, this.height, a.GWd, this._type, (null == e ? void 0 : e.mapping) || a.UTZ, (null == e ? void 0 : e.wrapS) || a.ghU, (null == e ? void 0 : e.wrapT) || a.ghU, (null == e ? void 0 : e.magFilter) || a.k6q, (null == e ? void 0 : e.minFilter) || a.k6q, (null == e ? void 0 : e.anisotropy) || 1, a.Zr2);
                    return t.generateMipmaps = (null == e ? void 0 : e.generateMipmaps) !== void 0 && (null == e ? void 0 : e.generateMipmaps), t
                }
                disposeOnDemandRenderer() {
                    this._renderer.setRenderTarget(null), this._rendererIsDisposable && (this._renderer.dispose(), this._renderer.forceContextLoss())
                }
                dispose(e) {
                    this.disposeOnDemandRenderer(), e && this.renderTarget.dispose(), this.material instanceof a.BKk && Object.values(this.material.uniforms).forEach(e => {
                        e.value instanceof a.gPd && e.value.dispose()
                    }), Object.values(this.material).forEach(e => {
                        e instanceof a.gPd && e.dispose()
                    }), this.material.dispose(), this._quad.geometry.dispose()
                }
                get width() {
                    return this._width
                }
                set width(e) {
                    this._width = e, this._renderTarget.setSize(this._width, this._height)
                }
                get height() {
                    return this._height
                }
                set height(e) {
                    this._height = e, this._renderTarget.setSize(this._width, this._height)
                }
                get renderer() {
                    return this._renderer
                }
                get renderTarget() {
                    return this._renderTarget
                }
                set renderTarget(e) {
                    this._renderTarget = e, this._width = e.width, this._height = e.height
                }
                get material() {
                    return this._material
                }
                get type() {
                    return this._type
                }
                get colorSpace() {
                    return this._colorSpace
                }
            }
            let eO = `
varying vec2 vUv;

void main() {
  vUv = uv;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}
`,
                eG = `
// min half float value
#define HALF_FLOAT_MIN vec3( -65504, -65504, -65504 )
// max half float value
#define HALF_FLOAT_MAX vec3( 65504, 65504, 65504 )

uniform sampler2D sdr;
uniform sampler2D gainMap;
uniform vec3 gamma;
uniform vec3 offsetHdr;
uniform vec3 offsetSdr;
uniform vec3 gainMapMin;
uniform vec3 gainMapMax;
uniform float weightFactor;

varying vec2 vUv;

void main() {
  vec3 rgb = texture2D( sdr, vUv ).rgb;
  vec3 recovery = texture2D( gainMap, vUv ).rgb;
  vec3 logRecovery = pow( recovery, gamma );
  vec3 logBoost = gainMapMin * ( 1.0 - logRecovery ) + gainMapMax * logRecovery;
  vec3 hdrColor = (rgb + offsetSdr) * exp2( logBoost * weightFactor ) - offsetHdr;
  vec3 clampedHdrColor = max( HALF_FLOAT_MIN, min( HALF_FLOAT_MAX, hdrColor ));
  gl_FragColor = vec4( clampedHdrColor , 1.0 );
}
`;
            class eP extends a.BKk {
                constructor({
                    gamma: e,
                    offsetHdr: t,
                    offsetSdr: r,
                    gainMapMin: n,
                    gainMapMax: i,
                    maxDisplayBoost: o,
                    hdrCapacityMin: s,
                    hdrCapacityMax: l,
                    sdr: u,
                    gainMap: c
                }) {
                    super({
                        name: "GainMapDecoderMaterial",
                        vertexShader: eO,
                        fragmentShader: eG,
                        uniforms: {
                            sdr: {
                                value: u
                            },
                            gainMap: {
                                value: c
                            },
                            gamma: {
                                value: new a.Pq0(1 / e[0], 1 / e[1], 1 / e[2])
                            },
                            offsetHdr: {
                                value: new a.Pq0().fromArray(t)
                            },
                            offsetSdr: {
                                value: new a.Pq0().fromArray(r)
                            },
                            gainMapMin: {
                                value: new a.Pq0().fromArray(n)
                            },
                            gainMapMax: {
                                value: new a.Pq0().fromArray(i)
                            },
                            weightFactor: {
                                value: (Math.log2(o) - s) / (l - s)
                            }
                        },
                        blending: a.XIg,
                        depthTest: !1,
                        depthWrite: !1
                    }), this._maxDisplayBoost = o, this._hdrCapacityMin = s, this._hdrCapacityMax = l, this.needsUpdate = !0, this.uniformsNeedUpdate = !0
                }
                get sdr() {
                    return this.uniforms.sdr.value
                }
                set sdr(e) {
                    this.uniforms.sdr.value = e
                }
                get gainMap() {
                    return this.uniforms.gainMap.value
                }
                set gainMap(e) {
                    this.uniforms.gainMap.value = e
                }
                get offsetHdr() {
                    return this.uniforms.offsetHdr.value.toArray()
                }
                set offsetHdr(e) {
                    this.uniforms.offsetHdr.value.fromArray(e)
                }
                get offsetSdr() {
                    return this.uniforms.offsetSdr.value.toArray()
                }
                set offsetSdr(e) {
                    this.uniforms.offsetSdr.value.fromArray(e)
                }
                get gainMapMin() {
                    return this.uniforms.gainMapMin.value.toArray()
                }
                set gainMapMin(e) {
                    this.uniforms.gainMapMin.value.fromArray(e)
                }
                get gainMapMax() {
                    return this.uniforms.gainMapMax.value.toArray()
                }
                set gainMapMax(e) {
                    this.uniforms.gainMapMax.value.fromArray(e)
                }
                get gamma() {
                    let e = this.uniforms.gamma.value;
                    return [1 / e.x, 1 / e.y, 1 / e.z]
                }
                set gamma(e) {
                    let t = this.uniforms.gamma.value;
                    t.x = 1 / e[0], t.y = 1 / e[1], t.z = 1 / e[2]
                }
                get hdrCapacityMin() {
                    return this._hdrCapacityMin
                }
                set hdrCapacityMin(e) {
                    this._hdrCapacityMin = e, this.calculateWeight()
                }
                get hdrCapacityMax() {
                    return this._hdrCapacityMax
                }
                set hdrCapacityMax(e) {
                    this._hdrCapacityMax = e, this.calculateWeight()
                }
                get maxDisplayBoost() {
                    return this._maxDisplayBoost
                }
                set maxDisplayBoost(e) {
                    this._maxDisplayBoost = Math.max(1, Math.min(65504, e)), this.calculateWeight()
                }
                calculateWeight() {
                    let e = (Math.log2(this._maxDisplayBoost) - this._hdrCapacityMin) / (this._hdrCapacityMax - this._hdrCapacityMin);
                    this.uniforms.weightFactor.value = Math.max(0, Math.min(1, e))
                }
            }
            class eH extends Error {}
            class eU extends Error {}
            let e_ = (e, t, r) => {
                    let n = RegExp(`${t}="([^"]*)"`, "i").exec(e);
                    if (n) return n[1];
                    let i = RegExp(`<${t}[^>]*>([\\s\\S]*?)</${t}>`, "i").exec(e);
                    if (i) {
                        let e = i[1].match(/<rdf:li>([^<]*)<\/rdf:li>/g);
                        return e && 3 === e.length ? e.map(e => e.replace(/<\/?rdf:li>/g, "")) : i[1].trim()
                    }
                    if (void 0 !== r) return r;
                    throw Error(`Can't find ${t} in gainmap metadata`)
                },
                eL = e => {
                    let t, r = (t = "undefined" != typeof TextDecoder ? new TextDecoder().decode(e) : e.toString()).indexOf("<x:xmpmeta");
                    for (; - 1 !== r;) {
                        let e = t.indexOf("x:xmpmeta>", r),
                            n = t.slice(r, e + 10);
                        try {
                            let e = e_(n, "hdrgm:GainMapMin", "0"),
                                t = e_(n, "hdrgm:GainMapMax"),
                                r = e_(n, "hdrgm:Gamma", "1"),
                                i = e_(n, "hdrgm:OffsetSDR", "0.015625"),
                                o = e_(n, "hdrgm:OffsetHDR", "0.015625"),
                                s = /hdrgm:HDRCapacityMin="([^"]*)"/.exec(n),
                                a = s ? s[1] : "0",
                                l = /hdrgm:HDRCapacityMax="([^"]*)"/.exec(n);
                            if (!l) throw Error("Incomplete gainmap metadata");
                            let u = l[1];
                            return {
                                gainMapMin: Array.isArray(e) ? e.map(e => parseFloat(e)) : [parseFloat(e), parseFloat(e), parseFloat(e)],
                                gainMapMax: Array.isArray(t) ? t.map(e => parseFloat(e)) : [parseFloat(t), parseFloat(t), parseFloat(t)],
                                gamma: Array.isArray(r) ? r.map(e => parseFloat(e)) : [parseFloat(r), parseFloat(r), parseFloat(r)],
                                offsetSdr: Array.isArray(i) ? i.map(e => parseFloat(e)) : [parseFloat(i), parseFloat(i), parseFloat(i)],
                                offsetHdr: Array.isArray(o) ? o.map(e => parseFloat(e)) : [parseFloat(o), parseFloat(o), parseFloat(o)],
                                hdrCapacityMin: parseFloat(a),
                                hdrCapacityMax: parseFloat(u)
                            }
                        } catch (e) {}
                        r = t.indexOf("<x:xmpmeta", e)
                    }
                };
            class eJ {
                constructor(e) {
                    this.options = {
                        debug: !!e && void 0 !== e.debug && e.debug,
                        extractFII: !e || void 0 === e.extractFII || e.extractFII,
                        extractNonFII: !e || void 0 === e.extractNonFII || e.extractNonFII
                    }
                }
                extract(e) {
                    return new Promise((t, r) => {
                        let n, i = this.options.debug,
                            o = new DataView(e.buffer);
                        if (65496 !== o.getUint16(0)) return void r(Error("Not a valid jpeg"));
                        let s = o.byteLength,
                            a = 2,
                            l = 0;
                        for (; a < s;) {
                            if (++l > 250) return void r(Error(`Found no marker after ${l} loops 😵`));
                            if (255 !== o.getUint8(a)) return void r(Error(`Not a valid marker at offset 0x${a.toString(16)}, found: 0x${o.getUint8(a).toString(16)}`));
                            if (n = o.getUint8(a + 1), i && console.log(`Marker: ${n.toString(16)}`), 226 === n) {
                                i && console.log("Found APP2 marker (0xffe2)");
                                let e = a + 4;
                                if (0x4d504600 === o.getUint32(e)) {
                                    let n, i = e + 4;
                                    if (18761 === o.getUint16(i)) n = !1;
                                    else {
                                        if (19789 !== o.getUint16(i)) return void r(Error("No valid endianness marker found in TIFF header"));
                                        n = !0
                                    }
                                    if (42 !== o.getUint16(i + 2, !n)) return void r(Error("Not valid TIFF data! (no 0x002A marker)"));
                                    let s = o.getUint32(i + 4, !n);
                                    if (s < 8) return void r(Error("Not valid TIFF data! (First offset less than 8)"));
                                    let a = i + s,
                                        l = o.getUint16(a, !n),
                                        u = a + 2,
                                        c = 0;
                                    for (let e = u; e < u + 12 * l; e += 12) 45057 === o.getUint16(e, !n) && (c = o.getUint32(e + 8, !n));
                                    let f = a + 2 + 12 * l + 4,
                                        d = [];
                                    for (let e = f; e < f + 16 * c; e += 16) {
                                        let t = {
                                            MPType: o.getUint32(e, !n),
                                            size: o.getUint32(e + 4, !n),
                                            dataOffset: o.getUint32(e + 8, !n),
                                            dependantImages: o.getUint32(e + 12, !n),
                                            start: -1,
                                            end: -1,
                                            isFII: !1
                                        };
                                        t.dataOffset ? (t.start = i + t.dataOffset, t.isFII = !1) : (t.start = 0, t.isFII = !0), t.end = t.start + t.size, d.push(t)
                                    }
                                    if (this.options.extractNonFII && d.length) {
                                        let e = new Blob([o]),
                                            r = [];
                                        for (let t of d) {
                                            if (t.isFII && !this.options.extractFII) continue;
                                            let n = e.slice(t.start, t.end + 1, "image/jpeg");
                                            r.push(n)
                                        }
                                        t(r)
                                    }
                                }
                            }
                            a += 2 + o.getUint16(a + 2)
                        }
                    })
                }
            }
            let ej = async e => {
                    let t = eL(e);
                    if (!t) throw new eU("Gain map XMP metadata not found");
                    let r = new eJ({
                            extractFII: !0,
                            extractNonFII: !0
                        }),
                        n = await r.extract(e);
                    if (2 !== n.length) throw new eH("Gain map recovery image not found");
                    return {
                        sdr: new Uint8Array(await n[0].arrayBuffer()),
                        gainMap: new Uint8Array(await n[1].arrayBuffer()),
                        metadata: t
                    }
                },
                ek = e => new Promise((t, r) => {
                    let n = document.createElement("img");
                    n.onload = () => {
                        t(n)
                    }, n.onerror = e => {
                        r(e)
                    }, n.src = URL.createObjectURL(e)
                });
            class eN extends a.aHM {
                constructor(e, t) {
                    super(t), e && (this._renderer = e), this._internalLoadingManager = new a.KPJ
                }
                setRenderer(e) {
                    return this._renderer = e, this
                }
                setRenderTargetOptions(e) {
                    return this._renderTargetOptions = e, this
                }
                prepareQuadRenderer() {
                    this._renderer || console.warn("WARNING: An existing WebGL Renderer was not passed to this Loader constructor or in setRenderer, the result of this Loader will need to be converted to a Data Texture with toDataTexture() before you can use it in your renderer.");
                    let e = new eP({
                        gainMapMax: [1, 1, 1],
                        gainMapMin: [0, 0, 0],
                        gamma: [1, 1, 1],
                        offsetHdr: [1, 1, 1],
                        offsetSdr: [1, 1, 1],
                        hdrCapacityMax: 1,
                        hdrCapacityMin: 0,
                        maxDisplayBoost: 1,
                        gainMap: new a.gPd,
                        sdr: new a.gPd
                    });
                    return new eD({
                        width: 16,
                        height: 16,
                        type: a.ix0,
                        colorSpace: a.Zr2,
                        material: e,
                        renderer: this._renderer,
                        renderTargetOptions: this._renderTargetOptions
                    })
                }
                async render(e, t, r, n) {
                    let i, o, s = n ? new Blob([n], {
                            type: "image/jpeg"
                        }) : void 0,
                        l = new Blob([r], {
                            type: "image/jpeg"
                        }),
                        u = !1;
                    if ("undefined" == typeof createImageBitmap) {
                        let e = await Promise.all([s ? ek(s) : Promise.resolve(void 0), ek(l)]);
                        o = e[0], i = e[1], u = !0
                    } else {
                        let e = await Promise.all([s ? createImageBitmap(s, {
                            imageOrientation: "flipY"
                        }) : Promise.resolve(void 0), createImageBitmap(l, {
                            imageOrientation: "flipY"
                        })]);
                        o = e[0], i = e[1]
                    }
                    let c = new a.gPd(o || new ImageData(2, 2), a.UTZ, a.ghU, a.ghU, a.k6q, a.NZq, a.GWd, a.OUM, 1, a.Zr2);
                    c.flipY = u, c.needsUpdate = !0;
                    let f = new a.gPd(i, a.UTZ, a.ghU, a.ghU, a.k6q, a.NZq, a.GWd, a.OUM, 1, a.er$);
                    f.flipY = u, f.needsUpdate = !0, e.width = i.width, e.height = i.height, e.material.gainMap = c, e.material.sdr = f, e.material.gainMapMin = t.gainMapMin, e.material.gainMapMax = t.gainMapMax, e.material.offsetHdr = t.offsetHdr, e.material.offsetSdr = t.offsetSdr, e.material.gamma = t.gamma, e.material.hdrCapacityMin = t.hdrCapacityMin, e.material.hdrCapacityMax = t.hdrCapacityMax, e.material.maxDisplayBoost = Math.pow(2, t.hdrCapacityMax), e.material.needsUpdate = !0, e.render()
                }
            }
            class eK extends eN {
                load([e, t, r], n, i, o) {
                    let s, l, u, c = this.prepareQuadRenderer(),
                        f = async () => {
                            if (s && l && u) {
                                try {
                                    await this.render(c, u, s, l)
                                } catch (n) {
                                    this.manager.itemError(e), this.manager.itemError(t), this.manager.itemError(r), "function" == typeof o && o(n), c.disposeOnDemandRenderer();
                                    return
                                }
                                "function" == typeof n && n(c), this.manager.itemEnd(e), this.manager.itemEnd(t), this.manager.itemEnd(r), c.disposeOnDemandRenderer()
                            }
                        },
                        d = !0,
                        h = 0,
                        p = 0,
                        A = !0,
                        m = 0,
                        g = 0,
                        B = !0,
                        v = 0,
                        y = 0,
                        C = () => {
                            "function" == typeof i && i(new ProgressEvent("progress", {
                                lengthComputable: d && A && B,
                                loaded: p + g + y,
                                total: h + m + v
                            }))
                        };
                    this.manager.itemStart(e), this.manager.itemStart(t), this.manager.itemStart(r);
                    let b = new a.Y9S(this._internalLoadingManager);
                    b.setResponseType("arraybuffer"), b.setRequestHeader(this.requestHeader), b.setPath(this.path), b.setWithCredentials(this.withCredentials), b.load(e, async e => {
                        if ("string" == typeof e) throw Error("Invalid sdr buffer");
                        s = e, await f()
                    }, e => {
                        d = e.lengthComputable, p = e.loaded, h = e.total, C()
                    }, t => {
                        this.manager.itemError(e), "function" == typeof o && o(t)
                    });
                    let E = new a.Y9S(this._internalLoadingManager);
                    E.setResponseType("arraybuffer"), E.setRequestHeader(this.requestHeader), E.setPath(this.path), E.setWithCredentials(this.withCredentials), E.load(t, async e => {
                        if ("string" == typeof e) throw Error("Invalid gainmap buffer");
                        l = e, await f()
                    }, e => {
                        A = e.lengthComputable, g = e.loaded, m = e.total, C()
                    }, e => {
                        this.manager.itemError(t), "function" == typeof o && o(e)
                    });
                    let w = new a.Y9S(this._internalLoadingManager);
                    return w.setRequestHeader(this.requestHeader), w.setPath(this.path), w.setWithCredentials(this.withCredentials), w.load(r, async e => {
                        if ("string" != typeof e) throw Error("Invalid metadata string");
                        u = JSON.parse(e), await f()
                    }, e => {
                        B = e.lengthComputable, y = e.loaded, v = e.total, C()
                    }, e => {
                        this.manager.itemError(r), "function" == typeof o && o(e)
                    }), c
                }
            }
            class eQ extends eN {
                load(e, t, r, n) {
                    let i = this.prepareQuadRenderer(),
                        o = new a.Y9S(this._internalLoadingManager);
                    return o.setResponseType("arraybuffer"), o.setRequestHeader(this.requestHeader), o.setPath(this.path), o.setWithCredentials(this.withCredentials), this.manager.itemStart(e), o.load(e, async r => {
                        let o, s, a;
                        if ("string" == typeof r) throw Error("Invalid buffer, received [string], was expecting [ArrayBuffer]");
                        let l = new Uint8Array(r);
                        try {
                            let e = await ej(l);
                            o = e.sdr, s = e.gainMap, a = e.metadata
                        } catch (t) {
                            if (t instanceof eU || t instanceof eH) console.warn(`Failure to reconstruct an HDR image from ${e}: Gain map metadata not found in the file, HDRJPGLoader will render the SDR jpeg`), a = {
                                gainMapMin: [0, 0, 0],
                                gainMapMax: [1, 1, 1],
                                gamma: [1, 1, 1],
                                hdrCapacityMin: 0,
                                hdrCapacityMax: 1,
                                offsetHdr: [0, 0, 0],
                                offsetSdr: [0, 0, 0]
                            }, o = l;
                            else throw t
                        }
                        try {
                            await this.render(i, a, o, s)
                        } catch (t) {
                            this.manager.itemError(e), "function" == typeof n && n(t), i.disposeOnDemandRenderer();
                            return
                        }
                        "function" == typeof t && t(i), this.manager.itemEnd(e), i.disposeOnDemandRenderer()
                    }, r, t => {
                        this.manager.itemError(e), "function" == typeof n && n(t)
                    }), i
                }
            }
            let eX = {
                    apartment: "lebombo_1k.hdr",
                    city: "potsdamer_platz_1k.hdr",
                    dawn: "kiara_1_dawn_1k.hdr",
                    forest: "forest_slope_1k.hdr",
                    lobby: "st_fagans_interior_1k.hdr",
                    night: "dikhololo_night_1k.hdr",
                    park: "rooitou_park_1k.hdr",
                    studio: "studio_small_03_1k.hdr",
                    sunset: "venice_sunset_1k.hdr",
                    warehouse: "empty_warehouse_01_1k.hdr"
                },
                eY = "https://raw.githack.com/pmndrs/drei-assets/456060a26bbeb8fdf79326f224b6d99b8bcce736/hdri/",
                eW = e => Array.isArray(e),
                ez = ["/px.png", "/nx.png", "/py.png", "/ny.png", "/pz.png", "/nz.png"];

            function eq({
                files: e = ez,
                path: t = "",
                preset: r,
                colorSpace: n,
                extensions: i
            } = {}) {
                r && (e$(r), e = eX[r], t = eY);
                let l = eW(e),
                    {
                        extension: u,
                        isCubemap: c
                    } = e0(e),
                    f = e1(u);
                if (!f) throw Error("useEnvironment: Unrecognized file extension: " + e);
                let d = (0, s.A)(e => e.gl);
                (0, o.useLayoutEffect)(() => {
                    ("webp" === u || "jpg" === u || "jpeg" === u) && d.domElement.addEventListener("webglcontextlost", function() {
                        s.F.clear(f, l ? [e] : e)
                    }, {
                        once: !0
                    })
                }, [e, d.domElement]);
                let h = (0, s.F)(f, l ? [e] : e, e => {
                        ("webp" === u || "jpg" === u || "jpeg" === u) && e.setRenderer(d), null == e.setPath || e.setPath(t), i && i(e)
                    }),
                    p = l ? h[0] : h;
                if ("jpg" === u || "jpeg" === u || "webp" === u) {
                    var A;
                    p = null == (A = p.renderTarget) ? void 0 : A.texture
                }
                return p.mapping = c ? a.hy7 : a.wfO, p.colorSpace = null != n ? n : c ? "srgb" : "srgb-linear", p
            }
            let eZ = {
                files: ez,
                path: "",
                preset: void 0,
                extensions: void 0
            };
            eq.preload = e => {
                let t = { ...eZ,
                        ...e
                    },
                    {
                        files: r,
                        path: n = ""
                    } = t,
                    {
                        preset: i,
                        extensions: o
                    } = t;
                i && (e$(i), r = eX[i], n = eY);
                let {
                    extension: a
                } = e0(r);
                if ("webp" === a || "jpg" === a || "jpeg" === a) throw Error("useEnvironment: Preloading gainmaps is not supported");
                let l = e1(a);
                if (!l) throw Error("useEnvironment: Unrecognized file extension: " + r);
                s.F.preload(l, eW(r) ? [r] : r, e => {
                    null == e.setPath || e.setPath(n), o && o(e)
                })
            };
            let eV = {
                files: ez,
                preset: void 0
            };

            function e$(e) {
                if (!(e in eX)) throw Error("Preset must be one of: " + Object.keys(eX).join(", "))
            }

            function e0(e) {
                var t;
                let r = eW(e) && 6 === e.length,
                    n = eW(e) && 3 === e.length && e.some(e => e.endsWith("json")),
                    i = eW(e) ? e[0] : e;
                return {
                    extension: r ? "cube" : n ? "webp" : i.startsWith("data:application/exr") ? "exr" : i.startsWith("data:application/hdr") ? "hdr" : i.startsWith("data:image/jpeg") ? "jpg" : null == (t = i.split(".").pop()) || null == (t = t.split("?")) || null == (t = t.shift()) ? void 0 : t.toLowerCase(),
                    isCubemap: r,
                    isGainmap: n
                }
            }

            function e1(e) {
                return "cube" === e ? a.ScU : "hdr" === e ? f : "exr" === e ? ex : "jpg" === e || "jpeg" === e ? eQ : "webp" === e ? eK : null
            }
            eq.clear = e => {
                let t = { ...eV,
                        ...e
                    },
                    {
                        files: r
                    } = t,
                    {
                        preset: n
                    } = t;
                n && (e$(n), r = eX[n]);
                let {
                    extension: i
                } = e0(r), o = e1(i);
                if (!o) throw Error("useEnvironment: Unrecognized file extension: " + r);
                s.F.clear(o, eW(r) ? [r] : r)
            };
            let e2 = e => e.current && e.current.isScene,
                e9 = e => e2(e) ? e.current : e;

            function e8(e, t, r, n, i = {}) {
                var o, a, l, u;
                i = {
                    backgroundBlurriness: 0,
                    backgroundIntensity: 1,
                    backgroundRotation: [0, 0, 0],
                    environmentIntensity: 1,
                    environmentRotation: [0, 0, 0],
                    ...i
                };
                let c = e9(t || r),
                    f = c.background,
                    d = c.environment,
                    h = {
                        backgroundBlurriness: c.backgroundBlurriness,
                        backgroundIntensity: c.backgroundIntensity,
                        backgroundRotation: null != (o = null == (a = c.backgroundRotation) || null == a.clone ? void 0 : a.clone()) ? o : [0, 0, 0],
                        environmentIntensity: c.environmentIntensity,
                        environmentRotation: null != (l = null == (u = c.environmentRotation) || null == u.clone ? void 0 : u.clone()) ? l : [0, 0, 0]
                    };
                return "only" !== e && (c.environment = n), e && (c.background = n), (0, s.q)(c, i), () => {
                    "only" !== e && (c.environment = d), e && (c.background = f), (0, s.q)(c, h)
                }
            }

            function e3({
                scene: e,
                background: t = !1,
                map: r,
                ...n
            }) {
                let i = (0, s.A)(e => e.scene);
                return o.useLayoutEffect(() => {
                    if (r) return e8(t, e, i, r, n)
                }), null
            }

            function e6({
                background: e = !1,
                scene: t,
                blur: r,
                backgroundBlurriness: n,
                backgroundIntensity: i,
                backgroundRotation: a,
                environmentIntensity: l,
                environmentRotation: u,
                ...c
            }) {
                let f = eq(c),
                    d = (0, s.A)(e => e.scene);
                return o.useLayoutEffect(() => e8(e, t, d, f, {
                    backgroundBlurriness: null != r ? r : n,
                    backgroundIntensity: i,
                    backgroundRotation: a,
                    environmentIntensity: l,
                    environmentRotation: u
                })), o.useEffect(() => () => {
                    f.dispose()
                }, [f]), null
            }

            function e5({
                children: e,
                near: t = .1,
                far: r = 1e3,
                resolution: n = 256,
                frames: i = 1,
                map: l,
                background: u = !1,
                blur: c,
                backgroundBlurriness: f,
                backgroundIntensity: d,
                backgroundRotation: h,
                environmentIntensity: p,
                environmentRotation: A,
                scene: m,
                files: g,
                path: B,
                preset: v,
                extensions: y
            }) {
                let C = (0, s.A)(e => e.gl),
                    b = (0, s.A)(e => e.scene),
                    E = o.useRef(null),
                    [w] = o.useState(() => new a.Z58),
                    M = o.useMemo(() => {
                        let e = new a.o6l(n);
                        return e.texture.type = a.ix0, e
                    }, [n]);
                o.useEffect(() => () => {
                    M.dispose()
                }, [M]), o.useLayoutEffect(() => {
                    if (1 === i) {
                        let e = C.autoClear;
                        C.autoClear = !0, E.current.update(C, w), C.autoClear = e
                    }
                    return e8(u, m, b, M.texture, {
                        backgroundBlurriness: null != c ? c : f,
                        backgroundIntensity: d,
                        backgroundRotation: h,
                        environmentIntensity: p,
                        environmentRotation: A
                    })
                }, [e, w, M.texture, m, b, u, i, C]);
                let R = 1;
                return (0, s.C)(() => {
                    if (i === 1 / 0 || R < i) {
                        let e = C.autoClear;
                        C.autoClear = !0, E.current.update(C, w), C.autoClear = e, R++
                    }
                }), o.createElement(o.Fragment, null, (0, s.o)(o.createElement(o.Fragment, null, e, o.createElement("cubeCamera", {
                    ref: E,
                    args: [t, r, M]
                }), g || v ? o.createElement(e6, {
                    background: !0,
                    files: g,
                    preset: v,
                    path: B,
                    extensions: y
                }) : l ? o.createElement(e3, {
                    background: !0,
                    map: l,
                    extensions: y
                }) : null), w))
            }

            function e4(e) {
                var t, r, n, a;
                let l = eq(e),
                    u = e.map || l;
                o.useMemo(() => (0, s.e)({
                    GroundProjectedEnvImpl: c
                }), []), o.useEffect(() => () => {
                    l.dispose()
                }, [l]);
                let f = o.useMemo(() => [u], [u]),
                    d = null == (t = e.ground) ? void 0 : t.height,
                    h = null == (r = e.ground) ? void 0 : r.radius,
                    p = null != (n = null == (a = e.ground) ? void 0 : a.scale) ? n : 1e3;
                return o.createElement(o.Fragment, null, o.createElement(e3, (0, i.A)({}, e, {
                    map: u
                })), o.createElement("groundProjectedEnvImpl", {
                    args: f,
                    scale: p,
                    height: d,
                    radius: h
                }))
            }

            function e7(e) {
                return e.ground ? o.createElement(e4, e) : e.map ? o.createElement(e3, e) : e.children ? o.createElement(e5, e) : o.createElement(e6, e)
            }
        },
        3342: (e, t, r) => {
            "use strict";
            r.d(t, {
                AQ: () => et,
                Ux: () => eC,
                Xc: () => eA,
                Y7: () => eR,
                hE: () => eM,
                wV: () => em
            });
            var n = r(6729),
                i = r(8789),
                o = r(6797),
                s = r(4312),
                a = r(4187),
                l = r(5967);

            function u(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), r.push.apply(r, n)
                }
                return r
            }

            function c(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(r), !0).forEach(function(t) {
                        ! function(e, t, r) {
                            var n;
                            (t = "symbol" == typeof(n = function(e, t) {
                                if ("object" != typeof e || !e) return e;
                                var r = e[Symbol.toPrimitive];
                                if (void 0 !== r) {
                                    var n = r.call(e, t || "default");
                                    if ("object" != typeof n) return n;
                                    throw TypeError("@@toPrimitive must return a primitive value.")
                                }
                                return ("string" === t ? String : Number)(e)
                            }(t, "string")) ? n : n + "") in e ? Object.defineProperty(e, t, {
                                value: r,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : e[t] = r
                        }(e, t, r[t])
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : u(Object(r)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                    })
                }
                return e
            }
            let f = new s.PTz;
            new s.O9p;
            let d = new s.Pq0;
            new s.B69;
            let h = new s.kn4,
                p = new s.Pq0,
                A = new s.PTz,
                m = new s.Pq0,
                g = e => {
                    let [t, r, n] = e;
                    return new s.Pq0(t, r, n)
                },
                B = ({
                    x: e,
                    y: t,
                    z: r,
                    w: n
                }) => f.set(e, t, r, n),
                v = e => Array.isArray(e) ? new n.Vector3(e[0], e[1], e[2]) : "number" == typeof e ? new n.Vector3(e, e, e) : new n.Vector3(e.x, e.y, e.z),
                y = {
                    fixed: 1,
                    dynamic: 0,
                    kinematicPosition: 2,
                    kinematicVelocity: 3
                },
                C = e => y[e],
                b = (e, t) => {
                    let r = Array.from(e);
                    for (let n = 0; n < e.length / 3; n++) r[3 * n] *= t.x, r[3 * n + 1] *= t.y, r[3 * n + 2] *= t.z;
                    return r
                },
                E = e => e ? e instanceof s.PTz ? [e.x, e.y, e.z, e.w] : e instanceof s.Pq0 || e instanceof s.O9p ? [e.x, e.y, e.z] : Array.isArray(e) ? e : [e] : [0];

            function w(e) {
                let t = (0, o.useRef)(void 0);
                return void 0 === t.current && (t.current = {
                    value: "function" == typeof e ? e() : e
                }), t.current.value
            }
            let M = e => {
                    let t = (0, o.useRef)(e),
                        r = (0, o.useRef)(0),
                        n = (0, o.useRef)(0);
                    (0, o.useEffect)(() => {
                        t.current = e
                    }, [e]), (0, o.useEffect)(() => {
                        let e = () => {
                            let i = performance.now(),
                                o = i - n.current;
                            r.current = requestAnimationFrame(e), t.current(o / 1e3), n.current = i
                        };
                        return r.current = requestAnimationFrame(e), () => cancelAnimationFrame(r.current)
                    }, [])
                },
                R = ({
                    onStep: e,
                    updatePriority: t
                }) => ((0, i.C)((t, r) => {
                    e(r)
                }, t), null),
                F = ({
                    onStep: e
                }) => (M(t => {
                    e(t)
                }), null);
            var x = (0, o.memo)(({
                onStep: e,
                type: t,
                updatePriority: r
            }) => "independent" === t ? o.createElement(F, {
                onStep: e
            }) : o.createElement(R, {
                onStep: e,
                updatePriority: r
            }));

            function I(e, t) {
                if (null == e) return {};
                var r, n, i = function(e, t) {
                    if (null == e) return {};
                    var r = {};
                    for (var n in e)
                        if (({}).hasOwnProperty.call(e, n)) {
                            if (-1 !== t.indexOf(n)) continue;
                            r[n] = e[n]
                        }
                    return r
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    for (n = 0; n < o.length; n++) r = o[n], -1 === t.indexOf(r) && ({}).propertyIsEnumerable.call(e, r) && (i[r] = e[r])
                }
                return i
            }
            let T = ["mass", "linearDamping", "angularDamping", "type", "onCollisionEnter", "onCollisionExit", "onIntersectionEnter", "onIntersectionExit", "onContactForce", "children", "canSleep", "ccd", "gravityScale", "softCcdPrediction", "ref"],
                S = (e, t, r) => {
                    let n = t.slice();
                    if ("heightfield" === e) {
                        let e = n[3];
                        return e.x *= r.x, e.x *= r.y, e.x *= r.z, n
                    }
                    if ("trimesh" === e || "convexHull" === e) return n[0] = b(n[0], r), n;
                    let i = [r.x, r.y, r.z, r.x, r.x];
                    return n.map((e, t) => i[t] * e)
                },
                D = (e, t, r, i) => {
                    let o = S(e.shape, e.args, r),
                        s = n.ColliderDesc[e.shape](...o);
                    return t.createCollider(s, null == i ? void 0 : i())
                },
                O = ["shape", "args"],
                G = "Please pick ONLY ONE of the `density`, `mass` and `massProperties` options.",
                P = (e, t) => {
                    if (void 0 !== t.density) {
                        if (void 0 !== t.mass || void 0 !== t.massProperties) throw Error(G);
                        e.setDensity(t.density);
                        return
                    }
                    if (void 0 !== t.mass) {
                        if (void 0 !== t.massProperties) throw Error(G);
                        e.setMass(t.mass);
                        return
                    }
                    void 0 !== t.massProperties && e.setMassProperties(t.massProperties.mass, t.massProperties.centerOfMass, t.massProperties.principalAngularInertia, t.massProperties.angularInertiaLocalFrame)
                },
                H = {
                    sensor: (e, t) => {
                        e.setSensor(t)
                    },
                    collisionGroups: (e, t) => {
                        e.setCollisionGroups(t)
                    },
                    solverGroups: (e, t) => {
                        e.setSolverGroups(t)
                    },
                    friction: (e, t) => {
                        e.setFriction(t)
                    },
                    frictionCombineRule: (e, t) => {
                        e.setFrictionCombineRule(t)
                    },
                    restitution: (e, t) => {
                        e.setRestitution(t)
                    },
                    restitutionCombineRule: (e, t) => {
                        e.setRestitutionCombineRule(t)
                    },
                    activeCollisionTypes: (e, t) => {
                        e.setActiveCollisionTypes(t)
                    },
                    contactSkin: (e, t) => {
                        e.setContactSkin(t)
                    },
                    quaternion: () => {},
                    position: () => {},
                    rotation: () => {},
                    scale: () => {}
                },
                U = Object.keys(H),
                _ = (e, t, r) => {
                    let n = r.get(e.handle);
                    if (n) {
                        var i;
                        let r = n.object.parent.getWorldScale(d),
                            o = null == (i = n.worldParent) ? void 0 : i.matrixWorld.clone().invert();
                        n.object.updateWorldMatrix(!0, !1), h.copy(n.object.matrixWorld), o && h.premultiply(o), h.decompose(p, A, m), e.parent() ? (e.setTranslationWrtParent({
                            x: p.x * r.x,
                            y: p.y * r.y,
                            z: p.z * r.z
                        }), e.setRotationWrtParent(A)) : (e.setTranslation({
                            x: p.x * r.x,
                            y: p.y * r.y,
                            z: p.z * r.z
                        }), e.setRotation(A)), U.forEach(r => {
                            if (r in t) {
                                let n = t[r];
                                H[r](e, n, t)
                            }
                        }), P(e, t)
                    }
                },
                L = (e, t, r) => {
                    let n = (0, o.useMemo)(() => U.flatMap(e => E(t[e])), [t]);
                    (0, o.useEffect)(() => {
                        _(e(), t, r)
                    }, [...n, e])
                },
                J = e => {
                    let t = !1;
                    return e.traverseAncestors(e => {
                        "MeshCollider" === e.userData.r3RapierType && (t = !0)
                    }), t
                },
                j = (e, t, r) => ({
                    collider: e,
                    worldParent: r || void 0,
                    object: t
                }),
                k = {
                    cuboid: "cuboid",
                    ball: "ball",
                    hull: "convexHull",
                    trimesh: "trimesh"
                },
                N = ({
                    object: e,
                    ignoreMeshColliders: t = !0,
                    options: r
                }) => {
                    let n = [];
                    e.updateWorldMatrix(!0, !1);
                    let i = e.matrixWorld.clone().invert(),
                        o = e => {
                            if ("isMesh" in e) {
                                if (t && J(e)) return;
                                let o = e.getWorldScale(m),
                                    a = k[r.colliders || "cuboid"];
                                e.updateWorldMatrix(!0, !1), h.copy(e.matrixWorld).premultiply(i).decompose(p, A, m);
                                let l = new s.O9p().setFromQuaternion(A, "XYZ"),
                                    {
                                        geometry: u
                                    } = e,
                                    {
                                        args: f,
                                        offset: d
                                    } = K(u, r.colliders || "cuboid"),
                                    g = c(c({}, Y(r)), {}, {
                                        args: f,
                                        shape: a,
                                        rotation: [l.x, l.y, l.z],
                                        position: [p.x + d.x * o.x, p.y + d.y * o.y, p.z + d.z * o.z],
                                        scale: [o.x, o.y, o.z]
                                    });
                                n.push(g)
                            }
                        };
                    return r.includeInvisible ? e.traverse(o) : e.traverseVisible(o), n
                },
                K = (e, t) => {
                    switch (t) {
                        case "cuboid":
                            {
                                e.computeBoundingBox();
                                let {
                                    boundingBox: t
                                } = e,
                                r = t.getSize(new s.Pq0);
                                return {
                                    args: [r.x / 2, r.y / 2, r.z / 2],
                                    offset: t.getCenter(new s.Pq0)
                                }
                            }
                        case "ball":
                            {
                                e.computeBoundingSphere();
                                let {
                                    boundingSphere: t
                                } = e;
                                return {
                                    args: [t.radius],
                                    offset: t.center
                                }
                            }
                        case "trimesh":
                            {
                                var r;
                                let t = e.index ? e.clone() : (0, l.ec)(e);
                                return {
                                    args: [t.attributes.position.array, null == (r = t.index) ? void 0 : r.array],
                                    offset: new s.Pq0
                                }
                            }
                        case "hull":
                            return {
                                args: [e.clone().attributes.position.array],
                                offset: new s.Pq0
                            }
                    }
                    return {
                        args: [],
                        offset: new s.Pq0
                    }
                },
                Q = e => ({
                    collision: !!(null != e && e.onCollisionEnter || null != e && e.onCollisionExit || null != e && e.onIntersectionEnter || null != e && e.onIntersectionExit),
                    contactForce: !!(null != e && e.onContactForce)
                }),
                X = (e, t, r, i = {}) => {
                    let {
                        onCollisionEnter: s,
                        onCollisionExit: a,
                        onIntersectionEnter: l,
                        onIntersectionExit: u,
                        onContactForce: c
                    } = t;
                    (0, o.useEffect)(() => {
                        let o = e();
                        if (o) {
                            let {
                                collision: e,
                                contactForce: f
                            } = Q(t), d = e || i.collision, h = f || i.contactForce;
                            d && h ? o.setActiveEvents(n.ActiveEvents.COLLISION_EVENTS | n.ActiveEvents.CONTACT_FORCE_EVENTS) : d ? o.setActiveEvents(n.ActiveEvents.COLLISION_EVENTS) : h && o.setActiveEvents(n.ActiveEvents.CONTACT_FORCE_EVENTS), r.set(o.handle, {
                                onCollisionEnter: s,
                                onCollisionExit: a,
                                onIntersectionEnter: l,
                                onIntersectionExit: u,
                                onContactForce: c
                            })
                        }
                        return () => {
                            o && r.delete(o.handle)
                        }
                    }, [s, a, l, u, c, i])
                },
                Y = (e = {}) => I(e, T),
                W = () => {
                    let e = (0, o.useContext)(V);
                    if (!e) throw Error("react-three-rapier: useRapier must be used within <Physics />!");
                    return e
                },
                z = (e, t, r = !0) => {
                    let [n, i] = (0, o.useState)([]);
                    return (0, o.useEffect)(() => {
                        e.current && !1 !== t.colliders && i(N({
                            object: e.current,
                            options: t,
                            ignoreMeshColliders: r
                        }))
                    }, [t.colliders]), n
                },
                q = (0, o.memo)(() => {
                    let {
                        world: e
                    } = W(), t = (0, o.useRef)(null);
                    return (0, i.C)(() => {
                        let r = t.current;
                        if (!r) return;
                        let n = e.debugRender(),
                            i = new s.LoY;
                        i.setAttribute("position", new s.THS(n.vertices, 3)), i.setAttribute("color", new s.THS(n.colors, 4)), r.geometry.dispose(), r.geometry = i
                    }), o.createElement("group", null, o.createElement("lineSegments", {
                        ref: t,
                        frustumCulled: !1
                    }, o.createElement("lineBasicMaterial", {
                        color: 0xffffff,
                        vertexColors: !0
                    }), o.createElement("bufferGeometry", null)))
                }),
                Z = e => {
                    let t;
                    return {
                        proxy: new Proxy({}, {
                            get: (r, n) => (t || (t = e()), Reflect.get(t, n)),
                            set: (r, n, i) => (t || (t = e()), Reflect.set(t, n, i))
                        }),
                        reset: () => {
                            t = void 0
                        },
                        set: e => {
                            t = e
                        }
                    }
                },
                V = (0, o.createContext)(void 0),
                $ = (e, t) => {
                    var r, n, i, o, s, a;
                    return {
                        target: {
                            rigidBody: e.rigidBody.object,
                            collider: e.collider.object,
                            colliderObject: null == (r = e.collider.state) ? void 0 : r.object,
                            rigidBodyObject: null == (n = e.rigidBody.state) ? void 0 : n.object
                        },
                        other: {
                            rigidBody: t.rigidBody.object,
                            collider: t.collider.object,
                            colliderObject: null == (i = t.collider.state) ? void 0 : i.object,
                            rigidBodyObject: null == (o = t.rigidBody.state) ? void 0 : o.object
                        },
                        rigidBody: t.rigidBody.object,
                        collider: t.collider.object,
                        colliderObject: null == (s = t.collider.state) ? void 0 : s.object,
                        rigidBodyObject: null == (a = t.rigidBody.state) ? void 0 : a.object
                    }
                },
                ee = async () => {
                    let e = await Promise.resolve().then(r.bind(r, 6729));
                    return await e.init(), e
                },
                et = e => {
                    let {
                        colliders: t = "cuboid",
                        children: r,
                        timeStep: l = 1 / 60,
                        paused: u = !1,
                        interpolate: f = !0,
                        updatePriority: d,
                        updateLoop: y = "follow",
                        debug: C = !1,
                        gravity: b = [0, -9.81, 0],
                        allowedLinearError: E = .001,
                        predictionDistance: M = .002,
                        numSolverIterations: R = 4,
                        numAdditionalFrictionIterations: F = 4,
                        numInternalPgsIterations: I = 1,
                        minIslandSize: T = 128,
                        maxCcdSubsteps: S = 1,
                        contactNaturalFrequency: D = 30,
                        lengthUnit: O = 1
                    } = e, G = (0, a.DY)(ee, ["@react-thee/rapier", ee]), {
                        invalidate: P
                    } = (0, i.A)(), H = w(() => new Map), U = w(() => new Map), _ = w(() => new Map), L = w(() => new Map), J = w(() => new n.EventQueue(!1)), j = w(() => new Set), k = w(() => new Set), {
                        proxy: N,
                        reset: K,
                        set: Q
                    } = w(() => Z(() => new G.World(g(b))));
                    (0, o.useEffect)(() => () => {
                        N.free(), K()
                    }, []), (0, o.useEffect)(() => {
                        N.gravity = v(b), N.integrationParameters.numSolverIterations = R, N.integrationParameters.numAdditionalFrictionIterations = F, N.integrationParameters.numInternalPgsIterations = I, N.integrationParameters.normalizedAllowedLinearError = E, N.integrationParameters.minIslandSize = T, N.integrationParameters.maxCcdSubsteps = S, N.integrationParameters.normalizedPredictionDistance = M, N.lengthUnit = O, N.integrationParameters.contact_natural_frequency = D
                    }, [N, ...b, R, F, I, E, T, S, M, O, D]);
                    let X = (0, o.useCallback)(e => {
                            var t;
                            let r = N.getCollider(e),
                                n = L.get(e),
                                i = U.get(e),
                                o = null == r || null == (t = r.parent()) ? void 0 : t.handle,
                                s = void 0 !== o ? N.getRigidBody(o) : void 0,
                                a = s && void 0 !== o ? _.get(o) : void 0;
                            return {
                                collider: {
                                    object: r,
                                    events: n,
                                    state: i
                                },
                                rigidBody: {
                                    object: s,
                                    events: a,
                                    state: void 0 !== o ? H.get(o) : void 0
                                }
                            }
                        }, []),
                        [Y] = (0, o.useState)({
                            previousState: {},
                            accumulator: 0
                        }),
                        W = (0, o.useCallback)(e => {
                            let t = "vary" === l,
                                r = s.cj9.clamp(e, 0, .5),
                                n = e => {
                                    j.forEach(e => {
                                        e.current(N)
                                    }), N.timestep = e, N.step(J), k.forEach(e => {
                                        e.current(N)
                                    })
                                };
                            if (t) n(r);
                            else
                                for (Y.accumulator += r; Y.accumulator >= l;) f && (Y.previousState = {}, N.forEachRigidBody(e => {
                                    Y.previousState[e.handle] = {
                                        position: e.translation(),
                                        rotation: e.rotation()
                                    }
                                })), n(l), Y.accumulator -= l;
                            let i = t || !f || u ? 1 : Y.accumulator / l;
                            H.forEach((e, t) => {
                                let r = N.getRigidBody(t),
                                    n = _.get(t);
                                if (null != n && n.onSleep || null != n && n.onWake) {
                                    var o, s;
                                    r.isSleeping() && !e.isSleeping && (null == n || null == (o = n.onSleep) || o.call(n)), !r.isSleeping() && e.isSleeping && (null == n || null == (s = n.onWake) || s.call(n)), e.isSleeping = r.isSleeping()
                                }
                                if (!r || r.isSleeping() && !("isInstancedMesh" in e.object) || !e.setMatrix) return;
                                let a = r.translation(),
                                    l = r.rotation(),
                                    u = Y.previousState[t];
                                u && (h.compose(u.position, B(u.rotation), e.scale).premultiply(e.invertedWorldMatrix).decompose(p, A, m), "mesh" == e.meshType && (e.object.position.copy(p), e.object.quaternion.copy(A))), h.compose(a, B(l), e.scale).premultiply(e.invertedWorldMatrix).decompose(p, A, m), "instancedMesh" == e.meshType ? e.setMatrix(h) : (e.object.position.lerp(p, i), e.object.quaternion.slerp(A, i))
                            }), J.drainCollisionEvents((e, t, r) => {
                                var n, i, o, s, a, l, u, f, d, h, p, A, m, g, B, v, y, C, b, E, w, M, R, F;
                                let x = X(e),
                                    I = X(t);
                                if (!(null != x && x.collider.object) || !(null != I && I.collider.object)) return;
                                let T = $(x, I),
                                    S = $(I, x);
                                r ? N.contactPair(x.collider.object, I.collider.object, (e, t) => {
                                    var r, n, i, o, s, a, l, u;
                                    null == (r = x.rigidBody.events) || null == (n = r.onCollisionEnter) || n.call(r, c(c({}, T), {}, {
                                        manifold: e,
                                        flipped: t
                                    })), null == (i = I.rigidBody.events) || null == (o = i.onCollisionEnter) || o.call(i, c(c({}, S), {}, {
                                        manifold: e,
                                        flipped: t
                                    })), null == (s = x.collider.events) || null == (a = s.onCollisionEnter) || a.call(s, c(c({}, T), {}, {
                                        manifold: e,
                                        flipped: t
                                    })), null == (l = I.collider.events) || null == (u = l.onCollisionEnter) || u.call(l, c(c({}, S), {}, {
                                        manifold: e,
                                        flipped: t
                                    }))
                                }) : (null == (n = x.rigidBody.events) || null == (i = n.onCollisionExit) || i.call(n, T), null == (o = I.rigidBody.events) || null == (s = o.onCollisionExit) || s.call(o, S), null == (a = x.collider.events) || null == (l = a.onCollisionExit) || l.call(a, T), null == (u = I.collider.events) || null == (f = u.onCollisionExit) || f.call(u, S)), r ? N.intersectionPair(x.collider.object, I.collider.object) && (null == (d = x.rigidBody.events) || null == (h = d.onIntersectionEnter) || h.call(d, T), null == (p = I.rigidBody.events) || null == (A = p.onIntersectionEnter) || A.call(p, S), null == (m = x.collider.events) || null == (g = m.onIntersectionEnter) || g.call(m, T), null == (B = I.collider.events) || null == (v = B.onIntersectionEnter) || v.call(B, S)) : (null == (y = x.rigidBody.events) || null == (C = y.onIntersectionExit) || C.call(y, T), null == (b = I.rigidBody.events) || null == (E = b.onIntersectionExit) || E.call(b, S), null == (w = x.collider.events) || null == (M = w.onIntersectionExit) || M.call(w, T), null == (R = I.collider.events) || null == (F = R.onIntersectionExit) || F.call(R, S))
                            }), J.drainContactForceEvents(e => {
                                var t, r, n, i, o, s, a, l;
                                let u = X(e.collider1()),
                                    f = X(e.collider2());
                                if (!(null != u && u.collider.object) || !(null != f && f.collider.object)) return;
                                let d = $(u, f),
                                    h = $(f, u);
                                null == (t = u.rigidBody.events) || null == (r = t.onContactForce) || r.call(t, c(c({}, d), {}, {
                                    totalForce: e.totalForce(),
                                    totalForceMagnitude: e.totalForceMagnitude(),
                                    maxForceDirection: e.maxForceDirection(),
                                    maxForceMagnitude: e.maxForceMagnitude()
                                })), null == (n = f.rigidBody.events) || null == (i = n.onContactForce) || i.call(n, c(c({}, h), {}, {
                                    totalForce: e.totalForce(),
                                    totalForceMagnitude: e.totalForceMagnitude(),
                                    maxForceDirection: e.maxForceDirection(),
                                    maxForceMagnitude: e.maxForceMagnitude()
                                })), null == (o = u.collider.events) || null == (s = o.onContactForce) || s.call(o, c(c({}, d), {}, {
                                    totalForce: e.totalForce(),
                                    totalForceMagnitude: e.totalForceMagnitude(),
                                    maxForceDirection: e.maxForceDirection(),
                                    maxForceMagnitude: e.maxForceMagnitude()
                                })), null == (a = f.collider.events) || null == (l = a.onContactForce) || l.call(a, c(c({}, h), {}, {
                                    totalForce: e.totalForce(),
                                    totalForceMagnitude: e.totalForceMagnitude(),
                                    maxForceDirection: e.maxForceDirection(),
                                    maxForceMagnitude: e.maxForceMagnitude()
                                }))
                            }), N.forEachActiveRigidBody(() => {
                                P()
                            })
                        }, [u, l, f, N]),
                        z = (0, o.useMemo)(() => ({
                            rapier: G,
                            world: N,
                            setWorld: e => {
                                Q(e)
                            },
                            physicsOptions: {
                                colliders: t,
                                gravity: b
                            },
                            rigidBodyStates: H,
                            colliderStates: U,
                            rigidBodyEvents: _,
                            colliderEvents: L,
                            beforeStepCallbacks: j,
                            afterStepCallbacks: k,
                            isPaused: u,
                            isDebug: C,
                            step: W
                        }), [u, W, C, t, b]),
                        et = (0, o.useCallback)(e => {
                            u || W(e)
                        }, [u, W]);
                    return o.createElement(V.Provider, {
                        value: z
                    }, o.createElement(x, {
                        onStep: et,
                        type: y,
                        updatePriority: d
                    }), C && o.createElement(q, null), r)
                };

            function er() {
                return (er = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r)({}).hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }).apply(null, arguments)
            }
            let en = (e, t = null) => {
                    let r = (0, o.useRef)(t);
                    return e && "function" != typeof e ? (e.current || (e.current = r.current), e) : r
                },
                ei = (e, t, r) => {
                    let n = (0, o.useRef)(void 0),
                        i = (0, o.useCallback)(() => (n.current || (n.current = e()), n.current), r);
                    return (0, o.useEffect)(() => {
                        let e = i(),
                            r = () => t(e);
                        return () => {
                            r(), n.current = void 0
                        }
                    }, [i]), i
                },
                eo = e => {
                    var t;
                    let r = C((null == e ? void 0 : e.type) || "dynamic"),
                        i = new n.RigidBodyDesc(r);
                    return i.canSleep = null == (t = null == e ? void 0 : e.canSleep) || t, i
                },
                es = ({
                    rigidBody: e,
                    object: t,
                    setMatrix: r,
                    getMatrix: n,
                    worldScale: i,
                    meshType: o = "mesh"
                }) => {
                    t.updateWorldMatrix(!0, !1);
                    let s = t.parent.matrixWorld.clone().invert();
                    return {
                        object: t,
                        rigidBody: e,
                        invertedWorldMatrix: s,
                        setMatrix: r || (e => {
                            t.matrix.copy(e)
                        }),
                        getMatrix: n || (e => e.copy(t.matrix)),
                        scale: i || t.getWorldScale(m).clone(),
                        isSleeping: !1,
                        meshType: o
                    }
                },
                ea = ["args", "colliders", "canSleep"],
                el = {
                    gravityScale: (e, t) => {
                        e.setGravityScale(t, !0)
                    },
                    additionalSolverIterations(e, t) {
                        e.setAdditionalSolverIterations(t)
                    },
                    linearDamping: (e, t) => {
                        e.setLinearDamping(t)
                    },
                    angularDamping: (e, t) => {
                        e.setAngularDamping(t)
                    },
                    dominanceGroup: (e, t) => {
                        e.setDominanceGroup(t)
                    },
                    enabledRotations: (e, [t, r, n]) => {
                        e.setEnabledRotations(t, r, n, !0)
                    },
                    enabledTranslations: (e, [t, r, n]) => {
                        e.setEnabledTranslations(t, r, n, !0)
                    },
                    lockRotations: (e, t) => {
                        e.lockRotations(t, !0)
                    },
                    lockTranslations: (e, t) => {
                        e.lockTranslations(t, !0)
                    },
                    angularVelocity: (e, [t, r, n]) => {
                        e.setAngvel({
                            x: t,
                            y: r,
                            z: n
                        }, !0)
                    },
                    linearVelocity: (e, [t, r, n]) => {
                        e.setLinvel({
                            x: t,
                            y: r,
                            z: n
                        }, !0)
                    },
                    ccd: (e, t) => {
                        e.enableCcd(t)
                    },
                    softCcdPrediction: (e, t) => {
                        e.setSoftCcdPrediction(t)
                    },
                    userData: (e, t) => {
                        e.userData = t
                    },
                    type(e, t) {
                        e.setBodyType(C(t), !0)
                    },
                    position: () => {},
                    rotation: () => {},
                    quaternion: () => {},
                    scale: () => {}
                },
                eu = Object.keys(el),
                ec = (e, t, r, n = !0) => {
                    if (!e) return;
                    let i = r.get(e.handle);
                    i && (n && (i.object.updateWorldMatrix(!0, !1), h.copy(i.object.matrixWorld).decompose(p, A, m), e.setTranslation(p, !1), e.setRotation(A, !1)), eu.forEach(r => {
                        r in t && el[r](e, t[r])
                    }))
                },
                ef = (e, t, r, n = !0) => {
                    let i = (0, o.useMemo)(() => eu.flatMap(e => E(t[e])), [t]);
                    (0, o.useEffect)(() => {
                        ec(e(), t, r, n)
                    }, i)
                },
                ed = (e, t, r) => {
                    let {
                        onWake: n,
                        onSleep: i,
                        onCollisionEnter: s,
                        onCollisionExit: a,
                        onIntersectionEnter: l,
                        onIntersectionExit: u,
                        onContactForce: c
                    } = t, f = {
                        onWake: n,
                        onSleep: i,
                        onCollisionEnter: s,
                        onCollisionExit: a,
                        onIntersectionEnter: l,
                        onIntersectionExit: u,
                        onContactForce: c
                    };
                    (0, o.useEffect)(() => {
                        let t = e();
                        return r.set(t.handle, f), () => {
                            r.delete(t.handle)
                        }
                    }, [n, i, s, a, l, u, c])
                },
                eh = ({
                    x: e,
                    y: t,
                    z: r
                } = {
                    x: 0,
                    y: 0,
                    z: 0
                }) => new s.Pq0(e, t, r),
                ep = (0, o.memo)(e => {
                    let {
                        children: t,
                        position: r,
                        rotation: n,
                        quaternion: i,
                        scale: s,
                        name: a
                    } = e, {
                        world: l,
                        colliderEvents: u,
                        colliderStates: f
                    } = W(), d = ey(), h = en(e.ref), p = (0, o.useRef)(null), A = ei(() => {
                        let t = D(e, l, p.current.getWorldScale(eh()), null == d ? void 0 : d.getRigidBody);
                        return "function" == typeof e.ref && e.ref(t), h.current = t, t
                    }, e => {
                        l.getCollider(e.handle) && l.removeCollider(e, !0)
                    }, [...O.flatMap(t => Array.isArray(e[t]) ? e[t] : [e[t]]), d]);
                    (0, o.useEffect)(() => {
                        let e = A();
                        return f.set(e.handle, j(e, p.current, null == d ? void 0 : d.ref.current)), () => {
                            f.delete(e.handle)
                        }
                    }, [A]);
                    let m = (0, o.useMemo)(() => c(c({}, Y(null == d ? void 0 : d.options)), e), [e, null == d ? void 0 : d.options]);
                    return L(A, m, f), X(A, m, u, Q(null == d ? void 0 : d.options)), o.createElement("object3D", {
                        position: r,
                        rotation: n,
                        quaternion: i,
                        scale: s,
                        ref: p,
                        name: a
                    }, t)
                }),
                eA = o.forwardRef((e, t) => o.createElement(ep, er({}, e, {
                    shape: "cuboid",
                    ref: t
                })));
            eA.displayName = "CuboidCollider", o.forwardRef((e, t) => o.createElement(ep, er({}, e, {
                shape: "roundCuboid",
                ref: t
            }))).displayName = "RoundCuboidCollider";
            let em = o.forwardRef((e, t) => o.createElement(ep, er({}, e, {
                shape: "ball",
                ref: t
            })));
            em.displayName = "BallCollider", o.forwardRef((e, t) => o.createElement(ep, er({}, e, {
                shape: "capsule",
                ref: t
            }))).displayName = "CapsuleCollider", o.forwardRef((e, t) => o.createElement(ep, er({}, e, {
                shape: "heightfield",
                ref: t
            }))).displayName = "HeightfieldCollider", o.forwardRef((e, t) => o.createElement(ep, er({}, e, {
                shape: "trimesh",
                ref: t
            }))).displayName = "TrimeshCollider", o.forwardRef((e, t) => o.createElement(ep, er({}, e, {
                shape: "cone",
                ref: t
            }))).displayName = "ConeCollider", o.forwardRef((e, t) => o.createElement(ep, er({}, e, {
                shape: "roundCone",
                ref: t
            }))).displayName = "RoundConeCollider";
            let eg = o.forwardRef((e, t) => o.createElement(ep, er({}, e, {
                shape: "cylinder",
                ref: t
            })));
            eg.displayName = "CylinderCollider", eg.displayName = "RoundCylinderCollider", o.forwardRef((e, t) => o.createElement(ep, er({}, e, {
                shape: "convexHull",
                ref: t
            }))).displayName = "ConvexHullCollider";
            let eB = ["ref", "children", "type", "position", "rotation", "scale", "quaternion", "transformState"],
                ev = (0, o.createContext)(void 0),
                ey = () => (0, o.useContext)(ev),
                eC = (0, o.memo)(e => {
                    let {
                        ref: t,
                        children: r,
                        type: n,
                        position: i,
                        rotation: s,
                        scale: a,
                        quaternion: l,
                        transformState: u
                    } = e, f = I(e, eB), d = (0, o.useRef)(null), h = en(t), {
                        world: p,
                        rigidBodyStates: A,
                        physicsOptions: m,
                        rigidBodyEvents: g
                    } = W(), B = (0, o.useMemo)(() => c(c(c({}, m), e), {}, {
                        children: void 0
                    }), [m, e]), v = ea.flatMap(e => Array.isArray(B[e]) ? [...B[e]] : B[e]), y = z(d, B), C = ei(() => {
                        let e = eo(B),
                            r = p.createRigidBody(e);
                        return "function" == typeof t && t(r), h.current = r, r
                    }, e => {
                        p.getRigidBody(e.handle) && p.removeRigidBody(e)
                    }, v);
                    (0, o.useEffect)(() => {
                        let t = C(),
                            r = es({
                                rigidBody: t,
                                object: d.current
                            });
                        return A.set(t.handle, e.transformState ? e.transformState(r) : r), () => {
                            A.delete(t.handle)
                        }
                    }, [C]), ef(C, B, A), ed(C, B, g);
                    let b = (0, o.useMemo)(() => ({
                        ref: d,
                        getRigidBody: C,
                        options: B
                    }), [C]);
                    return o.createElement(ev.Provider, {
                        value: b
                    }, o.createElement("object3D", er({
                        ref: d
                    }, f, {
                        position: i,
                        rotation: s,
                        quaternion: l,
                        scale: a
                    }), r, y.map((e, t) => o.createElement(ep, er({
                        key: t
                    }, e)))))
                });
            eC.displayName = "RigidBody", (0, o.memo)(e => {
                let {
                    children: t,
                    type: r
                } = e, {
                    physicsOptions: n
                } = W(), i = (0, o.useRef)(null), {
                    options: s
                } = ey(), a = z(i, (0, o.useMemo)(() => c(c(c({}, n), s), {}, {
                    children: void 0,
                    colliders: r
                }), [n, s]), !1);
                return o.createElement("object3D", {
                    ref: i,
                    userData: {
                        r3RapierType: "MeshCollider"
                    }
                }, t, a.map((e, t) => o.createElement(ep, er({
                    key: t
                }, e))))
            }).displayName = "MeshCollider";
            let eb = ["ref"],
                eE = ["children", "instances", "colliderNodes", "position", "rotation", "quaternion", "scale"];
            (0, o.memo)(e => {
                let {
                    ref: t
                } = e, r = I(e, eb), n = en(t, []), i = (0, o.useRef)(null), a = (0, o.useRef)(null), {
                    children: l,
                    instances: u,
                    colliderNodes: f = [],
                    position: d,
                    rotation: h,
                    quaternion: p,
                    scale: A
                } = r, m = I(r, eE), g = z(i, c(c({}, r), {}, {
                    children: void 0
                })), B = () => {
                    let e = a.current.children[0];
                    if (e && "isInstancedMesh" in e) return e
                };
                (0, o.useEffect)(() => {
                    let e = B();
                    e ? e.instanceMatrix.setUsage(s.Vnu) : console.warn("InstancedRigidBodies expects exactly one child, which must be an InstancedMesh")
                }, []);
                let v = (e, t) => {
                    let r = B();
                    return r ? c(c({}, e), {}, {
                        getMatrix: e => (r.getMatrixAt(t, e), e),
                        setMatrix: e => {
                            r.setMatrixAt(t, e), r.instanceMatrix.needsUpdate = !0
                        },
                        meshType: "instancedMesh"
                    }) : e
                };
                return o.createElement("object3D", er({
                    ref: i
                }, m, {
                    position: d,
                    rotation: h,
                    quaternion: p,
                    scale: A
                }), o.createElement("object3D", {
                    ref: a
                }, l), null == u ? void 0 : u.map((e, t) => o.createElement(eC, er({}, m, e, {
                    ref: e => {
                        n.current[t] = e
                    },
                    transformState: e => v(e, t)
                }), o.createElement(o.Fragment, null, f.map((e, t) => o.createElement(o.Fragment, {
                    key: t
                }, e)), g.map((e, t) => o.createElement(ep, er({
                    key: t
                }, e)))))))
            }).displayName = "InstancedRigidBodies";
            let ew = (e, t, r) => {
                    let {
                        world: n
                    } = W(), i = (0, o.useRef)(void 0);
                    return ei(() => {
                        if (e.current && t.current) {
                            let o = n.createImpulseJoint(r, e.current, t.current, !0);
                            return i.current = o, o
                        }
                    }, e => {
                        e && (i.current = void 0, n.getImpulseJoint(e.handle) && n.removeImpulseJoint(e, !0))
                    }, []), i
                },
                eM = (e, t, [r, n]) => {
                    let {
                        rapier: i
                    } = W();
                    return ew(e, t, i.JointData.spherical(v(r), v(n)))
                },
                eR = (e, t, [r, n, i]) => {
                    let {
                        rapier: o
                    } = W(), s = v(r), a = v(n);
                    return ew(e, t, o.JointData.rope(i, s, a))
                }
        },
        3483: (e, t, r) => {
            "use strict";
            r.d(t, {
                Hl: () => d
            });
            var n = r(8789),
                i = r(6797),
                o = r(1759);

            function s(e, t) {
                let r;
                return (...n) => {
                    window.clearTimeout(r), r = window.setTimeout(() => e(...n), t)
                }
            }
            let a = ["x", "y", "top", "bottom", "left", "right", "width", "height"],
                l = (e, t) => a.every(r => e[r] === t[r]);
            var u = r(2087),
                c = r(5881);

            function f({
                ref: e,
                children: t,
                fallback: r,
                resize: a,
                style: u,
                gl: f,
                events: d = n.f,
                eventSource: h,
                eventPrefix: p,
                shadows: A,
                linear: m,
                flat: g,
                legacy: B,
                orthographic: v,
                frameloop: y,
                dpr: C,
                performance: b,
                raycaster: E,
                camera: w,
                scene: M,
                onPointerMissed: R,
                onCreated: F,
                ...x
            }) {
                i.useMemo(() => (0, n.e)(o), []);
                let I = (0, n.u)(),
                    [T, S] = function({
                        debounce: e,
                        scroll: t,
                        polyfill: r,
                        offsetSize: n
                    } = {
                        debounce: 0,
                        scroll: !1,
                        offsetSize: !1
                    }) {
                        var o, a, u;
                        let c = r || ("undefined" == typeof window ? class {} : window.ResizeObserver);
                        if (!c) throw Error("This browser does not support ResizeObserver out of the box. See: https://github.com/react-spring/react-use-measure/#resize-observer-polyfills");
                        let [f, d] = (0, i.useState)({
                            left: 0,
                            top: 0,
                            width: 0,
                            height: 0,
                            bottom: 0,
                            right: 0,
                            x: 0,
                            y: 0
                        }), h = (0, i.useRef)({
                            element: null,
                            scrollContainers: null,
                            resizeObserver: null,
                            lastBounds: f,
                            orientationHandler: null
                        }), p = e ? "number" == typeof e ? e : e.scroll : null, A = e ? "number" == typeof e ? e : e.resize : null, m = (0, i.useRef)(!1);
                        (0, i.useEffect)(() => (m.current = !0, () => void(m.current = !1)));
                        let [g, B, v] = (0, i.useMemo)(() => {
                            let e = () => {
                                if (!h.current.element) return;
                                let {
                                    left: e,
                                    top: t,
                                    width: r,
                                    height: i,
                                    bottom: o,
                                    right: s,
                                    x: a,
                                    y: u
                                } = h.current.element.getBoundingClientRect(), c = {
                                    left: e,
                                    top: t,
                                    width: r,
                                    height: i,
                                    bottom: o,
                                    right: s,
                                    x: a,
                                    y: u
                                };
                                h.current.element instanceof HTMLElement && n && (c.height = h.current.element.offsetHeight, c.width = h.current.element.offsetWidth), Object.freeze(c), m.current && !l(h.current.lastBounds, c) && d(h.current.lastBounds = c)
                            };
                            return [e, A ? s(e, A) : e, p ? s(e, p) : e]
                        }, [d, n, p, A]);

                        function y() {
                            h.current.scrollContainers && (h.current.scrollContainers.forEach(e => e.removeEventListener("scroll", v, !0)), h.current.scrollContainers = null), h.current.resizeObserver && (h.current.resizeObserver.disconnect(), h.current.resizeObserver = null), h.current.orientationHandler && ("orientation" in screen && "removeEventListener" in screen.orientation ? screen.orientation.removeEventListener("change", h.current.orientationHandler) : "onorientationchange" in window && window.removeEventListener("orientationchange", h.current.orientationHandler))
                        }

                        function C() {
                            h.current.element && (h.current.resizeObserver = new c(v), h.current.resizeObserver.observe(h.current.element), t && h.current.scrollContainers && h.current.scrollContainers.forEach(e => e.addEventListener("scroll", v, {
                                capture: !0,
                                passive: !0
                            })), h.current.orientationHandler = () => {
                                v()
                            }, "orientation" in screen && "addEventListener" in screen.orientation ? screen.orientation.addEventListener("change", h.current.orientationHandler) : "onorientationchange" in window && window.addEventListener("orientationchange", h.current.orientationHandler))
                        }
                        return o = v, a = !!t, (0, i.useEffect)(() => {
                            if (a) return window.addEventListener("scroll", o, {
                                capture: !0,
                                passive: !0
                            }), () => void window.removeEventListener("scroll", o, !0)
                        }, [o, a]), u = B, (0, i.useEffect)(() => (window.addEventListener("resize", u), () => void window.removeEventListener("resize", u)), [u]), (0, i.useEffect)(() => {
                            y(), C()
                        }, [t, v, B]), (0, i.useEffect)(() => y, []), [e => {
                            e && e !== h.current.element && (y(), h.current.element = e, h.current.scrollContainers = function e(t) {
                                let r = [];
                                if (!t || t === document.body) return r;
                                let {
                                    overflow: n,
                                    overflowX: i,
                                    overflowY: o
                                } = window.getComputedStyle(t);
                                return [n, i, o].some(e => "auto" === e || "scroll" === e) && r.push(t), [...r, ...e(t.parentElement)]
                            }(e), C())
                        }, f, g]
                    }({
                        scroll: !0,
                        debounce: {
                            scroll: 50,
                            resize: 0
                        },
                        ...a
                    }),
                    D = i.useRef(null),
                    O = i.useRef(null);
                i.useImperativeHandle(e, () => D.current);
                let G = (0, n.a)(R),
                    [P, H] = i.useState(!1),
                    [U, _] = i.useState(!1);
                if (P) throw P;
                if (U) throw U;
                let L = i.useRef(null);
                (0, n.b)(() => {
                    let e = D.current;
                    S.width > 0 && S.height > 0 && e && (L.current || (L.current = (0, n.c)(e)), async function() {
                        await L.current.configure({
                            gl: f,
                            scene: M,
                            events: d,
                            shadows: A,
                            linear: m,
                            flat: g,
                            legacy: B,
                            orthographic: v,
                            frameloop: y,
                            dpr: C,
                            performance: b,
                            raycaster: E,
                            camera: w,
                            size: S,
                            onPointerMissed: (...e) => null == G.current ? void 0 : G.current(...e),
                            onCreated: e => {
                                null == e.events.connect || e.events.connect(h ? (0, n.i)(h) ? h.current : h : O.current), p && e.setEvents({
                                    compute: (e, t) => {
                                        let r = e[p + "X"],
                                            n = e[p + "Y"];
                                        t.pointer.set(r / t.size.width * 2 - 1, -(2 * (n / t.size.height)) + 1), t.raycaster.setFromCamera(t.pointer, t.camera)
                                    }
                                }), null == F || F(e)
                            }
                        }), L.current.render((0, c.jsx)(I, {
                            children: (0, c.jsx)(n.E, {
                                set: _,
                                children: (0, c.jsx)(i.Suspense, {
                                    fallback: (0, c.jsx)(n.B, {
                                        set: H
                                    }),
                                    children: null != t ? t : null
                                })
                            })
                        }))
                    }())
                }), i.useEffect(() => {
                    let e = D.current;
                    if (e) return () => (0, n.d)(e)
                }, []);
                let J = h ? "none" : "auto";
                return (0, c.jsx)("div", {
                    ref: O,
                    style: {
                        position: "relative",
                        width: "100%",
                        height: "100%",
                        overflow: "hidden",
                        pointerEvents: J,
                        ...u
                    },
                    ...x,
                    children: (0, c.jsx)("div", {
                        ref: T,
                        style: {
                            width: "100%",
                            height: "100%"
                        },
                        children: (0, c.jsx)("canvas", {
                            ref: D,
                            style: {
                                display: "block"
                            },
                            children: r
                        })
                    })
                })
            }

            function d(e) {
                return (0, c.jsx)(u.Af, {
                    children: (0, c.jsx)(f, { ...e
                    })
                })
            }
            r(4012), r(1305), r(7077)
        },
        3598: (e, t) => {
            "use strict";

            function r(e, t) {
                var r = e.length;
                for (e.push(t); 0 < r;) {
                    var n = r - 1 >>> 1,
                        i = e[n];
                    if (0 < o(i, t)) e[n] = t, e[r] = i, r = n;
                    else break
                }
            }

            function n(e) {
                return 0 === e.length ? null : e[0]
            }

            function i(e) {
                if (0 === e.length) return null;
                var t = e[0],
                    r = e.pop();
                if (r !== t) {
                    e[0] = r;
                    for (var n = 0, i = e.length, s = i >>> 1; n < s;) {
                        var a = 2 * (n + 1) - 1,
                            l = e[a],
                            u = a + 1,
                            c = e[u];
                        if (0 > o(l, r)) u < i && 0 > o(c, l) ? (e[n] = c, e[u] = r, n = u) : (e[n] = l, e[a] = r, n = a);
                        else if (u < i && 0 > o(c, r)) e[n] = c, e[u] = r, n = u;
                        else break
                    }
                }
                return t
            }

            function o(e, t) {
                var r = e.sortIndex - t.sortIndex;
                return 0 !== r ? r : e.id - t.id
            }
            if (t.unstable_now = void 0, "object" == typeof performance && "function" == typeof performance.now) {
                var s, a = performance;
                t.unstable_now = function() {
                    return a.now()
                }
            } else {
                var l = Date,
                    u = l.now();
                t.unstable_now = function() {
                    return l.now() - u
                }
            }
            var c = [],
                f = [],
                d = 1,
                h = null,
                p = 3,
                A = !1,
                m = !1,
                g = !1,
                B = "function" == typeof setTimeout ? setTimeout : null,
                v = "function" == typeof clearTimeout ? clearTimeout : null,
                y = "undefined" != typeof setImmediate ? setImmediate : null;

            function C(e) {
                for (var t = n(f); null !== t;) {
                    if (null === t.callback) i(f);
                    else if (t.startTime <= e) i(f), t.sortIndex = t.expirationTime, r(c, t);
                    else break;
                    t = n(f)
                }
            }

            function b(e) {
                if (g = !1, C(e), !m)
                    if (null !== n(c)) m = !0, S();
                    else {
                        var t = n(f);
                        null !== t && D(b, t.startTime - e)
                    }
            }
            var E = !1,
                w = -1,
                M = 5,
                R = -1;

            function F() {
                return !(t.unstable_now() - R < M)
            }

            function x() {
                if (E) {
                    var e = t.unstable_now();
                    R = e;
                    var r = !0;
                    try {
                        e: {
                            m = !1,
                            g && (g = !1, v(w), w = -1),
                            A = !0;
                            var o = p;
                            try {
                                t: {
                                    for (C(e), h = n(c); null !== h && !(h.expirationTime > e && F());) {
                                        var a = h.callback;
                                        if ("function" == typeof a) {
                                            h.callback = null, p = h.priorityLevel;
                                            var l = a(h.expirationTime <= e);
                                            if (e = t.unstable_now(), "function" == typeof l) {
                                                h.callback = l, C(e), r = !0;
                                                break t
                                            }
                                            h === n(c) && i(c), C(e)
                                        } else i(c);
                                        h = n(c)
                                    }
                                    if (null !== h) r = !0;
                                    else {
                                        var u = n(f);
                                        null !== u && D(b, u.startTime - e), r = !1
                                    }
                                }
                                break e
                            }
                            finally {
                                h = null, p = o, A = !1
                            }
                        }
                    }
                    finally {
                        r ? s() : E = !1
                    }
                }
            }
            if ("function" == typeof y) s = function() {
                y(x)
            };
            else if ("undefined" != typeof MessageChannel) {
                var I = new MessageChannel,
                    T = I.port2;
                I.port1.onmessage = x, s = function() {
                    T.postMessage(null)
                }
            } else s = function() {
                B(x, 0)
            };

            function S() {
                E || (E = !0, s())
            }

            function D(e, r) {
                w = B(function() {
                    e(t.unstable_now())
                }, r)
            }
            t.unstable_IdlePriority = 5, t.unstable_ImmediatePriority = 1, t.unstable_LowPriority = 4, t.unstable_NormalPriority = 3, t.unstable_Profiling = null, t.unstable_UserBlockingPriority = 2, t.unstable_cancelCallback = function(e) {
                e.callback = null
            }, t.unstable_continueExecution = function() {
                m || A || (m = !0, S())
            }, t.unstable_forceFrameRate = function(e) {
                0 > e || 125 < e ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : M = 0 < e ? Math.floor(1e3 / e) : 5
            }, t.unstable_getCurrentPriorityLevel = function() {
                return p
            }, t.unstable_getFirstCallbackNode = function() {
                return n(c)
            }, t.unstable_next = function(e) {
                switch (p) {
                    case 1:
                    case 2:
                    case 3:
                        var t = 3;
                        break;
                    default:
                        t = p
                }
                var r = p;
                p = t;
                try {
                    return e()
                } finally {
                    p = r
                }
            }, t.unstable_pauseExecution = function() {}, t.unstable_requestPaint = function() {}, t.unstable_runWithPriority = function(e, t) {
                switch (e) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        break;
                    default:
                        e = 3
                }
                var r = p;
                p = e;
                try {
                    return t()
                } finally {
                    p = r
                }
            }, t.unstable_scheduleCallback = function(e, i, o) {
                var s = t.unstable_now();
                switch (o = "object" == typeof o && null !== o && "number" == typeof(o = o.delay) && 0 < o ? s + o : s, e) {
                    case 1:
                        var a = -1;
                        break;
                    case 2:
                        a = 250;
                        break;
                    case 5:
                        a = 0x3fffffff;
                        break;
                    case 4:
                        a = 1e4;
                        break;
                    default:
                        a = 5e3
                }
                return a = o + a, e = {
                    id: d++,
                    callback: i,
                    priorityLevel: e,
                    startTime: o,
                    expirationTime: a,
                    sortIndex: -1
                }, o > s ? (e.sortIndex = o, r(f, e), null === n(c) && e === n(f) && (g ? (v(w), w = -1) : g = !0, D(b, o - s))) : (e.sortIndex = a, r(c, e), m || A || (m = !0, S())), e
            }, t.unstable_shouldYield = F, t.unstable_wrapCallback = function(e) {
                var t = p;
                return function() {
                    var r = p;
                    p = t;
                    try {
                        return e.apply(this, arguments)
                    } finally {
                        p = r
                    }
                }
            }
        },
        3625: (e, t, r) => {
            "use strict";
            let n;
            r.d(t, {
                p: () => ec
            }), r(6797);
            var i = r(4312);
            let o = new WeakMap;
            class s extends i.aHM {
                constructor(e) {
                    super(e), this.decoderPath = "", this.decoderConfig = {}, this.decoderBinary = null, this.decoderPending = null, this.workerLimit = 4, this.workerPool = [], this.workerNextTaskID = 1, this.workerSourceURL = "", this.defaultAttributeIDs = {
                        position: "POSITION",
                        normal: "NORMAL",
                        color: "COLOR",
                        uv: "TEX_COORD"
                    }, this.defaultAttributeTypes = {
                        position: "Float32Array",
                        normal: "Float32Array",
                        color: "Float32Array",
                        uv: "Float32Array"
                    }
                }
                setDecoderPath(e) {
                    return this.decoderPath = e, this
                }
                setDecoderConfig(e) {
                    return this.decoderConfig = e, this
                }
                setWorkerLimit(e) {
                    return this.workerLimit = e, this
                }
                load(e, t, r, n) {
                    let o = new i.Y9S(this.manager);
                    o.setPath(this.path), o.setResponseType("arraybuffer"), o.setRequestHeader(this.requestHeader), o.setWithCredentials(this.withCredentials), o.load(e, e => {
                        let r = {
                            attributeIDs: this.defaultAttributeIDs,
                            attributeTypes: this.defaultAttributeTypes,
                            useUniqueIDs: !1
                        };
                        this.decodeGeometry(e, r).then(t).catch(n)
                    }, r, n)
                }
                decodeDracoFile(e, t, r, n) {
                    let i = {
                        attributeIDs: r || this.defaultAttributeIDs,
                        attributeTypes: n || this.defaultAttributeTypes,
                        useUniqueIDs: !!r
                    };
                    this.decodeGeometry(e, i).then(t)
                }
                decodeGeometry(e, t) {
                    let r;
                    for (let e in t.attributeTypes) {
                        let r = t.attributeTypes[e];
                        void 0 !== r.BYTES_PER_ELEMENT && (t.attributeTypes[e] = r.name)
                    }
                    let n = JSON.stringify(t);
                    if (o.has(e)) {
                        let t = o.get(e);
                        if (t.key === n) return t.promise;
                        if (0 === e.byteLength) throw Error("THREE.DRACOLoader: Unable to re-decode a buffer with different settings. Buffer has already been transferred.")
                    }
                    let i = this.workerNextTaskID++,
                        s = e.byteLength,
                        a = this._getWorker(i, s).then(n => (r = n, new Promise((n, o) => {
                            r._callbacks[i] = {
                                resolve: n,
                                reject: o
                            }, r.postMessage({
                                type: "decode",
                                id: i,
                                taskConfig: t,
                                buffer: e
                            }, [e])
                        }))).then(e => this._createGeometry(e.geometry));
                    return a.catch(() => !0).then(() => {
                        r && i && this._releaseTask(r, i)
                    }), o.set(e, {
                        key: n,
                        promise: a
                    }), a
                }
                _createGeometry(e) {
                    let t = new i.LoY;
                    e.index && t.setIndex(new i.THS(e.index.array, 1));
                    for (let r = 0; r < e.attributes.length; r++) {
                        let n = e.attributes[r],
                            o = n.name,
                            s = n.array,
                            a = n.itemSize;
                        t.setAttribute(o, new i.THS(s, a))
                    }
                    return t
                }
                _loadLibrary(e, t) {
                    let r = new i.Y9S(this.manager);
                    return r.setPath(this.decoderPath), r.setResponseType(t), r.setWithCredentials(this.withCredentials), new Promise((t, n) => {
                        r.load(e, t, void 0, n)
                    })
                }
                preload() {
                    return this._initDecoder(), this
                }
                _initDecoder() {
                    if (this.decoderPending) return this.decoderPending;
                    let e = "object" != typeof WebAssembly || "js" === this.decoderConfig.type,
                        t = [];
                    return e ? t.push(this._loadLibrary("draco_decoder.js", "text")) : (t.push(this._loadLibrary("draco_wasm_wrapper.js", "text")), t.push(this._loadLibrary("draco_decoder.wasm", "arraybuffer"))), this.decoderPending = Promise.all(t).then(t => {
                        let r = t[0];
                        e || (this.decoderConfig.wasmBinary = t[1]);
                        let n = a.toString(),
                            i = ["/* draco decoder */", r, "", "/* worker */", n.substring(n.indexOf("{") + 1, n.lastIndexOf("}"))].join("\n");
                        this.workerSourceURL = URL.createObjectURL(new Blob([i]))
                    }), this.decoderPending
                }
                _getWorker(e, t) {
                    return this._initDecoder().then(() => {
                        if (this.workerPool.length < this.workerLimit) {
                            let e = new Worker(this.workerSourceURL);
                            e._callbacks = {}, e._taskCosts = {}, e._taskLoad = 0, e.postMessage({
                                type: "init",
                                decoderConfig: this.decoderConfig
                            }), e.onmessage = function(t) {
                                let r = t.data;
                                switch (r.type) {
                                    case "decode":
                                        e._callbacks[r.id].resolve(r);
                                        break;
                                    case "error":
                                        e._callbacks[r.id].reject(r);
                                        break;
                                    default:
                                        console.error('THREE.DRACOLoader: Unexpected message, "' + r.type + '"')
                                }
                            }, this.workerPool.push(e)
                        } else this.workerPool.sort(function(e, t) {
                            return e._taskLoad > t._taskLoad ? -1 : 1
                        });
                        let r = this.workerPool[this.workerPool.length - 1];
                        return r._taskCosts[e] = t, r._taskLoad += t, r
                    })
                }
                _releaseTask(e, t) {
                    e._taskLoad -= e._taskCosts[t], delete e._callbacks[t], delete e._taskCosts[t]
                }
                debug() {
                    console.log("Task load: ", this.workerPool.map(e => e._taskLoad))
                }
                dispose() {
                    for (let e = 0; e < this.workerPool.length; ++e) this.workerPool[e].terminate();
                    return this.workerPool.length = 0, this
                }
            }

            function a() {
                let e, t;
                onmessage = function(r) {
                    let n = r.data;
                    switch (n.type) {
                        case "init":
                            e = n.decoderConfig, t = new Promise(function(t) {
                                e.onModuleLoaded = function(e) {
                                    t({
                                        draco: e
                                    })
                                }, DracoDecoderModule(e)
                            });
                            break;
                        case "decode":
                            let i = n.buffer,
                                o = n.taskConfig;
                            t.then(e => {
                                let t = e.draco,
                                    r = new t.Decoder,
                                    s = new t.DecoderBuffer;
                                s.Init(new Int8Array(i), i.byteLength);
                                try {
                                    let e = function(e, t, r, n) {
                                            let i, o, s = n.attributeIDs,
                                                a = n.attributeTypes,
                                                l = t.GetEncodedGeometryType(r);
                                            if (l === e.TRIANGULAR_MESH) i = new e.Mesh, o = t.DecodeBufferToMesh(r, i);
                                            else if (l === e.POINT_CLOUD) i = new e.PointCloud, o = t.DecodeBufferToPointCloud(r, i);
                                            else throw Error("THREE.DRACOLoader: Unexpected geometry type.");
                                            if (!o.ok() || 0 === i.ptr) throw Error("THREE.DRACOLoader: Decoding failed: " + o.error_msg());
                                            let u = {
                                                index: null,
                                                attributes: []
                                            };
                                            for (let r in s) {
                                                let o, l, c = self[a[r]];
                                                if (n.useUniqueIDs) l = s[r], o = t.GetAttributeByUniqueId(i, l);
                                                else {
                                                    if (-1 === (l = t.GetAttributeId(i, e[s[r]]))) continue;
                                                    o = t.GetAttribute(i, l)
                                                }
                                                u.attributes.push(function(e, t, r, n, i, o) {
                                                    let s = o.num_components(),
                                                        a = r.num_points() * s,
                                                        l = a * i.BYTES_PER_ELEMENT,
                                                        u = function(e, t) {
                                                            switch (t) {
                                                                case Float32Array:
                                                                    return e.DT_FLOAT32;
                                                                case Int8Array:
                                                                    return e.DT_INT8;
                                                                case Int16Array:
                                                                    return e.DT_INT16;
                                                                case Int32Array:
                                                                    return e.DT_INT32;
                                                                case Uint8Array:
                                                                    return e.DT_UINT8;
                                                                case Uint16Array:
                                                                    return e.DT_UINT16;
                                                                case Uint32Array:
                                                                    return e.DT_UINT32
                                                            }
                                                        }(e, i),
                                                        c = e._malloc(l);
                                                    t.GetAttributeDataArrayForAllPoints(r, o, u, l, c);
                                                    let f = new i(e.HEAPF32.buffer, c, a).slice();
                                                    return e._free(c), {
                                                        name: n,
                                                        array: f,
                                                        itemSize: s
                                                    }
                                                }(e, t, i, r, c, o))
                                            }
                                            return l === e.TRIANGULAR_MESH && (u.index = function(e, t, r) {
                                                let n = 3 * r.num_faces(),
                                                    i = 4 * n,
                                                    o = e._malloc(i);
                                                t.GetTrianglesUInt32Array(r, i, o);
                                                let s = new Uint32Array(e.HEAPF32.buffer, o, n).slice();
                                                return e._free(o), {
                                                    array: s,
                                                    itemSize: 1
                                                }
                                            }(e, t, i)), e.destroy(i), u
                                        }(t, r, s, o),
                                        i = e.attributes.map(e => e.array.buffer);
                                    e.index && i.push(e.index.array.buffer), self.postMessage({
                                        type: "decode",
                                        id: n.id,
                                        geometry: e
                                    }, i)
                                } catch (e) {
                                    console.error(e), self.postMessage({
                                        type: "error",
                                        id: n.id,
                                        error: e.message
                                    })
                                } finally {
                                    t.destroy(s), t.destroy(r)
                                }
                            })
                    }
                }
            }
            let l = () => {
                let e;
                if (n) return n;
                let t = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 3, 2, 0, 0, 5, 3, 1, 0, 1, 12, 1, 0, 10, 22, 2, 12, 0, 65, 0, 65, 0, 65, 0, 252, 10, 0, 0, 11, 7, 0, 65, 0, 253, 15, 26, 11]),
                    r = new Uint8Array([32, 0, 65, 253, 3, 1, 2, 34, 4, 106, 6, 5, 11, 8, 7, 20, 13, 33, 12, 16, 128, 9, 116, 64, 19, 113, 127, 15, 10, 21, 22, 14, 255, 66, 24, 54, 136, 107, 18, 23, 192, 26, 114, 118, 132, 17, 77, 101, 130, 144, 27, 87, 131, 44, 45, 74, 156, 154, 70, 167]);
                if ("object" != typeof WebAssembly) return {
                    supported: !1
                };
                let i = "B9h9z9tFBBBF8fL9gBB9gLaaaaaFa9gEaaaB9gFaFa9gEaaaFaEMcBFFFGGGEIIILF9wFFFLEFBFKNFaFCx/IFMO/LFVK9tv9t9vq95GBt9f9f939h9z9t9f9j9h9s9s9f9jW9vq9zBBp9tv9z9o9v9wW9f9kv9j9v9kv9WvqWv94h919m9mvqBF8Z9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv94h919m9mvqBGy9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv949TvZ91v9u9jvBEn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9P9jWBIi9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9R919hWBLn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9F949wBKI9z9iqlBOc+x8ycGBM/qQFTa8jUUUUBCU/EBlHL8kUUUUBC9+RKGXAGCFJAI9LQBCaRKAE2BBC+gF9HQBALAEAIJHOAGlAGTkUUUBRNCUoBAG9uC/wgBZHKCUGAKCUG9JyRVAECFJRICBRcGXEXAcAF9PQFAVAFAclAcAVJAF9JyRMGXGXAG9FQBAMCbJHKC9wZRSAKCIrCEJCGrRQANCUGJRfCBRbAIRTEXGXAOATlAQ9PQBCBRISEMATAQJRIGXAS9FQBCBRtCBREEXGXAOAIlCi9PQBCBRISLMANCU/CBJAEJRKGXGXGXGXGXATAECKrJ2BBAtCKZrCEZfIBFGEBMAKhB83EBAKCNJhB83EBSEMAKAI2BIAI2BBHmCKrHYAYCE6HYy86BBAKCFJAICIJAYJHY2BBAmCIrCEZHPAPCE6HPy86BBAKCGJAYAPJHY2BBAmCGrCEZHPAPCE6HPy86BBAKCEJAYAPJHY2BBAmCEZHmAmCE6Hmy86BBAKCIJAYAmJHY2BBAI2BFHmCKrHPAPCE6HPy86BBAKCLJAYAPJHY2BBAmCIrCEZHPAPCE6HPy86BBAKCKJAYAPJHY2BBAmCGrCEZHPAPCE6HPy86BBAKCOJAYAPJHY2BBAmCEZHmAmCE6Hmy86BBAKCNJAYAmJHY2BBAI2BGHmCKrHPAPCE6HPy86BBAKCVJAYAPJHY2BBAmCIrCEZHPAPCE6HPy86BBAKCcJAYAPJHY2BBAmCGrCEZHPAPCE6HPy86BBAKCMJAYAPJHY2BBAmCEZHmAmCE6Hmy86BBAKCSJAYAmJHm2BBAI2BEHICKrHYAYCE6HYy86BBAKCQJAmAYJHm2BBAICIrCEZHYAYCE6HYy86BBAKCfJAmAYJHm2BBAICGrCEZHYAYCE6HYy86BBAKCbJAmAYJHK2BBAICEZHIAICE6HIy86BBAKAIJRISGMAKAI2BNAI2BBHmCIrHYAYCb6HYy86BBAKCFJAICNJAYJHY2BBAmCbZHmAmCb6Hmy86BBAKCGJAYAmJHm2BBAI2BFHYCIrHPAPCb6HPy86BBAKCEJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCIJAmAYJHm2BBAI2BGHYCIrHPAPCb6HPy86BBAKCLJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCKJAmAYJHm2BBAI2BEHYCIrHPAPCb6HPy86BBAKCOJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCNJAmAYJHm2BBAI2BIHYCIrHPAPCb6HPy86BBAKCVJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCcJAmAYJHm2BBAI2BLHYCIrHPAPCb6HPy86BBAKCMJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCSJAmAYJHm2BBAI2BKHYCIrHPAPCb6HPy86BBAKCQJAmAPJHm2BBAYCbZHYAYCb6HYy86BBAKCfJAmAYJHm2BBAI2BOHICIrHYAYCb6HYy86BBAKCbJAmAYJHK2BBAICbZHIAICb6HIy86BBAKAIJRISFMAKAI8pBB83BBAKCNJAICNJ8pBB83BBAICTJRIMAtCGJRtAECTJHEAS9JQBMMGXAIQBCBRISEMGXAM9FQBANAbJ2BBRtCBRKAfREEXAEANCU/CBJAKJ2BBHTCFrCBATCFZl9zAtJHt86BBAEAGJREAKCFJHKAM9HQBMMAfCFJRfAIRTAbCFJHbAG9HQBMMABAcAG9sJANCUGJAMAG9sTkUUUBpANANCUGJAMCaJAG9sJAGTkUUUBpMAMCBAIyAcJRcAIQBMC9+RKSFMCBC99AOAIlAGCAAGCA9Ly6yRKMALCU/EBJ8kUUUUBAKM+OmFTa8jUUUUBCoFlHL8kUUUUBC9+RKGXAFCE9uHOCtJAI9LQBCaRKAE2BBHNC/wFZC/gF9HQBANCbZHVCF9LQBALCoBJCgFCUFT+JUUUBpALC84Jha83EBALC8wJha83EBALC8oJha83EBALCAJha83EBALCiJha83EBALCTJha83EBALha83ENALha83EBAEAIJC9wJRcAECFJHNAOJRMGXAF9FQBCQCbAVCF6yRSABRECBRVCBRQCBRfCBRICBRKEXGXAMAcuQBC9+RKSEMGXGXAN2BBHOC/vF9LQBALCoBJAOCIrCa9zAKJCbZCEWJHb8oGIRTAb8oGBRtGXAOCbZHbAS9PQBALAOCa9zAIJCbZCGWJ8oGBAVAbyROAb9FRbGXGXAGCG9HQBABAt87FBABCIJAO87FBABCGJAT87FBSFMAEAtjGBAECNJAOjGBAECIJATjGBMAVAbJRVALCoBJAKCEWJHmAOjGBAmATjGIALAICGWJAOjGBALCoBJAKCFJCbZHKCEWJHTAtjGBATAOjGIAIAbJRIAKCFJRKSGMGXGXAbCb6QBAQAbJAbC989zJCFJRQSFMAM1BBHbCgFZROGXGXAbCa9MQBAMCFJRMSFMAM1BFHbCgBZCOWAOCgBZqROGXAbCa9MQBAMCGJRMSFMAM1BGHbCgBZCfWAOqROGXAbCa9MQBAMCEJRMSFMAM1BEHbCgBZCdWAOqROGXAbCa9MQBAMCIJRMSFMAM2BIC8cWAOqROAMCLJRMMAOCFrCBAOCFZl9zAQJRQMGXGXAGCG9HQBABAt87FBABCIJAQ87FBABCGJAT87FBSFMAEAtjGBAECNJAQjGBAECIJATjGBMALCoBJAKCEWJHOAQjGBAOATjGIALAICGWJAQjGBALCoBJAKCFJCbZHKCEWJHOAtjGBAOAQjGIAICFJRIAKCFJRKSFMGXAOCDF9LQBALAIAcAOCbZJ2BBHbCIrHTlCbZCGWJ8oGBAVCFJHtATyROALAIAblCbZCGWJ8oGBAtAT9FHmJHtAbCbZHTyRbAT9FRTGXGXAGCG9HQBABAV87FBABCIJAb87FBABCGJAO87FBSFMAEAVjGBAECNJAbjGBAECIJAOjGBMALAICGWJAVjGBALCoBJAKCEWJHYAOjGBAYAVjGIALAICFJHICbZCGWJAOjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAIAmJCbZHICGWJAbjGBALCoBJAKCGJCbZHKCEWJHOAVjGBAOAbjGIAKCFJRKAIATJRIAtATJRVSFMAVCBAM2BBHYyHTAOC/+F6HPJROAYCbZRtGXGXAYCIrHmQBAOCFJRbSFMAORbALAIAmlCbZCGWJ8oGBROMGXGXAtQBAbCFJRVSFMAbRVALAIAYlCbZCGWJ8oGBRbMGXGXAP9FQBAMCFJRYSFMAM1BFHYCgFZRTGXGXAYCa9MQBAMCGJRYSFMAM1BGHYCgBZCOWATCgBZqRTGXAYCa9MQBAMCEJRYSFMAM1BEHYCgBZCfWATqRTGXAYCa9MQBAMCIJRYSFMAM1BIHYCgBZCdWATqRTGXAYCa9MQBAMCLJRYSFMAMCKJRYAM2BLC8cWATqRTMATCFrCBATCFZl9zAQJHQRTMGXGXAmCb6QBAYRPSFMAY1BBHMCgFZROGXGXAMCa9MQBAYCFJRPSFMAY1BFHMCgBZCOWAOCgBZqROGXAMCa9MQBAYCGJRPSFMAY1BGHMCgBZCfWAOqROGXAMCa9MQBAYCEJRPSFMAY1BEHMCgBZCdWAOqROGXAMCa9MQBAYCIJRPSFMAYCLJRPAY2BIC8cWAOqROMAOCFrCBAOCFZl9zAQJHQROMGXGXAtCb6QBAPRMSFMAP1BBHMCgFZRbGXGXAMCa9MQBAPCFJRMSFMAP1BFHMCgBZCOWAbCgBZqRbGXAMCa9MQBAPCGJRMSFMAP1BGHMCgBZCfWAbqRbGXAMCa9MQBAPCEJRMSFMAP1BEHMCgBZCdWAbqRbGXAMCa9MQBAPCIJRMSFMAPCLJRMAP2BIC8cWAbqRbMAbCFrCBAbCFZl9zAQJHQRbMGXGXAGCG9HQBABAT87FBABCIJAb87FBABCGJAO87FBSFMAEATjGBAECNJAbjGBAECIJAOjGBMALCoBJAKCEWJHYAOjGBAYATjGIALAICGWJATjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAICFJHICbZCGWJAOjGBALCoBJAKCGJCbZCEWJHOATjGBAOAbjGIALAIAm9FAmCb6qJHICbZCGWJAbjGBAIAt9FAtCb6qJRIAKCEJRKMANCFJRNABCKJRBAECSJREAKCbZRKAICbZRIAfCEJHfAF9JQBMMCBC99AMAc6yRKMALCoFJ8kUUUUBAKM/tIFGa8jUUUUBCTlRLC9+RKGXAFCLJAI9LQBCaRKAE2BBC/+FZC/QF9HQBALhB83ENAECFJRKAEAIJC98JREGXAF9FQBGXAGCG6QBEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMALCNJAICFZCGWqHGAICGrCBAICFrCFZl9zAG8oGBJHIjGBABAIjGBABCIJRBAFCaJHFQBSGMMEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMABAICGrCBAICFrCFZl9zALCNJAICFZCGWqHI8oGBJHG87FBAIAGjGBABCGJRBAFCaJHFQBMMCBC99AKAE6yRKMAKM+lLKFaF99GaG99FaG99GXGXAGCI9HQBAF9FQFEXGXGX9DBBB8/9DBBB+/ABCGJHG1BB+yAB1BBHE+yHI+L+TABCFJHL1BBHK+yHO+L+THN9DBBBB9gHVyAN9DBB/+hANAN+U9DBBBBANAVyHcAc+MHMAECa3yAI+SHIAI+UAcAMAKCa3yAO+SHcAc+U+S+S+R+VHO+U+SHN+L9DBBB9P9d9FQBAN+oRESFMCUUUU94REMAGAE86BBGXGX9DBBB8/9DBBB+/Ac9DBBBB9gyAcAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMALAG86BBGXGX9DBBB8/9DBBB+/AI9DBBBB9gyAIAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMABAG86BBABCIJRBAFCaJHFQBSGMMAF9FQBEXGXGX9DBBB8/9DBBB+/ABCIJHG8uFB+yAB8uFBHE+yHI+L+TABCGJHL8uFBHK+yHO+L+THN9DBBBB9gHVyAN9DB/+g6ANAN+U9DBBBBANAVyHcAc+MHMAECa3yAI+SHIAI+UAcAMAKCa3yAO+SHcAc+U+S+S+R+VHO+U+SHN+L9DBBB9P9d9FQBAN+oRESFMCUUUU94REMAGAE87FBGXGX9DBBB8/9DBBB+/Ac9DBBBB9gyAcAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMALAG87FBGXGX9DBBB8/9DBBB+/AI9DBBBB9gyAIAO+U+SHN+L9DBBB9P9d9FQBAN+oRGSFMCUUUU94RGMABAG87FBABCNJRBAFCaJHFQBMMM/SEIEaE99EaF99GXAF9FQBCBREABRIEXGXGX9D/zI818/AICKJ8uFBHLCEq+y+VHKAI8uFB+y+UHO9DB/+g6+U9DBBB8/9DBBB+/AO9DBBBB9gy+SHN+L9DBBB9P9d9FQBAN+oRVSFMCUUUU94RVMAICIJ8uFBRcAICGJ8uFBRMABALCFJCEZAEqCFWJAV87FBGXGXAKAM+y+UHN9DB/+g6+U9DBBB8/9DBBB+/AN9DBBBB9gy+SHS+L9DBBB9P9d9FQBAS+oRMSFMCUUUU94RMMABALCGJCEZAEqCFWJAM87FBGXGXAKAc+y+UHK9DB/+g6+U9DBBB8/9DBBB+/AK9DBBBB9gy+SHS+L9DBBB9P9d9FQBAS+oRcSFMCUUUU94RcMABALCaJCEZAEqCFWJAc87FBGXGX9DBBU8/AOAO+U+TANAN+U+TAKAK+U+THO9DBBBBAO9DBBBB9gy+R9DB/+g6+U9DBBB8/+SHO+L9DBBB9P9d9FQBAO+oRcSFMCUUUU94RcMABALCEZAEqCFWJAc87FBAICNJRIAECIJREAFCaJHFQBMMM9JBGXAGCGrAF9sHF9FQBEXABAB8oGBHGCNWCN91+yAGCi91CnWCUUU/8EJ+++U84GBABCIJRBAFCaJHFQBMMM9TFEaCBCB8oGUkUUBHFABCEJC98ZJHBjGUkUUBGXGXAB8/BCTWHGuQBCaREABAGlCggEJCTrXBCa6QFMAFREMAEM/lFFFaGXGXAFABqCEZ9FQBABRESFMGXGXAGCT9PQBABRESFMABREEXAEAF8oGBjGBAECIJAFCIJ8oGBjGBAECNJAFCNJ8oGBjGBAECSJAFCSJ8oGBjGBAECTJREAFCTJRFAGC9wJHGCb9LQBMMAGCI9JQBEXAEAF8oGBjGBAFCIJRFAECIJREAGC98JHGCE9LQBMMGXAG9FQBEXAEAF2BB86BBAECFJREAFCFJRFAGCaJHGQBMMABMoFFGaGXGXABCEZ9FQBABRESFMAFCgFZC+BwsN9sRIGXGXAGCT9PQBABRESFMABREEXAEAIjGBAECSJAIjGBAECNJAIjGBAECIJAIjGBAECTJREAGC9wJHGCb9LQBMMAGCI9JQBEXAEAIjGBAECIJREAGC98JHGCE9LQBMMGXAG9FQBEXAEAF86BBAECFJREAGCaJHGQBMMABMMMFBCUNMIT9kBB";
                WebAssembly.validate(t) && (i = "B9h9z9tFBBBFiI9gBB9gLaaaaaFa9gEaaaB9gFaFaEMcBBFBFFGGGEILF9wFFFLEFBFKNFaFCx/aFMO/LFVK9tv9t9vq95GBt9f9f939h9z9t9f9j9h9s9s9f9jW9vq9zBBp9tv9z9o9v9wW9f9kv9j9v9kv9WvqWv94h919m9mvqBG8Z9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv94h919m9mvqBIy9tv9z9o9v9wW9f9kv9j9v9kv9J9u9kv949TvZ91v9u9jvBLn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9P9jWBKi9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9R919hWBOn9tv9z9o9v9wW9f9kv9j9v9kv69p9sWvq9F949wBNI9z9iqlBVc+N9IcIBTEM9+FLa8jUUUUBCTlRBCBRFEXCBRGCBREEXABCNJAGJAECUaAFAGrCFZHIy86BBAEAIJREAGCFJHGCN9HQBMAFCx+YUUBJAE86BBAFCEWCxkUUBJAB8pEN83EBAFCFJHFCUG9HQBMMk8lLbaE97F9+FaL978jUUUUBCU/KBlHL8kUUUUBC9+RKGXAGCFJAI9LQBCaRKAE2BBC+gF9HQBALAEAIJHOAGlAG/8cBBCUoBAG9uC/wgBZHKCUGAKCUG9JyRNAECFJRKCBRVGXEXAVAF9PQFANAFAVlAVANJAF9JyRcGXGXAG9FQBAcCbJHIC9wZHMCE9sRSAMCFWRQAICIrCEJCGrRfCBRbEXAKRTCBRtGXEXGXAOATlAf9PQBCBRKSLMALCU/CBJAtAM9sJRmATAfJRKCBREGXAMCoB9JQBAOAKlC/gB9JQBCBRIEXAmAIJREGXGXGXGXGXATAICKrJ2BBHYCEZfIBFGEBMAECBDtDMIBSEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAEAKDBBBDMIBAKCTJRKMGXGXGXGXGXAYCGrCEZfIBFGEBMAECBDtDMITSEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMITAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMITAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAEAKDBBBDMITAKCTJRKMGXGXGXGXGXAYCIrCEZfIBFGEBMAECBDtDMIASEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIAAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIAAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAEAKDBBBDMIAAKCTJRKMGXGXGXGXGXAYCKrfIBFGEBMAECBDtDMI8wSEMAEAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHYCEWCxkUUBJDBEBAYCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHYCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMI8wAKCIJAeDeBJAYCx+YUUBJ2BBJRKSGMAEAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHYCEWCxkUUBJDBEBAYCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHYCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMI8wAKCNJAeDeBJAYCx+YUUBJ2BBJRKSFMAEAKDBBBDMI8wAKCTJRKMAICoBJREAICUFJAM9LQFAERIAOAKlC/fB9LQBMMGXAEAM9PQBAECErRIEXGXAOAKlCi9PQBCBRKSOMAmAEJRYGXGXGXGXGXATAECKrJ2BBAICKZrCEZfIBFGEBMAYCBDtDMIBSEMAYAKDBBIAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnHPCGD+MFAPDQBTFtGmEYIPLdKeOnC0+G+MiDtD9OHdCEDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCIJAeDeBJAiCx+YUUBJ2BBJRKSGMAYAKDBBNAKDBBBHPCID+MFAPDQBTFtGmEYIPLdKeOnC+P+e+8/4BDtD9OHdCbDbD8jHPAPDQBFGENVcMILKOSQfbHeD8dBh+BsxoxoUwN0AeD8dFhxoUwkwk+gUa0sHnhTkAnsHnhNkAnsHn7CgFZHiCEWCxkUUBJDBEBAiCx+YUUBJDBBBHeAeDQBBBBBBBBBBBBBBBBAnhAk7CgFZHiCEWCxkUUBJDBEBD9uDQBFGEILKOTtmYPdenDfAdAPD9SDMIBAKCNJAeDeBJAiCx+YUUBJ2BBJRKSFMAYAKDBBBDMIBAKCTJRKMAICGJRIAECTJHEAM9JQBMMGXAK9FQBAKRTAtCFJHtCI6QGSFMMCBRKSEMGXAM9FQBALCUGJAbJREALAbJDBGBReCBRYEXAEALCU/CBJAYJHIDBIBHdCFD9tAdCFDbHPD9OD9hD9RHdAIAMJDBIBH8ZCFD9tA8ZAPD9OD9hD9RH8ZDQBTFtGmEYIPLdKeOnHpAIAQJDBIBHyCFD9tAyAPD9OD9hD9RHyAIASJDBIBH8cCFD9tA8cAPD9OD9hD9RH8cDQBTFtGmEYIPLdKeOnH8dDQBFTtGEmYILPdKOenHPAPDQBFGEBFGEBFGEBFGEAeD9uHeDyBjGBAEAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJHIAeApA8dDQNVi8ZcMpySQ8c8dfb8e8fHPAPDQBFGEBFGEBFGEBFGED9uHeDyBjGBAIAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJHIAeAdA8ZDQNiV8ZcpMyS8cQ8df8eb8fHdAyA8cDQNiV8ZcpMyS8cQ8df8eb8fH8ZDQBFTtGEmYILPdKOenHPAPDQBFGEBFGEBFGEBFGED9uHeDyBjGBAIAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJHIAeAdA8ZDQNVi8ZcMpySQ8c8dfb8e8fHPAPDQBFGEBFGEBFGEBFGED9uHeDyBjGBAIAGJHIAeAPAPDQILKOILKOILKOILKOD9uHeDyBjGBAIAGJHIAeAPAPDQNVcMNVcMNVcMNVcMD9uHeDyBjGBAIAGJHIAeAPAPDQSQfbSQfbSQfbSQfbD9uHeDyBjGBAIAGJREAYCTJHYAM9JQBMMAbCIJHbAG9JQBMMABAVAG9sJALCUGJAcAG9s/8cBBALALCUGJAcCaJAG9sJAG/8cBBMAcCBAKyAVJRVAKQBMC9+RKSFMCBC99AOAKlAGCAAGCA9Ly6yRKMALCU/KBJ8kUUUUBAKMNBT+BUUUBM+KmFTa8jUUUUBCoFlHL8kUUUUBC9+RKGXAFCE9uHOCtJAI9LQBCaRKAE2BBHNC/wFZC/gF9HQBANCbZHVCF9LQBALCoBJCgFCUF/8MBALC84Jha83EBALC8wJha83EBALC8oJha83EBALCAJha83EBALCiJha83EBALCTJha83EBALha83ENALha83EBAEAIJC9wJRcAECFJHNAOJRMGXAF9FQBCQCbAVCF6yRSABRECBRVCBRQCBRfCBRICBRKEXGXAMAcuQBC9+RKSEMGXGXAN2BBHOC/vF9LQBALCoBJAOCIrCa9zAKJCbZCEWJHb8oGIRTAb8oGBRtGXAOCbZHbAS9PQBALAOCa9zAIJCbZCGWJ8oGBAVAbyROAb9FRbGXGXAGCG9HQBABAt87FBABCIJAO87FBABCGJAT87FBSFMAEAtjGBAECNJAOjGBAECIJATjGBMAVAbJRVALCoBJAKCEWJHmAOjGBAmATjGIALAICGWJAOjGBALCoBJAKCFJCbZHKCEWJHTAtjGBATAOjGIAIAbJRIAKCFJRKSGMGXGXAbCb6QBAQAbJAbC989zJCFJRQSFMAM1BBHbCgFZROGXGXAbCa9MQBAMCFJRMSFMAM1BFHbCgBZCOWAOCgBZqROGXAbCa9MQBAMCGJRMSFMAM1BGHbCgBZCfWAOqROGXAbCa9MQBAMCEJRMSFMAM1BEHbCgBZCdWAOqROGXAbCa9MQBAMCIJRMSFMAM2BIC8cWAOqROAMCLJRMMAOCFrCBAOCFZl9zAQJRQMGXGXAGCG9HQBABAt87FBABCIJAQ87FBABCGJAT87FBSFMAEAtjGBAECNJAQjGBAECIJATjGBMALCoBJAKCEWJHOAQjGBAOATjGIALAICGWJAQjGBALCoBJAKCFJCbZHKCEWJHOAtjGBAOAQjGIAICFJRIAKCFJRKSFMGXAOCDF9LQBALAIAcAOCbZJ2BBHbCIrHTlCbZCGWJ8oGBAVCFJHtATyROALAIAblCbZCGWJ8oGBAtAT9FHmJHtAbCbZHTyRbAT9FRTGXGXAGCG9HQBABAV87FBABCIJAb87FBABCGJAO87FBSFMAEAVjGBAECNJAbjGBAECIJAOjGBMALAICGWJAVjGBALCoBJAKCEWJHYAOjGBAYAVjGIALAICFJHICbZCGWJAOjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAIAmJCbZHICGWJAbjGBALCoBJAKCGJCbZHKCEWJHOAVjGBAOAbjGIAKCFJRKAIATJRIAtATJRVSFMAVCBAM2BBHYyHTAOC/+F6HPJROAYCbZRtGXGXAYCIrHmQBAOCFJRbSFMAORbALAIAmlCbZCGWJ8oGBROMGXGXAtQBAbCFJRVSFMAbRVALAIAYlCbZCGWJ8oGBRbMGXGXAP9FQBAMCFJRYSFMAM1BFHYCgFZRTGXGXAYCa9MQBAMCGJRYSFMAM1BGHYCgBZCOWATCgBZqRTGXAYCa9MQBAMCEJRYSFMAM1BEHYCgBZCfWATqRTGXAYCa9MQBAMCIJRYSFMAM1BIHYCgBZCdWATqRTGXAYCa9MQBAMCLJRYSFMAMCKJRYAM2BLC8cWATqRTMATCFrCBATCFZl9zAQJHQRTMGXGXAmCb6QBAYRPSFMAY1BBHMCgFZROGXGXAMCa9MQBAYCFJRPSFMAY1BFHMCgBZCOWAOCgBZqROGXAMCa9MQBAYCGJRPSFMAY1BGHMCgBZCfWAOqROGXAMCa9MQBAYCEJRPSFMAY1BEHMCgBZCdWAOqROGXAMCa9MQBAYCIJRPSFMAYCLJRPAY2BIC8cWAOqROMAOCFrCBAOCFZl9zAQJHQROMGXGXAtCb6QBAPRMSFMAP1BBHMCgFZRbGXGXAMCa9MQBAPCFJRMSFMAP1BFHMCgBZCOWAbCgBZqRbGXAMCa9MQBAPCGJRMSFMAP1BGHMCgBZCfWAbqRbGXAMCa9MQBAPCEJRMSFMAP1BEHMCgBZCdWAbqRbGXAMCa9MQBAPCIJRMSFMAPCLJRMAP2BIC8cWAbqRbMAbCFrCBAbCFZl9zAQJHQRbMGXGXAGCG9HQBABAT87FBABCIJAb87FBABCGJAO87FBSFMAEATjGBAECNJAbjGBAECIJAOjGBMALCoBJAKCEWJHYAOjGBAYATjGIALAICGWJATjGBALCoBJAKCFJCbZCEWJHYAbjGBAYAOjGIALAICFJHICbZCGWJAOjGBALCoBJAKCGJCbZCEWJHOATjGBAOAbjGIALAIAm9FAmCb6qJHICbZCGWJAbjGBAIAt9FAtCb6qJRIAKCEJRKMANCFJRNABCKJRBAECSJREAKCbZRKAICbZRIAfCEJHfAF9JQBMMCBC99AMAc6yRKMALCoFJ8kUUUUBAKM/tIFGa8jUUUUBCTlRLC9+RKGXAFCLJAI9LQBCaRKAE2BBC/+FZC/QF9HQBALhB83ENAECFJRKAEAIJC98JREGXAF9FQBGXAGCG6QBEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMALCNJAICFZCGWqHGAICGrCBAICFrCFZl9zAG8oGBJHIjGBABAIjGBABCIJRBAFCaJHFQBSGMMEXGXAKAE9JQBC9+bMAK1BBHGCgFZRIGXGXAGCa9MQBAKCFJRKSFMAK1BFHGCgBZCOWAICgBZqRIGXAGCa9MQBAKCGJRKSFMAK1BGHGCgBZCfWAIqRIGXAGCa9MQBAKCEJRKSFMAK1BEHGCgBZCdWAIqRIGXAGCa9MQBAKCIJRKSFMAK2BIC8cWAIqRIAKCLJRKMABAICGrCBAICFrCFZl9zALCNJAICFZCGWqHI8oGBJHG87FBAIAGjGBABCGJRBAFCaJHFQBMMCBC99AKAE6yRKMAKM/dLEK97FaF97GXGXAGCI9HQBAF9FQFCBRGEXABABDBBBHECiD+rFCiD+sFD/6FHIAECND+rFCiD+sFD/6FAID/gFAECTD+rFCiD+sFD/6FHLD/gFD/kFD/lFHKCBDtD+2FHOAICUUUU94DtHND9OD9RD/kFHI9DBB/+hDYAIAID/mFAKAKD/mFALAOALAND9OD9RD/kFHIAID/mFD/kFD/kFD/jFD/nFHLD/mF9DBBX9LDYHOD/kFCgFDtD9OAECUUU94DtD9OD9QAIALD/mFAOD/kFCND+rFCU/+EDtD9OD9QAKALD/mFAOD/kFCTD+rFCUU/8ODtD9OD9QDMBBABCTJRBAGCIJHGAF9JQBSGMMAF9FQBCBRGEXABCTJHVAVDBBBHECBDtHOCUU98D8cFCUU98D8cEHND9OABDBBBHKAEDQILKOSQfbPden8c8d8e8fCggFDtD9OD/6FAKAEDQBFGENVcMTtmYi8ZpyHECTD+sFD/6FHID/gFAECTD+rFCTD+sFD/6FHLD/gFD/kFD/lFHE9DB/+g6DYALAEAOD+2FHOALCUUUU94DtHcD9OD9RD/kFHLALD/mFAEAED/mFAIAOAIAcD9OD9RD/kFHEAED/mFD/kFD/kFD/jFD/nFHID/mF9DBBX9LDYHOD/kFCTD+rFALAID/mFAOD/kFCggEDtD9OD9QHLAEAID/mFAOD/kFCaDbCBDnGCBDnECBDnKCBDnOCBDncCBDnMCBDnfCBDnbD9OHEDQNVi8ZcMpySQ8c8dfb8e8fD9QDMBBABAKAND9OALAEDQBFTtGEmYILPdKOenD9QDMBBABCAJRBAGCIJHGAF9JQBMMM/hEIGaF97FaL978jUUUUBCTlREGXAF9FQBCBRIEXAEABDBBBHLABCTJHKDBBBHODQILKOSQfbPden8c8d8e8fHNCTD+sFHVCID+rFDMIBAB9DBBU8/DY9D/zI818/DYAVCEDtD9QD/6FD/nFHVALAODQBFGENVcMTtmYi8ZpyHLCTD+rFCTD+sFD/6FD/mFHOAOD/mFAVALCTD+sFD/6FD/mFHcAcD/mFAVANCTD+rFCTD+sFD/6FD/mFHNAND/mFD/kFD/kFD/lFCBDtD+4FD/jF9DB/+g6DYHVD/mF9DBBX9LDYHLD/kFCggEDtHMD9OAcAVD/mFALD/kFCTD+rFD9QHcANAVD/mFALD/kFCTD+rFAOAVD/mFALD/kFAMD9OD9QHVDQBFTtGEmYILPdKOenHLD8dBAEDBIBDyB+t+J83EBABCNJALD8dFAEDBIBDyF+t+J83EBAKAcAVDQNVi8ZcMpySQ8c8dfb8e8fHVD8dBAEDBIBDyG+t+J83EBABCiJAVD8dFAEDBIBDyE+t+J83EBABCAJRBAICIJHIAF9JQBMMM9jFF97GXAGCGrAF9sHG9FQBCBRFEXABABDBBBHECND+rFCND+sFD/6FAECiD+sFCnD+rFCUUU/8EDtD+uFD/mFDMBBABCTJRBAFCIJHFAG9JQBMMM9TFEaCBCB8oGUkUUBHFABCEJC98ZJHBjGUkUUBGXGXAB8/BCTWHGuQBCaREABAGlCggEJCTrXBCa6QFMAFREMAEMMMFBCUNMIT9tBB");
                let o = WebAssembly.instantiate(function(e) {
                    let t = new Uint8Array(e.length);
                    for (let r = 0; r < e.length; ++r) {
                        let n = e.charCodeAt(r);
                        t[r] = n > 96 ? n - 71 : n > 64 ? n - 65 : n > 47 ? n + 4 : n > 46 ? 63 : 62
                    }
                    let n = 0;
                    for (let i = 0; i < e.length; ++i) t[n++] = t[i] < 60 ? r[t[i]] : (t[i] - 60) * 64 + t[++i];
                    return t.buffer.slice(0, n)
                }(i), {}).then(t => {
                    (e = t.instance).exports.__wasm_call_ctors()
                });

                function s(t, r, n, i, o, s) {
                    let a = e.exports.sbrk,
                        l = n + 3 & -4,
                        u = a(l * i),
                        c = a(o.length),
                        f = new Uint8Array(e.exports.memory.buffer);
                    f.set(o, c);
                    let d = t(u, n, i, c, o.length);
                    if (0 === d && s && s(u, l, i), r.set(f.subarray(u, u + n * i)), a(u - a(0)), 0 !== d) throw Error(`Malformed buffer data: ${d}`)
                }
                let a = {
                        0: "",
                        1: "meshopt_decodeFilterOct",
                        2: "meshopt_decodeFilterQuat",
                        3: "meshopt_decodeFilterExp",
                        NONE: "",
                        OCTAHEDRAL: "meshopt_decodeFilterOct",
                        QUATERNION: "meshopt_decodeFilterQuat",
                        EXPONENTIAL: "meshopt_decodeFilterExp"
                    },
                    l = {
                        0: "meshopt_decodeVertexBuffer",
                        1: "meshopt_decodeIndexBuffer",
                        2: "meshopt_decodeIndexSequence",
                        ATTRIBUTES: "meshopt_decodeVertexBuffer",
                        TRIANGLES: "meshopt_decodeIndexBuffer",
                        INDICES: "meshopt_decodeIndexSequence"
                    };
                return n = {
                    ready: o,
                    supported: !0,
                    decodeVertexBuffer(t, r, n, i, o) {
                        s(e.exports.meshopt_decodeVertexBuffer, t, r, n, i, e.exports[a[o]])
                    },
                    decodeIndexBuffer(t, r, n, i) {
                        s(e.exports.meshopt_decodeIndexBuffer, t, r, n, i)
                    },
                    decodeIndexSequence(t, r, n, i) {
                        s(e.exports.meshopt_decodeIndexSequence, t, r, n, i)
                    },
                    decodeGltfBuffer(t, r, n, i, o, u) {
                        s(e.exports[l[o]], t, r, n, i, e.exports[a[u]])
                    }
                }
            };
            var u = r(5967),
                c = r(7338);

            function f(e) {
                if ("undefined" != typeof TextDecoder) return new TextDecoder().decode(e);
                let t = "";
                for (let r = 0, n = e.length; r < n; r++) t += String.fromCharCode(e[r]);
                try {
                    return decodeURIComponent(escape(t))
                } catch (e) {
                    return t
                }
            }
            let d = "srgb",
                h = "srgb-linear";
            class p extends i.aHM {
                constructor(e) {
                    super(e), this.dracoLoader = null, this.ktx2Loader = null, this.meshoptDecoder = null, this.pluginCallbacks = [], this.register(function(e) {
                        return new y(e)
                    }), this.register(function(e) {
                        return new C(e)
                    }), this.register(function(e) {
                        return new T(e)
                    }), this.register(function(e) {
                        return new S(e)
                    }), this.register(function(e) {
                        return new D(e)
                    }), this.register(function(e) {
                        return new E(e)
                    }), this.register(function(e) {
                        return new w(e)
                    }), this.register(function(e) {
                        return new M(e)
                    }), this.register(function(e) {
                        return new R(e)
                    }), this.register(function(e) {
                        return new v(e)
                    }), this.register(function(e) {
                        return new F(e)
                    }), this.register(function(e) {
                        return new b(e)
                    }), this.register(function(e) {
                        return new I(e)
                    }), this.register(function(e) {
                        return new x(e)
                    }), this.register(function(e) {
                        return new g(e)
                    }), this.register(function(e) {
                        return new O(e)
                    }), this.register(function(e) {
                        return new G(e)
                    })
                }
                load(e, t, r, n) {
                    let o, s = this;
                    if ("" !== this.resourcePath) o = this.resourcePath;
                    else if ("" !== this.path) {
                        let t = i.r6x.extractUrlBase(e);
                        o = i.r6x.resolveURL(t, this.path)
                    } else o = i.r6x.extractUrlBase(e);
                    this.manager.itemStart(e);
                    let a = function(t) {
                            n ? n(t) : console.error(t), s.manager.itemError(e), s.manager.itemEnd(e)
                        },
                        l = new i.Y9S(this.manager);
                    l.setPath(this.path), l.setResponseType("arraybuffer"), l.setRequestHeader(this.requestHeader), l.setWithCredentials(this.withCredentials), l.load(e, function(r) {
                        try {
                            s.parse(r, o, function(r) {
                                t(r), s.manager.itemEnd(e)
                            }, a)
                        } catch (e) {
                            a(e)
                        }
                    }, r, a)
                }
                setDRACOLoader(e) {
                    return this.dracoLoader = e, this
                }
                setDDSLoader() {
                    throw Error('THREE.GLTFLoader: "MSFT_texture_dds" no longer supported. Please update to "KHR_texture_basisu".')
                }
                setKTX2Loader(e) {
                    return this.ktx2Loader = e, this
                }
                setMeshoptDecoder(e) {
                    return this.meshoptDecoder = e, this
                }
                register(e) {
                    return -1 === this.pluginCallbacks.indexOf(e) && this.pluginCallbacks.push(e), this
                }
                unregister(e) {
                    return -1 !== this.pluginCallbacks.indexOf(e) && this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(e), 1), this
                }
                parse(e, t, r, n) {
                    let i, o = {},
                        s = {};
                    if ("string" == typeof e) i = JSON.parse(e);
                    else if (e instanceof ArrayBuffer)
                        if (f(new Uint8Array(e.slice(0, 4))) === P) {
                            try {
                                o[m.KHR_BINARY_GLTF] = new U(e)
                            } catch (e) {
                                n && n(e);
                                return
                            }
                            i = JSON.parse(o[m.KHR_BINARY_GLTF].content)
                        } else i = JSON.parse(f(new Uint8Array(e)));
                    else i = e;
                    if (void 0 === i.asset || i.asset.version[0] < 2) {
                        n && n(Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));
                        return
                    }
                    let a = new ei(i, {
                        path: t || this.resourcePath || "",
                        crossOrigin: this.crossOrigin,
                        requestHeader: this.requestHeader,
                        manager: this.manager,
                        ktx2Loader: this.ktx2Loader,
                        meshoptDecoder: this.meshoptDecoder
                    });
                    a.fileLoader.setRequestHeader(this.requestHeader);
                    for (let e = 0; e < this.pluginCallbacks.length; e++) {
                        let t = this.pluginCallbacks[e](a);
                        t.name || console.error("THREE.GLTFLoader: Invalid plugin found: missing name"), s[t.name] = t, o[t.name] = !0
                    }
                    if (i.extensionsUsed)
                        for (let e = 0; e < i.extensionsUsed.length; ++e) {
                            let t = i.extensionsUsed[e],
                                r = i.extensionsRequired || [];
                            switch (t) {
                                case m.KHR_MATERIALS_UNLIT:
                                    o[t] = new B;
                                    break;
                                case m.KHR_DRACO_MESH_COMPRESSION:
                                    o[t] = new _(i, this.dracoLoader);
                                    break;
                                case m.KHR_TEXTURE_TRANSFORM:
                                    o[t] = new L;
                                    break;
                                case m.KHR_MESH_QUANTIZATION:
                                    o[t] = new J;
                                    break;
                                default:
                                    r.indexOf(t) >= 0 && void 0 === s[t] && console.warn('THREE.GLTFLoader: Unknown extension "' + t + '".')
                            }
                        }
                    a.setExtensions(o), a.setPlugins(s), a.parse(r, n)
                }
                parseAsync(e, t) {
                    let r = this;
                    return new Promise(function(n, i) {
                        r.parse(e, t, n, i)
                    })
                }
            }

            function A() {
                let e = {};
                return {
                    get: function(t) {
                        return e[t]
                    },
                    add: function(t, r) {
                        e[t] = r
                    },
                    remove: function(t) {
                        delete e[t]
                    },
                    removeAll: function() {
                        e = {}
                    }
                }
            }
            let m = {
                KHR_BINARY_GLTF: "KHR_binary_glTF",
                KHR_DRACO_MESH_COMPRESSION: "KHR_draco_mesh_compression",
                KHR_LIGHTS_PUNCTUAL: "KHR_lights_punctual",
                KHR_MATERIALS_CLEARCOAT: "KHR_materials_clearcoat",
                KHR_MATERIALS_DISPERSION: "KHR_materials_dispersion",
                KHR_MATERIALS_IOR: "KHR_materials_ior",
                KHR_MATERIALS_SHEEN: "KHR_materials_sheen",
                KHR_MATERIALS_SPECULAR: "KHR_materials_specular",
                KHR_MATERIALS_TRANSMISSION: "KHR_materials_transmission",
                KHR_MATERIALS_IRIDESCENCE: "KHR_materials_iridescence",
                KHR_MATERIALS_ANISOTROPY: "KHR_materials_anisotropy",
                KHR_MATERIALS_UNLIT: "KHR_materials_unlit",
                KHR_MATERIALS_VOLUME: "KHR_materials_volume",
                KHR_TEXTURE_BASISU: "KHR_texture_basisu",
                KHR_TEXTURE_TRANSFORM: "KHR_texture_transform",
                KHR_MESH_QUANTIZATION: "KHR_mesh_quantization",
                KHR_MATERIALS_EMISSIVE_STRENGTH: "KHR_materials_emissive_strength",
                EXT_MATERIALS_BUMP: "EXT_materials_bump",
                EXT_TEXTURE_WEBP: "EXT_texture_webp",
                EXT_TEXTURE_AVIF: "EXT_texture_avif",
                EXT_MESHOPT_COMPRESSION: "EXT_meshopt_compression",
                EXT_MESH_GPU_INSTANCING: "EXT_mesh_gpu_instancing"
            };
            class g {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_LIGHTS_PUNCTUAL, this.cache = {
                        refs: {},
                        uses: {}
                    }
                }
                _markDefs() {
                    let e = this.parser,
                        t = this.parser.json.nodes || [];
                    for (let r = 0, n = t.length; r < n; r++) {
                        let n = t[r];
                        n.extensions && n.extensions[this.name] && void 0 !== n.extensions[this.name].light && e._addNodeRef(this.cache, n.extensions[this.name].light)
                    }
                }
                _loadLight(e) {
                    let t, r = this.parser,
                        n = "light:" + e,
                        o = r.cache.get(n);
                    if (o) return o;
                    let s = r.json,
                        a = ((s.extensions && s.extensions[this.name] || {}).lights || [])[e],
                        l = new i.Q1f(0xffffff);
                    void 0 !== a.color && l.setRGB(a.color[0], a.color[1], a.color[2], h);
                    let u = void 0 !== a.range ? a.range : 0;
                    switch (a.type) {
                        case "directional":
                            (t = new i.ZyN(l)).target.position.set(0, 0, -1), t.add(t.target);
                            break;
                        case "point":
                            (t = new i.HiM(l)).distance = u;
                            break;
                        case "spot":
                            (t = new i.nCl(l)).distance = u, a.spot = a.spot || {}, a.spot.innerConeAngle = void 0 !== a.spot.innerConeAngle ? a.spot.innerConeAngle : 0, a.spot.outerConeAngle = void 0 !== a.spot.outerConeAngle ? a.spot.outerConeAngle : Math.PI / 4, t.angle = a.spot.outerConeAngle, t.penumbra = 1 - a.spot.innerConeAngle / a.spot.outerConeAngle, t.target.position.set(0, 0, -1), t.add(t.target);
                            break;
                        default:
                            throw Error("THREE.GLTFLoader: Unexpected light type: " + a.type)
                    }
                    return t.position.set(0, 0, 0), t.decay = 2, ee(t, a), void 0 !== a.intensity && (t.intensity = a.intensity), t.name = r.createUniqueName(a.name || "light_" + e), o = Promise.resolve(t), r.cache.add(n, o), o
                }
                getDependency(e, t) {
                    if ("light" === e) return this._loadLight(t)
                }
                createNodeAttachment(e) {
                    let t = this,
                        r = this.parser,
                        n = r.json.nodes[e],
                        i = (n.extensions && n.extensions[this.name] || {}).light;
                    return void 0 === i ? null : this._loadLight(i).then(function(e) {
                        return r._getNodeRef(t.cache, i, e)
                    })
                }
            }
            class B {
                constructor() {
                    this.name = m.KHR_MATERIALS_UNLIT
                }
                getMaterialType() {
                    return i.V9B
                }
                extendParams(e, t, r) {
                    let n = [];
                    e.color = new i.Q1f(1, 1, 1), e.opacity = 1;
                    let o = t.pbrMetallicRoughness;
                    if (o) {
                        if (Array.isArray(o.baseColorFactor)) {
                            let t = o.baseColorFactor;
                            e.color.setRGB(t[0], t[1], t[2], h), e.opacity = t[3]
                        }
                        void 0 !== o.baseColorTexture && n.push(r.assignTexture(e, "map", o.baseColorTexture, d))
                    }
                    return Promise.all(n)
                }
            }
            class v {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_EMISSIVE_STRENGTH
                }
                extendMaterialParams(e, t) {
                    let r = this.parser.json.materials[e];
                    if (!r.extensions || !r.extensions[this.name]) return Promise.resolve();
                    let n = r.extensions[this.name].emissiveStrength;
                    return void 0 !== n && (t.emissiveIntensity = n), Promise.resolve()
                }
            }
            class y {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_CLEARCOAT
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.uSd : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let o = [],
                        s = n.extensions[this.name];
                    if (void 0 !== s.clearcoatFactor && (t.clearcoat = s.clearcoatFactor), void 0 !== s.clearcoatTexture && o.push(r.assignTexture(t, "clearcoatMap", s.clearcoatTexture)), void 0 !== s.clearcoatRoughnessFactor && (t.clearcoatRoughness = s.clearcoatRoughnessFactor), void 0 !== s.clearcoatRoughnessTexture && o.push(r.assignTexture(t, "clearcoatRoughnessMap", s.clearcoatRoughnessTexture)), void 0 !== s.clearcoatNormalTexture && (o.push(r.assignTexture(t, "clearcoatNormalMap", s.clearcoatNormalTexture)), void 0 !== s.clearcoatNormalTexture.scale)) {
                        let e = s.clearcoatNormalTexture.scale;
                        t.clearcoatNormalScale = new i.I9Y(e, e)
                    }
                    return Promise.all(o)
                }
            }
            class C {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_DISPERSION
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.uSd : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser.json.materials[e];
                    if (!r.extensions || !r.extensions[this.name]) return Promise.resolve();
                    let n = r.extensions[this.name];
                    return t.dispersion = void 0 !== n.dispersion ? n.dispersion : 0, Promise.resolve()
                }
            }
            class b {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_IRIDESCENCE
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.uSd : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let i = [],
                        o = n.extensions[this.name];
                    return void 0 !== o.iridescenceFactor && (t.iridescence = o.iridescenceFactor), void 0 !== o.iridescenceTexture && i.push(r.assignTexture(t, "iridescenceMap", o.iridescenceTexture)), void 0 !== o.iridescenceIor && (t.iridescenceIOR = o.iridescenceIor), void 0 === t.iridescenceThicknessRange && (t.iridescenceThicknessRange = [100, 400]), void 0 !== o.iridescenceThicknessMinimum && (t.iridescenceThicknessRange[0] = o.iridescenceThicknessMinimum), void 0 !== o.iridescenceThicknessMaximum && (t.iridescenceThicknessRange[1] = o.iridescenceThicknessMaximum), void 0 !== o.iridescenceThicknessTexture && i.push(r.assignTexture(t, "iridescenceThicknessMap", o.iridescenceThicknessTexture)), Promise.all(i)
                }
            }
            class E {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_SHEEN
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.uSd : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let o = [];
                    t.sheenColor = new i.Q1f(0, 0, 0), t.sheenRoughness = 0, t.sheen = 1;
                    let s = n.extensions[this.name];
                    if (void 0 !== s.sheenColorFactor) {
                        let e = s.sheenColorFactor;
                        t.sheenColor.setRGB(e[0], e[1], e[2], h)
                    }
                    return void 0 !== s.sheenRoughnessFactor && (t.sheenRoughness = s.sheenRoughnessFactor), void 0 !== s.sheenColorTexture && o.push(r.assignTexture(t, "sheenColorMap", s.sheenColorTexture, d)), void 0 !== s.sheenRoughnessTexture && o.push(r.assignTexture(t, "sheenRoughnessMap", s.sheenRoughnessTexture)), Promise.all(o)
                }
            }
            class w {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_TRANSMISSION
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.uSd : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let i = [],
                        o = n.extensions[this.name];
                    return void 0 !== o.transmissionFactor && (t.transmission = o.transmissionFactor), void 0 !== o.transmissionTexture && i.push(r.assignTexture(t, "transmissionMap", o.transmissionTexture)), Promise.all(i)
                }
            }
            class M {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_VOLUME
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.uSd : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let o = [],
                        s = n.extensions[this.name];
                    t.thickness = void 0 !== s.thicknessFactor ? s.thicknessFactor : 0, void 0 !== s.thicknessTexture && o.push(r.assignTexture(t, "thicknessMap", s.thicknessTexture)), t.attenuationDistance = s.attenuationDistance || 1 / 0;
                    let a = s.attenuationColor || [1, 1, 1];
                    return t.attenuationColor = new i.Q1f().setRGB(a[0], a[1], a[2], h), Promise.all(o)
                }
            }
            class R {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_IOR
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.uSd : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser.json.materials[e];
                    if (!r.extensions || !r.extensions[this.name]) return Promise.resolve();
                    let n = r.extensions[this.name];
                    return t.ior = void 0 !== n.ior ? n.ior : 1.5, Promise.resolve()
                }
            }
            class F {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_SPECULAR
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.uSd : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let o = [],
                        s = n.extensions[this.name];
                    t.specularIntensity = void 0 !== s.specularFactor ? s.specularFactor : 1, void 0 !== s.specularTexture && o.push(r.assignTexture(t, "specularIntensityMap", s.specularTexture));
                    let a = s.specularColorFactor || [1, 1, 1];
                    return t.specularColor = new i.Q1f().setRGB(a[0], a[1], a[2], h), void 0 !== s.specularColorTexture && o.push(r.assignTexture(t, "specularColorMap", s.specularColorTexture, d)), Promise.all(o)
                }
            }
            class x {
                constructor(e) {
                    this.parser = e, this.name = m.EXT_MATERIALS_BUMP
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.uSd : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let i = [],
                        o = n.extensions[this.name];
                    return t.bumpScale = void 0 !== o.bumpFactor ? o.bumpFactor : 1, void 0 !== o.bumpTexture && i.push(r.assignTexture(t, "bumpMap", o.bumpTexture)), Promise.all(i)
                }
            }
            class I {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_MATERIALS_ANISOTROPY
                }
                getMaterialType(e) {
                    let t = this.parser.json.materials[e];
                    return t.extensions && t.extensions[this.name] ? i.uSd : null
                }
                extendMaterialParams(e, t) {
                    let r = this.parser,
                        n = r.json.materials[e];
                    if (!n.extensions || !n.extensions[this.name]) return Promise.resolve();
                    let i = [],
                        o = n.extensions[this.name];
                    return void 0 !== o.anisotropyStrength && (t.anisotropy = o.anisotropyStrength), void 0 !== o.anisotropyRotation && (t.anisotropyRotation = o.anisotropyRotation), void 0 !== o.anisotropyTexture && i.push(r.assignTexture(t, "anisotropyMap", o.anisotropyTexture)), Promise.all(i)
                }
            }
            class T {
                constructor(e) {
                    this.parser = e, this.name = m.KHR_TEXTURE_BASISU
                }
                loadTexture(e) {
                    let t = this.parser,
                        r = t.json,
                        n = r.textures[e];
                    if (!n.extensions || !n.extensions[this.name]) return null;
                    let i = n.extensions[this.name],
                        o = t.options.ktx2Loader;
                    if (!o)
                        if (!(r.extensionsRequired && r.extensionsRequired.indexOf(this.name) >= 0)) return null;
                        else throw Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");
                    return t.loadTextureImage(e, i.source, o)
                }
            }
            class S {
                constructor(e) {
                    this.parser = e, this.name = m.EXT_TEXTURE_WEBP, this.isSupported = null
                }
                loadTexture(e) {
                    let t = this.name,
                        r = this.parser,
                        n = r.json,
                        i = n.textures[e];
                    if (!i.extensions || !i.extensions[t]) return null;
                    let o = i.extensions[t],
                        s = n.images[o.source],
                        a = r.textureLoader;
                    if (s.uri) {
                        let e = r.options.manager.getHandler(s.uri);
                        null !== e && (a = e)
                    }
                    return this.detectSupport().then(function(i) {
                        if (i) return r.loadTextureImage(e, o.source, a);
                        if (n.extensionsRequired && n.extensionsRequired.indexOf(t) >= 0) throw Error("THREE.GLTFLoader: WebP required by asset but unsupported.");
                        return r.loadTexture(e)
                    })
                }
                detectSupport() {
                    return this.isSupported || (this.isSupported = new Promise(function(e) {
                        let t = new Image;
                        t.src = "data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA", t.onload = t.onerror = function() {
                            e(1 === t.height)
                        }
                    })), this.isSupported
                }
            }
            class D {
                constructor(e) {
                    this.parser = e, this.name = m.EXT_TEXTURE_AVIF, this.isSupported = null
                }
                loadTexture(e) {
                    let t = this.name,
                        r = this.parser,
                        n = r.json,
                        i = n.textures[e];
                    if (!i.extensions || !i.extensions[t]) return null;
                    let o = i.extensions[t],
                        s = n.images[o.source],
                        a = r.textureLoader;
                    if (s.uri) {
                        let e = r.options.manager.getHandler(s.uri);
                        null !== e && (a = e)
                    }
                    return this.detectSupport().then(function(i) {
                        if (i) return r.loadTextureImage(e, o.source, a);
                        if (n.extensionsRequired && n.extensionsRequired.indexOf(t) >= 0) throw Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");
                        return r.loadTexture(e)
                    })
                }
                detectSupport() {
                    return this.isSupported || (this.isSupported = new Promise(function(e) {
                        let t = new Image;
                        t.src = "data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=", t.onload = t.onerror = function() {
                            e(1 === t.height)
                        }
                    })), this.isSupported
                }
            }
            class O {
                constructor(e) {
                    this.name = m.EXT_MESHOPT_COMPRESSION, this.parser = e
                }
                loadBufferView(e) {
                    let t = this.parser.json,
                        r = t.bufferViews[e];
                    if (!r.extensions || !r.extensions[this.name]) return null; {
                        let e = r.extensions[this.name],
                            n = this.parser.getDependency("buffer", e.buffer),
                            i = this.parser.options.meshoptDecoder;
                        if (!i || !i.supported)
                            if (!(t.extensionsRequired && t.extensionsRequired.indexOf(this.name) >= 0)) return null;
                            else throw Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");
                        return n.then(function(t) {
                            let r = e.byteOffset || 0,
                                n = e.byteLength || 0,
                                o = e.count,
                                s = e.byteStride,
                                a = new Uint8Array(t, r, n);
                            return i.decodeGltfBufferAsync ? i.decodeGltfBufferAsync(o, s, a, e.mode, e.filter).then(function(e) {
                                return e.buffer
                            }) : i.ready.then(function() {
                                let t = new ArrayBuffer(o * s);
                                return i.decodeGltfBuffer(new Uint8Array(t), o, s, a, e.mode, e.filter), t
                            })
                        })
                    }
                }
            }
            class G {
                constructor(e) {
                    this.name = m.EXT_MESH_GPU_INSTANCING, this.parser = e
                }
                createNodeMesh(e) {
                    let t = this.parser.json,
                        r = t.nodes[e];
                    if (!r.extensions || !r.extensions[this.name] || void 0 === r.mesh) return null;
                    for (let e of t.meshes[r.mesh].primitives)
                        if (e.mode !== K.TRIANGLES && e.mode !== K.TRIANGLE_STRIP && e.mode !== K.TRIANGLE_FAN && void 0 !== e.mode) return null;
                    let n = r.extensions[this.name].attributes,
                        o = [],
                        s = {};
                    for (let e in n) o.push(this.parser.getDependency("accessor", n[e]).then(t => (s[e] = t, s[e])));
                    return o.length < 1 ? null : (o.push(this.parser.createNodeMesh(e)), Promise.all(o).then(e => {
                        let t = e.pop(),
                            r = t.isGroup ? t.children : [t],
                            n = e[0].count,
                            o = [];
                        for (let e of r) {
                            let t = new i.kn4,
                                r = new i.Pq0,
                                a = new i.PTz,
                                l = new i.Pq0(1, 1, 1),
                                u = new i.ZLX(e.geometry, e.material, n);
                            for (let e = 0; e < n; e++) s.TRANSLATION && r.fromBufferAttribute(s.TRANSLATION, e), s.ROTATION && a.fromBufferAttribute(s.ROTATION, e), s.SCALE && l.fromBufferAttribute(s.SCALE, e), u.setMatrixAt(e, t.compose(r, a, l));
                            for (let t in s)
                                if ("_COLOR_0" === t) {
                                    let e = s[t];
                                    u.instanceColor = new i.uWO(e.array, e.itemSize, e.normalized)
                                } else "TRANSLATION" !== t && "ROTATION" !== t && "SCALE" !== t && e.geometry.setAttribute(t, s[t]);
                            i.B69.prototype.copy.call(u, e), this.parser.assignFinalMaterial(u), o.push(u)
                        }
                        return t.isGroup ? (t.clear(), t.add(...o), t) : o[0]
                    }))
                }
            }
            let P = "glTF",
                H = {
                    JSON: 0x4e4f534a,
                    BIN: 5130562
                };
            class U {
                constructor(e) {
                    this.name = m.KHR_BINARY_GLTF, this.content = null, this.body = null;
                    let t = new DataView(e, 0, 12);
                    if (this.header = {
                            magic: f(new Uint8Array(e.slice(0, 4))),
                            version: t.getUint32(4, !0),
                            length: t.getUint32(8, !0)
                        }, this.header.magic !== P) throw Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");
                    if (this.header.version < 2) throw Error("THREE.GLTFLoader: Legacy binary file detected.");
                    let r = this.header.length - 12,
                        n = new DataView(e, 12),
                        i = 0;
                    for (; i < r;) {
                        let t = n.getUint32(i, !0);
                        i += 4;
                        let r = n.getUint32(i, !0);
                        if (i += 4, r === H.JSON) {
                            let r = new Uint8Array(e, 12 + i, t);
                            this.content = f(r)
                        } else if (r === H.BIN) {
                            let r = 12 + i;
                            this.body = e.slice(r, r + t)
                        }
                        i += t
                    }
                    if (null === this.content) throw Error("THREE.GLTFLoader: JSON content not found.")
                }
            }
            class _ {
                constructor(e, t) {
                    if (!t) throw Error("THREE.GLTFLoader: No DRACOLoader instance provided.");
                    this.name = m.KHR_DRACO_MESH_COMPRESSION, this.json = e, this.dracoLoader = t, this.dracoLoader.preload()
                }
                decodePrimitive(e, t) {
                    let r = this.json,
                        n = this.dracoLoader,
                        i = e.extensions[this.name].bufferView,
                        o = e.extensions[this.name].attributes,
                        s = {},
                        a = {},
                        l = {};
                    for (let e in o) s[z[e] || e.toLowerCase()] = o[e];
                    for (let t in e.attributes) {
                        let n = z[t] || t.toLowerCase();
                        if (void 0 !== o[t]) {
                            let i = r.accessors[e.attributes[t]],
                                o = Q[i.componentType];
                            l[n] = o.name, a[n] = !0 === i.normalized
                        }
                    }
                    return t.getDependency("bufferView", i).then(function(e) {
                        return new Promise(function(t, r) {
                            n.decodeDracoFile(e, function(e) {
                                for (let t in e.attributes) {
                                    let r = e.attributes[t],
                                        n = a[t];
                                    void 0 !== n && (r.normalized = n)
                                }
                                t(e)
                            }, s, l, h, r)
                        })
                    })
                }
            }
            class L {
                constructor() {
                    this.name = m.KHR_TEXTURE_TRANSFORM
                }
                extendTexture(e, t) {
                    return (void 0 === t.texCoord || t.texCoord === e.channel) && void 0 === t.offset && void 0 === t.rotation && void 0 === t.scale || (e = e.clone(), void 0 !== t.texCoord && (e.channel = t.texCoord), void 0 !== t.offset && e.offset.fromArray(t.offset), void 0 !== t.rotation && (e.rotation = t.rotation), void 0 !== t.scale && e.repeat.fromArray(t.scale), e.needsUpdate = !0), e
                }
            }
            class J {
                constructor() {
                    this.name = m.KHR_MESH_QUANTIZATION
                }
            }
            class j extends i.lGw {
                constructor(e, t, r, n) {
                    super(e, t, r, n)
                }
                copySampleValue_(e) {
                    let t = this.resultBuffer,
                        r = this.sampleValues,
                        n = this.valueSize,
                        i = e * n * 3 + n;
                    for (let e = 0; e !== n; e++) t[e] = r[i + e];
                    return t
                }
                interpolate_(e, t, r, n) {
                    let i = this.resultBuffer,
                        o = this.sampleValues,
                        s = this.valueSize,
                        a = 2 * s,
                        l = 3 * s,
                        u = n - t,
                        c = (r - t) / u,
                        f = c * c,
                        d = f * c,
                        h = e * l,
                        p = h - l,
                        A = -2 * d + 3 * f,
                        m = d - f,
                        g = 1 - A,
                        B = m - f + c;
                    for (let e = 0; e !== s; e++) {
                        let t = o[p + e + s],
                            r = o[p + e + a] * u,
                            n = o[h + e + s],
                            l = o[h + e] * u;
                        i[e] = g * t + B * r + A * n + m * l
                    }
                    return i
                }
            }
            let k = new i.PTz;
            class N extends j {
                interpolate_(e, t, r, n) {
                    let i = super.interpolate_(e, t, r, n);
                    return k.fromArray(i).normalize().toArray(i), i
                }
            }
            let K = {
                    POINTS: 0,
                    LINES: 1,
                    LINE_LOOP: 2,
                    LINE_STRIP: 3,
                    TRIANGLES: 4,
                    TRIANGLE_STRIP: 5,
                    TRIANGLE_FAN: 6
                },
                Q = {
                    5120: Int8Array,
                    5121: Uint8Array,
                    5122: Int16Array,
                    5123: Uint16Array,
                    5125: Uint32Array,
                    5126: Float32Array
                },
                X = {
                    9728: i.hxR,
                    9729: i.k6q,
                    9984: i.pHI,
                    9985: i.kRr,
                    9986: i.Cfg,
                    9987: i.$_I
                },
                Y = {
                    33071: i.ghU,
                    33648: i.kTW,
                    10497: i.GJx
                },
                W = {
                    SCALAR: 1,
                    VEC2: 2,
                    VEC3: 3,
                    VEC4: 4,
                    MAT2: 4,
                    MAT3: 9,
                    MAT4: 16
                },
                z = {
                    POSITION: "position",
                    NORMAL: "normal",
                    TANGENT: "tangent",
                    ...c.r >= 152 ? {
                        TEXCOORD_0: "uv",
                        TEXCOORD_1: "uv1",
                        TEXCOORD_2: "uv2",
                        TEXCOORD_3: "uv3"
                    } : {
                        TEXCOORD_0: "uv",
                        TEXCOORD_1: "uv2"
                    },
                    COLOR_0: "color",
                    WEIGHTS_0: "skinWeight",
                    JOINTS_0: "skinIndex"
                },
                q = {
                    scale: "scale",
                    translation: "position",
                    rotation: "quaternion",
                    weights: "morphTargetInfluences"
                },
                Z = {
                    CUBICSPLINE: void 0,
                    LINEAR: i.PJ3,
                    STEP: i.ljd
                },
                V = {
                    OPAQUE: "OPAQUE",
                    MASK: "MASK",
                    BLEND: "BLEND"
                };

            function $(e, t, r) {
                for (let n in r.extensions) void 0 === e[n] && (t.userData.gltfExtensions = t.userData.gltfExtensions || {}, t.userData.gltfExtensions[n] = r.extensions[n])
            }

            function ee(e, t) {
                void 0 !== t.extras && ("object" == typeof t.extras ? Object.assign(e.userData, t.extras) : console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, " + t.extras))
            }

            function et(e) {
                let t = "",
                    r = Object.keys(e).sort();
                for (let n = 0, i = r.length; n < i; n++) t += r[n] + ":" + e[r[n]] + ";";
                return t
            }

            function er(e) {
                switch (e) {
                    case Int8Array:
                        return 1 / 127;
                    case Uint8Array:
                        return 1 / 255;
                    case Int16Array:
                        return 1 / 32767;
                    case Uint16Array:
                        return 1 / 65535;
                    default:
                        throw Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")
                }
            }
            let en = new i.kn4;
            class ei {
                constructor(e = {}, t = {}) {
                    this.json = e, this.extensions = {}, this.plugins = {}, this.options = t, this.cache = new A, this.associations = new Map, this.primitiveCache = {}, this.nodeCache = {}, this.meshCache = {
                        refs: {},
                        uses: {}
                    }, this.cameraCache = {
                        refs: {},
                        uses: {}
                    }, this.lightCache = {
                        refs: {},
                        uses: {}
                    }, this.sourceCache = {}, this.textureCache = {}, this.nodeNamesUsed = {};
                    let r = !1,
                        n = !1,
                        o = -1;
                    "undefined" != typeof navigator && void 0 !== navigator.userAgent && (r = !0 === /^((?!chrome|android).)*safari/i.test(navigator.userAgent), o = (n = navigator.userAgent.indexOf("Firefox") > -1) ? navigator.userAgent.match(/Firefox\/([0-9]+)\./)[1] : -1), "undefined" == typeof createImageBitmap || r || n && o < 98 ? this.textureLoader = new i.Tap(this.options.manager) : this.textureLoader = new i.Kzg(this.options.manager), this.textureLoader.setCrossOrigin(this.options.crossOrigin), this.textureLoader.setRequestHeader(this.options.requestHeader), this.fileLoader = new i.Y9S(this.options.manager), this.fileLoader.setResponseType("arraybuffer"), "use-credentials" === this.options.crossOrigin && this.fileLoader.setWithCredentials(!0)
                }
                setExtensions(e) {
                    this.extensions = e
                }
                setPlugins(e) {
                    this.plugins = e
                }
                parse(e, t) {
                    let r = this,
                        n = this.json,
                        i = this.extensions;
                    this.cache.removeAll(), this.nodeCache = {}, this._invokeAll(function(e) {
                        return e._markDefs && e._markDefs()
                    }), Promise.all(this._invokeAll(function(e) {
                        return e.beforeRoot && e.beforeRoot()
                    })).then(function() {
                        return Promise.all([r.getDependencies("scene"), r.getDependencies("animation"), r.getDependencies("camera")])
                    }).then(function(t) {
                        let o = {
                            scene: t[0][n.scene || 0],
                            scenes: t[0],
                            animations: t[1],
                            cameras: t[2],
                            asset: n.asset,
                            parser: r,
                            userData: {}
                        };
                        return $(i, o, n), ee(o, n), Promise.all(r._invokeAll(function(e) {
                            return e.afterRoot && e.afterRoot(o)
                        })).then(function() {
                            for (let e of o.scenes) e.updateMatrixWorld();
                            e(o)
                        })
                    }).catch(t)
                }
                _markDefs() {
                    let e = this.json.nodes || [],
                        t = this.json.skins || [],
                        r = this.json.meshes || [];
                    for (let r = 0, n = t.length; r < n; r++) {
                        let n = t[r].joints;
                        for (let t = 0, r = n.length; t < r; t++) e[n[t]].isBone = !0
                    }
                    for (let t = 0, n = e.length; t < n; t++) {
                        let n = e[t];
                        void 0 !== n.mesh && (this._addNodeRef(this.meshCache, n.mesh), void 0 !== n.skin && (r[n.mesh].isSkinnedMesh = !0)), void 0 !== n.camera && this._addNodeRef(this.cameraCache, n.camera)
                    }
                }
                _addNodeRef(e, t) {
                    void 0 !== t && (void 0 === e.refs[t] && (e.refs[t] = e.uses[t] = 0), e.refs[t]++)
                }
                _getNodeRef(e, t, r) {
                    if (e.refs[t] <= 1) return r;
                    let n = r.clone(),
                        i = (e, t) => {
                            let r = this.associations.get(e);
                            for (let [n, o] of (null != r && this.associations.set(t, r), e.children.entries())) i(o, t.children[n])
                        };
                    return i(r, n), n.name += "_instance_" + e.uses[t]++, n
                }
                _invokeOne(e) {
                    let t = Object.values(this.plugins);
                    t.push(this);
                    for (let r = 0; r < t.length; r++) {
                        let n = e(t[r]);
                        if (n) return n
                    }
                    return null
                }
                _invokeAll(e) {
                    let t = Object.values(this.plugins);
                    t.unshift(this);
                    let r = [];
                    for (let n = 0; n < t.length; n++) {
                        let i = e(t[n]);
                        i && r.push(i)
                    }
                    return r
                }
                getDependency(e, t) {
                    let r = e + ":" + t,
                        n = this.cache.get(r);
                    if (!n) {
                        switch (e) {
                            case "scene":
                                n = this.loadScene(t);
                                break;
                            case "node":
                                n = this._invokeOne(function(e) {
                                    return e.loadNode && e.loadNode(t)
                                });
                                break;
                            case "mesh":
                                n = this._invokeOne(function(e) {
                                    return e.loadMesh && e.loadMesh(t)
                                });
                                break;
                            case "accessor":
                                n = this.loadAccessor(t);
                                break;
                            case "bufferView":
                                n = this._invokeOne(function(e) {
                                    return e.loadBufferView && e.loadBufferView(t)
                                });
                                break;
                            case "buffer":
                                n = this.loadBuffer(t);
                                break;
                            case "material":
                                n = this._invokeOne(function(e) {
                                    return e.loadMaterial && e.loadMaterial(t)
                                });
                                break;
                            case "texture":
                                n = this._invokeOne(function(e) {
                                    return e.loadTexture && e.loadTexture(t)
                                });
                                break;
                            case "skin":
                                n = this.loadSkin(t);
                                break;
                            case "animation":
                                n = this._invokeOne(function(e) {
                                    return e.loadAnimation && e.loadAnimation(t)
                                });
                                break;
                            case "camera":
                                n = this.loadCamera(t);
                                break;
                            default:
                                if (!(n = this._invokeOne(function(r) {
                                        return r != this && r.getDependency && r.getDependency(e, t)
                                    }))) throw Error("Unknown type: " + e)
                        }
                        this.cache.add(r, n)
                    }
                    return n
                }
                getDependencies(e) {
                    let t = this.cache.get(e);
                    if (!t) {
                        let r = this;
                        t = Promise.all((this.json[e + ("mesh" === e ? "es" : "s")] || []).map(function(t, n) {
                            return r.getDependency(e, n)
                        })), this.cache.add(e, t)
                    }
                    return t
                }
                loadBuffer(e) {
                    let t = this.json.buffers[e],
                        r = this.fileLoader;
                    if (t.type && "arraybuffer" !== t.type) throw Error("THREE.GLTFLoader: " + t.type + " buffer type is not supported.");
                    if (void 0 === t.uri && 0 === e) return Promise.resolve(this.extensions[m.KHR_BINARY_GLTF].body);
                    let n = this.options;
                    return new Promise(function(e, o) {
                        r.load(i.r6x.resolveURL(t.uri, n.path), e, void 0, function() {
                            o(Error('THREE.GLTFLoader: Failed to load buffer "' + t.uri + '".'))
                        })
                    })
                }
                loadBufferView(e) {
                    let t = this.json.bufferViews[e];
                    return this.getDependency("buffer", t.buffer).then(function(e) {
                        let r = t.byteLength || 0,
                            n = t.byteOffset || 0;
                        return e.slice(n, n + r)
                    })
                }
                loadAccessor(e) {
                    let t = this,
                        r = this.json,
                        n = this.json.accessors[e];
                    if (void 0 === n.bufferView && void 0 === n.sparse) {
                        let e = W[n.type],
                            t = Q[n.componentType],
                            r = !0 === n.normalized,
                            o = new t(n.count * e);
                        return Promise.resolve(new i.THS(o, e, r))
                    }
                    let o = [];
                    return void 0 !== n.bufferView ? o.push(this.getDependency("bufferView", n.bufferView)) : o.push(null), void 0 !== n.sparse && (o.push(this.getDependency("bufferView", n.sparse.indices.bufferView)), o.push(this.getDependency("bufferView", n.sparse.values.bufferView))), Promise.all(o).then(function(e) {
                        let o, s, a = e[0],
                            l = W[n.type],
                            u = Q[n.componentType],
                            c = u.BYTES_PER_ELEMENT,
                            f = c * l,
                            d = n.byteOffset || 0,
                            h = void 0 !== n.bufferView ? r.bufferViews[n.bufferView].byteStride : void 0,
                            p = !0 === n.normalized;
                        if (h && h !== f) {
                            let e = Math.floor(d / h),
                                r = "InterleavedBuffer:" + n.bufferView + ":" + n.componentType + ":" + e + ":" + n.count,
                                f = t.cache.get(r);
                            f || (o = new u(a, e * h, n.count * h / c), f = new i.eB$(o, h / c), t.cache.add(r, f)), s = new i.eHs(f, l, d % h / c, p)
                        } else o = null === a ? new u(n.count * l) : new u(a, d, n.count * l), s = new i.THS(o, l, p);
                        if (void 0 !== n.sparse) {
                            let t = W.SCALAR,
                                r = Q[n.sparse.indices.componentType],
                                o = n.sparse.indices.byteOffset || 0,
                                c = n.sparse.values.byteOffset || 0,
                                f = new r(e[1], o, n.sparse.count * t),
                                d = new u(e[2], c, n.sparse.count * l);
                            null !== a && (s = new i.THS(s.array.slice(), s.itemSize, s.normalized));
                            for (let e = 0, t = f.length; e < t; e++) {
                                let t = f[e];
                                if (s.setX(t, d[e * l]), l >= 2 && s.setY(t, d[e * l + 1]), l >= 3 && s.setZ(t, d[e * l + 2]), l >= 4 && s.setW(t, d[e * l + 3]), l >= 5) throw Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")
                            }
                        }
                        return s
                    })
                }
                loadTexture(e) {
                    let t = this.json,
                        r = this.options,
                        n = t.textures[e].source,
                        i = t.images[n],
                        o = this.textureLoader;
                    if (i.uri) {
                        let e = r.manager.getHandler(i.uri);
                        null !== e && (o = e)
                    }
                    return this.loadTextureImage(e, n, o)
                }
                loadTextureImage(e, t, r) {
                    let n = this,
                        o = this.json,
                        s = o.textures[e],
                        a = o.images[t],
                        l = (a.uri || a.bufferView) + ":" + s.sampler;
                    if (this.textureCache[l]) return this.textureCache[l];
                    let u = this.loadImageSource(t, r).then(function(t) {
                        t.flipY = !1, t.name = s.name || a.name || "", "" === t.name && "string" == typeof a.uri && !1 === a.uri.startsWith("data:image/") && (t.name = a.uri);
                        let r = (o.samplers || {})[s.sampler] || {};
                        return t.magFilter = X[r.magFilter] || i.k6q, t.minFilter = X[r.minFilter] || i.$_I, t.wrapS = Y[r.wrapS] || i.GJx, t.wrapT = Y[r.wrapT] || i.GJx, n.associations.set(t, {
                            textures: e
                        }), t
                    }).catch(function() {
                        return null
                    });
                    return this.textureCache[l] = u, u
                }
                loadImageSource(e, t) {
                    let r = this.json,
                        n = this.options;
                    if (void 0 !== this.sourceCache[e]) return this.sourceCache[e].then(e => e.clone());
                    let o = r.images[e],
                        s = self.URL || self.webkitURL,
                        a = o.uri || "",
                        l = !1;
                    if (void 0 !== o.bufferView) a = this.getDependency("bufferView", o.bufferView).then(function(e) {
                        l = !0;
                        let t = new Blob([e], {
                            type: o.mimeType
                        });
                        return a = s.createObjectURL(t)
                    });
                    else if (void 0 === o.uri) throw Error("THREE.GLTFLoader: Image " + e + " is missing URI and bufferView");
                    let u = Promise.resolve(a).then(function(e) {
                        return new Promise(function(r, o) {
                            let s = r;
                            !0 === t.isImageBitmapLoader && (s = function(e) {
                                let t = new i.gPd(e);
                                t.needsUpdate = !0, r(t)
                            }), t.load(i.r6x.resolveURL(e, n.path), s, void 0, o)
                        })
                    }).then(function(e) {
                        var t;
                        return !0 === l && s.revokeObjectURL(a), ee(e, o), e.userData.mimeType = o.mimeType || ((t = o.uri).search(/\.jpe?g($|\?)/i) > 0 || 0 === t.search(/^data\:image\/jpeg/) ? "image/jpeg" : t.search(/\.webp($|\?)/i) > 0 || 0 === t.search(/^data\:image\/webp/) ? "image/webp" : "image/png"), e
                    }).catch(function(e) {
                        throw console.error("THREE.GLTFLoader: Couldn't load texture", a), e
                    });
                    return this.sourceCache[e] = u, u
                }
                assignTexture(e, t, r, n) {
                    let i = this;
                    return this.getDependency("texture", r.index).then(function(o) {
                        if (!o) return null;
                        if (void 0 !== r.texCoord && r.texCoord > 0 && ((o = o.clone()).channel = r.texCoord), i.extensions[m.KHR_TEXTURE_TRANSFORM]) {
                            let e = void 0 !== r.extensions ? r.extensions[m.KHR_TEXTURE_TRANSFORM] : void 0;
                            if (e) {
                                let t = i.associations.get(o);
                                o = i.extensions[m.KHR_TEXTURE_TRANSFORM].extendTexture(o, e), i.associations.set(o, t)
                            }
                        }
                        return void 0 !== n && ("number" == typeof n && (n = 3001 === n ? d : h), "colorSpace" in o ? o.colorSpace = n : o.encoding = n === d ? 3001 : 3e3), e[t] = o, o
                    })
                }
                assignFinalMaterial(e) {
                    let t = e.geometry,
                        r = e.material,
                        n = void 0 === t.attributes.tangent,
                        o = void 0 !== t.attributes.color,
                        s = void 0 === t.attributes.normal;
                    if (e.isPoints) {
                        let e = "PointsMaterial:" + r.uuid,
                            t = this.cache.get(e);
                        t || (t = new i.BH$, i.imn.prototype.copy.call(t, r), t.color.copy(r.color), t.map = r.map, t.sizeAttenuation = !1, this.cache.add(e, t)), r = t
                    } else if (e.isLine) {
                        let e = "LineBasicMaterial:" + r.uuid,
                            t = this.cache.get(e);
                        t || (t = new i.mrM, i.imn.prototype.copy.call(t, r), t.color.copy(r.color), t.map = r.map, this.cache.add(e, t)), r = t
                    }
                    if (n || o || s) {
                        let e = "ClonedMaterial:" + r.uuid + ":";
                        n && (e += "derivative-tangents:"), o && (e += "vertex-colors:"), s && (e += "flat-shading:");
                        let t = this.cache.get(e);
                        t || (t = r.clone(), o && (t.vertexColors = !0), s && (t.flatShading = !0), n && (t.normalScale && (t.normalScale.y *= -1), t.clearcoatNormalScale && (t.clearcoatNormalScale.y *= -1)), this.cache.add(e, t), this.associations.set(t, this.associations.get(r))), r = t
                    }
                    e.material = r
                }
                getMaterialType() {
                    return i._4j
                }
                loadMaterial(e) {
                    let t, r = this,
                        n = this.json,
                        o = this.extensions,
                        s = n.materials[e],
                        a = {},
                        l = s.extensions || {},
                        u = [];
                    if (l[m.KHR_MATERIALS_UNLIT]) {
                        let e = o[m.KHR_MATERIALS_UNLIT];
                        t = e.getMaterialType(), u.push(e.extendParams(a, s, r))
                    } else {
                        let n = s.pbrMetallicRoughness || {};
                        if (a.color = new i.Q1f(1, 1, 1), a.opacity = 1, Array.isArray(n.baseColorFactor)) {
                            let e = n.baseColorFactor;
                            a.color.setRGB(e[0], e[1], e[2], h), a.opacity = e[3]
                        }
                        void 0 !== n.baseColorTexture && u.push(r.assignTexture(a, "map", n.baseColorTexture, d)), a.metalness = void 0 !== n.metallicFactor ? n.metallicFactor : 1, a.roughness = void 0 !== n.roughnessFactor ? n.roughnessFactor : 1, void 0 !== n.metallicRoughnessTexture && (u.push(r.assignTexture(a, "metalnessMap", n.metallicRoughnessTexture)), u.push(r.assignTexture(a, "roughnessMap", n.metallicRoughnessTexture))), t = this._invokeOne(function(t) {
                            return t.getMaterialType && t.getMaterialType(e)
                        }), u.push(Promise.all(this._invokeAll(function(t) {
                            return t.extendMaterialParams && t.extendMaterialParams(e, a)
                        })))
                    }!0 === s.doubleSided && (a.side = i.$EB);
                    let c = s.alphaMode || V.OPAQUE;
                    if (c === V.BLEND ? (a.transparent = !0, a.depthWrite = !1) : (a.transparent = !1, c === V.MASK && (a.alphaTest = void 0 !== s.alphaCutoff ? s.alphaCutoff : .5)), void 0 !== s.normalTexture && t !== i.V9B && (u.push(r.assignTexture(a, "normalMap", s.normalTexture)), a.normalScale = new i.I9Y(1, 1), void 0 !== s.normalTexture.scale)) {
                        let e = s.normalTexture.scale;
                        a.normalScale.set(e, e)
                    }
                    if (void 0 !== s.occlusionTexture && t !== i.V9B && (u.push(r.assignTexture(a, "aoMap", s.occlusionTexture)), void 0 !== s.occlusionTexture.strength && (a.aoMapIntensity = s.occlusionTexture.strength)), void 0 !== s.emissiveFactor && t !== i.V9B) {
                        let e = s.emissiveFactor;
                        a.emissive = new i.Q1f().setRGB(e[0], e[1], e[2], h)
                    }
                    return void 0 !== s.emissiveTexture && t !== i.V9B && u.push(r.assignTexture(a, "emissiveMap", s.emissiveTexture, d)), Promise.all(u).then(function() {
                        let n = new t(a);
                        return s.name && (n.name = s.name), ee(n, s), r.associations.set(n, {
                            materials: e
                        }), s.extensions && $(o, n, s), n
                    })
                }
                createUniqueName(e) {
                    let t = i.Nwf.sanitizeNodeName(e || "");
                    return t in this.nodeNamesUsed ? t + "_" + ++this.nodeNamesUsed[t] : (this.nodeNamesUsed[t] = 0, t)
                }
                loadGeometries(e) {
                    let t = this,
                        r = this.extensions,
                        n = this.primitiveCache,
                        o = [];
                    for (let s = 0, a = e.length; s < a; s++) {
                        let a = e[s],
                            l = function(e) {
                                let t, r = e.extensions && e.extensions[m.KHR_DRACO_MESH_COMPRESSION];
                                if (t = r ? "draco:" + r.bufferView + ":" + r.indices + ":" + et(r.attributes) : e.indices + ":" + et(e.attributes) + ":" + e.mode, void 0 !== e.targets)
                                    for (let r = 0, n = e.targets.length; r < n; r++) t += ":" + et(e.targets[r]);
                                return t
                            }(a),
                            u = n[l];
                        if (u) o.push(u.promise);
                        else {
                            let e;
                            e = a.extensions && a.extensions[m.KHR_DRACO_MESH_COMPRESSION] ? function(e) {
                                return r[m.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(e, t).then(function(r) {
                                    return eo(r, e, t)
                                })
                            }(a) : eo(new i.LoY, a, t), n[l] = {
                                primitive: a,
                                promise: e
                            }, o.push(e)
                        }
                    }
                    return Promise.all(o)
                }
                loadMesh(e) {
                    let t = this,
                        r = this.json,
                        n = this.extensions,
                        o = r.meshes[e],
                        s = o.primitives,
                        a = [];
                    for (let e = 0, t = s.length; e < t; e++) {
                        var l;
                        let t = void 0 === s[e].material ? (void 0 === (l = this.cache).DefaultMaterial && (l.DefaultMaterial = new i._4j({
                            color: 0xffffff,
                            emissive: 0,
                            metalness: 1,
                            roughness: 1,
                            transparent: !1,
                            depthTest: !0,
                            side: i.hB5
                        })), l.DefaultMaterial) : this.getDependency("material", s[e].material);
                        a.push(t)
                    }
                    return a.push(t.loadGeometries(s)), Promise.all(a).then(function(r) {
                        let a = r.slice(0, r.length - 1),
                            l = r[r.length - 1],
                            c = [];
                        for (let r = 0, f = l.length; r < f; r++) {
                            let f, d = l[r],
                                h = s[r],
                                p = a[r];
                            if (h.mode === K.TRIANGLES || h.mode === K.TRIANGLE_STRIP || h.mode === K.TRIANGLE_FAN || void 0 === h.mode) !0 === (f = !0 === o.isSkinnedMesh ? new i.I46(d, p) : new i.eaF(d, p)).isSkinnedMesh && f.normalizeSkinWeights(), h.mode === K.TRIANGLE_STRIP ? f.geometry = (0, u._c)(f.geometry, i.O49) : h.mode === K.TRIANGLE_FAN && (f.geometry = (0, u._c)(f.geometry, i.rYR));
                            else if (h.mode === K.LINES) f = new i.DXC(d, p);
                            else if (h.mode === K.LINE_STRIP) f = new i.N1A(d, p);
                            else if (h.mode === K.LINE_LOOP) f = new i.FCc(d, p);
                            else if (h.mode === K.POINTS) f = new i.ONl(d, p);
                            else throw Error("THREE.GLTFLoader: Primitive mode unsupported: " + h.mode);
                            Object.keys(f.geometry.morphAttributes).length > 0 && function(e, t) {
                                if (e.updateMorphTargets(), void 0 !== t.weights)
                                    for (let r = 0, n = t.weights.length; r < n; r++) e.morphTargetInfluences[r] = t.weights[r];
                                if (t.extras && Array.isArray(t.extras.targetNames)) {
                                    let r = t.extras.targetNames;
                                    if (e.morphTargetInfluences.length === r.length) {
                                        e.morphTargetDictionary = {};
                                        for (let t = 0, n = r.length; t < n; t++) e.morphTargetDictionary[r[t]] = t
                                    } else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")
                                }
                            }(f, o), f.name = t.createUniqueName(o.name || "mesh_" + e), ee(f, o), h.extensions && $(n, f, h), t.assignFinalMaterial(f), c.push(f)
                        }
                        for (let r = 0, n = c.length; r < n; r++) t.associations.set(c[r], {
                            meshes: e,
                            primitives: r
                        });
                        if (1 === c.length) return o.extensions && $(n, c[0], o), c[0];
                        let f = new i.YJl;
                        o.extensions && $(n, f, o), t.associations.set(f, {
                            meshes: e
                        });
                        for (let e = 0, t = c.length; e < t; e++) f.add(c[e]);
                        return f
                    })
                }
                loadCamera(e) {
                    let t, r = this.json.cameras[e],
                        n = r[r.type];
                    return n ? ("perspective" === r.type ? t = new i.ubm(i.cj9.radToDeg(n.yfov), n.aspectRatio || 1, n.znear || 1, n.zfar || 2e6) : "orthographic" === r.type && (t = new i.qUd(-n.xmag, n.xmag, n.ymag, -n.ymag, n.znear, n.zfar)), r.name && (t.name = this.createUniqueName(r.name)), ee(t, r), Promise.resolve(t)) : void console.warn("THREE.GLTFLoader: Missing camera parameters.")
                }
                loadSkin(e) {
                    let t = this.json.skins[e],
                        r = [];
                    for (let e = 0, n = t.joints.length; e < n; e++) r.push(this._loadNodeShallow(t.joints[e]));
                    return void 0 !== t.inverseBindMatrices ? r.push(this.getDependency("accessor", t.inverseBindMatrices)) : r.push(null), Promise.all(r).then(function(e) {
                        let r = e.pop(),
                            n = [],
                            o = [];
                        for (let s = 0, a = e.length; s < a; s++) {
                            let a = e[s];
                            if (a) {
                                n.push(a);
                                let e = new i.kn4;
                                null !== r && e.fromArray(r.array, 16 * s), o.push(e)
                            } else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.', t.joints[s])
                        }
                        return new i.EAD(n, o)
                    })
                }
                loadAnimation(e) {
                    let t = this.json,
                        r = this,
                        n = t.animations[e],
                        o = n.name ? n.name : "animation_" + e,
                        s = [],
                        a = [],
                        l = [],
                        u = [],
                        c = [];
                    for (let e = 0, t = n.channels.length; e < t; e++) {
                        let t = n.channels[e],
                            r = n.samplers[t.sampler],
                            i = t.target,
                            o = i.node,
                            f = void 0 !== n.parameters ? n.parameters[r.input] : r.input,
                            d = void 0 !== n.parameters ? n.parameters[r.output] : r.output;
                        void 0 !== i.node && (s.push(this.getDependency("node", o)), a.push(this.getDependency("accessor", f)), l.push(this.getDependency("accessor", d)), u.push(r), c.push(i))
                    }
                    return Promise.all([Promise.all(s), Promise.all(a), Promise.all(l), Promise.all(u), Promise.all(c)]).then(function(e) {
                        let t = e[0],
                            n = e[1],
                            s = e[2],
                            a = e[3],
                            l = e[4],
                            u = [];
                        for (let e = 0, i = t.length; e < i; e++) {
                            let i = t[e],
                                o = n[e],
                                c = s[e],
                                f = a[e],
                                d = l[e];
                            if (void 0 === i) continue;
                            i.updateMatrix && i.updateMatrix();
                            let h = r._createAnimationTracks(i, o, c, f, d);
                            if (h)
                                for (let e = 0; e < h.length; e++) u.push(h[e])
                        }
                        return new i.tz3(o, void 0, u)
                    })
                }
                createNodeMesh(e) {
                    let t = this.json,
                        r = this,
                        n = t.nodes[e];
                    return void 0 === n.mesh ? null : r.getDependency("mesh", n.mesh).then(function(e) {
                        let t = r._getNodeRef(r.meshCache, n.mesh, e);
                        return void 0 !== n.weights && t.traverse(function(e) {
                            if (e.isMesh)
                                for (let t = 0, r = n.weights.length; t < r; t++) e.morphTargetInfluences[t] = n.weights[t]
                        }), t
                    })
                }
                loadNode(e) {
                    let t = this.json.nodes[e],
                        r = this._loadNodeShallow(e),
                        n = [],
                        i = t.children || [];
                    for (let e = 0, t = i.length; e < t; e++) n.push(this.getDependency("node", i[e]));
                    let o = void 0 === t.skin ? Promise.resolve(null) : this.getDependency("skin", t.skin);
                    return Promise.all([r, Promise.all(n), o]).then(function(e) {
                        let t = e[0],
                            r = e[1],
                            n = e[2];
                        null !== n && t.traverse(function(e) {
                            e.isSkinnedMesh && e.bind(n, en)
                        });
                        for (let e = 0, n = r.length; e < n; e++) t.add(r[e]);
                        return t
                    })
                }
                _loadNodeShallow(e) {
                    let t = this.json,
                        r = this.extensions,
                        n = this;
                    if (void 0 !== this.nodeCache[e]) return this.nodeCache[e];
                    let o = t.nodes[e],
                        s = o.name ? n.createUniqueName(o.name) : "",
                        a = [],
                        l = n._invokeOne(function(t) {
                            return t.createNodeMesh && t.createNodeMesh(e)
                        });
                    return l && a.push(l), void 0 !== o.camera && a.push(n.getDependency("camera", o.camera).then(function(e) {
                        return n._getNodeRef(n.cameraCache, o.camera, e)
                    })), n._invokeAll(function(t) {
                        return t.createNodeAttachment && t.createNodeAttachment(e)
                    }).forEach(function(e) {
                        a.push(e)
                    }), this.nodeCache[e] = Promise.all(a).then(function(t) {
                        let a;
                        if ((a = !0 === o.isBone ? new i.$Kf : t.length > 1 ? new i.YJl : 1 === t.length ? t[0] : new i.B69) !== t[0])
                            for (let e = 0, r = t.length; e < r; e++) a.add(t[e]);
                        if (o.name && (a.userData.name = o.name, a.name = s), ee(a, o), o.extensions && $(r, a, o), void 0 !== o.matrix) {
                            let e = new i.kn4;
                            e.fromArray(o.matrix), a.applyMatrix4(e)
                        } else void 0 !== o.translation && a.position.fromArray(o.translation), void 0 !== o.rotation && a.quaternion.fromArray(o.rotation), void 0 !== o.scale && a.scale.fromArray(o.scale);
                        return n.associations.has(a) || n.associations.set(a, {}), n.associations.get(a).nodes = e, a
                    }), this.nodeCache[e]
                }
                loadScene(e) {
                    let t = this.extensions,
                        r = this.json.scenes[e],
                        n = this,
                        o = new i.YJl;
                    r.name && (o.name = n.createUniqueName(r.name)), ee(o, r), r.extensions && $(t, o, r);
                    let s = r.nodes || [],
                        a = [];
                    for (let e = 0, t = s.length; e < t; e++) a.push(n.getDependency("node", s[e]));
                    return Promise.all(a).then(function(e) {
                        for (let t = 0, r = e.length; t < r; t++) o.add(e[t]);
                        return n.associations = (e => {
                            let t = new Map;
                            for (let [e, r] of n.associations)(e instanceof i.imn || e instanceof i.gPd) && t.set(e, r);
                            return e.traverse(e => {
                                let r = n.associations.get(e);
                                null != r && t.set(e, r)
                            }), t
                        })(o), o
                    })
                }
                _createAnimationTracks(e, t, r, n, o) {
                    let s, a = [],
                        l = e.name ? e.name : e.uuid,
                        u = [];
                    switch (q[o.path] === q.weights ? e.traverse(function(e) {
                        e.morphTargetInfluences && u.push(e.name ? e.name : e.uuid)
                    }) : u.push(l), q[o.path]) {
                        case q.weights:
                            s = i.Hit;
                            break;
                        case q.rotation:
                            s = i.MBL;
                            break;
                        case q.position:
                        case q.scale:
                            s = i.RiT;
                            break;
                        default:
                            s = 1 === r.itemSize ? i.Hit : i.RiT
                    }
                    let c = void 0 !== n.interpolation ? Z[n.interpolation] : i.PJ3,
                        f = this._getArrayFromAccessor(r);
                    for (let e = 0, r = u.length; e < r; e++) {
                        let r = new s(u[e] + "." + q[o.path], t.array, f, c);
                        "CUBICSPLINE" === n.interpolation && this._createCubicSplineTrackInterpolant(r), a.push(r)
                    }
                    return a
                }
                _getArrayFromAccessor(e) {
                    let t = e.array;
                    if (e.normalized) {
                        let e = er(t.constructor),
                            r = new Float32Array(t.length);
                        for (let n = 0, i = t.length; n < i; n++) r[n] = t[n] * e;
                        t = r
                    }
                    return t
                }
                _createCubicSplineTrackInterpolant(e) {
                    e.createInterpolant = function(e) {
                        return new(this instanceof i.MBL ? N : j)(this.times, this.values, this.getValueSize() / 3, e)
                    }, e.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline = !0
                }
            }

            function eo(e, t, r) {
                let n = t.attributes,
                    o = [];
                for (let t in n) {
                    let i = z[t] || t.toLowerCase();
                    i in e.attributes || o.push(function(t, n) {
                        return r.getDependency("accessor", t).then(function(t) {
                            e.setAttribute(n, t)
                        })
                    }(n[t], i))
                }
                if (void 0 !== t.indices && !e.index) {
                    let n = r.getDependency("accessor", t.indices).then(function(t) {
                        e.setIndex(t)
                    });
                    o.push(n)
                }
                return ee(e, t), ! function(e, t, r) {
                    let n = t.attributes,
                        o = new i.NRn;
                    if (void 0 === n.POSITION) return; {
                        let e = r.json.accessors[n.POSITION],
                            t = e.min,
                            s = e.max;
                        if (void 0 === t || void 0 === s) return console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");
                        if (o.set(new i.Pq0(t[0], t[1], t[2]), new i.Pq0(s[0], s[1], s[2])), e.normalized) {
                            let t = er(Q[e.componentType]);
                            o.min.multiplyScalar(t), o.max.multiplyScalar(t)
                        }
                    }
                    let s = t.targets;
                    if (void 0 !== s) {
                        let e = new i.Pq0,
                            t = new i.Pq0;
                        for (let n = 0, i = s.length; n < i; n++) {
                            let i = s[n];
                            if (void 0 !== i.POSITION) {
                                let n = r.json.accessors[i.POSITION],
                                    o = n.min,
                                    s = n.max;
                                if (void 0 !== o && void 0 !== s) {
                                    if (t.setX(Math.max(Math.abs(o[0]), Math.abs(s[0]))), t.setY(Math.max(Math.abs(o[1]), Math.abs(s[1]))), t.setZ(Math.max(Math.abs(o[2]), Math.abs(s[2]))), n.normalized) {
                                        let e = er(Q[n.componentType]);
                                        t.multiplyScalar(e)
                                    }
                                    e.max(t)
                                } else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")
                            }
                        }
                        o.expandByVector(e)
                    }
                    e.boundingBox = o;
                    let a = new i.iyt;
                    o.getCenter(a.center), a.radius = o.min.distanceTo(o.max) / 2, e.boundingSphere = a
                }(e, t, r), Promise.all(o).then(function() {
                    return void 0 !== t.targets ? function(e, t, r) {
                        let n = !1,
                            i = !1,
                            o = !1;
                        for (let e = 0, r = t.length; e < r; e++) {
                            let r = t[e];
                            if (void 0 !== r.POSITION && (n = !0), void 0 !== r.NORMAL && (i = !0), void 0 !== r.COLOR_0 && (o = !0), n && i && o) break
                        }
                        if (!n && !i && !o) return Promise.resolve(e);
                        let s = [],
                            a = [],
                            l = [];
                        for (let u = 0, c = t.length; u < c; u++) {
                            let c = t[u];
                            if (n) {
                                let t = void 0 !== c.POSITION ? r.getDependency("accessor", c.POSITION) : e.attributes.position;
                                s.push(t)
                            }
                            if (i) {
                                let t = void 0 !== c.NORMAL ? r.getDependency("accessor", c.NORMAL) : e.attributes.normal;
                                a.push(t)
                            }
                            if (o) {
                                let t = void 0 !== c.COLOR_0 ? r.getDependency("accessor", c.COLOR_0) : e.attributes.color;
                                l.push(t)
                            }
                        }
                        return Promise.all([Promise.all(s), Promise.all(a), Promise.all(l)]).then(function(t) {
                            let r = t[0],
                                s = t[1],
                                a = t[2];
                            return n && (e.morphAttributes.position = r), i && (e.morphAttributes.normal = s), o && (e.morphAttributes.color = a), e.morphTargetsRelative = !0, e
                        })
                    }(e, t.targets, r) : e
                })
            }
            var es = r(8789);
            let ea = null,
                el = "https://www.gstatic.com/draco/versioned/decoders/1.5.5/";

            function eu(e = !0, t = !0, r) {
                return n => {
                    r && r(n), e && (ea || (ea = new s), ea.setDecoderPath("string" == typeof e ? e : el), n.setDRACOLoader(ea)), t && n.setMeshoptDecoder("function" == typeof l ? l() : l)
                }
            }
            let ec = (e, t, r, n) => (0, es.F)(p, e, eu(t, r, n));
            ec.preload = (e, t, r, n) => es.F.preload(p, e, eu(t, r, n)), ec.clear = e => es.F.clear(p, e), ec.setDecoderPath = e => {
                el = e
            }
        },
        4012: (e, t, r) => {
            "use strict";
            e.exports = r(7829)
        },
        4187: (e, t, r) => {
            "use strict";
            r.d(t, {
                DY: () => a,
                IU: () => u,
                uv: () => l
            });
            let n = e => "object" == typeof e && "function" == typeof e.then,
                i = [];

            function o(e, t, r = (e, t) => e === t) {
                if (e === t) return !0;
                if (!e || !t) return !1;
                let n = e.length;
                if (t.length !== n) return !1;
                for (let i = 0; i < n; i++)
                    if (!r(e[i], t[i])) return !1;
                return !0
            }

            function s(e, t = null, r = !1, a = {}) {
                for (let n of (null === t && (t = [e]), i))
                    if (o(t, n.keys, n.equal)) {
                        if (r) return;
                        if (Object.prototype.hasOwnProperty.call(n, "error")) throw n.error;
                        if (Object.prototype.hasOwnProperty.call(n, "response")) return a.lifespan && a.lifespan > 0 && (n.timeout && clearTimeout(n.timeout), n.timeout = setTimeout(n.remove, a.lifespan)), n.response;
                        if (!r) throw n.promise
                    }
                let l = {
                    keys: t,
                    equal: a.equal,
                    remove: () => {
                        let e = i.indexOf(l); - 1 !== e && i.splice(e, 1)
                    },
                    promise: (n(e) ? e : e(...t)).then(e => {
                        l.response = e, a.lifespan && a.lifespan > 0 && (l.timeout = setTimeout(l.remove, a.lifespan))
                    }).catch(e => l.error = e)
                };
                if (i.push(l), !r) throw l.promise
            }
            let a = (e, t, r) => s(e, t, !1, r),
                l = (e, t, r) => void s(e, t, !0, r),
                u = e => {
                    if (void 0 === e || 0 === e.length) i.splice(0, i.length);
                    else {
                        let t = i.find(t => o(e, t.keys, t.equal));
                        t && t.remove()
                    }
                }
        },
        4650: (e, t) => {
            t.read = function(e, t, r, n, i) {
                var o, s, a = 8 * i - n - 1,
                    l = (1 << a) - 1,
                    u = l >> 1,
                    c = -7,
                    f = r ? i - 1 : 0,
                    d = r ? -1 : 1,
                    h = e[t + f];
                for (f += d, o = h & (1 << -c) - 1, h >>= -c, c += a; c > 0; o = 256 * o + e[t + f], f += d, c -= 8);
                for (s = o & (1 << -c) - 1, o >>= -c, c += n; c > 0; s = 256 * s + e[t + f], f += d, c -= 8);
                if (0 === o) o = 1 - u;
                else {
                    if (o === l) return s ? NaN : 1 / 0 * (h ? -1 : 1);
                    s += Math.pow(2, n), o -= u
                }
                return (h ? -1 : 1) * s * Math.pow(2, o - n)
            }, t.write = function(e, t, r, n, i, o) {
                var s, a, l, u = 8 * o - i - 1,
                    c = (1 << u) - 1,
                    f = c >> 1,
                    d = 5960464477539062e-23 * (23 === i),
                    h = n ? 0 : o - 1,
                    p = n ? 1 : -1,
                    A = +(t < 0 || 0 === t && 1 / t < 0);
                for (isNaN(t = Math.abs(t)) || t === 1 / 0 ? (a = +!!isNaN(t), s = c) : (s = Math.floor(Math.log(t) / Math.LN2), t * (l = Math.pow(2, -s)) < 1 && (s--, l *= 2), s + f >= 1 ? t += d / l : t += d * Math.pow(2, 1 - f), t * l >= 2 && (s++, l /= 2), s + f >= c ? (a = 0, s = c) : s + f >= 1 ? (a = (t * l - 1) * Math.pow(2, i), s += f) : (a = t * Math.pow(2, f - 1) * Math.pow(2, i), s = 0)); i >= 8; e[r + h] = 255 & a, h += p, a /= 256, i -= 8);
                for (s = s << i | a, u += i; u > 0; e[r + h] = 255 & s, h += p, s /= 256, u -= 8);
                e[r + h - p] |= 128 * A
            }
        },
        5967: (e, t, r) => {
            "use strict";
            r.d(t, {
                _c: () => o,
                ec: () => i
            });
            var n = r(4312);

            function i(e, t = 1e-4) {
                t = Math.max(t, Number.EPSILON);
                let r = {},
                    o = e.getIndex(),
                    s = e.getAttribute("position"),
                    a = o ? o.count : s.count,
                    l = 0,
                    u = Object.keys(e.attributes),
                    c = {},
                    f = {},
                    d = [],
                    h = ["getX", "getY", "getZ", "getW"];
                for (let t = 0, r = u.length; t < r; t++) {
                    let r = u[t];
                    c[r] = [];
                    let n = e.morphAttributes[r];
                    n && (f[r] = Array(n.length).fill(0).map(() => []))
                }
                let p = Math.pow(10, Math.log10(1 / t));
                for (let t = 0; t < a; t++) {
                    let n = o ? o.getX(t) : t,
                        i = "";
                    for (let t = 0, r = u.length; t < r; t++) {
                        let r = u[t],
                            o = e.getAttribute(r),
                            s = o.itemSize;
                        for (let e = 0; e < s; e++) i += `${~~(o[h[e]](n)*p)},`
                    }
                    if (i in r) d.push(r[i]);
                    else {
                        for (let t = 0, r = u.length; t < r; t++) {
                            let r = u[t],
                                i = e.getAttribute(r),
                                o = e.morphAttributes[r],
                                s = i.itemSize,
                                a = c[r],
                                l = f[r];
                            for (let e = 0; e < s; e++) {
                                let t = h[e];
                                if (a.push(i[t](n)), o)
                                    for (let e = 0, r = o.length; e < r; e++) l[e].push(o[e][t](n))
                            }
                        }
                        r[i] = l, d.push(l), l++
                    }
                }
                let A = e.clone();
                for (let t = 0, r = u.length; t < r; t++) {
                    let r = u[t],
                        i = e.getAttribute(r),
                        o = new i.array.constructor(c[r]),
                        s = new n.THS(o, i.itemSize, i.normalized);
                    if (A.setAttribute(r, s), r in f)
                        for (let t = 0; t < f[r].length; t++) {
                            let i = e.morphAttributes[r][t],
                                o = new i.array.constructor(f[r][t]),
                                s = new n.THS(o, i.itemSize, i.normalized);
                            A.morphAttributes[r][t] = s
                        }
                }
                return A.setIndex(d), A
            }

            function o(e, t) {
                if (t === n.RJ4) return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."), e;
                if (t !== n.rYR && t !== n.O49) return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:", t), e; {
                    let r = e.getIndex();
                    if (null === r) {
                        let t = [],
                            n = e.getAttribute("position");
                        if (void 0 === n) return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."), e;
                        for (let e = 0; e < n.count; e++) t.push(e);
                        e.setIndex(t), r = e.getIndex()
                    }
                    let i = r.count - 2,
                        o = [];
                    if (r)
                        if (t === n.rYR)
                            for (let e = 1; e <= i; e++) o.push(r.getX(0)), o.push(r.getX(e)), o.push(r.getX(e + 1));
                        else
                            for (let e = 0; e < i; e++) e % 2 == 0 ? (o.push(r.getX(e)), o.push(r.getX(e + 1)), o.push(r.getX(e + 2))) : (o.push(r.getX(e + 2)), o.push(r.getX(e + 1)), o.push(r.getX(e)));
                    o.length / 3 !== i && console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");
                    let s = e.clone();
                    return s.setIndex(o), s.clearGroups(), s
                }
            }
        },
        5995: (e, t, r) => {
            "use strict";
            r.d(t, {
                O: () => a
            });
            var n = r(9585),
                i = r(8789),
                o = r(6797),
                s = r(4312);
            let a = o.forwardRef(({
                light: e,
                args: t,
                map: r,
                toneMapped: a = !1,
                color: l = "white",
                form: u = "rect",
                intensity: c = 1,
                scale: f = 1,
                target: d = [0, 0, 0],
                children: h,
                ...p
            }, A) => {
                let m = o.useRef(null);
                return o.useImperativeHandle(A, () => m.current, []), o.useLayoutEffect(() => {
                    h || p.material || ((0, i.q)(m.current.material, {
                        color: l
                    }), m.current.material.color.multiplyScalar(c))
                }, [l, c, h, p.material]), o.useLayoutEffect(() => {
                    p.rotation || m.current.quaternion.identity(), d && !p.rotation && ("boolean" == typeof d ? m.current.lookAt(0, 0, 0) : m.current.lookAt(Array.isArray(d) ? new s.Pq0(...d) : d))
                }, [d, p.rotation]), f = Array.isArray(f) && 2 === f.length ? [f[0], f[1], 1] : f, o.createElement("mesh", (0, n.A)({
                    ref: m,
                    scale: f
                }, p), "circle" === u ? o.createElement("ringGeometry", {
                    args: t || [0, .5, 64]
                }) : "ring" === u ? o.createElement("ringGeometry", {
                    args: t || [.25, .5, 64]
                }) : "rect" === u || "plane" === u ? o.createElement("planeGeometry", {
                    args: t || [1, 1]
                }) : "box" === u ? o.createElement("boxGeometry", {
                    args: t || [1, 1, 1]
                }) : o.createElement(u, {
                    args: t
                }), h || o.createElement("meshBasicMaterial", {
                    toneMapped: a,
                    map: r,
                    side: s.$EB
                }), e && o.createElement("pointLight", (0, n.A)({
                    castShadow: !0
                }, e)))
            })
        },
        7077: (e, t, r) => {
            "use strict";
            e.exports = r(3598)
        },
        7338: (e, t, r) => {
            "use strict";
            r.d(t, {
                r: () => n
            });
            let n = parseInt(r(4312).sPf.replace(/\D+/g, ""))
        },
        7829: (e, t) => {
            "use strict";
            t.ConcurrentRoot = 1, t.ContinuousEventPriority = 8, t.DefaultEventPriority = 32, t.DiscreteEventPriority = 2
        },
        8333: (e, t, r) => {
            "use strict";
            e.exports = r(9512)
        },
        8500: (e, t, r) => {
            "use strict";
            let n = r(1119),
                i = r(4650),
                o = "function" == typeof Symbol && "function" == typeof Symbol.for ? Symbol.for("nodejs.util.inspect.custom") : null;

            function s(e) {
                if (e > 0x7fffffff) throw RangeError('The value "' + e + '" is invalid for option "size"');
                let t = new Uint8Array(e);
                return Object.setPrototypeOf(t, a.prototype), t
            }

            function a(e, t, r) {
                if ("number" == typeof e) {
                    if ("string" == typeof t) throw TypeError('The "string" argument must be of type string. Received type number');
                    return c(e)
                }
                return l(e, t, r)
            }

            function l(e, t, r) {
                if ("string" == typeof e) {
                    var n = e,
                        i = t;
                    if (("string" != typeof i || "" === i) && (i = "utf8"), !a.isEncoding(i)) throw TypeError("Unknown encoding: " + i);
                    let r = 0 | p(n, i),
                        o = s(r),
                        l = o.write(n, i);
                    return l !== r && (o = o.slice(0, l)), o
                }
                if (ArrayBuffer.isView(e)) {
                    var o = e;
                    if (U(o, Uint8Array)) {
                        let e = new Uint8Array(o);
                        return d(e.buffer, e.byteOffset, e.byteLength)
                    }
                    return f(o)
                }
                if (null == e) throw TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e);
                if (U(e, ArrayBuffer) || e && U(e.buffer, ArrayBuffer) || "undefined" != typeof SharedArrayBuffer && (U(e, SharedArrayBuffer) || e && U(e.buffer, SharedArrayBuffer))) return d(e, t, r);
                if ("number" == typeof e) throw TypeError('The "value" argument must not be of type number. Received type number');
                let l = e.valueOf && e.valueOf();
                if (null != l && l !== e) return a.from(l, t, r);
                let u = function(e) {
                    if (a.isBuffer(e)) {
                        let t = 0 | h(e.length),
                            r = s(t);
                        return 0 === r.length || e.copy(r, 0, 0, t), r
                    }
                    return void 0 !== e.length ? "number" != typeof e.length || function(e) {
                        return e != e
                    }(e.length) ? s(0) : f(e) : "Buffer" === e.type && Array.isArray(e.data) ? f(e.data) : void 0
                }(e);
                if (u) return u;
                if ("undefined" != typeof Symbol && null != Symbol.toPrimitive && "function" == typeof e[Symbol.toPrimitive]) return a.from(e[Symbol.toPrimitive]("string"), t, r);
                throw TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e)
            }

            function u(e) {
                if ("number" != typeof e) throw TypeError('"size" argument must be of type number');
                if (e < 0) throw RangeError('The value "' + e + '" is invalid for option "size"')
            }

            function c(e) {
                return u(e), s(e < 0 ? 0 : 0 | h(e))
            }

            function f(e) {
                let t = e.length < 0 ? 0 : 0 | h(e.length),
                    r = s(t);
                for (let n = 0; n < t; n += 1) r[n] = 255 & e[n];
                return r
            }

            function d(e, t, r) {
                let n;
                if (t < 0 || e.byteLength < t) throw RangeError('"offset" is outside of buffer bounds');
                if (e.byteLength < t + (r || 0)) throw RangeError('"length" is outside of buffer bounds');
                return Object.setPrototypeOf(n = void 0 === t && void 0 === r ? new Uint8Array(e) : void 0 === r ? new Uint8Array(e, t) : new Uint8Array(e, t, r), a.prototype), n
            }

            function h(e) {
                if (e >= 0x7fffffff) throw RangeError("Attempt to allocate Buffer larger than maximum size: 0x7fffffff bytes");
                return 0 | e
            }

            function p(e, t) {
                if (a.isBuffer(e)) return e.length;
                if (ArrayBuffer.isView(e) || U(e, ArrayBuffer)) return e.byteLength;
                if ("string" != typeof e) throw TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof e);
                let r = e.length,
                    n = arguments.length > 2 && !0 === arguments[2];
                if (!n && 0 === r) return 0;
                let i = !1;
                for (;;) switch (t) {
                    case "ascii":
                    case "latin1":
                    case "binary":
                        return r;
                    case "utf8":
                    case "utf-8":
                        return G(e).length;
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return 2 * r;
                    case "hex":
                        return r >>> 1;
                    case "base64":
                        return P(e).length;
                    default:
                        if (i) return n ? -1 : G(e).length;
                        t = ("" + t).toLowerCase(), i = !0
                }
            }

            function A(e, t, r) {
                let i = !1;
                if ((void 0 === t || t < 0) && (t = 0), t > this.length || ((void 0 === r || r > this.length) && (r = this.length), r <= 0 || (r >>>= 0) <= (t >>>= 0))) return "";
                for (e || (e = "utf8");;) switch (e) {
                    case "hex":
                        return function(e, t, r) {
                            let n = e.length;
                            (!t || t < 0) && (t = 0), (!r || r < 0 || r > n) && (r = n);
                            let i = "";
                            for (let n = t; n < r; ++n) i += _[e[n]];
                            return i
                        }(this, t, r);
                    case "utf8":
                    case "utf-8":
                        return v(this, t, r);
                    case "ascii":
                        return function(e, t, r) {
                            let n = "";
                            r = Math.min(e.length, r);
                            for (let i = t; i < r; ++i) n += String.fromCharCode(127 & e[i]);
                            return n
                        }(this, t, r);
                    case "latin1":
                    case "binary":
                        return function(e, t, r) {
                            let n = "";
                            r = Math.min(e.length, r);
                            for (let i = t; i < r; ++i) n += String.fromCharCode(e[i]);
                            return n
                        }(this, t, r);
                    case "base64":
                        var o, s, a;
                        return o = this, s = t, a = r, 0 === s && a === o.length ? n.fromByteArray(o) : n.fromByteArray(o.slice(s, a));
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return function(e, t, r) {
                            let n = e.slice(t, r),
                                i = "";
                            for (let e = 0; e < n.length - 1; e += 2) i += String.fromCharCode(n[e] + 256 * n[e + 1]);
                            return i
                        }(this, t, r);
                    default:
                        if (i) throw TypeError("Unknown encoding: " + e);
                        e = (e + "").toLowerCase(), i = !0
                }
            }

            function m(e, t, r) {
                let n = e[t];
                e[t] = e[r], e[r] = n
            }

            function g(e, t, r, n, i) {
                var o;
                if (0 === e.length) return -1;
                if ("string" == typeof r ? (n = r, r = 0) : r > 0x7fffffff ? r = 0x7fffffff : r < -0x80000000 && (r = -0x80000000), (o = r *= 1) != o && (r = i ? 0 : e.length - 1), r < 0 && (r = e.length + r), r >= e.length)
                    if (i) return -1;
                    else r = e.length - 1;
                else if (r < 0)
                    if (!i) return -1;
                    else r = 0;
                if ("string" == typeof t && (t = a.from(t, n)), a.isBuffer(t)) return 0 === t.length ? -1 : B(e, t, r, n, i);
                if ("number" == typeof t) {
                    if (t &= 255, "function" == typeof Uint8Array.prototype.indexOf)
                        if (i) return Uint8Array.prototype.indexOf.call(e, t, r);
                        else return Uint8Array.prototype.lastIndexOf.call(e, t, r);
                    return B(e, [t], r, n, i)
                }
                throw TypeError("val must be string, number or Buffer")
            }

            function B(e, t, r, n, i) {
                let o, s = 1,
                    a = e.length,
                    l = t.length;
                if (void 0 !== n && ("ucs2" === (n = String(n).toLowerCase()) || "ucs-2" === n || "utf16le" === n || "utf-16le" === n)) {
                    if (e.length < 2 || t.length < 2) return -1;
                    s = 2, a /= 2, l /= 2, r /= 2
                }

                function u(e, t) {
                    return 1 === s ? e[t] : e.readUInt16BE(t * s)
                }
                if (i) {
                    let n = -1;
                    for (o = r; o < a; o++)
                        if (u(e, o) === u(t, -1 === n ? 0 : o - n)) {
                            if (-1 === n && (n = o), o - n + 1 === l) return n * s
                        } else -1 !== n && (o -= o - n), n = -1
                } else
                    for (r + l > a && (r = a - l), o = r; o >= 0; o--) {
                        let r = !0;
                        for (let n = 0; n < l; n++)
                            if (u(e, o + n) !== u(t, n)) {
                                r = !1;
                                break
                            }
                        if (r) return o
                    }
                return -1
            }

            function v(e, t, r) {
                r = Math.min(e.length, r);
                let n = [],
                    i = t;
                for (; i < r;) {
                    let t = e[i],
                        o = null,
                        s = t > 239 ? 4 : t > 223 ? 3 : t > 191 ? 2 : 1;
                    if (i + s <= r) {
                        let r, n, a, l;
                        switch (s) {
                            case 1:
                                t < 128 && (o = t);
                                break;
                            case 2:
                                (192 & (r = e[i + 1])) == 128 && (l = (31 & t) << 6 | 63 & r) > 127 && (o = l);
                                break;
                            case 3:
                                r = e[i + 1], n = e[i + 2], (192 & r) == 128 && (192 & n) == 128 && (l = (15 & t) << 12 | (63 & r) << 6 | 63 & n) > 2047 && (l < 55296 || l > 57343) && (o = l);
                                break;
                            case 4:
                                r = e[i + 1], n = e[i + 2], a = e[i + 3], (192 & r) == 128 && (192 & n) == 128 && (192 & a) == 128 && (l = (15 & t) << 18 | (63 & r) << 12 | (63 & n) << 6 | 63 & a) > 65535 && l < 1114112 && (o = l)
                        }
                    }
                    null === o ? (o = 65533, s = 1) : o > 65535 && (o -= 65536, n.push(o >>> 10 & 1023 | 55296), o = 56320 | 1023 & o), n.push(o), i += s
                }
                var o = n;
                let s = o.length;
                if (s <= 4096) return String.fromCharCode.apply(String, o);
                let a = "",
                    l = 0;
                for (; l < s;) a += String.fromCharCode.apply(String, o.slice(l, l += 4096));
                return a
            }

            function y(e, t, r) {
                if (e % 1 != 0 || e < 0) throw RangeError("offset is not uint");
                if (e + t > r) throw RangeError("Trying to access beyond buffer length")
            }

            function C(e, t, r, n, i, o) {
                if (!a.isBuffer(e)) throw TypeError('"buffer" argument must be a Buffer instance');
                if (t > i || t < o) throw RangeError('"value" argument is out of bounds');
                if (r + n > e.length) throw RangeError("Index out of range")
            }

            function b(e, t, r, n, i) {
                T(t, n, i, e, r, 7);
                let o = Number(t & BigInt(0xffffffff));
                e[r++] = o, o >>= 8, e[r++] = o, o >>= 8, e[r++] = o, o >>= 8, e[r++] = o;
                let s = Number(t >> BigInt(32) & BigInt(0xffffffff));
                return e[r++] = s, s >>= 8, e[r++] = s, s >>= 8, e[r++] = s, s >>= 8, e[r++] = s, r
            }

            function E(e, t, r, n, i) {
                T(t, n, i, e, r, 7);
                let o = Number(t & BigInt(0xffffffff));
                e[r + 7] = o, o >>= 8, e[r + 6] = o, o >>= 8, e[r + 5] = o, o >>= 8, e[r + 4] = o;
                let s = Number(t >> BigInt(32) & BigInt(0xffffffff));
                return e[r + 3] = s, s >>= 8, e[r + 2] = s, s >>= 8, e[r + 1] = s, s >>= 8, e[r] = s, r + 8
            }

            function w(e, t, r, n, i, o) {
                if (r + n > e.length || r < 0) throw RangeError("Index out of range")
            }

            function M(e, t, r, n, o) {
                return t *= 1, r >>>= 0, o || w(e, t, r, 4, 34028234663852886e22, -34028234663852886e22), i.write(e, t, r, n, 23, 4), r + 4
            }

            function R(e, t, r, n, o) {
                return t *= 1, r >>>= 0, o || w(e, t, r, 8, 17976931348623157e292, -17976931348623157e292), i.write(e, t, r, n, 52, 8), r + 8
            }
            t.hp = a, t.IS = 50, a.TYPED_ARRAY_SUPPORT = function() {
                try {
                    let e = new Uint8Array(1),
                        t = {
                            foo: function() {
                                return 42
                            }
                        };
                    return Object.setPrototypeOf(t, Uint8Array.prototype), Object.setPrototypeOf(e, t), 42 === e.foo()
                } catch (e) {
                    return !1
                }
            }(), a.TYPED_ARRAY_SUPPORT || "undefined" == typeof console || "function" != typeof console.error || console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), Object.defineProperty(a.prototype, "parent", {
                enumerable: !0,
                get: function() {
                    if (a.isBuffer(this)) return this.buffer
                }
            }), Object.defineProperty(a.prototype, "offset", {
                enumerable: !0,
                get: function() {
                    if (a.isBuffer(this)) return this.byteOffset
                }
            }), a.poolSize = 8192, a.from = function(e, t, r) {
                return l(e, t, r)
            }, Object.setPrototypeOf(a.prototype, Uint8Array.prototype), Object.setPrototypeOf(a, Uint8Array), a.alloc = function(e, t, r) {
                return (u(e), e <= 0) ? s(e) : void 0 !== t ? "string" == typeof r ? s(e).fill(t, r) : s(e).fill(t) : s(e)
            }, a.allocUnsafe = function(e) {
                return c(e)
            }, a.allocUnsafeSlow = function(e) {
                return c(e)
            }, a.isBuffer = function(e) {
                return null != e && !0 === e._isBuffer && e !== a.prototype
            }, a.compare = function(e, t) {
                if (U(e, Uint8Array) && (e = a.from(e, e.offset, e.byteLength)), U(t, Uint8Array) && (t = a.from(t, t.offset, t.byteLength)), !a.isBuffer(e) || !a.isBuffer(t)) throw TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
                if (e === t) return 0;
                let r = e.length,
                    n = t.length;
                for (let i = 0, o = Math.min(r, n); i < o; ++i)
                    if (e[i] !== t[i]) {
                        r = e[i], n = t[i];
                        break
                    }
                return r < n ? -1 : +(n < r)
            }, a.isEncoding = function(e) {
                switch (String(e).toLowerCase()) {
                    case "hex":
                    case "utf8":
                    case "utf-8":
                    case "ascii":
                    case "latin1":
                    case "binary":
                    case "base64":
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return !0;
                    default:
                        return !1
                }
            }, a.concat = function(e, t) {
                let r;
                if (!Array.isArray(e)) throw TypeError('"list" argument must be an Array of Buffers');
                if (0 === e.length) return a.alloc(0);
                if (void 0 === t)
                    for (r = 0, t = 0; r < e.length; ++r) t += e[r].length;
                let n = a.allocUnsafe(t),
                    i = 0;
                for (r = 0; r < e.length; ++r) {
                    let t = e[r];
                    if (U(t, Uint8Array)) i + t.length > n.length ? (a.isBuffer(t) || (t = a.from(t)), t.copy(n, i)) : Uint8Array.prototype.set.call(n, t, i);
                    else if (a.isBuffer(t)) t.copy(n, i);
                    else throw TypeError('"list" argument must be an Array of Buffers');
                    i += t.length
                }
                return n
            }, a.byteLength = p, a.prototype._isBuffer = !0, a.prototype.swap16 = function() {
                let e = this.length;
                if (e % 2 != 0) throw RangeError("Buffer size must be a multiple of 16-bits");
                for (let t = 0; t < e; t += 2) m(this, t, t + 1);
                return this
            }, a.prototype.swap32 = function() {
                let e = this.length;
                if (e % 4 != 0) throw RangeError("Buffer size must be a multiple of 32-bits");
                for (let t = 0; t < e; t += 4) m(this, t, t + 3), m(this, t + 1, t + 2);
                return this
            }, a.prototype.swap64 = function() {
                let e = this.length;
                if (e % 8 != 0) throw RangeError("Buffer size must be a multiple of 64-bits");
                for (let t = 0; t < e; t += 8) m(this, t, t + 7), m(this, t + 1, t + 6), m(this, t + 2, t + 5), m(this, t + 3, t + 4);
                return this
            }, a.prototype.toString = function() {
                let e = this.length;
                return 0 === e ? "" : 0 == arguments.length ? v(this, 0, e) : A.apply(this, arguments)
            }, a.prototype.toLocaleString = a.prototype.toString, a.prototype.equals = function(e) {
                if (!a.isBuffer(e)) throw TypeError("Argument must be a Buffer");
                return this === e || 0 === a.compare(this, e)
            }, a.prototype.inspect = function() {
                let e = "",
                    r = t.IS;
                return e = this.toString("hex", 0, r).replace(/(.{2})/g, "$1 ").trim(), this.length > r && (e += " ... "), "<Buffer " + e + ">"
            }, o && (a.prototype[o] = a.prototype.inspect), a.prototype.compare = function(e, t, r, n, i) {
                if (U(e, Uint8Array) && (e = a.from(e, e.offset, e.byteLength)), !a.isBuffer(e)) throw TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof e);
                if (void 0 === t && (t = 0), void 0 === r && (r = e ? e.length : 0), void 0 === n && (n = 0), void 0 === i && (i = this.length), t < 0 || r > e.length || n < 0 || i > this.length) throw RangeError("out of range index");
                if (n >= i && t >= r) return 0;
                if (n >= i) return -1;
                if (t >= r) return 1;
                if (t >>>= 0, r >>>= 0, n >>>= 0, i >>>= 0, this === e) return 0;
                let o = i - n,
                    s = r - t,
                    l = Math.min(o, s),
                    u = this.slice(n, i),
                    c = e.slice(t, r);
                for (let e = 0; e < l; ++e)
                    if (u[e] !== c[e]) {
                        o = u[e], s = c[e];
                        break
                    }
                return o < s ? -1 : +(s < o)
            }, a.prototype.includes = function(e, t, r) {
                return -1 !== this.indexOf(e, t, r)
            }, a.prototype.indexOf = function(e, t, r) {
                return g(this, e, t, r, !0)
            }, a.prototype.lastIndexOf = function(e, t, r) {
                return g(this, e, t, r, !1)
            }, a.prototype.write = function(e, t, r, n) {
                var i, o, s, a, l, u, c, f;
                if (void 0 === t) n = "utf8", r = this.length, t = 0;
                else if (void 0 === r && "string" == typeof t) n = t, r = this.length, t = 0;
                else if (isFinite(t)) t >>>= 0, isFinite(r) ? (r >>>= 0, void 0 === n && (n = "utf8")) : (n = r, r = void 0);
                else throw Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                let d = this.length - t;
                if ((void 0 === r || r > d) && (r = d), e.length > 0 && (r < 0 || t < 0) || t > this.length) throw RangeError("Attempt to write outside buffer bounds");
                n || (n = "utf8");
                let h = !1;
                for (;;) switch (n) {
                    case "hex":
                        return function(e, t, r, n) {
                            let i;
                            r = Number(r) || 0;
                            let o = e.length - r;
                            n ? (n = Number(n)) > o && (n = o) : n = o;
                            let s = t.length;
                            for (n > s / 2 && (n = s / 2), i = 0; i < n; ++i) {
                                var a;
                                let n = parseInt(t.substr(2 * i, 2), 16);
                                if ((a = n) != a) break;
                                e[r + i] = n
                            }
                            return i
                        }(this, e, t, r);
                    case "utf8":
                    case "utf-8":
                        return i = t, o = r, H(G(e, this.length - i), this, i, o);
                    case "ascii":
                    case "latin1":
                    case "binary":
                        return s = t, a = r, H(function(e) {
                            let t = [];
                            for (let r = 0; r < e.length; ++r) t.push(255 & e.charCodeAt(r));
                            return t
                        }(e), this, s, a);
                    case "base64":
                        return l = t, u = r, H(P(e), this, l, u);
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return c = t, f = r, H(function(e, t) {
                            let r, n, i = [];
                            for (let o = 0; o < e.length && !((t -= 2) < 0); ++o) n = (r = e.charCodeAt(o)) >> 8, i.push(r % 256), i.push(n);
                            return i
                        }(e, this.length - c), this, c, f);
                    default:
                        if (h) throw TypeError("Unknown encoding: " + n);
                        n = ("" + n).toLowerCase(), h = !0
                }
            }, a.prototype.toJSON = function() {
                return {
                    type: "Buffer",
                    data: Array.prototype.slice.call(this._arr || this, 0)
                }
            }, a.prototype.slice = function(e, t) {
                let r = this.length;
                e = ~~e, t = void 0 === t ? r : ~~t, e < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r), t < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r), t < e && (t = e);
                let n = this.subarray(e, t);
                return Object.setPrototypeOf(n, a.prototype), n
            }, a.prototype.readUintLE = a.prototype.readUIntLE = function(e, t, r) {
                e >>>= 0, t >>>= 0, r || y(e, t, this.length);
                let n = this[e],
                    i = 1,
                    o = 0;
                for (; ++o < t && (i *= 256);) n += this[e + o] * i;
                return n
            }, a.prototype.readUintBE = a.prototype.readUIntBE = function(e, t, r) {
                e >>>= 0, t >>>= 0, r || y(e, t, this.length);
                let n = this[e + --t],
                    i = 1;
                for (; t > 0 && (i *= 256);) n += this[e + --t] * i;
                return n
            }, a.prototype.readUint8 = a.prototype.readUInt8 = function(e, t) {
                return e >>>= 0, t || y(e, 1, this.length), this[e]
            }, a.prototype.readUint16LE = a.prototype.readUInt16LE = function(e, t) {
                return e >>>= 0, t || y(e, 2, this.length), this[e] | this[e + 1] << 8
            }, a.prototype.readUint16BE = a.prototype.readUInt16BE = function(e, t) {
                return e >>>= 0, t || y(e, 2, this.length), this[e] << 8 | this[e + 1]
            }, a.prototype.readUint32LE = a.prototype.readUInt32LE = function(e, t) {
                return e >>>= 0, t || y(e, 4, this.length), (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + 0x1000000 * this[e + 3]
            }, a.prototype.readUint32BE = a.prototype.readUInt32BE = function(e, t) {
                return e >>>= 0, t || y(e, 4, this.length), 0x1000000 * this[e] + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3])
            }, a.prototype.readBigUInt64LE = L(function(e) {
                S(e >>>= 0, "offset");
                let t = this[e],
                    r = this[e + 7];
                (void 0 === t || void 0 === r) && D(e, this.length - 8);
                let n = t + 256 * this[++e] + 65536 * this[++e] + 0x1000000 * this[++e],
                    i = this[++e] + 256 * this[++e] + 65536 * this[++e] + 0x1000000 * r;
                return BigInt(n) + (BigInt(i) << BigInt(32))
            }), a.prototype.readBigUInt64BE = L(function(e) {
                S(e >>>= 0, "offset");
                let t = this[e],
                    r = this[e + 7];
                (void 0 === t || void 0 === r) && D(e, this.length - 8);
                let n = 0x1000000 * t + 65536 * this[++e] + 256 * this[++e] + this[++e],
                    i = 0x1000000 * this[++e] + 65536 * this[++e] + 256 * this[++e] + r;
                return (BigInt(n) << BigInt(32)) + BigInt(i)
            }), a.prototype.readIntLE = function(e, t, r) {
                e >>>= 0, t >>>= 0, r || y(e, t, this.length);
                let n = this[e],
                    i = 1,
                    o = 0;
                for (; ++o < t && (i *= 256);) n += this[e + o] * i;
                return n >= (i *= 128) && (n -= Math.pow(2, 8 * t)), n
            }, a.prototype.readIntBE = function(e, t, r) {
                e >>>= 0, t >>>= 0, r || y(e, t, this.length);
                let n = t,
                    i = 1,
                    o = this[e + --n];
                for (; n > 0 && (i *= 256);) o += this[e + --n] * i;
                return o >= (i *= 128) && (o -= Math.pow(2, 8 * t)), o
            }, a.prototype.readInt8 = function(e, t) {
                return (e >>>= 0, t || y(e, 1, this.length), 128 & this[e]) ? -((255 - this[e] + 1) * 1) : this[e]
            }, a.prototype.readInt16LE = function(e, t) {
                e >>>= 0, t || y(e, 2, this.length);
                let r = this[e] | this[e + 1] << 8;
                return 32768 & r ? 0xffff0000 | r : r
            }, a.prototype.readInt16BE = function(e, t) {
                e >>>= 0, t || y(e, 2, this.length);
                let r = this[e + 1] | this[e] << 8;
                return 32768 & r ? 0xffff0000 | r : r
            }, a.prototype.readInt32LE = function(e, t) {
                return e >>>= 0, t || y(e, 4, this.length), this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24
            }, a.prototype.readInt32BE = function(e, t) {
                return e >>>= 0, t || y(e, 4, this.length), this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]
            }, a.prototype.readBigInt64LE = L(function(e) {
                S(e >>>= 0, "offset");
                let t = this[e],
                    r = this[e + 7];
                return (void 0 === t || void 0 === r) && D(e, this.length - 8), (BigInt(this[e + 4] + 256 * this[e + 5] + 65536 * this[e + 6] + (r << 24)) << BigInt(32)) + BigInt(t + 256 * this[++e] + 65536 * this[++e] + 0x1000000 * this[++e])
            }), a.prototype.readBigInt64BE = L(function(e) {
                S(e >>>= 0, "offset");
                let t = this[e],
                    r = this[e + 7];
                return (void 0 === t || void 0 === r) && D(e, this.length - 8), (BigInt((t << 24) + 65536 * this[++e] + 256 * this[++e] + this[++e]) << BigInt(32)) + BigInt(0x1000000 * this[++e] + 65536 * this[++e] + 256 * this[++e] + r)
            }), a.prototype.readFloatLE = function(e, t) {
                return e >>>= 0, t || y(e, 4, this.length), i.read(this, e, !0, 23, 4)
            }, a.prototype.readFloatBE = function(e, t) {
                return e >>>= 0, t || y(e, 4, this.length), i.read(this, e, !1, 23, 4)
            }, a.prototype.readDoubleLE = function(e, t) {
                return e >>>= 0, t || y(e, 8, this.length), i.read(this, e, !0, 52, 8)
            }, a.prototype.readDoubleBE = function(e, t) {
                return e >>>= 0, t || y(e, 8, this.length), i.read(this, e, !1, 52, 8)
            }, a.prototype.writeUintLE = a.prototype.writeUIntLE = function(e, t, r, n) {
                if (e *= 1, t >>>= 0, r >>>= 0, !n) {
                    let n = Math.pow(2, 8 * r) - 1;
                    C(this, e, t, r, n, 0)
                }
                let i = 1,
                    o = 0;
                for (this[t] = 255 & e; ++o < r && (i *= 256);) this[t + o] = e / i & 255;
                return t + r
            }, a.prototype.writeUintBE = a.prototype.writeUIntBE = function(e, t, r, n) {
                if (e *= 1, t >>>= 0, r >>>= 0, !n) {
                    let n = Math.pow(2, 8 * r) - 1;
                    C(this, e, t, r, n, 0)
                }
                let i = r - 1,
                    o = 1;
                for (this[t + i] = 255 & e; --i >= 0 && (o *= 256);) this[t + i] = e / o & 255;
                return t + r
            }, a.prototype.writeUint8 = a.prototype.writeUInt8 = function(e, t, r) {
                return e *= 1, t >>>= 0, r || C(this, e, t, 1, 255, 0), this[t] = 255 & e, t + 1
            }, a.prototype.writeUint16LE = a.prototype.writeUInt16LE = function(e, t, r) {
                return e *= 1, t >>>= 0, r || C(this, e, t, 2, 65535, 0), this[t] = 255 & e, this[t + 1] = e >>> 8, t + 2
            }, a.prototype.writeUint16BE = a.prototype.writeUInt16BE = function(e, t, r) {
                return e *= 1, t >>>= 0, r || C(this, e, t, 2, 65535, 0), this[t] = e >>> 8, this[t + 1] = 255 & e, t + 2
            }, a.prototype.writeUint32LE = a.prototype.writeUInt32LE = function(e, t, r) {
                return e *= 1, t >>>= 0, r || C(this, e, t, 4, 0xffffffff, 0), this[t + 3] = e >>> 24, this[t + 2] = e >>> 16, this[t + 1] = e >>> 8, this[t] = 255 & e, t + 4
            }, a.prototype.writeUint32BE = a.prototype.writeUInt32BE = function(e, t, r) {
                return e *= 1, t >>>= 0, r || C(this, e, t, 4, 0xffffffff, 0), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e, t + 4
            }, a.prototype.writeBigUInt64LE = L(function(e, t = 0) {
                return b(this, e, t, BigInt(0), BigInt("0xffffffffffffffff"))
            }), a.prototype.writeBigUInt64BE = L(function(e, t = 0) {
                return E(this, e, t, BigInt(0), BigInt("0xffffffffffffffff"))
            }), a.prototype.writeIntLE = function(e, t, r, n) {
                if (e *= 1, t >>>= 0, !n) {
                    let n = Math.pow(2, 8 * r - 1);
                    C(this, e, t, r, n - 1, -n)
                }
                let i = 0,
                    o = 1,
                    s = 0;
                for (this[t] = 255 & e; ++i < r && (o *= 256);) e < 0 && 0 === s && 0 !== this[t + i - 1] && (s = 1), this[t + i] = (e / o | 0) - s & 255;
                return t + r
            }, a.prototype.writeIntBE = function(e, t, r, n) {
                if (e *= 1, t >>>= 0, !n) {
                    let n = Math.pow(2, 8 * r - 1);
                    C(this, e, t, r, n - 1, -n)
                }
                let i = r - 1,
                    o = 1,
                    s = 0;
                for (this[t + i] = 255 & e; --i >= 0 && (o *= 256);) e < 0 && 0 === s && 0 !== this[t + i + 1] && (s = 1), this[t + i] = (e / o | 0) - s & 255;
                return t + r
            }, a.prototype.writeInt8 = function(e, t, r) {
                return e *= 1, t >>>= 0, r || C(this, e, t, 1, 127, -128), e < 0 && (e = 255 + e + 1), this[t] = 255 & e, t + 1
            }, a.prototype.writeInt16LE = function(e, t, r) {
                return e *= 1, t >>>= 0, r || C(this, e, t, 2, 32767, -32768), this[t] = 255 & e, this[t + 1] = e >>> 8, t + 2
            }, a.prototype.writeInt16BE = function(e, t, r) {
                return e *= 1, t >>>= 0, r || C(this, e, t, 2, 32767, -32768), this[t] = e >>> 8, this[t + 1] = 255 & e, t + 2
            }, a.prototype.writeInt32LE = function(e, t, r) {
                return e *= 1, t >>>= 0, r || C(this, e, t, 4, 0x7fffffff, -0x80000000), this[t] = 255 & e, this[t + 1] = e >>> 8, this[t + 2] = e >>> 16, this[t + 3] = e >>> 24, t + 4
            }, a.prototype.writeInt32BE = function(e, t, r) {
                return e *= 1, t >>>= 0, r || C(this, e, t, 4, 0x7fffffff, -0x80000000), e < 0 && (e = 0xffffffff + e + 1), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e, t + 4
            }, a.prototype.writeBigInt64LE = L(function(e, t = 0) {
                return b(this, e, t, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"))
            }), a.prototype.writeBigInt64BE = L(function(e, t = 0) {
                return E(this, e, t, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"))
            }), a.prototype.writeFloatLE = function(e, t, r) {
                return M(this, e, t, !0, r)
            }, a.prototype.writeFloatBE = function(e, t, r) {
                return M(this, e, t, !1, r)
            }, a.prototype.writeDoubleLE = function(e, t, r) {
                return R(this, e, t, !0, r)
            }, a.prototype.writeDoubleBE = function(e, t, r) {
                return R(this, e, t, !1, r)
            }, a.prototype.copy = function(e, t, r, n) {
                if (!a.isBuffer(e)) throw TypeError("argument should be a Buffer");
                if (r || (r = 0), n || 0 === n || (n = this.length), t >= e.length && (t = e.length), t || (t = 0), n > 0 && n < r && (n = r), n === r || 0 === e.length || 0 === this.length) return 0;
                if (t < 0) throw RangeError("targetStart out of bounds");
                if (r < 0 || r >= this.length) throw RangeError("Index out of range");
                if (n < 0) throw RangeError("sourceEnd out of bounds");
                n > this.length && (n = this.length), e.length - t < n - r && (n = e.length - t + r);
                let i = n - r;
                return this === e && "function" == typeof Uint8Array.prototype.copyWithin ? this.copyWithin(t, r, n) : Uint8Array.prototype.set.call(e, this.subarray(r, n), t), i
            }, a.prototype.fill = function(e, t, r, n) {
                let i;
                if ("string" == typeof e) {
                    if ("string" == typeof t ? (n = t, t = 0, r = this.length) : "string" == typeof r && (n = r, r = this.length), void 0 !== n && "string" != typeof n) throw TypeError("encoding must be a string");
                    if ("string" == typeof n && !a.isEncoding(n)) throw TypeError("Unknown encoding: " + n);
                    if (1 === e.length) {
                        let t = e.charCodeAt(0);
                        ("utf8" === n && t < 128 || "latin1" === n) && (e = t)
                    }
                } else "number" == typeof e ? e &= 255 : "boolean" == typeof e && (e = Number(e));
                if (t < 0 || this.length < t || this.length < r) throw RangeError("Out of range index");
                if (r <= t) return this;
                if (t >>>= 0, r = void 0 === r ? this.length : r >>> 0, e || (e = 0), "number" == typeof e)
                    for (i = t; i < r; ++i) this[i] = e;
                else {
                    let o = a.isBuffer(e) ? e : a.from(e, n),
                        s = o.length;
                    if (0 === s) throw TypeError('The value "' + e + '" is invalid for argument "value"');
                    for (i = 0; i < r - t; ++i) this[i + t] = o[i % s]
                }
                return this
            };
            let F = {};

            function x(e, t, r) {
                F[e] = class extends r {
                    constructor() {
                        super(), Object.defineProperty(this, "message", {
                            value: t.apply(this, arguments),
                            writable: !0,
                            configurable: !0
                        }), this.name = `${this.name} [${e}]`, this.stack, delete this.name
                    }
                    get code() {
                        return e
                    }
                    set code(e) {
                        Object.defineProperty(this, "code", {
                            configurable: !0,
                            enumerable: !0,
                            value: e,
                            writable: !0
                        })
                    }
                    toString() {
                        return `${this.name} [${e}]: ${this.message}`
                    }
                }
            }

            function I(e) {
                let t = "",
                    r = e.length,
                    n = +("-" === e[0]);
                for (; r >= n + 4; r -= 3) t = `_${e.slice(r-3,r)}${t}`;
                return `${e.slice(0,r)}${t}`
            }

            function T(e, t, r, n, i, o) {
                if (e > r || e < t) {
                    let n, i = "bigint" == typeof t ? "n" : "";
                    throw n = o > 3 ? 0 === t || t === BigInt(0) ? `>= 0${i} and < 2${i} ** ${(o+1)*8}${i}` : `>= -(2${i} ** ${(o+1)*8-1}${i}) and < 2 ** ${(o+1)*8-1}${i}` : `>= ${t}${i} and <= ${r}${i}`, new F.ERR_OUT_OF_RANGE("value", n, e)
                }
                S(i, "offset"), (void 0 === n[i] || void 0 === n[i + o]) && D(i, n.length - (o + 1))
            }

            function S(e, t) {
                if ("number" != typeof e) throw new F.ERR_INVALID_ARG_TYPE(t, "number", e)
            }

            function D(e, t, r) {
                if (Math.floor(e) !== e) throw S(e, r), new F.ERR_OUT_OF_RANGE(r || "offset", "an integer", e);
                if (t < 0) throw new F.ERR_BUFFER_OUT_OF_BOUNDS;
                throw new F.ERR_OUT_OF_RANGE(r || "offset", `>= ${+!!r} and <= ${t}`, e)
            }
            x("ERR_BUFFER_OUT_OF_BOUNDS", function(e) {
                return e ? `${e} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds"
            }, RangeError), x("ERR_INVALID_ARG_TYPE", function(e, t) {
                return `The "${e}" argument must be of type number. Received type ${typeof t}`
            }, TypeError), x("ERR_OUT_OF_RANGE", function(e, t, r) {
                let n = `The value of "${e}" is out of range.`,
                    i = r;
                return Number.isInteger(r) && Math.abs(r) > 0x100000000 ? i = I(String(r)) : "bigint" == typeof r && (i = String(r), (r > BigInt(2) ** BigInt(32) || r < -(BigInt(2) ** BigInt(32))) && (i = I(i)), i += "n"), n += ` It must be ${t}. Received ${i}`
            }, RangeError);
            let O = /[^+/0-9A-Za-z-_]/g;

            function G(e, t) {
                let r;
                t = t || 1 / 0;
                let n = e.length,
                    i = null,
                    o = [];
                for (let s = 0; s < n; ++s) {
                    if ((r = e.charCodeAt(s)) > 55295 && r < 57344) {
                        if (!i) {
                            if (r > 56319 || s + 1 === n) {
                                (t -= 3) > -1 && o.push(239, 191, 189);
                                continue
                            }
                            i = r;
                            continue
                        }
                        if (r < 56320) {
                            (t -= 3) > -1 && o.push(239, 191, 189), i = r;
                            continue
                        }
                        r = (i - 55296 << 10 | r - 56320) + 65536
                    } else i && (t -= 3) > -1 && o.push(239, 191, 189);
                    if (i = null, r < 128) {
                        if ((t -= 1) < 0) break;
                        o.push(r)
                    } else if (r < 2048) {
                        if ((t -= 2) < 0) break;
                        o.push(r >> 6 | 192, 63 & r | 128)
                    } else if (r < 65536) {
                        if ((t -= 3) < 0) break;
                        o.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128)
                    } else if (r < 1114112) {
                        if ((t -= 4) < 0) break;
                        o.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128)
                    } else throw Error("Invalid code point")
                }
                return o
            }

            function P(e) {
                return n.toByteArray(function(e) {
                    if ((e = (e = e.split("=")[0]).trim().replace(O, "")).length < 2) return "";
                    for (; e.length % 4 != 0;) e += "=";
                    return e
                }(e))
            }

            function H(e, t, r, n) {
                let i;
                for (i = 0; i < n && !(i + r >= t.length) && !(i >= e.length); ++i) t[i + r] = e[i];
                return i
            }

            function U(e, t) {
                return e instanceof t || null != e && null != e.constructor && null != e.constructor.name && e.constructor.name === t.name
            }
            let _ = function() {
                let e = "0123456789abcdef",
                    t = Array(256);
                for (let r = 0; r < 16; ++r) {
                    let n = 16 * r;
                    for (let i = 0; i < 16; ++i) t[n + i] = e[r] + e[i]
                }
                return t
            }();

            function L(e) {
                return "undefined" == typeof BigInt ? J : e
            }

            function J() {
                throw Error("BigInt not supported")
            }
        },
        8789: (e, t, r) => {
            "use strict";
            let n, i, o, s, a;
            r.d(t, {
                A: () => ei,
                B: () => O,
                C: () => eo,
                E: () => G,
                F: () => eu,
                a: () => S,
                b: () => T,
                c: () => eT,
                d: () => eD,
                e: () => eA,
                f: () => eY,
                i: () => x,
                o: () => eO,
                q: () => W,
                u: () => D
            });
            var l = r(4312),
                u = r(1759),
                c = r(6797),
                f = r.t(c, 2),
                d = r(4012),
                h = r(2839);
            let p = e => {
                    let t, r = new Set,
                        n = (e, n) => {
                            let i = "function" == typeof e ? e(t) : e;
                            if (!Object.is(i, t)) {
                                let e = t;
                                t = (null != n ? n : "object" != typeof i || null === i) ? i : Object.assign({}, t, i), r.forEach(r => r(t, e))
                            }
                        },
                        i = () => t,
                        o = {
                            setState: n,
                            getState: i,
                            getInitialState: () => s,
                            subscribe: e => (r.add(e), () => r.delete(e))
                        },
                        s = t = e(n, i, o);
                    return o
                },
                A = e => e ? p(e) : p,
                {
                    useSyncExternalStoreWithSelector: m
                } = h,
                g = e => e,
                B = (e, t) => {
                    let r = A(e),
                        n = (e, n = t) => (function(e, t = g, r) {
                            let n = m(e.subscribe, e.getState, e.getInitialState, t, r);
                            return c.useDebugValue(n), n
                        })(r, e, n);
                    return Object.assign(n, r), n
                },
                v = (e, t) => e ? B(e, t) : B;
            var y = r(1305),
                C = r.n(y),
                b = r(7077),
                E = r(4187),
                w = r(5881),
                M = r(2087);

            function R(e) {
                let t = e.root;
                for (; t.getState().previousRoot;) t = t.getState().previousRoot;
                return t
            }
            r(5633), f.act;
            let F = e => e && e.isOrthographicCamera,
                x = e => e && e.hasOwnProperty("current"),
                I = e => null != e && ("string" == typeof e || "number" == typeof e || e.isColor),
                T = ((e, t) => "undefined" != typeof window && ((null == (e = window.document) ? void 0 : e.createElement) || (null == (t = window.navigator) ? void 0 : t.product) === "ReactNative"))() ? c.useLayoutEffect : c.useEffect;

            function S(e) {
                let t = c.useRef(e);
                return T(() => void(t.current = e), [e]), t
            }

            function D() {
                let e = (0, M.u5)(),
                    t = (0, M.y3)();
                return c.useMemo(() => ({
                    children: r
                }) => {
                    let n = (0, M.Nz)(e, !0, e => e.type === c.StrictMode) ? c.StrictMode : c.Fragment;
                    return (0, w.jsx)(n, {
                        children: (0, w.jsx)(t, {
                            children: r
                        })
                    })
                }, [e, t])
            }

            function O({
                set: e
            }) {
                return T(() => (e(new Promise(() => null)), () => e(!1)), [e]), null
            }
            let G = (e => ((e = class extends c.Component {
                constructor(...e) {
                    super(...e), this.state = {
                        error: !1
                    }
                }
                componentDidCatch(e) {
                    this.props.set(e)
                }
                render() {
                    return this.state.error ? null : this.props.children
                }
            }).getDerivedStateFromError = () => ({
                error: !0
            }), e))();

            function P(e) {
                var t;
                let r = "undefined" != typeof window ? null != (t = window.devicePixelRatio) ? t : 2 : 1;
                return Array.isArray(e) ? Math.min(Math.max(e[0], r), e[1]) : e
            }

            function H(e) {
                var t;
                return null == (t = e.__r3f) ? void 0 : t.root.getState()
            }
            let U = {
                    obj: e => e === Object(e) && !U.arr(e) && "function" != typeof e,
                    fun: e => "function" == typeof e,
                    str: e => "string" == typeof e,
                    num: e => "number" == typeof e,
                    boo: e => "boolean" == typeof e,
                    und: e => void 0 === e,
                    nul: e => null === e,
                    arr: e => Array.isArray(e),
                    equ(e, t, {
                        arrays: r = "shallow",
                        objects: n = "reference",
                        strict: i = !0
                    } = {}) {
                        let o;
                        if (typeof e != typeof t || !!e != !!t) return !1;
                        if (U.str(e) || U.num(e) || U.boo(e)) return e === t;
                        let s = U.obj(e);
                        if (s && "reference" === n) return e === t;
                        let a = U.arr(e);
                        if (a && "reference" === r) return e === t;
                        if ((a || s) && e === t) return !0;
                        for (o in e)
                            if (!(o in t)) return !1;
                        if (s && "shallow" === r && "shallow" === n) {
                            for (o in i ? t : e)
                                if (!U.equ(e[o], t[o], {
                                        strict: i,
                                        objects: "reference"
                                    })) return !1
                        } else
                            for (o in i ? t : e)
                                if (e[o] !== t[o]) return !1;
                        if (U.und(o)) {
                            if (a && 0 === e.length && 0 === t.length || s && 0 === Object.keys(e).length && 0 === Object.keys(t).length) return !0;
                            if (e !== t) return !1
                        }
                        return !0
                    }
                },
                _ = ["children", "key", "ref"];

            function L(e, t, r, n) {
                let i = null == e ? void 0 : e.__r3f;
                return !i && (i = {
                    root: t,
                    type: r,
                    parent: null,
                    children: [],
                    props: function(e) {
                        let t = {};
                        for (let r in e) _.includes(r) || (t[r] = e[r]);
                        return t
                    }(n),
                    object: e,
                    eventCount: 0,
                    handlers: {},
                    isHidden: !1
                }, e && (e.__r3f = i)), i
            }

            function J(e, t) {
                let r = e[t];
                if (!t.includes("-")) return {
                    root: e,
                    key: t,
                    target: r
                };
                for (let i of (r = e, t.split("-"))) {
                    var n;
                    t = i, e = r, r = null == (n = r) ? void 0 : n[t]
                }
                return {
                    root: e,
                    key: t,
                    target: r
                }
            }
            let j = /-\d+$/;

            function k(e, t) {
                if (U.str(t.props.attach)) {
                    if (j.test(t.props.attach)) {
                        let r = t.props.attach.replace(j, ""),
                            {
                                root: n,
                                key: i
                            } = J(e.object, r);
                        Array.isArray(n[i]) || (n[i] = [])
                    }
                    let {
                        root: r,
                        key: n
                    } = J(e.object, t.props.attach);
                    t.previousAttach = r[n], r[n] = t.object
                } else U.fun(t.props.attach) && (t.previousAttach = t.props.attach(e.object, t.object))
            }

            function N(e, t) {
                if (U.str(t.props.attach)) {
                    let {
                        root: r,
                        key: n
                    } = J(e.object, t.props.attach), i = t.previousAttach;
                    void 0 === i ? delete r[n] : r[n] = i
                } else null == t.previousAttach || t.previousAttach(e.object, t.object);
                delete t.previousAttach
            }
            let K = [..._, "args", "dispose", "attach", "object", "onUpdate", "dispose"],
                Q = new Map,
                X = ["map", "emissiveMap", "sheenColorMap", "specularColorMap", "envMap"],
                Y = /^on(Pointer|Click|DoubleClick|ContextMenu|Wheel)/;

            function W(e, t) {
                var r, n;
                let i = e.__r3f,
                    o = i && R(i).getState(),
                    s = null == i ? void 0 : i.eventCount;
                for (let r in t) {
                    let s = t[r];
                    if (K.includes(r)) continue;
                    if (i && Y.test(r)) {
                        "function" == typeof s ? i.handlers[r] = s : delete i.handlers[r], i.eventCount = Object.keys(i.handlers).length;
                        continue
                    }
                    if (void 0 === s) continue;
                    let {
                        root: a,
                        key: u,
                        target: c
                    } = J(e, r);
                    c instanceof l.zgK && s instanceof l.zgK ? c.mask = s.mask : c instanceof l.Q1f && I(s) ? c.set(s) : null !== c && "object" == typeof c && "function" == typeof c.set && "function" == typeof c.copy && null != s && s.constructor && c.constructor === s.constructor ? c.copy(s) : null !== c && "object" == typeof c && "function" == typeof c.set && Array.isArray(s) ? "function" == typeof c.fromArray ? c.fromArray(s) : c.set(...s) : null !== c && "object" == typeof c && "function" == typeof c.set && "number" == typeof s ? "function" == typeof c.setScalar ? c.setScalar(s) : c.set(s) : (a[u] = s, o && !o.linear && X.includes(u) && null != (n = a[u]) && n.isTexture && a[u].format === l.GWd && a[u].type === l.OUM && (a[u].colorSpace = l.er$))
                }
                if (null != i && i.parent && null != o && o.internal && null != (r = i.object) && r.isObject3D && s !== i.eventCount) {
                    let e = i.object,
                        t = o.internal.interaction.indexOf(e);
                    t > -1 && o.internal.interaction.splice(t, 1), i.eventCount && null !== e.raycast && o.internal.interaction.push(e)
                }
                return i && void 0 === i.props.attach && (i.object.isBufferGeometry ? i.props.attach = "geometry" : i.object.isMaterial && (i.props.attach = "material")), i && z(i), e
            }

            function z(e) {
                var t;
                if (!e.parent) return;
                null == e.props.onUpdate || e.props.onUpdate(e.object);
                let r = null == (t = e.root) || null == t.getState ? void 0 : t.getState();
                r && 0 === r.internal.frames && r.invalidate()
            }

            function q(e, t) {
                e.manual || (F(e) ? (e.left = -(t.width / 2), e.right = t.width / 2, e.top = t.height / 2, e.bottom = -(t.height / 2)) : e.aspect = t.width / t.height, e.updateProjectionMatrix())
            }
            let Z = e => null == e ? void 0 : e.isObject3D;

            function V(e) {
                return (e.eventObject || e.object).uuid + "/" + e.index + e.instanceId
            }

            function $(e, t, r, n) {
                let i = r.get(t);
                i && (r.delete(t), 0 === r.size && (e.delete(n), i.target.releasePointerCapture(n)))
            }
            let ee = e => !!(null != e && e.render),
                et = c.createContext(null),
                er = (e, t) => {
                    let r = v((r, n) => {
                            let i, o = new l.Pq0,
                                s = new l.Pq0,
                                a = new l.Pq0;

                            function u(e = n().camera, t = s, r = n().size) {
                                let {
                                    width: i,
                                    height: l,
                                    top: c,
                                    left: f
                                } = r, d = i / l;
                                t.isVector3 ? a.copy(t) : a.set(...t);
                                let h = e.getWorldPosition(o).distanceTo(a);
                                if (F(e)) return {
                                    width: i / e.zoom,
                                    height: l / e.zoom,
                                    top: c,
                                    left: f,
                                    factor: 1,
                                    distance: h,
                                    aspect: d
                                }; {
                                    let t = 2 * Math.tan(e.fov * Math.PI / 180 / 2) * h,
                                        r = i / l * t;
                                    return {
                                        width: r,
                                        height: t,
                                        top: c,
                                        left: f,
                                        factor: i / r,
                                        distance: h,
                                        aspect: d
                                    }
                                }
                            }
                            let f = e => r(t => ({
                                    performance: { ...t.performance,
                                        current: e
                                    }
                                })),
                                d = new l.I9Y;
                            return {
                                set: r,
                                get: n,
                                gl: null,
                                camera: null,
                                raycaster: null,
                                events: {
                                    priority: 1,
                                    enabled: !0,
                                    connected: !1
                                },
                                scene: null,
                                xr: null,
                                invalidate: (t = 1) => e(n(), t),
                                advance: (e, r) => t(e, r, n()),
                                legacy: !1,
                                linear: !1,
                                flat: !1,
                                controls: null,
                                clock: new l.zD7,
                                pointer: d,
                                mouse: d,
                                frameloop: "always",
                                onPointerMissed: void 0,
                                performance: {
                                    current: 1,
                                    min: .5,
                                    max: 1,
                                    debounce: 200,
                                    regress: () => {
                                        let e = n();
                                        i && clearTimeout(i), e.performance.current !== e.performance.min && f(e.performance.min), i = setTimeout(() => f(n().performance.max), e.performance.debounce)
                                    }
                                },
                                size: {
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    left: 0
                                },
                                viewport: {
                                    initialDpr: 0,
                                    dpr: 0,
                                    width: 0,
                                    height: 0,
                                    top: 0,
                                    left: 0,
                                    aspect: 0,
                                    distance: 0,
                                    factor: 0,
                                    getCurrentViewport: u
                                },
                                setEvents: e => r(t => ({ ...t,
                                    events: { ...t.events,
                                        ...e
                                    }
                                })),
                                setSize: (e, t, i = 0, o = 0) => {
                                    let a = n().camera,
                                        l = {
                                            width: e,
                                            height: t,
                                            top: i,
                                            left: o
                                        };
                                    r(e => ({
                                        size: l,
                                        viewport: { ...e.viewport,
                                            ...u(a, s, l)
                                        }
                                    }))
                                },
                                setDpr: e => r(t => {
                                    let r = P(e);
                                    return {
                                        viewport: { ...t.viewport,
                                            dpr: r,
                                            initialDpr: t.viewport.initialDpr || r
                                        }
                                    }
                                }),
                                setFrameloop: (e = "always") => {
                                    let t = n().clock;
                                    t.stop(), t.elapsedTime = 0, "never" !== e && (t.start(), t.elapsedTime = 0), r(() => ({
                                        frameloop: e
                                    }))
                                },
                                previousRoot: void 0,
                                internal: {
                                    interaction: [],
                                    hovered: new Map,
                                    subscribers: [],
                                    initialClick: [0, 0],
                                    initialHits: [],
                                    capturedMap: new Map,
                                    lastEvent: c.createRef(),
                                    active: !1,
                                    frames: 0,
                                    priority: 0,
                                    subscribe: (e, t, r) => {
                                        let i = n().internal;
                                        return i.priority = i.priority + +(t > 0), i.subscribers.push({
                                            ref: e,
                                            priority: t,
                                            store: r
                                        }), i.subscribers = i.subscribers.sort((e, t) => e.priority - t.priority), () => {
                                            let r = n().internal;
                                            null != r && r.subscribers && (r.priority = r.priority - (t > 0), r.subscribers = r.subscribers.filter(t => t.ref !== e))
                                        }
                                    }
                                }
                            }
                        }),
                        n = r.getState(),
                        i = n.size,
                        o = n.viewport.dpr,
                        s = n.camera;
                    return r.subscribe(() => {
                        let {
                            camera: e,
                            size: t,
                            viewport: n,
                            gl: a,
                            set: l
                        } = r.getState();
                        if (t.width !== i.width || t.height !== i.height || n.dpr !== o) {
                            i = t, o = n.dpr, q(e, t), n.dpr > 0 && a.setPixelRatio(n.dpr);
                            let r = "undefined" != typeof HTMLCanvasElement && a.domElement instanceof HTMLCanvasElement;
                            a.setSize(t.width, t.height, r)
                        }
                        e !== s && (s = e, l(t => ({
                            viewport: { ...t.viewport,
                                ...t.viewport.getCurrentViewport(e)
                            }
                        })))
                    }), r.subscribe(t => e(t)), r
                };

            function en() {
                let e = c.useContext(et);
                if (!e) throw Error("R3F: Hooks can only be used within the Canvas component!");
                return e
            }

            function ei(e = e => e, t) {
                return en()(e, t)
            }

            function eo(e, t = 0) {
                let r = en(),
                    n = r.getState().internal.subscribe,
                    i = S(e);
                return T(() => n(i, t, r), [t, n, r]), null
            }
            let es = new WeakMap,
                ea = e => {
                    var t;
                    return "function" == typeof e && (null == e || null == (t = e.prototype) ? void 0 : t.constructor) === e
                };

            function el(e, t) {
                return function(r, ...n) {
                    let i;
                    return ea(r) ? (i = es.get(r)) || (i = new r, es.set(r, i)) : i = r, e && e(i), Promise.all(n.map(e => new Promise((r, n) => i.load(e, e => {
                        Z(null == e ? void 0 : e.scene) && Object.assign(e, function(e) {
                            let t = {
                                nodes: {},
                                materials: {},
                                meshes: {}
                            };
                            return e && e.traverse(e => {
                                e.name && (t.nodes[e.name] = e), e.material && !t.materials[e.material.name] && (t.materials[e.material.name] = e.material), e.isMesh && !t.meshes[e.name] && (t.meshes[e.name] = e)
                            }), t
                        }(e.scene)), r(e)
                    }, t, t => n(Error(`Could not load ${e}: ${null==t?void 0:t.message}`))))))
                }
            }

            function eu(e, t, r, n) {
                let i = Array.isArray(t) ? t : [t],
                    o = (0, E.DY)(el(r, n), [e, ...i], {
                        equal: U.equ
                    });
                return Array.isArray(t) ? o : o[0]
            }
            eu.preload = function(e, t, r) {
                let n = Array.isArray(t) ? t : [t];
                return (0, E.uv)(el(r), [e, ...n])
            }, eu.clear = function(e, t) {
                let r = Array.isArray(t) ? t : [t];
                return (0, E.IU)([e, ...r])
            };
            let ec = {},
                ef = /^three(?=[A-Z])/,
                ed = e => `${e[0].toUpperCase()}${e.slice(1)}`,
                eh = 0,
                ep = e => "function" == typeof e;

            function eA(e) {
                if (ep(e)) {
                    let t = `${eh++}`;
                    return ec[t] = e, t
                }
                Object.assign(ec, e)
            }

            function em(e, t) {
                let r = ed(e),
                    n = ec[r];
                if ("primitive" !== e && !n) throw Error(`R3F: ${r} is not part of the THREE namespace! Did you forget to extend? See: https://docs.pmnd.rs/react-three-fiber/api/objects#using-3rd-party-objects-declaratively`);
                if ("primitive" === e && !t.object) throw Error("R3F: Primitives without 'object' are invalid!");
                if (void 0 !== t.args && !Array.isArray(t.args)) throw Error("R3F: The args prop must be an array!")
            }

            function eg(e) {
                if (e.isHidden) {
                    var t;
                    e.props.attach && null != (t = e.parent) && t.object ? k(e.parent, e) : Z(e.object) && !1 !== e.props.visible && (e.object.visible = !0), e.isHidden = !1, z(e)
                }
            }

            function eB(e, t, r) {
                let n = t.root.getState();
                if (e.parent || e.object === n.scene) {
                    if (!t.object) {
                        var i, o;
                        let e = ec[ed(t.type)];
                        t.object = null != (i = t.props.object) ? i : new e(...null != (o = t.props.args) ? o : []), t.object.__r3f = t
                    }
                    if (W(t.object, t.props), t.props.attach) k(e, t);
                    else if (Z(t.object) && Z(e.object)) {
                        let n = e.object.children.indexOf(null == r ? void 0 : r.object);
                        if (r && -1 !== n) {
                            let r = e.object.children.indexOf(t.object); - 1 !== r ? (e.object.children.splice(r, 1), e.object.children.splice(r < n ? n - 1 : n, 0, t.object)) : (t.object.parent = e.object, e.object.children.splice(n, 0, t.object), t.object.dispatchEvent({
                                type: "added"
                            }), e.object.dispatchEvent({
                                type: "childadded",
                                child: t.object
                            }))
                        } else e.object.add(t.object)
                    }
                    for (let e of t.children) eB(t, e);
                    z(t)
                }
            }

            function ev(e, t) {
                t && (t.parent = e, e.children.push(t), eB(e, t))
            }

            function ey(e, t, r) {
                if (!t || !r) return;
                t.parent = e;
                let n = e.children.indexOf(r); - 1 !== n ? e.children.splice(n, 0, t) : e.children.push(t), eB(e, t, r)
            }

            function eC(e) {
                if ("function" == typeof e.dispose) {
                    let t = () => {
                        try {
                            e.dispose()
                        } catch {}
                    };
                    "undefined" != typeof IS_REACT_ACT_ENVIRONMENT ? t() : (0, b.unstable_scheduleCallback)(b.unstable_IdlePriority, t)
                }
            }

            function eb(e, t, r) {
                if (!t) return;
                t.parent = null;
                let n = e.children.indexOf(t); - 1 !== n && e.children.splice(n, 1), t.props.attach ? N(e, t) : Z(t.object) && Z(e.object) && (e.object.remove(t.object), function(e, t) {
                    let {
                        internal: r
                    } = e.getState();
                    r.interaction = r.interaction.filter(e => e !== t), r.initialHits = r.initialHits.filter(e => e !== t), r.hovered.forEach((e, n) => {
                        (e.eventObject === t || e.object === t) && r.hovered.delete(n)
                    }), r.capturedMap.forEach((e, n) => {
                        $(r.capturedMap, t, e, n)
                    })
                }(R(t), t.object));
                let i = null !== t.props.dispose && !1 !== r;
                for (let e = t.children.length - 1; e >= 0; e--) {
                    let r = t.children[e];
                    eb(t, r, i)
                }
                t.children.length = 0, delete t.object.__r3f, i && "primitive" !== t.type && "Scene" !== t.object.type && eC(t.object), void 0 === r && z(t)
            }
            let eE = [],
                ew = () => {},
                eM = {},
                eR = 0,
                eF = function(e) {
                    let t = C()(e);
                    return t.injectIntoDevTools({
                        bundleType: 0,
                        rendererPackageName: "@react-three/fiber",
                        version: c.version
                    }), t
                }({
                    isPrimaryRenderer: !1,
                    warnsIfNotActing: !1,
                    supportsMutation: !0,
                    supportsPersistence: !1,
                    supportsHydration: !1,
                    createInstance: function(e, t, r) {
                        var n;
                        return em(e = ed(e) in ec ? e : e.replace(ef, ""), t), "primitive" === e && null != (n = t.object) && n.__r3f && delete t.object.__r3f, L(t.object, r, e, t)
                    },
                    removeChild: eb,
                    appendChild: ev,
                    appendInitialChild: ev,
                    insertBefore: ey,
                    appendChildToContainer(e, t) {
                        let r = e.getState().scene.__r3f;
                        t && r && ev(r, t)
                    },
                    removeChildFromContainer(e, t) {
                        let r = e.getState().scene.__r3f;
                        t && r && eb(r, t)
                    },
                    insertInContainerBefore(e, t, r) {
                        let n = e.getState().scene.__r3f;
                        t && r && n && ey(n, t, r)
                    },
                    getRootHostContext: () => eM,
                    getChildHostContext: () => eM,
                    commitUpdate(e, t, r, n, i) {
                        var o, s, a;
                        em(t, n);
                        let l = !1;
                        if ("primitive" === e.type && r.object !== n.object || (null == (o = n.args) ? void 0 : o.length) !== (null == (s = r.args) ? void 0 : s.length) ? l = !0 : null != (a = n.args) && a.some((e, t) => {
                                var n;
                                return e !== (null == (n = r.args) ? void 0 : n[t])
                            }) && (l = !0), l) eE.push([e, { ...n
                        }, i]);
                        else {
                            let t = function(e, t) {
                                let r = {};
                                for (let n in t)
                                    if (!K.includes(n) && !U.equ(t[n], e.props[n]))
                                        for (let e in r[n] = t[n], t) e.startsWith(`${n}-`) && (r[e] = t[e]);
                                for (let n in e.props) {
                                    if (K.includes(n) || t.hasOwnProperty(n)) continue;
                                    let {
                                        root: i,
                                        key: o
                                    } = J(e.object, n);
                                    if (i.constructor && 0 === i.constructor.length) {
                                        let e = function(e) {
                                            let t = Q.get(e.constructor);
                                            try {
                                                t || (t = new e.constructor, Q.set(e.constructor, t))
                                            } catch (e) {}
                                            return t
                                        }(i);
                                        U.und(e) || (r[o] = e[o])
                                    } else r[o] = 0
                                }
                                return r
                            }(e, n);
                            Object.keys(t).length && (Object.assign(e.props, t), W(e.object, t))
                        }(null === i.sibling || (4 & i.flags) == 0) && function() {
                            for (let [e] of eE) {
                                let t = e.parent;
                                if (t)
                                    for (let r of (e.props.attach ? N(t, e) : Z(e.object) && Z(t.object) && t.object.remove(e.object), e.children)) r.props.attach ? N(e, r) : Z(r.object) && Z(e.object) && e.object.remove(r.object);
                                e.isHidden && eg(e), e.object.__r3f && delete e.object.__r3f, "primitive" !== e.type && eC(e.object)
                            }
                            for (let [n, i, o] of eE) {
                                n.props = i;
                                let s = n.parent;
                                if (s) {
                                    let i = ec[ed(n.type)];
                                    n.object = null != (e = n.props.object) ? e : new i(...null != (t = n.props.args) ? t : []), n.object.__r3f = n;
                                    var e, t, r = n.object;
                                    for (let e of [o, o.alternate])
                                        if (null !== e)
                                            if ("function" == typeof e.ref) {
                                                null == e.refCleanup || e.refCleanup();
                                                let t = e.ref(r);
                                                "function" == typeof t && (e.refCleanup = t)
                                            } else e.ref && (e.ref.current = r);
                                    for (let e of (W(n.object, n.props), n.props.attach ? k(s, n) : Z(n.object) && Z(s.object) && s.object.add(n.object), n.children)) e.props.attach ? k(n, e) : Z(e.object) && Z(n.object) && n.object.add(e.object);
                                    z(n)
                                }
                            }
                            eE.length = 0
                        }()
                    },
                    finalizeInitialChildren: () => !1,
                    commitMount() {},
                    getPublicInstance: e => null == e ? void 0 : e.object,
                    prepareForCommit: () => null,
                    preparePortalMount: e => L(e.getState().scene, e, "", {}),
                    resetAfterCommit: () => {},
                    shouldSetTextContent: () => !1,
                    clearContainer: () => !1,
                    hideInstance: function(e) {
                        if (!e.isHidden) {
                            var t;
                            e.props.attach && null != (t = e.parent) && t.object ? N(e.parent, e) : Z(e.object) && (e.object.visible = !1), e.isHidden = !0, z(e)
                        }
                    },
                    unhideInstance: eg,
                    createTextInstance: ew,
                    hideTextInstance: ew,
                    unhideTextInstance: ew,
                    scheduleTimeout: "function" == typeof setTimeout ? setTimeout : void 0,
                    cancelTimeout: "function" == typeof clearTimeout ? clearTimeout : void 0,
                    noTimeout: -1,
                    getInstanceFromNode: () => null,
                    beforeActiveInstanceBlur() {},
                    afterActiveInstanceBlur() {},
                    detachDeletedInstance() {},
                    prepareScopeUpdate() {},
                    getInstanceFromScope: () => null,
                    shouldAttemptEagerTransition: () => !1,
                    trackSchedulerEvent: () => {},
                    resolveEventType: () => null,
                    resolveEventTimeStamp: () => -1.1,
                    requestPostPaintCallback() {},
                    maySuspendCommit: () => !1,
                    preloadInstance: () => !0,
                    startSuspendingCommit() {},
                    suspendInstance() {},
                    waitForCommitToBeReady: () => null,
                    NotPendingTransition: null,
                    HostTransitionContext: c.createContext(null),
                    setCurrentUpdatePriority(e) {
                        eR = e
                    },
                    getCurrentUpdatePriority: () => eR,
                    resolveUpdatePriority() {
                        var e;
                        if (0 !== eR) return eR;
                        switch ("undefined" != typeof window && (null == (e = window.event) ? void 0 : e.type)) {
                            case "click":
                            case "contextmenu":
                            case "dblclick":
                            case "pointercancel":
                            case "pointerdown":
                            case "pointerup":
                                return d.DiscreteEventPriority;
                            case "pointermove":
                            case "pointerout":
                            case "pointerover":
                            case "pointerenter":
                            case "pointerleave":
                            case "wheel":
                                return d.ContinuousEventPriority;
                            default:
                                return d.DefaultEventPriority
                        }
                    },
                    resetFormInstance() {}
                }),
                ex = new Map,
                eI = {
                    objects: "shallow",
                    strict: !1
                };

            function eT(e) {
                let t, r, n = ex.get(e),
                    i = null == n ? void 0 : n.fiber,
                    o = null == n ? void 0 : n.store;
                n && console.warn("R3F.createRoot should only be called once!");
                let s = "function" == typeof reportError ? reportError : console.error,
                    a = o || er(eK, eQ),
                    c = i || eF.createContainer(a, d.ConcurrentRoot, null, !1, null, "", s, s, s, null);
                n || ex.set(e, {
                    fiber: c,
                    store: a
                });
                let f = !1,
                    h = null;
                return {
                    async configure(n = {}) {
                        var i, o;
                        let s;
                        h = new Promise(e => s = e);
                        let {
                            gl: c,
                            size: d,
                            scene: p,
                            events: A,
                            onCreated: m,
                            shadows: g = !1,
                            linear: B = !1,
                            flat: v = !1,
                            legacy: y = !1,
                            orthographic: C = !1,
                            frameloop: b = "always",
                            dpr: E = [1, 2],
                            performance: w,
                            raycaster: M,
                            camera: R,
                            onPointerMissed: F
                        } = n, x = a.getState(), I = x.gl;
                        if (!x.gl) {
                            let t = {
                                    canvas: e,
                                    powerPreference: "high-performance",
                                    antialias: !0,
                                    alpha: !0
                                },
                                r = "function" == typeof c ? await c(t) : c;
                            I = ee(r) ? r : new u.WebGLRenderer({ ...t,
                                ...c
                            }), x.set({
                                gl: I
                            })
                        }
                        let T = x.raycaster;
                        T || x.set({
                            raycaster: T = new l.tBo
                        });
                        let {
                            params: S,
                            ...D
                        } = M || {};
                        if (U.equ(D, T, eI) || W(T, { ...D
                            }), U.equ(S, T.params, eI) || W(T, {
                                params: { ...T.params,
                                    ...S
                                }
                            }), !x.camera || x.camera === r && !U.equ(r, R, eI)) {
                            r = R;
                            let e = null == R ? void 0 : R.isCamera,
                                t = e ? R : C ? new l.qUd(0, 0, 0, 0, .1, 1e3) : new l.ubm(75, 0, .1, 1e3);
                            !e && (t.position.z = 5, R && (W(t, R), !t.manual && ("aspect" in R || "left" in R || "right" in R || "bottom" in R || "top" in R) && (t.manual = !0, t.updateProjectionMatrix())), x.camera || null != R && R.rotation || t.lookAt(0, 0, 0)), x.set({
                                camera: t
                            }), T.camera = t
                        }
                        if (!x.scene) {
                            let e;
                            null != p && p.isScene ? L(e = p, a, "", {}) : (L(e = new l.Z58, a, "", {}), p && W(e, p)), x.set({
                                scene: e
                            })
                        }
                        A && !x.events.handlers && x.set({
                            events: A(a)
                        });
                        let O = function(e, t) {
                            if (!t && "undefined" != typeof HTMLCanvasElement && e instanceof HTMLCanvasElement && e.parentElement) {
                                let {
                                    width: t,
                                    height: r,
                                    top: n,
                                    left: i
                                } = e.parentElement.getBoundingClientRect();
                                return {
                                    width: t,
                                    height: r,
                                    top: n,
                                    left: i
                                }
                            }
                            return !t && "undefined" != typeof OffscreenCanvas && e instanceof OffscreenCanvas ? {
                                width: e.width,
                                height: e.height,
                                top: 0,
                                left: 0
                            } : {
                                width: 0,
                                height: 0,
                                top: 0,
                                left: 0,
                                ...t
                            }
                        }(e, d);
                        if (U.equ(O, x.size, eI) || x.setSize(O.width, O.height, O.top, O.left), E && x.viewport.dpr !== P(E) && x.setDpr(E), x.frameloop !== b && x.setFrameloop(b), x.onPointerMissed || x.set({
                                onPointerMissed: F
                            }), w && !U.equ(w, x.performance, eI) && x.set(e => ({
                                performance: { ...e.performance,
                                    ...w
                                }
                            })), !x.xr) {
                            let e = (e, t) => {
                                    let r = a.getState();
                                    "never" !== r.frameloop && eQ(e, !0, r, t)
                                },
                                t = () => {
                                    let t = a.getState();
                                    t.gl.xr.enabled = t.gl.xr.isPresenting, t.gl.xr.setAnimationLoop(t.gl.xr.isPresenting ? e : null), t.gl.xr.isPresenting || eK(t)
                                },
                                r = {
                                    connect() {
                                        let e = a.getState().gl;
                                        e.xr.addEventListener("sessionstart", t), e.xr.addEventListener("sessionend", t)
                                    },
                                    disconnect() {
                                        let e = a.getState().gl;
                                        e.xr.removeEventListener("sessionstart", t), e.xr.removeEventListener("sessionend", t)
                                    }
                                };
                            "function" == typeof(null == (i = I.xr) ? void 0 : i.addEventListener) && r.connect(), x.set({
                                xr: r
                            })
                        }
                        if (I.shadowMap) {
                            let e = I.shadowMap.enabled,
                                t = I.shadowMap.type;
                            if (I.shadowMap.enabled = !!g, U.boo(g)) I.shadowMap.type = l.Wk7;
                            else if (U.str(g)) {
                                let e = {
                                    basic: l.bTm,
                                    percentage: l.QP0,
                                    soft: l.Wk7,
                                    variance: l.RyA
                                };
                                I.shadowMap.type = null != (o = e[g]) ? o : l.Wk7
                            } else U.obj(g) && Object.assign(I.shadowMap, g);
                            (e !== I.shadowMap.enabled || t !== I.shadowMap.type) && (I.shadowMap.needsUpdate = !0)
                        }
                        return l.ppV.enabled = !y, f || (I.outputColorSpace = B ? l.Zr2 : l.er$, I.toneMapping = v ? l.y_p : l.FV), x.legacy !== y && x.set(() => ({
                            legacy: y
                        })), x.linear !== B && x.set(() => ({
                            linear: B
                        })), x.flat !== v && x.set(() => ({
                            flat: v
                        })), !c || U.fun(c) || ee(c) || U.equ(c, I, eI) || W(I, c), t = m, f = !0, s(), this
                    },
                    render(r) {
                        return f || h || this.configure(), h.then(() => {
                            eF.updateContainer((0, w.jsx)(eS, {
                                store: a,
                                children: r,
                                onCreated: t,
                                rootElement: e
                            }), c, null, () => void 0)
                        }), a
                    },
                    unmount() {
                        eD(e)
                    }
                }
            }

            function eS({
                store: e,
                children: t,
                onCreated: r,
                rootElement: n
            }) {
                return T(() => {
                    let t = e.getState();
                    t.set(e => ({
                        internal: { ...e.internal,
                            active: !0
                        }
                    })), r && r(t), e.getState().events.connected || null == t.events.connect || t.events.connect(n)
                }, []), (0, w.jsx)(et.Provider, {
                    value: e,
                    children: t
                })
            }

            function eD(e, t) {
                let r = ex.get(e),
                    n = null == r ? void 0 : r.fiber;
                if (n) {
                    let i = null == r ? void 0 : r.store.getState();
                    i && (i.internal.active = !1), eF.updateContainer(null, n, null, () => {
                        i && setTimeout(() => {
                            try {
                                null == i.events.disconnect || i.events.disconnect(), null == (r = i.gl) || null == (n = r.renderLists) || null == n.dispose || n.dispose(), null == (o = i.gl) || null == o.forceContextLoss || o.forceContextLoss(), null != (s = i.gl) && s.xr && i.xr.disconnect();
                                var r, n, o, s, a = i.scene;
                                for (let e in "Scene" !== a.type && (null == a.dispose || a.dispose()), a) {
                                    let t = a[e];
                                    (null == t ? void 0 : t.type) !== "Scene" && (null == t || null == t.dispose || t.dispose())
                                }
                                ex.delete(e), t && t(e)
                            } catch (e) {}
                        }, 500)
                    })
                }
            }

            function eO(e, t, r) {
                return (0, w.jsx)(eG, {
                    children: e,
                    container: t,
                    state: r
                })
            }

            function eG({
                state: e = {},
                children: t,
                container: r
            }) {
                let {
                    events: n,
                    size: i,
                    ...o
                } = e, s = en(), [a] = c.useState(() => new l.tBo), [u] = c.useState(() => new l.I9Y), f = S((e, t) => {
                    let o;
                    if (t.camera && i) {
                        let r = t.camera;
                        o = e.viewport.getCurrentViewport(r, new l.Pq0, i), r !== e.camera && q(r, i)
                    }
                    return { ...e,
                        ...t,
                        scene: r,
                        raycaster: a,
                        pointer: u,
                        mouse: u,
                        previousRoot: s,
                        events: { ...e.events,
                            ...t.events,
                            ...n
                        },
                        size: { ...e.size,
                            ...i
                        },
                        viewport: { ...e.viewport,
                            ...o
                        },
                        setEvents: e => t.set(t => ({ ...t,
                            events: { ...t.events,
                                ...e
                            }
                        }))
                    }
                }), d = c.useMemo(() => {
                    let e = v((e, t) => ({ ...o,
                            set: e,
                            get: t
                        })),
                        t = t => e.setState(e => f.current(t, e));
                    return t(s.getState()), s.subscribe(t), e
                }, [s, r]);
                return (0, w.jsx)(w.Fragment, {
                    children: eF.createPortal((0, w.jsx)(et.Provider, {
                        value: d,
                        children: t
                    }), d, null)
                })
            }
            let eP = new Set,
                eH = new Set,
                eU = new Set;

            function e_(e, t) {
                if (e.size)
                    for (let {
                            callback: r
                        } of e.values()) r(t)
            }

            function eL(e, t) {
                switch (e) {
                    case "before":
                        return e_(eP, t);
                    case "after":
                        return e_(eH, t);
                    case "tail":
                        return e_(eU, t)
                }
            }

            function eJ(e, t, r) {
                let o = t.clock.getDelta();
                "never" === t.frameloop && "number" == typeof e && (o = e - t.clock.elapsedTime, t.clock.oldTime = t.clock.elapsedTime, t.clock.elapsedTime = e), n = t.internal.subscribers;
                for (let e = 0; e < n.length; e++)(i = n[e]).ref.current(i.store.getState(), o, r);
                return !t.internal.priority && t.gl.render && t.gl.render(t.scene, t.camera), t.internal.frames = Math.max(0, t.internal.frames - 1), "always" === t.frameloop ? 1 : t.internal.frames
            }
            let ej = !1,
                ek = !1;

            function eN(e) {
                for (let r of (s = requestAnimationFrame(eN), ej = !0, o = 0, eL("before", e), ek = !0, ex.values())) {
                    var t;
                    (a = r.store.getState()).internal.active && ("always" === a.frameloop || a.internal.frames > 0) && !(null != (t = a.gl.xr) && t.isPresenting) && (o += eJ(e, a))
                }
                if (ek = !1, eL("after", e), 0 === o) return eL("tail", e), ej = !1, cancelAnimationFrame(s)
            }

            function eK(e, t = 1) {
                var r;
                if (!e) return ex.forEach(e => eK(e.store.getState(), t));
                (null == (r = e.gl.xr) || !r.isPresenting) && e.internal.active && "never" !== e.frameloop && (t > 1 ? e.internal.frames = Math.min(60, e.internal.frames + t) : ek ? e.internal.frames = 2 : e.internal.frames = 1, ej || (ej = !0, requestAnimationFrame(eN)))
            }

            function eQ(e, t = !0, r, n) {
                if (t && eL("before", e), r) eJ(e, r, n);
                else
                    for (let t of ex.values()) eJ(e, t.store.getState());
                t && eL("after", e)
            }
            let eX = {
                onClick: ["click", !1],
                onContextMenu: ["contextmenu", !1],
                onDoubleClick: ["dblclick", !1],
                onWheel: ["wheel", !0],
                onPointerDown: ["pointerdown", !0],
                onPointerUp: ["pointerup", !0],
                onPointerLeave: ["pointerleave", !0],
                onPointerMove: ["pointermove", !0],
                onPointerCancel: ["pointercancel", !0],
                onLostPointerCapture: ["lostpointercapture", !0]
            };

            function eY(e) {
                let {
                    handlePointer: t
                } = function(e) {
                    function t(e) {
                        return e.filter(e => ["Move", "Over", "Enter", "Out", "Leave"].some(t => {
                            var r;
                            return null == (r = e.__r3f) ? void 0 : r.handlers["onPointer" + t]
                        }))
                    }

                    function r(t) {
                        let {
                            internal: r
                        } = e.getState();
                        for (let e of r.hovered.values())
                            if (!t.length || !t.find(t => t.object === e.object && t.index === e.index && t.instanceId === e.instanceId)) {
                                let n = e.eventObject.__r3f;
                                if (r.hovered.delete(V(e)), null != n && n.eventCount) {
                                    let r = n.handlers,
                                        i = { ...e,
                                            intersections: t
                                        };
                                    null == r.onPointerOut || r.onPointerOut(i), null == r.onPointerLeave || r.onPointerLeave(i)
                                }
                            }
                    }

                    function n(e, t) {
                        for (let r = 0; r < t.length; r++) {
                            let n = t[r].__r3f;
                            null == n || null == n.handlers.onPointerMissed || n.handlers.onPointerMissed(e)
                        }
                    }
                    return {
                        handlePointer: function(i) {
                            switch (i) {
                                case "onPointerLeave":
                                case "onPointerCancel":
                                    return () => r([]);
                                case "onLostPointerCapture":
                                    return t => {
                                        let {
                                            internal: n
                                        } = e.getState();
                                        "pointerId" in t && n.capturedMap.has(t.pointerId) && requestAnimationFrame(() => {
                                            n.capturedMap.has(t.pointerId) && (n.capturedMap.delete(t.pointerId), r([]))
                                        })
                                    }
                            }
                            return function(o) {
                                let {
                                    onPointerMissed: s,
                                    internal: a
                                } = e.getState();
                                a.lastEvent.current = o;
                                let u = "onPointerMove" === i,
                                    c = "onClick" === i || "onContextMenu" === i || "onDoubleClick" === i,
                                    f = function(t, r) {
                                        let n = e.getState(),
                                            i = new Set,
                                            o = [],
                                            s = r ? r(n.internal.interaction) : n.internal.interaction;
                                        for (let e = 0; e < s.length; e++) {
                                            let t = H(s[e]);
                                            t && (t.raycaster.camera = void 0)
                                        }
                                        n.previousRoot || null == n.events.compute || n.events.compute(t, n);
                                        let a = s.flatMap(function(e) {
                                            let r = H(e);
                                            if (!r || !r.events.enabled || null === r.raycaster.camera) return [];
                                            if (void 0 === r.raycaster.camera) {
                                                var n;
                                                null == r.events.compute || r.events.compute(t, r, null == (n = r.previousRoot) ? void 0 : n.getState()), void 0 === r.raycaster.camera && (r.raycaster.camera = null)
                                            }
                                            return r.raycaster.camera ? r.raycaster.intersectObject(e, !0) : []
                                        }).sort((e, t) => {
                                            let r = H(e.object),
                                                n = H(t.object);
                                            return r && n && n.events.priority - r.events.priority || e.distance - t.distance
                                        }).filter(e => {
                                            let t = V(e);
                                            return !i.has(t) && (i.add(t), !0)
                                        });
                                        for (let e of (n.events.filter && (a = n.events.filter(a, n)), a)) {
                                            let t = e.object;
                                            for (; t;) {
                                                var l;
                                                null != (l = t.__r3f) && l.eventCount && o.push({ ...e,
                                                    eventObject: t
                                                }), t = t.parent
                                            }
                                        }
                                        if ("pointerId" in t && n.internal.capturedMap.has(t.pointerId))
                                            for (let e of n.internal.capturedMap.get(t.pointerId).values()) i.has(V(e.intersection)) || o.push(e.intersection);
                                        return o
                                    }(o, u ? t : void 0),
                                    d = c ? function(t) {
                                        let {
                                            internal: r
                                        } = e.getState(), n = t.offsetX - r.initialClick[0], i = t.offsetY - r.initialClick[1];
                                        return Math.round(Math.sqrt(n * n + i * i))
                                    }(o) : 0;
                                "onPointerDown" === i && (a.initialClick = [o.offsetX, o.offsetY], a.initialHits = f.map(e => e.eventObject)), c && !f.length && d <= 2 && (n(o, a.interaction), s && s(o)), u && r(f), ! function(e, t, n, i) {
                                    if (e.length) {
                                        let o = {
                                            stopped: !1
                                        };
                                        for (let s of e) {
                                            let a = H(s.object);
                                            if (a || s.object.traverseAncestors(e => {
                                                    let t = H(e);
                                                    if (t) return a = t, !1
                                                }), a) {
                                                let {
                                                    raycaster: u,
                                                    pointer: c,
                                                    camera: f,
                                                    internal: d
                                                } = a, h = new l.Pq0(c.x, c.y, 0).unproject(f), p = e => {
                                                    var t, r;
                                                    return null != (t = null == (r = d.capturedMap.get(e)) ? void 0 : r.has(s.eventObject)) && t
                                                }, A = e => {
                                                    let r = {
                                                        intersection: s,
                                                        target: t.target
                                                    };
                                                    d.capturedMap.has(e) ? d.capturedMap.get(e).set(s.eventObject, r) : d.capturedMap.set(e, new Map([
                                                        [s.eventObject, r]
                                                    ])), t.target.setPointerCapture(e)
                                                }, m = e => {
                                                    let t = d.capturedMap.get(e);
                                                    t && $(d.capturedMap, s.eventObject, t, e)
                                                }, g = {};
                                                for (let e in t) {
                                                    let r = t[e];
                                                    "function" != typeof r && (g[e] = r)
                                                }
                                                let B = { ...s,
                                                    ...g,
                                                    pointer: c,
                                                    intersections: e,
                                                    stopped: o.stopped,
                                                    delta: n,
                                                    unprojectedPoint: h,
                                                    ray: u.ray,
                                                    camera: f,
                                                    stopPropagation() {
                                                        let n = "pointerId" in t && d.capturedMap.get(t.pointerId);
                                                        (!n || n.has(s.eventObject)) && (B.stopped = o.stopped = !0, d.hovered.size && Array.from(d.hovered.values()).find(e => e.eventObject === s.eventObject) && r([...e.slice(0, e.indexOf(s)), s]))
                                                    },
                                                    target: {
                                                        hasPointerCapture: p,
                                                        setPointerCapture: A,
                                                        releasePointerCapture: m
                                                    },
                                                    currentTarget: {
                                                        hasPointerCapture: p,
                                                        setPointerCapture: A,
                                                        releasePointerCapture: m
                                                    },
                                                    nativeEvent: t
                                                };
                                                if (i(B), !0 === o.stopped) break
                                            }
                                        }
                                    }
                                }(f, o, d, function(e) {
                                    let t = e.eventObject,
                                        r = t.__r3f;
                                    if (!(null != r && r.eventCount)) return;
                                    let s = r.handlers;
                                    if (u) {
                                        if (s.onPointerOver || s.onPointerEnter || s.onPointerOut || s.onPointerLeave) {
                                            let t = V(e),
                                                r = a.hovered.get(t);
                                            r ? r.stopped && e.stopPropagation() : (a.hovered.set(t, e), null == s.onPointerOver || s.onPointerOver(e), null == s.onPointerEnter || s.onPointerEnter(e))
                                        }
                                        null == s.onPointerMove || s.onPointerMove(e)
                                    } else {
                                        let r = s[i];
                                        r ? (!c || a.initialHits.includes(t)) && (n(o, a.interaction.filter(e => !a.initialHits.includes(e))), r(e)) : c && a.initialHits.includes(t) && n(o, a.interaction.filter(e => !a.initialHits.includes(e)))
                                    }
                                })
                            }
                        }
                    }
                }(e);
                return {
                    priority: 1,
                    enabled: !0,
                    compute(e, t, r) {
                        t.pointer.set(e.offsetX / t.size.width * 2 - 1, -(2 * (e.offsetY / t.size.height)) + 1), t.raycaster.setFromCamera(t.pointer, t.camera)
                    },
                    connected: void 0,
                    handlers: Object.keys(eX).reduce((e, r) => ({ ...e,
                        [r]: t(r)
                    }), {}),
                    update: () => {
                        var t;
                        let {
                            events: r,
                            internal: n
                        } = e.getState();
                        null != (t = n.lastEvent) && t.current && r.handlers && r.handlers.onPointerMove(n.lastEvent.current)
                    },
                    connect: t => {
                        let {
                            set: r,
                            events: n
                        } = e.getState();
                        if (null == n.disconnect || n.disconnect(), r(e => ({
                                events: { ...e.events,
                                    connected: t
                                }
                            })), n.handlers)
                            for (let e in n.handlers) {
                                let r = n.handlers[e],
                                    [i, o] = eX[e];
                                t.addEventListener(i, r, {
                                    passive: o
                                })
                            }
                    },
                    disconnect: () => {
                        let {
                            set: t,
                            events: r
                        } = e.getState();
                        if (r.connected) {
                            if (r.handlers)
                                for (let e in r.handlers) {
                                    let t = r.handlers[e],
                                        [n] = eX[e];
                                    r.connected.removeEventListener(n, t)
                                }
                            t(e => ({
                                events: { ...e.events,
                                    connected: void 0
                                }
                            }))
                        }
                    }
                }
            }
        },
        9512: (e, t, r) => {
            "use strict";
            var n = r(6797),
                i = "function" == typeof Object.is ? Object.is : function(e, t) {
                    return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
                },
                o = n.useState,
                s = n.useEffect,
                a = n.useLayoutEffect,
                l = n.useDebugValue;

            function u(e) {
                var t = e.getSnapshot;
                e = e.value;
                try {
                    var r = t();
                    return !i(e, r)
                } catch (e) {
                    return !0
                }
            }
            var c = "undefined" == typeof window || void 0 === window.document || void 0 === window.document.createElement ? function(e, t) {
                return t()
            } : function(e, t) {
                var r = t(),
                    n = o({
                        inst: {
                            value: r,
                            getSnapshot: t
                        }
                    }),
                    i = n[0].inst,
                    c = n[1];
                return a(function() {
                    i.value = r, i.getSnapshot = t, u(i) && c({
                        inst: i
                    })
                }, [e, r, t]), s(function() {
                    return u(i) && c({
                        inst: i
                    }), e(function() {
                        u(i) && c({
                            inst: i
                        })
                    })
                }, [e]), l(r), r
            };
            t.useSyncExternalStore = void 0 !== n.useSyncExternalStore ? n.useSyncExternalStore : c
        },
        9521: (e, t, r) => {
            "use strict";
            let n;
            r.d(t, {
                A: () => tu
            });
            var i, o, s, a = {};

            function l(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            }
            r.r(a), r.d(a, {
                hasBrowserEnv: () => ed,
                hasStandardBrowserEnv: () => ep,
                hasStandardBrowserWebWorkerEnv: () => eA,
                navigator: () => eh,
                origin: () => em
            });
            var u = r(5633);
            let {
                toString: c
            } = Object.prototype, {
                getPrototypeOf: f
            } = Object, {
                iterator: d,
                toStringTag: h
            } = Symbol, p = (e => t => {
                let r = c.call(t);
                return e[r] || (e[r] = r.slice(8, -1).toLowerCase())
            })(Object.create(null)), A = e => (e = e.toLowerCase(), t => p(t) === e), m = e => t => typeof t === e, {
                isArray: g
            } = Array, B = m("undefined"), v = A("ArrayBuffer"), y = m("string"), C = m("function"), b = m("number"), E = e => null !== e && "object" == typeof e, w = e => {
                if ("object" !== p(e)) return !1;
                let t = f(e);
                return (null === t || t === Object.prototype || null === Object.getPrototypeOf(t)) && !(h in e) && !(d in e)
            }, M = A("Date"), R = A("File"), F = A("Blob"), x = A("FileList"), I = A("URLSearchParams"), [T, S, D, O] = ["ReadableStream", "Request", "Response", "Headers"].map(A);

            function G(e, t, {
                allOwnKeys: r = !1
            } = {}) {
                let n, i;
                if (null != e)
                    if ("object" != typeof e && (e = [e]), g(e))
                        for (n = 0, i = e.length; n < i; n++) t.call(null, e[n], n, e);
                    else {
                        let i, o = r ? Object.getOwnPropertyNames(e) : Object.keys(e),
                            s = o.length;
                        for (n = 0; n < s; n++) i = o[n], t.call(null, e[i], i, e)
                    }
            }

            function P(e, t) {
                let r;
                t = t.toLowerCase();
                let n = Object.keys(e),
                    i = n.length;
                for (; i-- > 0;)
                    if (t === (r = n[i]).toLowerCase()) return r;
                return null
            }
            let H = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : "undefined" != typeof window ? window : global,
                U = e => !B(e) && e !== H,
                _ = (e => t => e && t instanceof e)("undefined" != typeof Uint8Array && f(Uint8Array)),
                L = A("HTMLFormElement"),
                J = (({
                    hasOwnProperty: e
                }) => (t, r) => e.call(t, r))(Object.prototype),
                j = A("RegExp"),
                k = (e, t) => {
                    let r = Object.getOwnPropertyDescriptors(e),
                        n = {};
                    G(r, (r, i) => {
                        let o;
                        !1 !== (o = t(r, i, e)) && (n[i] = o || r)
                    }), Object.defineProperties(e, n)
                },
                N = A("AsyncFunction"),
                K = (i = "function" == typeof setImmediate, o = C(H.postMessage), i ? setImmediate : o ? ((e, t) => (H.addEventListener("message", ({
                    source: r,
                    data: n
                }) => {
                    r === H && n === e && t.length && t.shift()()
                }, !1), r => {
                    t.push(r), H.postMessage(e, "*")
                }))(`axios@${Math.random()}`, []) : e => setTimeout(e)),
                Q = "undefined" != typeof queueMicrotask ? queueMicrotask.bind(H) : void 0 !== u && u.nextTick || K,
                X = {
                    isArray: g,
                    isArrayBuffer: v,
                    isBuffer: function(e) {
                        return null !== e && !B(e) && null !== e.constructor && !B(e.constructor) && C(e.constructor.isBuffer) && e.constructor.isBuffer(e)
                    },
                    isFormData: e => {
                        let t;
                        return e && ("function" == typeof FormData && e instanceof FormData || C(e.append) && ("formdata" === (t = p(e)) || "object" === t && C(e.toString) && "[object FormData]" === e.toString()))
                    },
                    isArrayBufferView: function(e) {
                        let t;
                        return "undefined" != typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e) : e && e.buffer && v(e.buffer)
                    },
                    isString: y,
                    isNumber: b,
                    isBoolean: e => !0 === e || !1 === e,
                    isObject: E,
                    isPlainObject: w,
                    isReadableStream: T,
                    isRequest: S,
                    isResponse: D,
                    isHeaders: O,
                    isUndefined: B,
                    isDate: M,
                    isFile: R,
                    isBlob: F,
                    isRegExp: j,
                    isFunction: C,
                    isStream: e => E(e) && C(e.pipe),
                    isURLSearchParams: I,
                    isTypedArray: _,
                    isFileList: x,
                    forEach: G,
                    merge: function e() {
                        let {
                            caseless: t
                        } = U(this) && this || {}, r = {}, n = (n, i) => {
                            let o = t && P(r, i) || i;
                            w(r[o]) && w(n) ? r[o] = e(r[o], n) : w(n) ? r[o] = e({}, n) : g(n) ? r[o] = n.slice() : r[o] = n
                        };
                        for (let e = 0, t = arguments.length; e < t; e++) arguments[e] && G(arguments[e], n);
                        return r
                    },
                    extend: (e, t, r, {
                        allOwnKeys: n
                    } = {}) => (G(t, (t, n) => {
                        r && C(t) ? e[n] = l(t, r) : e[n] = t
                    }, {
                        allOwnKeys: n
                    }), e),
                    trim: e => e.trim ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ""),
                    stripBOM: e => (65279 === e.charCodeAt(0) && (e = e.slice(1)), e),
                    inherits: (e, t, r, n) => {
                        e.prototype = Object.create(t.prototype, n), e.prototype.constructor = e, Object.defineProperty(e, "super", {
                            value: t.prototype
                        }), r && Object.assign(e.prototype, r)
                    },
                    toFlatObject: (e, t, r, n) => {
                        let i, o, s, a = {};
                        if (t = t || {}, null == e) return t;
                        do {
                            for (o = (i = Object.getOwnPropertyNames(e)).length; o-- > 0;) s = i[o], (!n || n(s, e, t)) && !a[s] && (t[s] = e[s], a[s] = !0);
                            e = !1 !== r && f(e)
                        } while (e && (!r || r(e, t)) && e !== Object.prototype);
                        return t
                    },
                    kindOf: p,
                    kindOfTest: A,
                    endsWith: (e, t, r) => {
                        e = String(e), (void 0 === r || r > e.length) && (r = e.length), r -= t.length;
                        let n = e.indexOf(t, r);
                        return -1 !== n && n === r
                    },
                    toArray: e => {
                        if (!e) return null;
                        if (g(e)) return e;
                        let t = e.length;
                        if (!b(t)) return null;
                        let r = Array(t);
                        for (; t-- > 0;) r[t] = e[t];
                        return r
                    },
                    forEachEntry: (e, t) => {
                        let r, n = (e && e[d]).call(e);
                        for (;
                            (r = n.next()) && !r.done;) {
                            let n = r.value;
                            t.call(e, n[0], n[1])
                        }
                    },
                    matchAll: (e, t) => {
                        let r, n = [];
                        for (; null !== (r = e.exec(t));) n.push(r);
                        return n
                    },
                    isHTMLForm: L,
                    hasOwnProperty: J,
                    hasOwnProp: J,
                    reduceDescriptors: k,
                    freezeMethods: e => {
                        k(e, (t, r) => {
                            if (C(e) && -1 !== ["arguments", "caller", "callee"].indexOf(r)) return !1;
                            if (C(e[r])) {
                                if (t.enumerable = !1, "writable" in t) {
                                    t.writable = !1;
                                    return
                                }
                                t.set || (t.set = () => {
                                    throw Error("Can not rewrite read-only method '" + r + "'")
                                })
                            }
                        })
                    },
                    toObjectSet: (e, t) => {
                        let r = {};
                        return (g(e) ? e : String(e).split(t)).forEach(e => {
                            r[e] = !0
                        }), r
                    },
                    toCamelCase: e => e.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function(e, t, r) {
                        return t.toUpperCase() + r
                    }),
                    noop: () => {},
                    toFiniteNumber: (e, t) => null != e && Number.isFinite(e *= 1) ? e : t,
                    findKey: P,
                    global: H,
                    isContextDefined: U,
                    isSpecCompliantForm: function(e) {
                        return !!(e && C(e.append) && "FormData" === e[h] && e[d])
                    },
                    toJSONObject: e => {
                        let t = Array(10),
                            r = (e, n) => {
                                if (E(e)) {
                                    if (t.indexOf(e) >= 0) return;
                                    if (!("toJSON" in e)) {
                                        t[n] = e;
                                        let i = g(e) ? [] : {};
                                        return G(e, (e, t) => {
                                            let o = r(e, n + 1);
                                            B(o) || (i[t] = o)
                                        }), t[n] = void 0, i
                                    }
                                }
                                return e
                            };
                        return r(e, 0)
                    },
                    isAsyncFn: N,
                    isThenable: e => e && (E(e) || C(e)) && C(e.then) && C(e.catch),
                    setImmediate: K,
                    asap: Q,
                    isIterable: e => null != e && C(e[d])
                };

            function Y(e, t, r, n, i) {
                Error.call(this), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = Error().stack, this.message = e, this.name = "AxiosError", t && (this.code = t), r && (this.config = r), n && (this.request = n), i && (this.response = i, this.status = i.status ? i.status : null)
            }
            X.inherits(Y, Error, {
                toJSON: function() {
                    return {
                        message: this.message,
                        name: this.name,
                        description: this.description,
                        number: this.number,
                        fileName: this.fileName,
                        lineNumber: this.lineNumber,
                        columnNumber: this.columnNumber,
                        stack: this.stack,
                        config: X.toJSONObject(this.config),
                        code: this.code,
                        status: this.status
                    }
                }
            });
            let W = Y.prototype,
                z = {};
            ["ERR_BAD_OPTION_VALUE", "ERR_BAD_OPTION", "ECONNABORTED", "ETIMEDOUT", "ERR_NETWORK", "ERR_FR_TOO_MANY_REDIRECTS", "ERR_DEPRECATED", "ERR_BAD_RESPONSE", "ERR_BAD_REQUEST", "ERR_CANCELED", "ERR_NOT_SUPPORT", "ERR_INVALID_URL"].forEach(e => {
                z[e] = {
                    value: e
                }
            }), Object.defineProperties(Y, z), Object.defineProperty(W, "isAxiosError", {
                value: !0
            }), Y.from = (e, t, r, n, i, o) => {
                let s = Object.create(W);
                return X.toFlatObject(e, s, function(e) {
                    return e !== Error.prototype
                }, e => "isAxiosError" !== e), Y.call(s, e.message, t, r, n, i), s.cause = e, s.name = e.name, o && Object.assign(s, o), s
            };
            var q = r(8500).hp;

            function Z(e) {
                return X.isPlainObject(e) || X.isArray(e)
            }

            function V(e) {
                return X.endsWith(e, "[]") ? e.slice(0, -2) : e
            }

            function $(e, t, r) {
                return e ? e.concat(t).map(function(e, t) {
                    return e = V(e), !r && t ? "[" + e + "]" : e
                }).join(r ? "." : "") : t
            }
            let ee = X.toFlatObject(X, {}, null, function(e) {
                    return /^is[A-Z]/.test(e)
                }),
                et = function(e, t, r) {
                    if (!X.isObject(e)) throw TypeError("target must be an object");
                    t = t || new FormData;
                    let n = (r = X.toFlatObject(r, {
                            metaTokens: !0,
                            dots: !1,
                            indexes: !1
                        }, !1, function(e, t) {
                            return !X.isUndefined(t[e])
                        })).metaTokens,
                        i = r.visitor || u,
                        o = r.dots,
                        s = r.indexes,
                        a = (r.Blob || "undefined" != typeof Blob && Blob) && X.isSpecCompliantForm(t);
                    if (!X.isFunction(i)) throw TypeError("visitor must be a function");

                    function l(e) {
                        if (null === e) return "";
                        if (X.isDate(e)) return e.toISOString();
                        if (!a && X.isBlob(e)) throw new Y("Blob is not supported. Use a Buffer instead.");
                        return X.isArrayBuffer(e) || X.isTypedArray(e) ? a && "function" == typeof Blob ? new Blob([e]) : q.from(e) : e
                    }

                    function u(e, r, i) {
                        let a = e;
                        if (e && !i && "object" == typeof e)
                            if (X.endsWith(r, "{}")) r = n ? r : r.slice(0, -2), e = JSON.stringify(e);
                            else {
                                var u;
                                if (X.isArray(e) && (u = e, X.isArray(u) && !u.some(Z)) || (X.isFileList(e) || X.endsWith(r, "[]")) && (a = X.toArray(e))) return r = V(r), a.forEach(function(e, n) {
                                    X.isUndefined(e) || null === e || t.append(!0 === s ? $([r], n, o) : null === s ? r : r + "[]", l(e))
                                }), !1
                            }
                        return !!Z(e) || (t.append($(i, r, o), l(e)), !1)
                    }
                    let c = [],
                        f = Object.assign(ee, {
                            defaultVisitor: u,
                            convertValue: l,
                            isVisitable: Z
                        });
                    if (!X.isObject(e)) throw TypeError("data must be an object");
                    return ! function e(r, n) {
                        if (!X.isUndefined(r)) {
                            if (-1 !== c.indexOf(r)) throw Error("Circular reference detected in " + n.join("."));
                            c.push(r), X.forEach(r, function(r, o) {
                                !0 === (!(X.isUndefined(r) || null === r) && i.call(t, r, X.isString(o) ? o.trim() : o, n, f)) && e(r, n ? n.concat(o) : [o])
                            }), c.pop()
                        }
                    }(e), t
                };

            function er(e) {
                let t = {
                    "!": "%21",
                    "'": "%27",
                    "(": "%28",
                    ")": "%29",
                    "~": "%7E",
                    "%20": "+",
                    "%00": "\0"
                };
                return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g, function(e) {
                    return t[e]
                })
            }

            function en(e, t) {
                this._pairs = [], e && et(e, this, t)
            }
            let ei = en.prototype;

            function eo(e) {
                return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
            }

            function es(e, t, r) {
                let n;
                if (!t) return e;
                let i = r && r.encode || eo;
                X.isFunction(r) && (r = {
                    serialize: r
                });
                let o = r && r.serialize;
                if (n = o ? o(t, r) : X.isURLSearchParams(t) ? t.toString() : new en(t, r).toString(i)) {
                    let t = e.indexOf("#"); - 1 !== t && (e = e.slice(0, t)), e += (-1 === e.indexOf("?") ? "?" : "&") + n
                }
                return e
            }
            ei.append = function(e, t) {
                this._pairs.push([e, t])
            }, ei.toString = function(e) {
                let t = e ? function(t) {
                    return e.call(this, t, er)
                } : er;
                return this._pairs.map(function(e) {
                    return t(e[0]) + "=" + t(e[1])
                }, "").join("&")
            };
            class ea {
                constructor() {
                    this.handlers = []
                }
                use(e, t, r) {
                    return this.handlers.push({
                        fulfilled: e,
                        rejected: t,
                        synchronous: !!r && r.synchronous,
                        runWhen: r ? r.runWhen : null
                    }), this.handlers.length - 1
                }
                eject(e) {
                    this.handlers[e] && (this.handlers[e] = null)
                }
                clear() {
                    this.handlers && (this.handlers = [])
                }
                forEach(e) {
                    X.forEach(this.handlers, function(t) {
                        null !== t && e(t)
                    })
                }
            }
            let el = {
                    silentJSONParsing: !0,
                    forcedJSONParsing: !0,
                    clarifyTimeoutError: !1
                },
                eu = "undefined" != typeof URLSearchParams ? URLSearchParams : en,
                ec = "undefined" != typeof FormData ? FormData : null,
                ef = "undefined" != typeof Blob ? Blob : null,
                ed = "undefined" != typeof window && "undefined" != typeof document,
                eh = "object" == typeof navigator && navigator || void 0,
                ep = ed && (!eh || 0 > ["ReactNative", "NativeScript", "NS"].indexOf(eh.product)),
                eA = "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope && "function" == typeof self.importScripts,
                em = ed && window.location.href || "http://localhost",
                eg = { ...a,
                    isBrowser: !0,
                    classes: {
                        URLSearchParams: eu,
                        FormData: ec,
                        Blob: ef
                    },
                    protocols: ["http", "https", "file", "blob", "url", "data"]
                },
                eB = function(e) {
                    if (X.isFormData(e) && X.isFunction(e.entries)) {
                        let t = {};
                        return X.forEachEntry(e, (e, r) => {
                            ! function e(t, r, n, i) {
                                let o = t[i++];
                                if ("__proto__" === o) return !0;
                                let s = Number.isFinite(+o),
                                    a = i >= t.length;
                                return (o = !o && X.isArray(n) ? n.length : o, a) ? X.hasOwnProp(n, o) ? n[o] = [n[o], r] : n[o] = r : (n[o] && X.isObject(n[o]) || (n[o] = []), e(t, r, n[o], i) && X.isArray(n[o]) && (n[o] = function(e) {
                                    let t, r, n = {},
                                        i = Object.keys(e),
                                        o = i.length;
                                    for (t = 0; t < o; t++) n[r = i[t]] = e[r];
                                    return n
                                }(n[o]))), !s
                            }(X.matchAll(/\w+|\[(\w*)]/g, e).map(e => "[]" === e[0] ? "" : e[1] || e[0]), r, t, 0)
                        }), t
                    }
                    return null
                },
                ev = {
                    transitional: el,
                    adapter: ["xhr", "http", "fetch"],
                    transformRequest: [function(e, t) {
                        let r, n = t.getContentType() || "",
                            i = n.indexOf("application/json") > -1,
                            o = X.isObject(e);
                        if (o && X.isHTMLForm(e) && (e = new FormData(e)), X.isFormData(e)) return i ? JSON.stringify(eB(e)) : e;
                        if (X.isArrayBuffer(e) || X.isBuffer(e) || X.isStream(e) || X.isFile(e) || X.isBlob(e) || X.isReadableStream(e)) return e;
                        if (X.isArrayBufferView(e)) return e.buffer;
                        if (X.isURLSearchParams(e)) return t.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), e.toString();
                        if (o) {
                            if (n.indexOf("application/x-www-form-urlencoded") > -1) {
                                var s, a;
                                return (s = e, a = this.formSerializer, et(s, new eg.classes.URLSearchParams, Object.assign({
                                    visitor: function(e, t, r, n) {
                                        return eg.isNode && X.isBuffer(e) ? (this.append(t, e.toString("base64")), !1) : n.defaultVisitor.apply(this, arguments)
                                    }
                                }, a))).toString()
                            }
                            if ((r = X.isFileList(e)) || n.indexOf("multipart/form-data") > -1) {
                                let t = this.env && this.env.FormData;
                                return et(r ? {
                                    "files[]": e
                                } : e, t && new t, this.formSerializer)
                            }
                        }
                        if (o || i) {
                            t.setContentType("application/json", !1);
                            var l = e;
                            if (X.isString(l)) try {
                                return (0, JSON.parse)(l), X.trim(l)
                            } catch (e) {
                                if ("SyntaxError" !== e.name) throw e
                            }
                            return (0, JSON.stringify)(l)
                        }
                        return e
                    }],
                    transformResponse: [function(e) {
                        let t = this.transitional || ev.transitional,
                            r = t && t.forcedJSONParsing,
                            n = "json" === this.responseType;
                        if (X.isResponse(e) || X.isReadableStream(e)) return e;
                        if (e && X.isString(e) && (r && !this.responseType || n)) {
                            let r = t && t.silentJSONParsing;
                            try {
                                return JSON.parse(e)
                            } catch (e) {
                                if (!r && n) {
                                    if ("SyntaxError" === e.name) throw Y.from(e, Y.ERR_BAD_RESPONSE, this, null, this.response);
                                    throw e
                                }
                            }
                        }
                        return e
                    }],
                    timeout: 0,
                    xsrfCookieName: "XSRF-TOKEN",
                    xsrfHeaderName: "X-XSRF-TOKEN",
                    maxContentLength: -1,
                    maxBodyLength: -1,
                    env: {
                        FormData: eg.classes.FormData,
                        Blob: eg.classes.Blob
                    },
                    validateStatus: function(e) {
                        return e >= 200 && e < 300
                    },
                    headers: {
                        common: {
                            Accept: "application/json, text/plain, */*",
                            "Content-Type": void 0
                        }
                    }
                };
            X.forEach(["delete", "get", "head", "post", "put", "patch"], e => {
                ev.headers[e] = {}
            });
            let ey = X.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]),
                eC = e => {
                    let t, r, n, i = {};
                    return e && e.split("\n").forEach(function(e) {
                        n = e.indexOf(":"), t = e.substring(0, n).trim().toLowerCase(), r = e.substring(n + 1).trim(), !t || i[t] && ey[t] || ("set-cookie" === t ? i[t] ? i[t].push(r) : i[t] = [r] : i[t] = i[t] ? i[t] + ", " + r : r)
                    }), i
                },
                eb = Symbol("internals");

            function eE(e) {
                return e && String(e).trim().toLowerCase()
            }

            function ew(e) {
                return !1 === e || null == e ? e : X.isArray(e) ? e.map(ew) : String(e)
            }
            let eM = e => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(e.trim());

            function eR(e, t, r, n, i) {
                if (X.isFunction(n)) return n.call(this, t, r);
                if (i && (t = r), X.isString(t)) {
                    if (X.isString(n)) return -1 !== t.indexOf(n);
                    if (X.isRegExp(n)) return n.test(t)
                }
            }
            class eF {
                constructor(e) {
                    e && this.set(e)
                }
                set(e, t, r) {
                    let n = this;

                    function i(e, t, r) {
                        let i = eE(t);
                        if (!i) throw Error("header name must be a non-empty string");
                        let o = X.findKey(n, i);
                        o && void 0 !== n[o] && !0 !== r && (void 0 !== r || !1 === n[o]) || (n[o || t] = ew(e))
                    }
                    let o = (e, t) => X.forEach(e, (e, r) => i(e, r, t));
                    if (X.isPlainObject(e) || e instanceof this.constructor) o(e, t);
                    else if (X.isString(e) && (e = e.trim()) && !eM(e)) o(eC(e), t);
                    else if (X.isObject(e) && X.isIterable(e)) {
                        let r = {},
                            n, i;
                        for (let t of e) {
                            if (!X.isArray(t)) throw TypeError("Object iterator must return a key-value pair");
                            r[i = t[0]] = (n = r[i]) ? X.isArray(n) ? [...n, t[1]] : [n, t[1]] : t[1]
                        }
                        o(r, t)
                    } else null != e && i(t, e, r);
                    return this
                }
                get(e, t) {
                    if (e = eE(e)) {
                        let r = X.findKey(this, e);
                        if (r) {
                            let e = this[r];
                            if (!t) return e;
                            if (!0 === t) {
                                let t, r = Object.create(null),
                                    n = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
                                for (; t = n.exec(e);) r[t[1]] = t[2];
                                return r
                            }
                            if (X.isFunction(t)) return t.call(this, e, r);
                            if (X.isRegExp(t)) return t.exec(e);
                            throw TypeError("parser must be boolean|regexp|function")
                        }
                    }
                }
                has(e, t) {
                    if (e = eE(e)) {
                        let r = X.findKey(this, e);
                        return !!(r && void 0 !== this[r] && (!t || eR(this, this[r], r, t)))
                    }
                    return !1
                }
                delete(e, t) {
                    let r = this,
                        n = !1;

                    function i(e) {
                        if (e = eE(e)) {
                            let i = X.findKey(r, e);
                            i && (!t || eR(r, r[i], i, t)) && (delete r[i], n = !0)
                        }
                    }
                    return X.isArray(e) ? e.forEach(i) : i(e), n
                }
                clear(e) {
                    let t = Object.keys(this),
                        r = t.length,
                        n = !1;
                    for (; r--;) {
                        let i = t[r];
                        (!e || eR(this, this[i], i, e, !0)) && (delete this[i], n = !0)
                    }
                    return n
                }
                normalize(e) {
                    let t = this,
                        r = {};
                    return X.forEach(this, (n, i) => {
                        let o = X.findKey(r, i);
                        if (o) {
                            t[o] = ew(n), delete t[i];
                            return
                        }
                        let s = e ? i.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (e, t, r) => t.toUpperCase() + r) : String(i).trim();
                        s !== i && delete t[i], t[s] = ew(n), r[s] = !0
                    }), this
                }
                concat(...e) {
                    return this.constructor.concat(this, ...e)
                }
                toJSON(e) {
                    let t = Object.create(null);
                    return X.forEach(this, (r, n) => {
                        null != r && !1 !== r && (t[n] = e && X.isArray(r) ? r.join(", ") : r)
                    }), t
                }[Symbol.iterator]() {
                    return Object.entries(this.toJSON())[Symbol.iterator]()
                }
                toString() {
                    return Object.entries(this.toJSON()).map(([e, t]) => e + ": " + t).join("\n")
                }
                getSetCookie() {
                    return this.get("set-cookie") || []
                }
                get[Symbol.toStringTag]() {
                    return "AxiosHeaders"
                }
                static from(e) {
                    return e instanceof this ? e : new this(e)
                }
                static concat(e, ...t) {
                    let r = new this(e);
                    return t.forEach(e => r.set(e)), r
                }
                static accessor(e) {
                    let t = (this[eb] = this[eb] = {
                            accessors: {}
                        }).accessors,
                        r = this.prototype;

                    function n(e) {
                        let n = eE(e);
                        if (!t[n]) {
                            let i = X.toCamelCase(" " + e);
                            ["get", "set", "has"].forEach(t => {
                                Object.defineProperty(r, t + i, {
                                    value: function(r, n, i) {
                                        return this[t].call(this, e, r, n, i)
                                    },
                                    configurable: !0
                                })
                            }), t[n] = !0
                        }
                    }
                    return X.isArray(e) ? e.forEach(n) : n(e), this
                }
            }

            function ex(e, t) {
                let r = this || ev,
                    n = t || r,
                    i = eF.from(n.headers),
                    o = n.data;
                return X.forEach(e, function(e) {
                    o = e.call(r, o, i.normalize(), t ? t.status : void 0)
                }), i.normalize(), o
            }

            function eI(e) {
                return !!(e && e.__CANCEL__)
            }

            function eT(e, t, r) {
                Y.call(this, null == e ? "canceled" : e, Y.ERR_CANCELED, t, r), this.name = "CanceledError"
            }

            function eS(e, t, r) {
                let n = r.config.validateStatus;
                !r.status || !n || n(r.status) ? e(r) : t(new Y("Request failed with status code " + r.status, [Y.ERR_BAD_REQUEST, Y.ERR_BAD_RESPONSE][Math.floor(r.status / 100) - 4], r.config, r.request, r))
            }
            eF.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]), X.reduceDescriptors(eF.prototype, ({
                value: e
            }, t) => {
                let r = t[0].toUpperCase() + t.slice(1);
                return {
                    get: () => e,
                    set(e) {
                        this[r] = e
                    }
                }
            }), X.freezeMethods(eF), X.inherits(eT, Y, {
                __CANCEL__: !0
            });
            let eD = function(e, t) {
                    let r, n = Array(e = e || 10),
                        i = Array(e),
                        o = 0,
                        s = 0;
                    return t = void 0 !== t ? t : 1e3,
                        function(a) {
                            let l = Date.now(),
                                u = i[s];
                            r || (r = l), n[o] = a, i[o] = l;
                            let c = s,
                                f = 0;
                            for (; c !== o;) f += n[c++], c %= e;
                            if ((o = (o + 1) % e) === s && (s = (s + 1) % e), l - r < t) return;
                            let d = u && l - u;
                            return d ? Math.round(1e3 * f / d) : void 0
                        }
                },
                eO = function(e, t) {
                    let r, n, i = 0,
                        o = 1e3 / t,
                        s = (t, o = Date.now()) => {
                            i = o, r = null, n && (clearTimeout(n), n = null), e.apply(null, t)
                        };
                    return [(...e) => {
                        let t = Date.now(),
                            a = t - i;
                        a >= o ? s(e, t) : (r = e, n || (n = setTimeout(() => {
                            n = null, s(r)
                        }, o - a)))
                    }, () => r && s(r)]
                },
                eG = (e, t, r = 3) => {
                    let n = 0,
                        i = eD(50, 250);
                    return eO(r => {
                        let o = r.loaded,
                            s = r.lengthComputable ? r.total : void 0,
                            a = o - n,
                            l = i(a);
                        n = o, e({
                            loaded: o,
                            total: s,
                            progress: s ? o / s : void 0,
                            bytes: a,
                            rate: l || void 0,
                            estimated: l && s && o <= s ? (s - o) / l : void 0,
                            event: r,
                            lengthComputable: null != s,
                            [t ? "download" : "upload"]: !0
                        })
                    }, r)
                },
                eP = (e, t) => {
                    let r = null != e;
                    return [n => t[0]({
                        lengthComputable: r,
                        total: e,
                        loaded: n
                    }), t[1]]
                },
                eH = e => (...t) => X.asap(() => e(...t)),
                eU = eg.hasStandardBrowserEnv ? ((e, t) => r => (r = new URL(r, eg.origin), e.protocol === r.protocol && e.host === r.host && (t || e.port === r.port)))(new URL(eg.origin), eg.navigator && /(msie|trident)/i.test(eg.navigator.userAgent)) : () => !0,
                e_ = eg.hasStandardBrowserEnv ? {
                    write(e, t, r, n, i, o) {
                        let s = [e + "=" + encodeURIComponent(t)];
                        X.isNumber(r) && s.push("expires=" + new Date(r).toGMTString()), X.isString(n) && s.push("path=" + n), X.isString(i) && s.push("domain=" + i), !0 === o && s.push("secure"), document.cookie = s.join("; ")
                    },
                    read(e) {
                        let t = document.cookie.match(RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
                        return t ? decodeURIComponent(t[3]) : null
                    },
                    remove(e) {
                        this.write(e, "", Date.now() - 864e5)
                    }
                } : {
                    write() {},
                    read: () => null,
                    remove() {}
                };

            function eL(e, t, r) {
                let n = !/^([a-z][a-z\d+\-.]*:)?\/\//i.test(t);
                return e && (n || !1 == r) ? t ? e.replace(/\/?\/$/, "") + "/" + t.replace(/^\/+/, "") : e : t
            }
            let eJ = e => e instanceof eF ? { ...e
            } : e;

            function ej(e, t) {
                t = t || {};
                let r = {};

                function n(e, t, r, n) {
                    return X.isPlainObject(e) && X.isPlainObject(t) ? X.merge.call({
                        caseless: n
                    }, e, t) : X.isPlainObject(t) ? X.merge({}, t) : X.isArray(t) ? t.slice() : t
                }

                function i(e, t, r, i) {
                    return X.isUndefined(t) ? X.isUndefined(e) ? void 0 : n(void 0, e, r, i) : n(e, t, r, i)
                }

                function o(e, t) {
                    if (!X.isUndefined(t)) return n(void 0, t)
                }

                function s(e, t) {
                    return X.isUndefined(t) ? X.isUndefined(e) ? void 0 : n(void 0, e) : n(void 0, t)
                }

                function a(r, i, o) {
                    return o in t ? n(r, i) : o in e ? n(void 0, r) : void 0
                }
                let l = {
                    url: o,
                    method: o,
                    data: o,
                    baseURL: s,
                    transformRequest: s,
                    transformResponse: s,
                    paramsSerializer: s,
                    timeout: s,
                    timeoutMessage: s,
                    withCredentials: s,
                    withXSRFToken: s,
                    adapter: s,
                    responseType: s,
                    xsrfCookieName: s,
                    xsrfHeaderName: s,
                    onUploadProgress: s,
                    onDownloadProgress: s,
                    decompress: s,
                    maxContentLength: s,
                    maxBodyLength: s,
                    beforeRedirect: s,
                    transport: s,
                    httpAgent: s,
                    httpsAgent: s,
                    cancelToken: s,
                    socketPath: s,
                    responseEncoding: s,
                    validateStatus: a,
                    headers: (e, t, r) => i(eJ(e), eJ(t), r, !0)
                };
                return X.forEach(Object.keys(Object.assign({}, e, t)), function(n) {
                    let o = l[n] || i,
                        s = o(e[n], t[n], n);
                    X.isUndefined(s) && o !== a || (r[n] = s)
                }), r
            }
            let ek = e => {
                    let t, r = ej({}, e),
                        {
                            data: n,
                            withXSRFToken: i,
                            xsrfHeaderName: o,
                            xsrfCookieName: s,
                            headers: a,
                            auth: l
                        } = r;
                    if (r.headers = a = eF.from(a), r.url = es(eL(r.baseURL, r.url, r.allowAbsoluteUrls), e.params, e.paramsSerializer), l && a.set("Authorization", "Basic " + btoa((l.username || "") + ":" + (l.password ? unescape(encodeURIComponent(l.password)) : ""))), X.isFormData(n)) {
                        if (eg.hasStandardBrowserEnv || eg.hasStandardBrowserWebWorkerEnv) a.setContentType(void 0);
                        else if (!1 !== (t = a.getContentType())) {
                            let [e, ...r] = t ? t.split(";").map(e => e.trim()).filter(Boolean) : [];
                            a.setContentType([e || "multipart/form-data", ...r].join("; "))
                        }
                    }
                    if (eg.hasStandardBrowserEnv && (i && X.isFunction(i) && (i = i(r)), i || !1 !== i && eU(r.url))) {
                        let e = o && s && e_.read(s);
                        e && a.set(o, e)
                    }
                    return r
                },
                eN = "undefined" != typeof XMLHttpRequest && function(e) {
                    return new Promise(function(t, r) {
                        let n, i, o, s, a, l = ek(e),
                            u = l.data,
                            c = eF.from(l.headers).normalize(),
                            {
                                responseType: f,
                                onUploadProgress: d,
                                onDownloadProgress: h
                            } = l;

                        function p() {
                            s && s(), a && a(), l.cancelToken && l.cancelToken.unsubscribe(n), l.signal && l.signal.removeEventListener("abort", n)
                        }
                        let A = new XMLHttpRequest;

                        function m() {
                            if (!A) return;
                            let n = eF.from("getAllResponseHeaders" in A && A.getAllResponseHeaders());
                            eS(function(e) {
                                t(e), p()
                            }, function(e) {
                                r(e), p()
                            }, {
                                data: f && "text" !== f && "json" !== f ? A.response : A.responseText,
                                status: A.status,
                                statusText: A.statusText,
                                headers: n,
                                config: e,
                                request: A
                            }), A = null
                        }
                        A.open(l.method.toUpperCase(), l.url, !0), A.timeout = l.timeout, "onloadend" in A ? A.onloadend = m : A.onreadystatechange = function() {
                            A && 4 === A.readyState && (0 !== A.status || A.responseURL && 0 === A.responseURL.indexOf("file:")) && setTimeout(m)
                        }, A.onabort = function() {
                            A && (r(new Y("Request aborted", Y.ECONNABORTED, e, A)), A = null)
                        }, A.onerror = function() {
                            r(new Y("Network Error", Y.ERR_NETWORK, e, A)), A = null
                        }, A.ontimeout = function() {
                            let t = l.timeout ? "timeout of " + l.timeout + "ms exceeded" : "timeout exceeded",
                                n = l.transitional || el;
                            l.timeoutErrorMessage && (t = l.timeoutErrorMessage), r(new Y(t, n.clarifyTimeoutError ? Y.ETIMEDOUT : Y.ECONNABORTED, e, A)), A = null
                        }, void 0 === u && c.setContentType(null), "setRequestHeader" in A && X.forEach(c.toJSON(), function(e, t) {
                            A.setRequestHeader(t, e)
                        }), X.isUndefined(l.withCredentials) || (A.withCredentials = !!l.withCredentials), f && "json" !== f && (A.responseType = l.responseType), h && ([o, a] = eG(h, !0), A.addEventListener("progress", o)), d && A.upload && ([i, s] = eG(d), A.upload.addEventListener("progress", i), A.upload.addEventListener("loadend", s)), (l.cancelToken || l.signal) && (n = t => {
                            A && (r(!t || t.type ? new eT(null, e, A) : t), A.abort(), A = null)
                        }, l.cancelToken && l.cancelToken.subscribe(n), l.signal && (l.signal.aborted ? n() : l.signal.addEventListener("abort", n)));
                        let g = function(e) {
                            let t = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e);
                            return t && t[1] || ""
                        }(l.url);
                        if (g && -1 === eg.protocols.indexOf(g)) return void r(new Y("Unsupported protocol " + g + ":", Y.ERR_BAD_REQUEST, e));
                        A.send(u || null)
                    })
                },
                eK = (e, t) => {
                    let {
                        length: r
                    } = e = e ? e.filter(Boolean) : [];
                    if (t || r) {
                        let r, n = new AbortController,
                            i = function(e) {
                                if (!r) {
                                    r = !0, s();
                                    let t = e instanceof Error ? e : this.reason;
                                    n.abort(t instanceof Y ? t : new eT(t instanceof Error ? t.message : t))
                                }
                            },
                            o = t && setTimeout(() => {
                                o = null, i(new Y(`timeout ${t} of ms exceeded`, Y.ETIMEDOUT))
                            }, t),
                            s = () => {
                                e && (o && clearTimeout(o), o = null, e.forEach(e => {
                                    e.unsubscribe ? e.unsubscribe(i) : e.removeEventListener("abort", i)
                                }), e = null)
                            };
                        e.forEach(e => e.addEventListener("abort", i));
                        let {
                            signal: a
                        } = n;
                        return a.unsubscribe = () => X.asap(s), a
                    }
                },
                eQ = function*(e, t) {
                    let r, n = e.byteLength;
                    if (!t || n < t) return void(yield e);
                    let i = 0;
                    for (; i < n;) r = i + t, yield e.slice(i, r), i = r
                },
                eX = async function*(e, t) {
                    for await (let r of eY(e)) yield* eQ(r, t)
                },
                eY = async function*(e) {
                    if (e[Symbol.asyncIterator]) return void(yield* e);
                    let t = e.getReader();
                    try {
                        for (;;) {
                            let {
                                done: e,
                                value: r
                            } = await t.read();
                            if (e) break;
                            yield r
                        }
                    } finally {
                        await t.cancel()
                    }
                },
                eW = (e, t, r, n) => {
                    let i, o = eX(e, t),
                        s = 0,
                        a = e => {
                            !i && (i = !0, n && n(e))
                        };
                    return new ReadableStream({
                        async pull(e) {
                            try {
                                let {
                                    done: t,
                                    value: n
                                } = await o.next();
                                if (t) {
                                    a(), e.close();
                                    return
                                }
                                let i = n.byteLength;
                                if (r) {
                                    let e = s += i;
                                    r(e)
                                }
                                e.enqueue(new Uint8Array(n))
                            } catch (e) {
                                throw a(e), e
                            }
                        },
                        cancel: e => (a(e), o.return())
                    }, {
                        highWaterMark: 2
                    })
                },
                ez = "function" == typeof fetch && "function" == typeof Request && "function" == typeof Response,
                eq = ez && "function" == typeof ReadableStream,
                eZ = ez && ("function" == typeof TextEncoder ? (n = new TextEncoder, e => n.encode(e)) : async e => new Uint8Array(await new Response(e).arrayBuffer())),
                eV = (e, ...t) => {
                    try {
                        return !!e(...t)
                    } catch (e) {
                        return !1
                    }
                },
                e$ = eq && eV(() => {
                    let e = !1,
                        t = new Request(eg.origin, {
                            body: new ReadableStream,
                            method: "POST",
                            get duplex() {
                                return e = !0, "half"
                            }
                        }).headers.has("Content-Type");
                    return e && !t
                }),
                e0 = eq && eV(() => X.isReadableStream(new Response("").body)),
                e1 = {
                    stream: e0 && (e => e.body)
                };
            ez && (s = new Response, ["text", "arrayBuffer", "blob", "formData", "stream"].forEach(e => {
                e1[e] || (e1[e] = X.isFunction(s[e]) ? t => t[e]() : (t, r) => {
                    throw new Y(`Response type '${e}' is not supported`, Y.ERR_NOT_SUPPORT, r)
                })
            }));
            let e2 = async e => {
                    if (null == e) return 0;
                    if (X.isBlob(e)) return e.size;
                    if (X.isSpecCompliantForm(e)) {
                        let t = new Request(eg.origin, {
                            method: "POST",
                            body: e
                        });
                        return (await t.arrayBuffer()).byteLength
                    }
                    return X.isArrayBufferView(e) || X.isArrayBuffer(e) ? e.byteLength : (X.isURLSearchParams(e) && (e += ""), X.isString(e)) ? (await eZ(e)).byteLength : void 0
                },
                e9 = async (e, t) => {
                    let r = X.toFiniteNumber(e.getContentLength());
                    return null == r ? e2(t) : r
                },
                e8 = {
                    http: null,
                    xhr: eN,
                    fetch: ez && (async e => {
                        let t, r, {
                            url: n,
                            method: i,
                            data: o,
                            signal: s,
                            cancelToken: a,
                            timeout: l,
                            onDownloadProgress: u,
                            onUploadProgress: c,
                            responseType: f,
                            headers: d,
                            withCredentials: h = "same-origin",
                            fetchOptions: p
                        } = ek(e);
                        f = f ? (f + "").toLowerCase() : "text";
                        let A = eK([s, a && a.toAbortSignal()], l),
                            m = A && A.unsubscribe && (() => {
                                A.unsubscribe()
                            });
                        try {
                            if (c && e$ && "get" !== i && "head" !== i && 0 !== (r = await e9(d, o))) {
                                let e, t = new Request(n, {
                                    method: "POST",
                                    body: o,
                                    duplex: "half"
                                });
                                if (X.isFormData(o) && (e = t.headers.get("content-type")) && d.setContentType(e), t.body) {
                                    let [e, n] = eP(r, eG(eH(c)));
                                    o = eW(t.body, 65536, e, n)
                                }
                            }
                            X.isString(h) || (h = h ? "include" : "omit");
                            let s = "credentials" in Request.prototype;
                            t = new Request(n, { ...p,
                                signal: A,
                                method: i.toUpperCase(),
                                headers: d.normalize().toJSON(),
                                body: o,
                                duplex: "half",
                                credentials: s ? h : void 0
                            });
                            let a = await fetch(t),
                                l = e0 && ("stream" === f || "response" === f);
                            if (e0 && (u || l && m)) {
                                let e = {};
                                ["status", "statusText", "headers"].forEach(t => {
                                    e[t] = a[t]
                                });
                                let t = X.toFiniteNumber(a.headers.get("content-length")),
                                    [r, n] = u && eP(t, eG(eH(u), !0)) || [];
                                a = new Response(eW(a.body, 65536, r, () => {
                                    n && n(), m && m()
                                }), e)
                            }
                            f = f || "text";
                            let g = await e1[X.findKey(e1, f) || "text"](a, e);
                            return !l && m && m(), await new Promise((r, n) => {
                                eS(r, n, {
                                    data: g,
                                    headers: eF.from(a.headers),
                                    status: a.status,
                                    statusText: a.statusText,
                                    config: e,
                                    request: t
                                })
                            })
                        } catch (r) {
                            if (m && m(), r && "TypeError" === r.name && /Load failed|fetch/i.test(r.message)) throw Object.assign(new Y("Network Error", Y.ERR_NETWORK, e, t), {
                                cause: r.cause || r
                            });
                            throw Y.from(r, r && r.code, e, t)
                        }
                    })
                };
            X.forEach(e8, (e, t) => {
                if (e) {
                    try {
                        Object.defineProperty(e, "name", {
                            value: t
                        })
                    } catch (e) {}
                    Object.defineProperty(e, "adapterName", {
                        value: t
                    })
                }
            });
            let e3 = e => `- ${e}`,
                e6 = e => X.isFunction(e) || null === e || !1 === e,
                e5 = {
                    getAdapter: e => {
                        let t, r, {
                                length: n
                            } = e = X.isArray(e) ? e : [e],
                            i = {};
                        for (let o = 0; o < n; o++) {
                            let n;
                            if (r = t = e[o], !e6(t) && void 0 === (r = e8[(n = String(t)).toLowerCase()])) throw new Y(`Unknown adapter '${n}'`);
                            if (r) break;
                            i[n || "#" + o] = r
                        }
                        if (!r) {
                            let e = Object.entries(i).map(([e, t]) => `adapter ${e} ` + (!1 === t ? "is not supported by the environment" : "is not available in the build"));
                            throw new Y("There is no suitable adapter to dispatch the request " + (n ? e.length > 1 ? "since :\n" + e.map(e3).join("\n") : " " + e3(e[0]) : "as no adapter specified"), "ERR_NOT_SUPPORT")
                        }
                        return r
                    }
                };

            function e4(e) {
                if (e.cancelToken && e.cancelToken.throwIfRequested(), e.signal && e.signal.aborted) throw new eT(null, e)
            }

            function e7(e) {
                return e4(e), e.headers = eF.from(e.headers), e.data = ex.call(e, e.transformRequest), -1 !== ["post", "put", "patch"].indexOf(e.method) && e.headers.setContentType("application/x-www-form-urlencoded", !1), e5.getAdapter(e.adapter || ev.adapter)(e).then(function(t) {
                    return e4(e), t.data = ex.call(e, e.transformResponse, t), t.headers = eF.from(t.headers), t
                }, function(t) {
                    return !eI(t) && (e4(e), t && t.response && (t.response.data = ex.call(e, e.transformResponse, t.response), t.response.headers = eF.from(t.response.headers))), Promise.reject(t)
                })
            }
            let te = "1.9.0",
                tt = {};
            ["object", "boolean", "number", "function", "string", "symbol"].forEach((e, t) => {
                tt[e] = function(r) {
                    return typeof r === e || "a" + (t < 1 ? "n " : " ") + e
                }
            });
            let tr = {};
            tt.transitional = function(e, t, r) {
                function n(e, t) {
                    return "[Axios v" + te + "] Transitional option '" + e + "'" + t + (r ? ". " + r : "")
                }
                return (r, i, o) => {
                    if (!1 === e) throw new Y(n(i, " has been removed" + (t ? " in " + t : "")), Y.ERR_DEPRECATED);
                    return t && !tr[i] && (tr[i] = !0, console.warn(n(i, " has been deprecated since v" + t + " and will be removed in the near future"))), !e || e(r, i, o)
                }
            }, tt.spelling = function(e) {
                return (t, r) => (console.warn(`${r} is likely a misspelling of ${e}`), !0)
            };
            let tn = {
                    assertOptions: function(e, t, r) {
                        if ("object" != typeof e) throw new Y("options must be an object", Y.ERR_BAD_OPTION_VALUE);
                        let n = Object.keys(e),
                            i = n.length;
                        for (; i-- > 0;) {
                            let o = n[i],
                                s = t[o];
                            if (s) {
                                let t = e[o],
                                    r = void 0 === t || s(t, o, e);
                                if (!0 !== r) throw new Y("option " + o + " must be " + r, Y.ERR_BAD_OPTION_VALUE);
                                continue
                            }
                            if (!0 !== r) throw new Y("Unknown option " + o, Y.ERR_BAD_OPTION)
                        }
                    },
                    validators: tt
                },
                ti = tn.validators;
            class to {
                constructor(e) {
                    this.defaults = e || {}, this.interceptors = {
                        request: new ea,
                        response: new ea
                    }
                }
                async request(e, t) {
                    try {
                        return await this._request(e, t)
                    } catch (e) {
                        if (e instanceof Error) {
                            let t = {};
                            Error.captureStackTrace ? Error.captureStackTrace(t) : t = Error();
                            let r = t.stack ? t.stack.replace(/^.+\n/, "") : "";
                            try {
                                e.stack ? r && !String(e.stack).endsWith(r.replace(/^.+\n.+\n/, "")) && (e.stack += "\n" + r) : e.stack = r
                            } catch (e) {}
                        }
                        throw e
                    }
                }
                _request(e, t) {
                    let r, n;
                    "string" == typeof e ? (t = t || {}).url = e : t = e || {};
                    let {
                        transitional: i,
                        paramsSerializer: o,
                        headers: s
                    } = t = ej(this.defaults, t);
                    void 0 !== i && tn.assertOptions(i, {
                        silentJSONParsing: ti.transitional(ti.boolean),
                        forcedJSONParsing: ti.transitional(ti.boolean),
                        clarifyTimeoutError: ti.transitional(ti.boolean)
                    }, !1), null != o && (X.isFunction(o) ? t.paramsSerializer = {
                        serialize: o
                    } : tn.assertOptions(o, {
                        encode: ti.function,
                        serialize: ti.function
                    }, !0)), void 0 !== t.allowAbsoluteUrls || (void 0 !== this.defaults.allowAbsoluteUrls ? t.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls : t.allowAbsoluteUrls = !0), tn.assertOptions(t, {
                        baseUrl: ti.spelling("baseURL"),
                        withXsrfToken: ti.spelling("withXSRFToken")
                    }, !0), t.method = (t.method || this.defaults.method || "get").toLowerCase();
                    let a = s && X.merge(s.common, s[t.method]);
                    s && X.forEach(["delete", "get", "head", "post", "put", "patch", "common"], e => {
                        delete s[e]
                    }), t.headers = eF.concat(a, s);
                    let l = [],
                        u = !0;
                    this.interceptors.request.forEach(function(e) {
                        ("function" != typeof e.runWhen || !1 !== e.runWhen(t)) && (u = u && e.synchronous, l.unshift(e.fulfilled, e.rejected))
                    });
                    let c = [];
                    this.interceptors.response.forEach(function(e) {
                        c.push(e.fulfilled, e.rejected)
                    });
                    let f = 0;
                    if (!u) {
                        let e = [e7.bind(this), void 0];
                        for (e.unshift.apply(e, l), e.push.apply(e, c), n = e.length, r = Promise.resolve(t); f < n;) r = r.then(e[f++], e[f++]);
                        return r
                    }
                    n = l.length;
                    let d = t;
                    for (f = 0; f < n;) {
                        let e = l[f++],
                            t = l[f++];
                        try {
                            d = e(d)
                        } catch (e) {
                            t.call(this, e);
                            break
                        }
                    }
                    try {
                        r = e7.call(this, d)
                    } catch (e) {
                        return Promise.reject(e)
                    }
                    for (f = 0, n = c.length; f < n;) r = r.then(c[f++], c[f++]);
                    return r
                }
                getUri(e) {
                    return es(eL((e = ej(this.defaults, e)).baseURL, e.url, e.allowAbsoluteUrls), e.params, e.paramsSerializer)
                }
            }
            X.forEach(["delete", "get", "head", "options"], function(e) {
                to.prototype[e] = function(t, r) {
                    return this.request(ej(r || {}, {
                        method: e,
                        url: t,
                        data: (r || {}).data
                    }))
                }
            }), X.forEach(["post", "put", "patch"], function(e) {
                function t(t) {
                    return function(r, n, i) {
                        return this.request(ej(i || {}, {
                            method: e,
                            headers: t ? {
                                "Content-Type": "multipart/form-data"
                            } : {},
                            url: r,
                            data: n
                        }))
                    }
                }
                to.prototype[e] = t(), to.prototype[e + "Form"] = t(!0)
            });
            class ts {
                constructor(e) {
                    let t;
                    if ("function" != typeof e) throw TypeError("executor must be a function.");
                    this.promise = new Promise(function(e) {
                        t = e
                    });
                    let r = this;
                    this.promise.then(e => {
                        if (!r._listeners) return;
                        let t = r._listeners.length;
                        for (; t-- > 0;) r._listeners[t](e);
                        r._listeners = null
                    }), this.promise.then = e => {
                        let t, n = new Promise(e => {
                            r.subscribe(e), t = e
                        }).then(e);
                        return n.cancel = function() {
                            r.unsubscribe(t)
                        }, n
                    }, e(function(e, n, i) {
                        r.reason || (r.reason = new eT(e, n, i), t(r.reason))
                    })
                }
                throwIfRequested() {
                    if (this.reason) throw this.reason
                }
                subscribe(e) {
                    if (this.reason) return void e(this.reason);
                    this._listeners ? this._listeners.push(e) : this._listeners = [e]
                }
                unsubscribe(e) {
                    if (!this._listeners) return;
                    let t = this._listeners.indexOf(e); - 1 !== t && this._listeners.splice(t, 1)
                }
                toAbortSignal() {
                    let e = new AbortController,
                        t = t => {
                            e.abort(t)
                        };
                    return this.subscribe(t), e.signal.unsubscribe = () => this.unsubscribe(t), e.signal
                }
                static source() {
                    let e;
                    return {
                        token: new ts(function(t) {
                            e = t
                        }),
                        cancel: e
                    }
                }
            }
            let ta = {
                Continue: 100,
                SwitchingProtocols: 101,
                Processing: 102,
                EarlyHints: 103,
                Ok: 200,
                Created: 201,
                Accepted: 202,
                NonAuthoritativeInformation: 203,
                NoContent: 204,
                ResetContent: 205,
                PartialContent: 206,
                MultiStatus: 207,
                AlreadyReported: 208,
                ImUsed: 226,
                MultipleChoices: 300,
                MovedPermanently: 301,
                Found: 302,
                SeeOther: 303,
                NotModified: 304,
                UseProxy: 305,
                Unused: 306,
                TemporaryRedirect: 307,
                PermanentRedirect: 308,
                BadRequest: 400,
                Unauthorized: 401,
                PaymentRequired: 402,
                Forbidden: 403,
                NotFound: 404,
                MethodNotAllowed: 405,
                NotAcceptable: 406,
                ProxyAuthenticationRequired: 407,
                RequestTimeout: 408,
                Conflict: 409,
                Gone: 410,
                LengthRequired: 411,
                PreconditionFailed: 412,
                PayloadTooLarge: 413,
                UriTooLong: 414,
                UnsupportedMediaType: 415,
                RangeNotSatisfiable: 416,
                ExpectationFailed: 417,
                ImATeapot: 418,
                MisdirectedRequest: 421,
                UnprocessableEntity: 422,
                Locked: 423,
                FailedDependency: 424,
                TooEarly: 425,
                UpgradeRequired: 426,
                PreconditionRequired: 428,
                TooManyRequests: 429,
                RequestHeaderFieldsTooLarge: 431,
                UnavailableForLegalReasons: 451,
                InternalServerError: 500,
                NotImplemented: 501,
                BadGateway: 502,
                ServiceUnavailable: 503,
                GatewayTimeout: 504,
                HttpVersionNotSupported: 505,
                VariantAlsoNegotiates: 506,
                InsufficientStorage: 507,
                LoopDetected: 508,
                NotExtended: 510,
                NetworkAuthenticationRequired: 511
            };
            Object.entries(ta).forEach(([e, t]) => {
                ta[t] = e
            });
            let tl = function e(t) {
                let r = new to(t),
                    n = l(to.prototype.request, r);
                return X.extend(n, to.prototype, r, {
                    allOwnKeys: !0
                }), X.extend(n, r, null, {
                    allOwnKeys: !0
                }), n.create = function(r) {
                    return e(ej(t, r))
                }, n
            }(ev);
            tl.Axios = to, tl.CanceledError = eT, tl.CancelToken = ts, tl.isCancel = eI, tl.VERSION = te, tl.toFormData = et, tl.AxiosError = Y, tl.Cancel = tl.CanceledError, tl.all = function(e) {
                return Promise.all(e)
            }, tl.spread = function(e) {
                return function(t) {
                    return e.apply(null, t)
                }
            }, tl.isAxiosError = function(e) {
                return X.isObject(e) && !0 === e.isAxiosError
            }, tl.mergeConfig = ej, tl.AxiosHeaders = eF, tl.formToJSON = e => eB(X.isHTMLForm(e) ? new FormData(e) : e), tl.getAdapter = e5.getAdapter, tl.HttpStatusCode = ta, tl.default = tl;
            let tu = tl
        },
        9585: (e, t, r) => {
            "use strict";

            function n() {
                return (n = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r)({}).hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }).apply(null, arguments)
            }
            r.d(t, {
                A: () => n
            })
        },
        9663: (e, t, r) => {
            "use strict";
            var n = r(6797),
                i = r(8333),
                o = "function" == typeof Object.is ? Object.is : function(e, t) {
                    return e === t && (0 !== e || 1 / e == 1 / t) || e != e && t != t
                },
                s = i.useSyncExternalStore,
                a = n.useRef,
                l = n.useEffect,
                u = n.useMemo,
                c = n.useDebugValue;
            t.useSyncExternalStoreWithSelector = function(e, t, r, n, i) {
                var f = a(null);
                if (null === f.current) {
                    var d = {
                        hasValue: !1,
                        value: null
                    };
                    f.current = d
                } else d = f.current;
                var h = s(e, (f = u(function() {
                    function e(e) {
                        if (!l) {
                            if (l = !0, s = e, e = n(e), void 0 !== i && d.hasValue) {
                                var t = d.value;
                                if (i(t, e)) return a = t
                            }
                            return a = e
                        }
                        if (t = a, o(s, e)) return t;
                        var r = n(e);
                        return void 0 !== i && i(t, r) ? (s = e, t) : (s = e, a = r)
                    }
                    var s, a, l = !1,
                        u = void 0 === r ? null : r;
                    return [function() {
                        return e(t())
                    }, null === u ? void 0 : function() {
                        return e(u())
                    }]
                }, [t, r, n, i]))[0], f[1]);
                return l(function() {
                    d.hasValue = !0, d.value = h
                }, [h]), c(h), h
            }
        }
    }
]);