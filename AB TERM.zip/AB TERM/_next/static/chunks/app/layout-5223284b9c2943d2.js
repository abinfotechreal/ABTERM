(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [177], {
        322: () => {},
        2078: e => {
            e.exports = {
                style: {
                    fontFamily: "'Geist', 'Geist Fallback'",
                    fontStyle: "normal"
                },
                className: "__className_5cfdac",
                variable: "__variable_5cfdac"
            }
        },
        3435: (e, t, n) => {
            Promise.resolve().then(n.bind(n, 6693)), Promise.resolve().then(n.t.bind(n, 2078, 23)), Promise.resolve().then(n.t.bind(n, 8906, 23)), Promise.resolve().then(n.t.bind(n, 322, 23))
        },
        6693: (e, t, n) => {
            "use strict";
            n.d(t, {
                PostHogProvider: () => m
            });
            var o = n(5881),
                r = n(2116),
                i = n(6797),
                a = (0, i.createContext)({
                    client: r.Ay
                });

            function s(e) {
                var t = e.children,
                    n = e.client,
                    o = e.apiKey,
                    s = e.options,
                    l = (0, i.useRef)(null),
                    c = (0, i.useMemo)(function() {
                        return n ? (o && console.warn("[PostHog.js] You have provided both `client` and `apiKey` to `PostHogProvider`. `apiKey` will be ignored in favour of `client`."), s && console.warn("[PostHog.js] You have provided both `client` and `options` to `PostHogProvider`. `options` will be ignored in favour of `client`."), n) : (o || console.warn("[PostHog.js] No `apiKey` or `client` were provided to `PostHogProvider`. Using default global `window.posthog` instance. You must initialize it manually. This is not recommended behavior."), r.Ay)
                    }, [n, o, JSON.stringify(s)]);
                return (0, i.useEffect)(function() {
                    if (!n) {
                        var e = l.current;
                        e ? (o !== e.apiKey && console.warn("[PostHog.js] You have provided a different `apiKey` to `PostHogProvider` than the one that was already initialized. This is not supported by our provider and we'll keep using the previous key. If you need to toggle between API Keys you need to control the `client` yourself and pass it in as a prop rather than an `apiKey` prop."), s && ! function e(t, n, o) {
                            if (void 0 === o && (o = new WeakMap), t === n) return !0;
                            if ("object" != typeof t || null === t || "object" != typeof n || null === n) return !1;
                            if (o.has(t) && o.get(t) === n) return !0;
                            o.set(t, n);
                            var r = Object.keys(t),
                                i = Object.keys(n);
                            if (r.length !== i.length) return !1;
                            for (var a = 0; a < r.length; a++) {
                                var s = r[a];
                                if (!i.includes(s) || !e(t[s], n[s], o)) return !1
                            }
                            return !0
                        }(s, e.options) && r.Ay.set_config(s)) : (r.Ay.__loaded && console.warn("[PostHog.js] `posthog` was already loaded elsewhere. This may cause issues."), r.Ay.init(o, s)), l.current = {
                            apiKey: o,
                            options: null != s ? s : {}
                        }
                    }
                }, [n, o, JSON.stringify(s)]), i.createElement(a.Provider, {
                    value: {
                        client: c
                    }
                }, t)
            }
            var l = function() {
                    return (0, i.useContext)(a).client
                },
                c = function(e, t) {
                    return (c = Object.setPrototypeOf || ({
                        __proto__: []
                    }) instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    })(e, t)
                },
                u = function() {
                    return (u = Object.assign || function(e) {
                        for (var t, n = 1, o = arguments.length; n < o; n++)
                            for (var r in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                        return e
                    }).apply(this, arguments)
                };

            function p(e, t) {
                var n = {};
                for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && 0 > t.indexOf(o) && (n[o] = e[o]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var r = 0, o = Object.getOwnPropertySymbols(e); r < o.length; r++) 0 > t.indexOf(o[r]) && Object.prototype.propertyIsEnumerable.call(e, o[r]) && (n[o[r]] = e[o[r]]);
                return n
            }
            var f = function(e) {
                return "function" == typeof e
            };

            function d(e) {
                var t = e.flag,
                    n = e.children,
                    o = e.onIntersect,
                    r = e.onClick,
                    i = e.trackView,
                    a = e.options,
                    s = p(e, ["flag", "children", "onIntersect", "onClick", "trackView", "options"]),
                    c = useRef(null);
                return useEffect(function() {
                    if (null !== c.current && i) {
                        var e = new IntersectionObserver(function(e) {
                            return o(e[0])
                        }, u({
                            threshold: .1
                        }, a));
                        return e.observe(c.current),
                            function() {
                                return e.disconnect()
                            }
                    }
                }, [t, a, l(), c, i, o]), React.createElement("div", u({
                    ref: c
                }, s, {
                    onClick: r
                }), n)
            }
            var y = {
                    componentStack: null,
                    error: null
                },
                h = {
                    INVALID_FALLBACK: "[PostHog.js][PostHogErrorBoundary] Invalid fallback prop, provide a valid React element or a function that returns a valid React element."
                };
            ! function(e) {
                if ("function" != typeof e && null !== e) throw TypeError("Class extends value " + String(e) + " is not a constructor or null");

                function t() {
                    this.constructor = n
                }

                function n(t) {
                    var n = e.call(this, t) || this;
                    return n.state = y, n
                }
                c(n, e), n.prototype = null === e ? Object.create(e) : (t.prototype = e.prototype, new t), n.prototype.componentDidCatch = function(e, t) {
                    var n, o = t.componentStack,
                        r = this.props.additionalProperties;
                    this.setState({
                        error: e,
                        componentStack: o
                    }), f(r) ? n = r(e) : "object" == typeof r && (n = r), this.context.client.captureException(e, n)
                }, n.prototype.render = function() {
                    var e = this.props,
                        t = e.children,
                        n = e.fallback,
                        o = this.state;
                    if (null == o.componentStack) return f(t) ? t() : t;
                    var r = f(n) ? i.createElement(n, {
                        error: o.error,
                        componentStack: o.componentStack
                    }) : n;
                    return i.isValidElement(r) ? r : (console.warn(h.INVALID_FALLBACK), i.createElement(i.Fragment, null))
                }, n.contextType = a
            }(i.Component);
            var v = n(1139);

            function b() {
                let e = (0, v.usePathname)(),
                    t = (0, v.useSearchParams)(),
                    n = l();
                return (0, i.useEffect)(() => {
                    if (e && n) {
                        let o = window.origin + e;
                        t.toString() && (o += "?".concat(t.toString())), n.capture("$pageview", {
                            $current_url: o
                        })
                    }
                }, [e, t, n]), null
            }

            function g() {
                return (0, o.jsx)(i.Suspense, {
                    fallback: null,
                    children: (0, o.jsx)(b, {})
                })
            }

            function m(e) {
                let {
                    children: t
                } = e;
                return (0, i.useEffect)(() => {
                    r.Ay.init("phc_T1R7arj8g3DWx4IbvNTtJkUinnreuUxzCUoLEbP9Rh6", {
                        api_host: "https://us.i.posthog.com",
                        capture_pageview: !1
                    })
                }, []), (0, o.jsxs)(s, {
                    client: r.Ay,
                    children: [(0, o.jsx)(g, {}), t]
                })
            }
        },
        8906: e => {
            e.exports = {
                style: {
                    fontFamily: "'Geist Mono', 'Geist Mono Fallback'",
                    fontStyle: "normal"
                },
                className: "__className_9a8899",
                variable: "__variable_9a8899"
            }
        }
    },
    e => {
        var t = t => e(e.s = t);
        e.O(0, [911, 206, 364, 770, 358], () => t(3435)), _N_E = e.O()
    }
]);