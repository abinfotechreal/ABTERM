(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [974], {
        513: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                default: () => v
            });
            var r = n(5881),
                a = n(6797),
                s = n(8789),
                o = n(3483),
                i = n(3625),
                l = n(293),
                c = n(3299),
                d = n(5995),
                u = n(3342),
                m = n(655),
                p = n(4312);
            (0, s.e)({
                MeshLineGeometry: m.mx,
                MeshLineMaterial: m.Xu
            });
            let h = {
                type: "dynamic",
                canSleep: !0,
                colliders: !1,
                angularDamping: 2,
                linearDamping: 2
            };

            function g(e) {
                let {
                    maxSpeed: t = 50,
                    minSpeed: n = 10
                } = e, o = (0, a.useRef)(null), c = (0, a.useRef)(null), d = (0, a.useRef)(null), m = (0, a.useRef)(null), g = (0, a.useRef)(null), f = (0, a.useRef)(null), x = new p.Pq0, b = new p.Pq0, y = new p.Pq0, w = new p.Pq0, [v, k] = (0, a.useState)(!1), [j, A] = (0, a.useState)(!1), {
                    nodes: S,
                    materials: I
                } = (0, i.p)("/assets/newgaterecard.glb"), L = (0, l.zo)("/assets/gatereband.png"), [C] = (0, a.useState)(() => new p.B6O([new p.Pq0, new p.Pq0, new p.Pq0, new p.Pq0]));
                return (0, u.Y7)(c, d, [
                    [0, 0, 0],
                    [0, 0, 0], 1
                ]), (0, u.Y7)(d, m, [
                    [0, 0, 0],
                    [0, 0, 0], 1
                ]), (0, u.Y7)(m, g, [
                    [0, 0, 0],
                    [0, 0, 0], 1
                ]), (0, u.hE)(g, f, [
                    [0, 0, 0],
                    [0, 1.45, 0]
                ]), (0, a.useEffect)(() => (j && (document.body.style.cursor = v ? "grabbing" : "grab"), () => void(document.body.style.cursor = "auto")), [j, v]), (0, s.C)((e, r) => {
                    if (c.current && d.current && m.current && g.current && o.current && f.current) {
                        if (v) {
                            var a;
                            x.set(e.pointer.x, e.pointer.y, .5).unproject(e.camera), w.copy(x).sub(e.camera.position).normalize(), x.add(w.multiplyScalar(e.camera.position.length())), [f, d, m, g, c].forEach(e => {
                                var t;
                                return null == (t = e.current) ? void 0 : t.wakeUp()
                            }), null == (a = f.current) || a.setNextKinematicTranslation({
                                x: x.x - v.x,
                                y: x.y - v.y,
                                z: x.z - v.z
                            })
                        }
                        if (c.current) {
                            let [e, a] = [d, m].map(e => {
                                if (e.current) {
                                    let a = new p.Pq0().copy(e.current.translation()),
                                        s = Math.max(.1, Math.min(1, a.distanceTo(e.current.translation())));
                                    return a.lerp(e.current.translation(), r * (n + s * (t - n)))
                                }
                            });
                            C.points[0].copy(g.current.translation()), C.points[1].copy(null != a ? a : m.current.translation()), C.points[2].copy(null != e ? e : d.current.translation()), C.points[3].copy(c.current.translation()), o.current.geometry.setPoints(C.getPoints(32)), b.copy(f.current.angvel()), y.copy(f.current.rotation()), f.current.setAngvel({
                                x: b.x,
                                y: b.y - .25 * y.y,
                                z: b.z
                            }, !1)
                        }
                    }
                }), C.curveType = "chordal", L.wrapS = L.wrapT = p.GJx, (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsxs)("group", {
                        position: [0, 4.6, 0],
                        children: [(0, r.jsx)(u.Ux, {
                            ref: c,
                            ...h,
                            type: "fixed"
                        }), (0, r.jsx)(u.Ux, {
                            position: [.5, 0, 0],
                            ref: d,
                            ...h,
                            children: (0, r.jsx)(u.wV, {
                                args: [.1]
                            })
                        }), (0, r.jsx)(u.Ux, {
                            position: [1, 0, 0],
                            ref: m,
                            ...h,
                            children: (0, r.jsx)(u.wV, {
                                args: [.1]
                            })
                        }), (0, r.jsx)(u.Ux, {
                            position: [1.5, 0, 0],
                            ref: g,
                            ...h,
                            children: (0, r.jsx)(u.wV, {
                                args: [.1]
                            })
                        }), (0, r.jsxs)(u.Ux, {
                            position: [2, 0, 0],
                            ref: f,
                            ...h,
                            type: v ? "kinematicPosition" : "dynamic",
                            children: [(0, r.jsx)(u.Xc, {
                                args: [.8, 1.125, .01]
                            }), (0, r.jsxs)("group", {
                                scale: 2.25,
                                position: [0, -1.25, -.05],
                                onPointerOver: () => A(!0),
                                onPointerOut: () => A(!1),
                                onPointerUp: e => {
                                    var t;
                                    return null == (t = e.target) || t.releasePointerCapture(e.pointerId), k(!1)
                                },
                                onPointerDown: e => {
                                    var t;
                                    return null == (t = e.target) || t.setPointerCapture(e.pointerId), f.current && k(new p.Pq0().copy(e.point).sub(x.copy(f.current.translation())))
                                },
                                children: [(0, r.jsx)("mesh", {
                                    geometry: S.card.geometry,
                                    children: (0, r.jsx)("meshPhysicalMaterial", {
                                        map: I.base.map,
                                        "map-anisotropy": 16,
                                        clearcoat: 1,
                                        clearcoatRoughness: .15,
                                        roughness: .3,
                                        metalness: .5
                                    })
                                }), (0, r.jsx)("mesh", {
                                    geometry: S.clip.geometry,
                                    material: I.metal,
                                    "material-roughness": .3
                                }), (0, r.jsx)("mesh", {
                                    geometry: S.clamp.geometry,
                                    material: I.metal
                                })]
                            })]
                        })]
                    }), (0, r.jsxs)("mesh", {
                        ref: o,
                        children: [(0, r.jsx)("meshLineGeometry", {}), (0, r.jsx)("meshLineMaterial", {
                            color: "white",
                            depthTest: !1,
                            resolution: new p.I9Y(2, 1),
                            useMap: 1,
                            map: L,
                            repeat: new p.I9Y(-3, 1),
                            lineWidth: 1
                        })]
                    })]
                })
            }

            function f() {
                return (0, r.jsx)("div", {
                    className: "absolute inset-0 h-full w-100vh",
                    children: (0, r.jsxs)(o.Hl, {
                        camera: {
                            position: [0, 0, 13],
                            fov: 25
                        },
                        style: {
                            backgroundColor: "transparent"
                        },
                        children: [(0, r.jsx)(u.AQ, {
                            debug: !1,
                            interpolate: !0,
                            gravity: [0, -40, 0],
                            timeStep: 1 / 60,
                            children: (0, r.jsx)(g, {})
                        }), (0, r.jsxs)(c.OH, {
                            background: !0,
                            blur: .75,
                            children: [(0, r.jsx)(d.O, {
                                intensity: 2,
                                color: "white",
                                position: [0, -1, 5],
                                rotation: [0, 0, Math.PI / 3],
                                scale: [100, .1, 1]
                            }), (0, r.jsx)(d.O, {
                                intensity: 3,
                                color: "white",
                                position: [-1, -1, 1],
                                rotation: [0, 0, Math.PI / 3],
                                scale: [100, .1, 1]
                            }), (0, r.jsx)(d.O, {
                                intensity: 3,
                                color: "white",
                                position: [1, 1, 1],
                                rotation: [0, 0, Math.PI / 3],
                                scale: [100, .1, 1]
                            }), (0, r.jsx)(d.O, {
                                intensity: 10,
                                color: "white",
                                position: [-10, 0, 14],
                                rotation: [0, Math.PI / 2, Math.PI / 3],
                                scale: [100, 10, 1]
                            })]
                        })]
                    })
                })
            }(0, s.e)({
                MeshLineGeometry: m.mx,
                MeshLineMaterial: m.Xu
            }), i.p.preload("/assets/newgaterecard.glb"), l.zo.preload("/assets/gatereband.png");
            var x = n(9521);
            let b = e => {
                    let {
                        command: t = ""
                    } = e;
                    return (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsxs)("span", {
                            className: "text-red-500",
                            children: ["bash: ", t, ": command not found"]
                        }), (0, r.jsx)("div", {
                            className: "mt-1",
                            children: (0, r.jsxs)("span", {
                                className: "inline-flex items-center",
                                children: ["Fetching information from AI assistant", (0, r.jsxs)("span", {
                                    className: "inline-flex pl-1",
                                    children: [(0, r.jsx)("span", {
                                        className: "animate-[pulseDot_1s_infinite_0ms]",
                                        children: "."
                                    }), (0, r.jsx)("span", {
                                        className: "animate-[pulseDot_1s_infinite_200ms]",
                                        children: "."
                                    }), (0, r.jsx)("span", {
                                        className: "animate-[pulseDot_1s_infinite_400ms]",
                                        children: "."
                                    })]
                                })]
                            })
                        })]
                    })
                },
                y = e => {
                    let {
                        commands: t
                    } = e, [n, s] = (0, a.useState)(""), [o, i] = (0, a.useState)([]), [l, c] = (0, a.useState)(!1), [d, u] = (0, a.useState)(0), [m, p] = (0, a.useState)(""), [h, g] = (0, a.useState)([]), [f, y] = (0, a.useState)(-1), [w, v] = (0, a.useState)(0), [k, j] = (0, a.useState)(!1), A = (0, a.useRef)(null), S = (0, a.useRef)(null), I = t.map(e => e.name), L = e => {
                        if (!e) return "";
                        let t = /(@[\w./-]+|\/(in)\/[\w./-]+)\s+\[(https?:\/\/[^\]]+)\]/g,
                            n = /(https?:\/\/[^\s]+)/g,
                            a = /\(Link\)\[(https?:\/\/[^\]]+)\]/g;
                        if (e.match(a)) {
                            let t, n = [],
                                s = 0,
                                o = new RegExp(a);
                            for (; null !== (t = o.exec(e));) {
                                t.index > s && n.push(e.substring(s, t.index));
                                let a = t[1];
                                n.push((0, r.jsx)("a", {
                                    href: a,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "text-blue-400 hover:underline",
                                    children: "Link"
                                }, "cert-link-".concat(t.index))), s = t.index + t[0].length
                            }
                            return s < e.length && n.push(e.substring(s)), n
                        }
                        if (e.match(t)) {
                            let n, a = [],
                                s = 0,
                                o = new RegExp(t);
                            for (; null !== (n = o.exec(e));) {
                                n.index > s && a.push(e.substring(s, n.index));
                                let t = n[1],
                                    o = n[3];
                                a.push((0, r.jsx)("a", {
                                    href: o,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "text-blue-400 hover:underline",
                                    children: t
                                }, "social-link-".concat(n.index))), s = n.index + n[0].length
                            }
                            return s < e.length && a.push(e.substring(s)), a
                        }
                        if (e.match(n)) {
                            let t, a = [],
                                s = 0,
                                o = new RegExp(n);
                            for (; null !== (t = o.exec(e));) {
                                t.index > s && a.push(e.substring(s, t.index));
                                let n = t[0];
                                a.push((0, r.jsx)("a", {
                                    href: n,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "text-blue-400 hover:underline",
                                    children: n
                                }, "link-".concat(t.index))), s = t.index + t[0].length
                            }
                            return s < e.length && a.push(e.substring(s)), a
                        }
                        return e
                    }, C = e => {
                        let n = e.trim().toLowerCase();
                        if ("" === n) return;
                        if ("clear" === n) {
                            i([]), s("");
                            return
                        }
                        "" !== n && (g(e => [...e, n]), y(-1));
                        let r = t.find(e => e.name === n);
                        if (r) {
                            c(!0), u(0);
                            let e = r.response;
                            Array.isArray(e) ? p(e.join("\n")) : p(e), i(e => [...e, {
                                command: n,
                                response: ""
                            }])
                        } else {
                            let e = o.length;
                            i(e => [...e, {
                                command: n,
                                response: "bash: ".concat(n, ": command not found\nFetching information from AI assistant"),
                                isLoading: !0
                            }]), P(), j(!0), x.A.post("/api/chat", {
                                prompt: n
                            }).then(t => {
                                c(!0), u(0), p(t.data.message), i(t => {
                                    let r = [...t];
                                    return r.length > e && (r[e] = {
                                        command: n,
                                        response: "bash: ".concat(n, ": command not found\n\n"),
                                        isAiResponse: !0
                                    }), r
                                })
                            }).catch(t => {
                                console.error("Error calling AI API:", t), i(t => {
                                    let r = [...t];
                                    return r.length > e && (r[e] = {
                                        command: n,
                                        response: "bash: ".concat(n, ": command not found\n\nSorry, I couldn't process that request."),
                                        isError: !0
                                    }), r
                                }), j(!1)
                            })
                        }
                        s("")
                    }, N = () => {
                        A.current && A.current.focus()
                    }, P = () => {
                        S.current && S.current.scrollIntoView({
                            behavior: "smooth"
                        })
                    };
                    return (0, a.useEffect)(() => {
                        if (!l) return;
                        let e = setInterval(() => {
                            d < m.length ? (u(e => e + 1), i(e => {
                                let t = [...e];
                                if (t.length > 0) {
                                    let e = t.length - 1,
                                        n = t[e],
                                        r = m.substring(0, d + 1);
                                    n.isAiResponse ? t[e] = { ...n,
                                        response: "bash: ".concat(n.command, ": command not found\n\n").concat(L(r)),
                                        isLoading: !1
                                    } : t[e] = { ...n,
                                        response: L(r)
                                    }
                                }
                                return t
                            }), P()) : (clearInterval(e), c(!1), u(0), j(!1), setTimeout(() => {
                                A.current && (A.current.focus(), A.current.disabled = !1)
                            }, 50))
                        }, 10);
                        return () => {
                            clearInterval(e)
                        }
                    }, [l, d, m]), (0, a.useEffect)(() => (i([{
                        command: "welcome",
                        response: L("Hi, I'm AB Coders, a Software & AI Engineer.\n\nWelcome to my interactive 'AI powered' portfolio terminal!\nType 'help' to see available commands.")
                    }]), N(), document.addEventListener("click", N), () => {
                        document.removeEventListener("click", N)
                    }), []), (0, r.jsxs)("div", {
                        className: "terminal-container w-full h-full overflow-y-auto bg-black text-green-500 font-mono px-4 pb-6",
                        onClick: N,
                        children: [(0, r.jsx)("div", {
                            className: "available-commands  py-4 text-sm border-b border-green-700 pb-2 md:fixed bg-black z-10 hidden md:block",
                            children: I.join(" | ")
                        }), (0, r.jsx)("div", {
                            className: "command-history md:pt-16 pt-2",
                            children: o.map((e, t) => (0, r.jsxs)("div", {
                                className: "mb-4",
                                children: [(0, r.jsxs)("div", {
                                    className: "command-line flex items-center",
                                    children: [(0, r.jsx)("span", {
                                        className: "text-blue-400 mr-2",
                                        children: "abcoder@portfolio:~$"
                                    }), (0, r.jsx)("span", {
                                        children: e.command
                                    })]
                                }), (0, r.jsx)("div", {
                                    className: "response mt-1 ".concat(e.isError ? "text-red-500" : "text-white", " whitespace-pre-wrap"),
                                    children: e.isLoading ? (0, r.jsx)(b, {
                                        command: e.command
                                    }) : e.response
                                })]
                            }, t))
                        }), (0, r.jsxs)("div", {
                            className: "command-input flex items-center",
                            children: [(0, r.jsx)("span", {
                                className: "text-blue-400 mr-2",
                                children: "abcoder@portfolio:~$"
                            }), (0, r.jsxs)("div", {
                                className: "fake-input flex-1 relative",
                                children: [(0, r.jsx)("span", {
                                    className: "text-green-500",
                                    children: n.substring(0, w)
                                }), (0, r.jsx)("span", {
                                    className: "cursor"
                                }), (0, r.jsx)("span", {
                                    className: "text-green-500",
                                    children: n.substring(w)
                                }), (0, r.jsx)("input", {
                                    ref: A,
                                    type: "text",
                                    value: n,
                                    onChange: e => {
                                        let t = e.target.value;
                                        s(t), e.target.selectionStart === t.length ? v(t.length) : v(e.target.selectionStart || 0)
                                    },
                                    onKeyDown: e => {
                                        if (l) return void e.preventDefault();
                                        if ("Enter" === e.key) C(n), v(0);
                                        else if ("ArrowUp" === e.key) {
                                            if (e.preventDefault(), h.length > 0 && f < h.length - 1) {
                                                let e = f + 1;
                                                y(e);
                                                let t = h[h.length - 1 - e];
                                                s(t), v(t.length)
                                            }
                                        } else if ("ArrowDown" === e.key)
                                            if (e.preventDefault(), f > 0) {
                                                let e = f - 1;
                                                y(e);
                                                let t = h[h.length - 1 - e];
                                                s(t), v(t.length)
                                            } else 0 === f && (y(-1), s(""), v(0));
                                        else if ("Tab" === e.key) {
                                            if (e.preventDefault(), n) {
                                                let e = I.filter(e => e.startsWith(n.toLowerCase()));
                                                1 === e.length && (s(e[0]), v(e[0].length))
                                            }
                                        } else "ArrowLeft" === e.key && w > 0 ? v(w - 1) : "ArrowRight" === e.key && w < n.length ? v(w + 1) : "Home" === e.key ? v(0) : "End" === e.key && v(n.length)
                                    },
                                    disabled: l || k,
                                    className: "absolute top-0 left-0 w-full h-full opacity-0",
                                    autoFocus: !0,
                                    "aria-label": "Terminal input",
                                    spellCheck: !1
                                })]
                            })]
                        }), (0, r.jsx)("div", {
                            ref: S
                        })]
                    })
                },
                w = [{
                    name: "help",
                    description: "Shows available commands",
                    response: ["Available commands:", "about       - Learn about me", "projects    - View my projects", "skills      - See my technical skills", "experience  - My work experience", "contact     - How to reach me", "education   - My educational background", "certifications - View my certifications", "leadership  - Leadership and community involvement", "clear       - Clear the terminal", "", "Type any command to continue..."]
                }, {
                    name: "about",
                    description: "Information about me",
                    response: ["\uD83D\uDC4B Hello, I'm AB Coders!", "", "I'm a Software Engineer with expertise in full-stack development, AI integration, and cloud infrastructure.", "", "Background:", "- Currently a Software Engineering Intern at Microsoft working with the Windows Team", "- Previously led the development of payment portals and dashboards at FarCas Consult (FCL)", "- Previously worked at Microsoft Garage, Digitalfarmer, and QuizardHQ", "- Focus on building scalable web applications and data visualization tools", "- Skilled in Next.js, React, AWS, Azure, and AI integration", "- Winner of the Ayute Africa Challenge with the Afyamavuno project", "", "When not coding, I enjoy speaking at tech conferences and contributing to developer communities like GDG and Microsoft Learn.", "", "Feel free to explore more using the 'projects', 'skills', or 'contact' commands!"]
                }, {
                    name: "projects",
                    description: "My projects",
                    response: ["\uD83D\uDE80 Projects:", "", "1. Afyamavuno", "   AI platform to detect crop diseases from plant images", "   Technologies: Next.js, TypeScript, Python, Flask, TensorFlow, OpenAI API", "   Link: https://afyamavuno.vercel.app", "", "2. Masomo Net", "   Subscription-based e-learning platform for students", "   Technologies: Next.js, Tailwind CSS, AWS, Supabase, PostgreSQL, Paystack, Node.js", "   Link: https://masomo-net.vercel.app/", "", "3. Lishebora (Supported by Microsoft for Startups)", "   AI meal planner generating personalized plans based on health details", "   Technologies: Next.js, Tailwind CSS, Azure, Cosmos DB, OpenAI API", "   Link: http://lishebora.vercel.app/", "", "4. Charge24 Africa Payment Portal", "   Payment system for power bank dispensing machines serving 3,000+ customers", "   Technologies: Next.js, AWS S3, Amazon Lightsail, PostgreSQL, Daraja API", "   Link: https://charge24.africa/", "", "Type 'contact' to discuss collaborations!"]
                }, {
                    name: "skills",
                    description: "My technical skills",
                    response: ["\uD83D\uDCBB Technical Skills:", "", "Programming Languages:", "- JavaScript/TypeScript", "- Python", "- C#", "- C++", "", "Frontend:", "- React.js/Next.js", "- Redux/Zustand", "- Material UI", "- Tailwind CSS", "", "Backend:", "- Node.js/Express", "- Flask/FastAPI", "- .NET", "- SQL (PostgreSQL)", "- KQL (Kusto Query Language)", "", "Cloud & DevOps:", "- Azure", "- AWS", "- Docker/Kubernetes", "- Grafana & Prometheus", "- CI/CD Pipelines", "", "Machine Learning & Tools:", "- TensorFlow", "- Git/GitHub", "- Testing (Vitest, PyTest)", "- Bash Scripting"]
                }, {
                    name: "experience",
                    description: "My work experience",
                    response: ["\uD83D\uDCBC Work Experience:", "", "Software Engineering Intern | Microsoft (July 2025 - Present)", "- Windows Team", "", "Microsoft Garage Intern | Microsoft (August 2024 - June 2025)", "- Developed inventory system with Azure OpenAI and RAG chatbot integration", "- Built file repository platform using Next.js and Azure cloud services", "- Contributed to Microsoft Global Hackathon with 87% registration rate", "- Facilitated 12 Game of Learners workshops for 200+ students", "", "Software Engineer | FarCas Consult – FCL (June 2024 - May 2025)", "- Leading Charge24 Africa's payment portal for 100+ power bank dispensing machines", "- Engineering membership portals for NextGen and Afrofit Gyms managing 700+ members", "- Implementing real-time data visualization for 500-1,000+ daily transactions", "- Setting up CI/CD pipelines that improved deployment speed by 60%", "", "Software Engineer | Digitalfarmer (Aug. 2023 - May 2024)", "- Collaborated with 4 developers on agricultural supply chain platform", "- Played key role in B2B/B2C platform that increased user base by 75%", "- Reduced load times by 20% through optimized front-end components", "", "Software Engineer | QuizardHQ (Apr. 2022 - July 2023)", "- Implemented frontend/backend with React.js, FastAPI, and AWS", "- Improved user engagement by 30% through system enhancements", "- Reduced user-reported issues by 25% through systematic troubleshooting", "", "Type 'projects' to see my recent work."]
                }, {
                    name: "contact",
                    description: "Contact information",
                    response: ["\uD83D\uDCEC Get In Touch:", "", "Email: abcoders@gmail.com", "Phone: +91-9262-917049", "GitHub: @abgroupavi [https://github.com/abgroupavi]", "LinkedIn: /in/abgroupavi [https://linkedin.com/in/abgroupavi]", "Twitter (X): @abcoder [https://x.com/abcoder]", "", "Feel free to reach out!"]
                }, {
                    name: "education",
                    description: "My educational background",
                    response: ["\uD83C\uDF93 Education:", "", "Bachelor's in Information Technology", "- Focused on software engineering, AI, and data structures", "- Relevant coursework: Algorithms, Database Systems, Computer Networks, AI/ML", "", "Additional Learning:", "- Continuous professional development through certifications", "- Self-guided study in cloud technologies and artificial intelligence", "- Regular participation in hackathons and coding challenges"]
                }, {
                    name: "certifications",
                    description: "My certifications",
                    response: ["\uD83C\uDFC6 Certifications:", "", "Technical Certifications:", "- Microsoft Certified: Azure AI Fundamentals (Link)[https://learn.microsoft.com/en-us/users/abgroupavi/credentials/F865042F07E63125]", "- Andela: React Learning Program (Link)[https://credsverse.com/credentials/83b4903a-eadc-462c-b99f-12ac8dd171e1]", "- Data Analyst Associate Certificate - DataCamp (Link)[https://www.datacamp.com/certificate/DAA0017347104862]", "- SQL Associate Certificate - DataCamp (Link)[https://www.datacamp.com/certificate/SQA0011261438691]", "", "Industry Recognition:", "- Microsoft Global Hackathon Volunteer (Link)[https://www.credly.com/badges/728c91ad-61e0-45b3-b0bb-bf5105a93e4c/public_url]", "", "Visit my LinkedIn profile - 'contact' - for a complete list of certifications."]
                }, {
                    name: "leadership",
                    description: "Leadership and community involvement",
                    response: ["\uD83D\uDC65 Leadership & Community:", "", "Speaking & Hosting:", "- Keynote Speaker - Enhance Mind AI Conference", "- Host - Global AI Conference, Student Edition", "- Featured Speaker - Microsoft Reactor", "", "Community Leadership:", "- Organizer - Google Developer Groups (GDG)", "- Lead - Google Developer Student Clubs", "- Beta - Microsoft Learn Student Ambassador", "", "Mentorship:", "- Technical workshop facilitator for Game of Learners (GOL) Clinics", "", "I'm passionate about tech community building and knowledge sharing!"]
                }, {
                    name: "sudo",
                    description: "Run as administrator",
                    response: "Hi, I'm AB Coders, a Software & AI Engineer." 
                }, {
                    name: "clear",
                    description: "Clear terminal",
                    response: "CLEAR_TERMINAL"
                }],
                v = () => {
                    let [e, t] = (0, a.useState)(!1), [n, s] = (0, a.useState)(!1), [o, i] = (0, a.useState)(new Date);
                    return ((0, a.useEffect)(() => {
                        t(!0);
                        let e = () => {
                            s(window.innerWidth < 1024)
                        };
                        return e(), window.addEventListener("resize", e), () => window.removeEventListener("resize", e)
                    }, []), (0, a.useEffect)(() => {
                        let e = setInterval(() => {
                            i(new Date)
                        }, 1e3);
                        return () => clearInterval(e)
                    }, []), e) ? (0, r.jsxs)("div", {
                        className: "flex flex-col w-full h-screen bg-black text-white overflow-hidden",
                        children: [(0, r.jsxs)("header", {
                            className: "p-4 border-b border-green-700 text-center md:text-left",
                            children: [(0, r.jsx)("h1", {
                                className: "text-2xl font-bold text-green-500 font-mono",
                                children: "AB Coders"
                            }), (0, r.jsx)("p", {
                                className: "text-sm text-gray-400 font-mono",
                                children: "Software Engineer"
                            })]
                        }), (0, r.jsxs)("div", {
                            className: "flex flex-1 overflow-hidden ".concat(n ? "flex-col" : "flex-row"),
                            children: [(0, r.jsx)("div", {
                                className: "".concat(n ? "h-1/3 w-full hidden" : "w-2/5 h-full", " border-green-700 ").concat(n ? "border-b" : "border-r", " relative z-10"),
                                children: (0, r.jsxs)("div", {
                                    className: "relative w-full h-full",
                                    children: [(0, r.jsx)(f, {}), (0, r.jsx)("div", {
                                        className: "absolute bottom-2 right-2 text-xs text-green-500 font-mono bg-black bg-opacity-70 p-1 rounded z-20",
                                        children: "[Interactive 3D Card]"
                                    })]
                                })
                            }), (0, r.jsx)("div", {
                                className: "".concat(n ? " w-full" : "w-3/5 h-full", " overflow-auto relative"),
                                children: (0, r.jsx)(y, {
                                    commands: w
                                })
                            })]
                        }), (0, r.jsxs)("footer", {
                            className: "p-2 border-t border-green-700 bg-black text-xs text-green-500 font-mono flex justify-between items-center",
                            children: [(0, r.jsx)("span", {
                                children: "abcoder@portfolio:~$"
                            }), (0, r.jsx)("span", {
                                children: o.toLocaleString("en-US", {
                                    timeZone: "Africa/Nairobi"
                                })
                            })]
                        })]
                    }) : null
                }
        },
        8163: (e, t, n) => {
            Promise.resolve().then(n.bind(n, 513))
        }
    },
    e => {
        var t = t => e(e.s = t);
        e.O(0, [970, 667, 269, 558, 330, 364, 770, 358], () => t(8163)), _N_E = e.O()
    }
]);