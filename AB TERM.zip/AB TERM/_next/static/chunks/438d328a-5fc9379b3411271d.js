"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [206], {
        2116: (e, t, i) => {
            i.d(t, {
                Ay: () => nf
            });
            var s, r = "undefined" != typeof window ? window : void 0,
                n = "undefined" != typeof globalThis ? globalThis : r,
                o = Array.prototype,
                a = o.forEach,
                l = o.indexOf,
                c = null == n ? void 0 : n.navigator,
                u = null == n ? void 0 : n.document,
                d = null == n ? void 0 : n.location,
                h = null == n ? void 0 : n.fetch,
                _ = null != n && n.XMLHttpRequest && "withCredentials" in new n.XMLHttpRequest ? n.XMLHttpRequest : void 0,
                p = null == n ? void 0 : n.AbortController,
                g = null == c ? void 0 : c.userAgent,
                f = null != r ? r : {},
                v = {
                    DEBUG: !1,
                    LIB_VERSION: "1.236.7"
                },
                m = "$copy_autocapture",
                y = ["$snapshot", "$pageview", "$pageleave", "$set", "survey dismissed", "survey sent", "survey shown", "$identify", "$groupidentify", "$create_alias", "$$client_ingestion_warning", "$web_experiment_applied", "$feature_enrollment_update", "$feature_flag_called"];
            ! function(e) {
                e.GZipJS = "gzip-js", e.Base64 = "base64"
            }(s || (s = {}));
            var b = ["fatal", "error", "warning", "log", "info", "debug"];

            function w(e, t) {
                return -1 !== e.indexOf(t)
            }
            var S = function(e) {
                    return e.trim()
                },
                k = function(e) {
                    return e.replace(/^\$/, "")
                },
                E = Array.isArray,
                x = Object.prototype,
                I = x.hasOwnProperty,
                C = x.toString,
                P = E || function(e) {
                    return "[object Array]" === C.call(e)
                },
                F = e => "function" == typeof e,
                R = e => e === Object(e) && !P(e),
                T = e => {
                    if (R(e)) {
                        for (var t in e)
                            if (I.call(e, t)) return !1;
                        return !0
                    }
                    return !1
                },
                $ = e => void 0 === e,
                O = e => "[object String]" == C.call(e),
                A = e => O(e) && 0 === e.trim().length,
                M = e => null === e,
                L = e => $(e) || M(e),
                D = e => "[object Number]" == C.call(e),
                q = e => "[object Boolean]" === C.call(e),
                N = e => e instanceof FormData,
                B = e => w(y, e),
                H = e => {
                    var t = {
                        _log: function(t) {
                            if (r && (v.DEBUG || f.POSTHOG_DEBUG) && !$(r.console) && r.console) {
                                for (var i = ("__rrweb_original__" in r.console[t]) ? r.console[t].__rrweb_original__ : r.console[t], s = arguments.length, n = Array(s > 1 ? s - 1 : 0), o = 1; o < s; o++) n[o - 1] = arguments[o];
                                i(e, ...n)
                            }
                        },
                        info: function() {
                            for (var e = arguments.length, i = Array(e), s = 0; s < e; s++) i[s] = arguments[s];
                            t._log("log", ...i)
                        },
                        warn: function() {
                            for (var e = arguments.length, i = Array(e), s = 0; s < e; s++) i[s] = arguments[s];
                            t._log("warn", ...i)
                        },
                        error: function() {
                            for (var e = arguments.length, i = Array(e), s = 0; s < e; s++) i[s] = arguments[s];
                            t._log("error", ...i)
                        },
                        critical: function() {
                            for (var t = arguments.length, i = Array(t), s = 0; s < t; s++) i[s] = arguments[s];
                            console.error(e, ...i)
                        },
                        uninitializedWarning: e => {
                            t.error("You must initialize PostHog before calling ".concat(e))
                        },
                        createLogger: t => H("".concat(e, " ").concat(t))
                    };
                    return t
                },
                j = H("[PostHog.js]"),
                z = j.createLogger,
                U = z("[ExternalScriptsLoader]"),
                W = (e, t, i) => {
                    if (e.config.disable_external_dependency_loading) return U.warn("".concat(t, " was requested but loading of external scripts is disabled.")), i("Loading of external scripts is disabled");
                    var s = null == u ? void 0 : u.querySelectorAll("script");
                    if (s) {
                        for (var r = 0; r < s.length; r++)
                            if (s[r].src === t) return i()
                    }
                    var n = () => {
                        if (!u) return i("document not found");
                        var s = u.createElement("script");
                        if (s.type = "text/javascript", s.crossOrigin = "anonymous", s.src = t, s.onload = e => i(void 0, e), s.onerror = e => i(e), e.config.prepare_external_dependency_script && (s = e.config.prepare_external_dependency_script(s)), !s) return i("prepare_external_dependency_script returned null");
                        var r, n = u.querySelectorAll("body > script");
                        n.length > 0 ? null == (r = n[0].parentNode) || r.insertBefore(s, n[0]) : u.body.appendChild(s)
                    };
                    null != u && u.body ? n() : null == u || u.addEventListener("DOMContentLoaded", n)
                };

            function G(e, t) {
                var i = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var s = Object.getOwnPropertySymbols(e);
                    t && (s = s.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), i.push.apply(i, s)
                }
                return i
            }

            function V(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var i = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? G(Object(i), !0).forEach(function(t) {
                        J(e, t, i[t])
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : G(Object(i)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t))
                    })
                }
                return e
            }

            function J(e, t, i) {
                return t in e ? Object.defineProperty(e, t, {
                    value: i,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = i, e
            }

            function Y(e, t) {
                if (null == e) return {};
                var i, s, r = function(e, t) {
                    if (null == e) return {};
                    var i, s, r = {},
                        n = Object.keys(e);
                    for (s = 0; s < n.length; s++) i = n[s], t.indexOf(i) >= 0 || (r[i] = e[i]);
                    return r
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    for (s = 0; s < n.length; s++) i = n[s], t.indexOf(i) >= 0 || Object.prototype.propertyIsEnumerable.call(e, i) && (r[i] = e[i])
                }
                return r
            }
            f.__PosthogExtensions__ = f.__PosthogExtensions__ || {}, f.__PosthogExtensions__.loadExternalDependency = (e, t, i) => {
                var s = "/static/".concat(t, ".js") + "?v=".concat(e.version);
                if ("remote-config" === t && (s = "/array/".concat(e.config.token, "/config.js")), "toolbar" === t) {
                    var r = 3e5 * Math.floor(Date.now() / 3e5);
                    s = "".concat(s, "&t=").concat(r)
                }
                var n = e.requestRouter.endpointFor("assets", s);
                W(e, n, i)
            }, f.__PosthogExtensions__.loadSiteApp = (e, t, i) => {
                var s = e.requestRouter.endpointFor("api", t);
                W(e, s, i)
            };
            var K = {};

            function X(e, t, i) {
                if (P(e)) {
                    if (a && e.forEach === a) e.forEach(t, i);
                    else if ("length" in e && e.length === +e.length) {
                        for (var s = 0, r = e.length; s < r; s++)
                            if (s in e && t.call(i, e[s], s) === K) return
                    }
                }
            }

            function Q(e, t, i) {
                if (!L(e)) {
                    if (P(e)) return X(e, t, i);
                    if (N(e)) {
                        for (var s of e.entries())
                            if (t.call(i, s[1], s[0]) === K) return
                    } else
                        for (var r in e)
                            if (I.call(e, r) && t.call(i, e[r], r) === K) return
                }
            }
            var Z = function(e) {
                    for (var t = arguments.length, i = Array(t > 1 ? t - 1 : 0), s = 1; s < t; s++) i[s - 1] = arguments[s];
                    return X(i, function(t) {
                        for (var i in t) void 0 !== t[i] && (e[i] = t[i])
                    }), e
                },
                ee = function(e) {
                    for (var t = arguments.length, i = Array(t > 1 ? t - 1 : 0), s = 1; s < t; s++) i[s - 1] = arguments[s];
                    return X(i, function(t) {
                        X(t, function(t) {
                            e.push(t)
                        })
                    }), e
                };

            function et(e) {
                for (var t = Object.keys(e), i = t.length, s = Array(i); i--;) s[i] = [t[i], e[t[i]]];
                return s
            }
            var ei = function(e) {
                    try {
                        return e()
                    } catch (e) {
                        return
                    }
                },
                es = function(e) {
                    return function() {
                        try {
                            for (var t = arguments.length, i = Array(t), s = 0; s < t; s++) i[s] = arguments[s];
                            return e.apply(this, i)
                        } catch (e) {
                            j.critical("Implementation error. Please turn on debug mode and open a ticket on https://app.posthog.com/home#panel=support%3Asupport%3A."), j.critical(e)
                        }
                    }
                },
                er = function(e) {
                    var t = {};
                    return Q(e, function(e, i) {
                        (O(e) && e.length > 0 || D(e)) && (t[i] = e)
                    }), t
                },
                en = ["herokuapp.com", "vercel.app", "netlify.app"];

            function eo(e, t) {
                for (var i = 0; i < e.length; i++)
                    if (t(e[i])) return e[i]
            }

            function ea(e, t, i, s) {
                var {
                    capture: r = !1,
                    passive: n = !0
                } = null != s ? s : {};
                null == e || e.addEventListener(t, i, {
                    capture: r,
                    passive: n
                })
            }
            var el = "$people_distinct_id",
                ec = "__alias",
                eu = "__timers",
                ed = "$autocapture_disabled_server_side",
                eh = "$heatmaps_enabled_server_side",
                e_ = "$exception_capture_enabled_server_side",
                ep = "$web_vitals_enabled_server_side",
                eg = "$dead_clicks_enabled_server_side",
                ef = "$web_vitals_allowed_metrics",
                ev = "$session_recording_enabled_server_side",
                em = "$console_log_recording_enabled_server_side",
                ey = "$session_recording_network_payload_capture",
                eb = "$session_recording_masking",
                ew = "$session_recording_canvas_recording",
                eS = "$replay_sample_rate",
                ek = "$replay_minimum_duration",
                eE = "$replay_script_config",
                ex = "$sesid",
                eI = "$session_is_sampled",
                eC = "$session_recording_url_trigger_activated_session",
                eP = "$session_recording_event_trigger_activated_session",
                eF = "$enabled_feature_flags",
                eR = "$early_access_features",
                eT = "$feature_flag_details",
                e$ = "$stored_person_properties",
                eO = "$stored_group_properties",
                eA = "$surveys",
                eM = "$surveys_activated",
                eL = "$flag_call_reported",
                eD = "$user_state",
                eq = "$client_session_props",
                eN = "$capture_rate_limit",
                eB = "$initial_campaign_params",
                eH = "$initial_referrer_info",
                ej = "$initial_person_info",
                ez = "$epp",
                eU = "__POSTHOG_TOOLBAR__",
                eW = "$posthog_cookieless",
                eG = [el, ec, "__cmpns", eu, ev, eh, ex, eF, eD, eR, eT, eO, e$, eA, eL, eq, eN, eB, eH, ez];

            function eV(e) {
                var t;
                return e instanceof Element && (e.id === eU || !(null == (t = e.closest) || !t.call(e, ".toolbar-global-fade-container")))
            }

            function eJ(e) {
                return !!e && 1 === e.nodeType
            }

            function eY(e, t) {
                return !!e && !!e.tagName && e.tagName.toLowerCase() === t.toLowerCase()
            }

            function eK(e) {
                return !!e && 3 === e.nodeType
            }

            function eX(e) {
                return !!e && 11 === e.nodeType
            }

            function eQ(e) {
                return e ? S(e).split(/\s+/) : []
            }

            function eZ(e) {
                var t = null == r ? void 0 : r.location.href;
                return !!(t && e && e.some(e => t.match(e)))
            }

            function e0(e) {
                var t = "";
                switch (typeof e.className) {
                    case "string":
                        t = e.className;
                        break;
                    case "object":
                        t = (e.className && "baseVal" in e.className ? e.className.baseVal : null) || e.getAttribute("class") || "";
                        break;
                    default:
                        t = ""
                }
                return eQ(t)
            }

            function e1(e) {
                return L(e) ? null : S(e).split(/(\s+)/).filter(e => tr(e)).join("").replace(/[\r\n]/g, " ").replace(/[ ]+/g, " ").substring(0, 255)
            }

            function e2(e) {
                var t = "";
                return e4(e) && !e8(e) && e.childNodes && e.childNodes.length && Q(e.childNodes, function(e) {
                    var i;
                    eK(e) && e.textContent && (t += null != (i = e1(e.textContent)) ? i : "")
                }), S(t)
            }

            function e3(e) {
                var t;
                return $(e.target) ? e.srcElement || null : null != (t = e.target) && t.shadowRoot ? e.composedPath()[0] || null : e.target || null
            }
            var e5 = ["a", "button", "form", "input", "select", "textarea", "label"];

            function e6(e) {
                var t = e.parentNode;
                return !(!t || !eJ(t)) && t
            }

            function e4(e) {
                for (var t = e; t.parentNode && !eY(t, "body"); t = t.parentNode) {
                    var i = e0(t);
                    if (w(i, "ph-sensitive") || w(i, "ph-no-capture")) return !1
                }
                if (w(e0(e), "ph-include")) return !0;
                var s = e.type || "";
                if (O(s)) switch (s.toLowerCase()) {
                    case "hidden":
                    case "password":
                        return !1
                }
                var r = e.name || e.id || "";
                return !(O(r) && /^cc|cardnum|ccnum|creditcard|csc|cvc|cvv|exp|pass|pwd|routing|seccode|securitycode|securitynum|socialsec|socsec|ssn/i.test(r.replace(/[^a-zA-Z0-9]/g, "")))
            }

            function e8(e) {
                return !!(eY(e, "input") && !["button", "checkbox", "submit", "reset"].includes(e.type) || eY(e, "select") || eY(e, "textarea") || "true" === e.getAttribute("contenteditable"))
            }
            var e7 = "(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(6(?:011|5[0-9]{2})[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|((?:2131|1800|35[0-9]{3})[0-9]{11})",
                e9 = new RegExp("^(?:".concat(e7, ")$")),
                te = new RegExp(e7),
                tt = "\\d{3}-?\\d{2}-?\\d{4}",
                ti = new RegExp("^(".concat(tt, ")$")),
                ts = new RegExp("(".concat(tt, ")"));

            function tr(e) {
                var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                return !(L(e) || O(e) && (e = S(e), (t ? e9 : te).test((e || "").replace(/[- ]/g, "")) || (t ? ti : ts).test(e))) && !0
            }

            function tn(e) {
                var t = e2(e);
                return tr(t = "".concat(t, " ").concat(function e(t) {
                    var i = "";
                    return t && t.childNodes && t.childNodes.length && Q(t.childNodes, function(t) {
                        var s;
                        if (t && "span" === (null == (s = t.tagName) ? void 0 : s.toLowerCase())) try {
                            var r = e2(t);
                            i = "".concat(i, " ").concat(r).trim(), t.childNodes && t.childNodes.length && (i = "".concat(i, " ").concat(e(t)).trim())
                        } catch (e) {
                            j.error("[AutoCapture]", e)
                        }
                    }), i
                }(e)).trim()) ? t : ""
            }

            function to(e) {
                return e.replace(/"|\\"/g, '\\"')
            }
            class ta {
                constructor() {
                    this.clicks = []
                }
                isRageClick(e, t, i) {
                    var s = this.clicks[this.clicks.length - 1];
                    if (s && Math.abs(e - s.x) + Math.abs(t - s.y) < 30 && i - s.timestamp < 1e3) {
                        if (this.clicks.push({
                                x: e,
                                y: t,
                                timestamp: i
                            }), 3 === this.clicks.length) return !0
                    } else this.clicks = [{
                        x: e,
                        y: t,
                        timestamp: i
                    }];
                    return !1
                }
            }
            var tl = ["localhost", "127.0.0.1"],
                tc = e => {
                    var t = null == u ? void 0 : u.createElement("a");
                    return $(t) ? null : (t.href = e, t)
                },
                tu = function(e) {
                    var t, i, s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "&",
                        r = [];
                    return Q(e, function(e, s) {
                        $(e) || $(s) || "undefined" === s || (t = encodeURIComponent(e instanceof File ? e.name : e.toString()), i = encodeURIComponent(s), r[r.length] = i + "=" + t)
                    }), r.join(s)
                },
                td = function(e, t) {
                    for (var i, s = ((e.split("#")[0] || "").split(/\?(.*)/)[1] || "").replace(/^\?+/g, "").split("&"), r = 0; r < s.length; r++) {
                        var n = s[r].split("=");
                        if (n[0] === t) {
                            i = n;
                            break
                        }
                    }
                    if (!P(i) || i.length < 2) return "";
                    var o = i[1];
                    try {
                        o = decodeURIComponent(o)
                    } catch (e) {
                        j.error("Skipping decoding for malformed query param: " + o)
                    }
                    return o.replace(/\+/g, " ")
                },
                th = function(e, t, i) {
                    if (!e || !t || !t.length) return e;
                    for (var s = e.split("#"), r = s[0] || "", n = s[1], o = r.split("?"), a = o[1], l = o[0], c = (a || "").split("&"), u = [], d = 0; d < c.length; d++) {
                        var h = c[d].split("=");
                        P(h) && (t.includes(h[0]) ? u.push(h[0] + "=" + i) : u.push(c[d]))
                    }
                    var _ = l;
                    return null != a && (_ += "?" + u.join("&")), null != n && (_ += "#" + n), _
                },
                t_ = function(e, t) {
                    var i = e.match(RegExp(t + "=([^&]*)"));
                    return i ? i[1] : null
                },
                tp = z("[AutoCapture]");

            function tg(e, t) {
                return t.length > e ? t.slice(0, e) + "..." : t
            }
            class tf {
                constructor(e) {
                    J(this, "_initialized", !1), J(this, "_isDisabledServerSide", null), J(this, "rageclicks", new ta), J(this, "_elementsChainAsString", !1), this.instance = e, this._elementSelectors = null
                }
                get _config() {
                    var e, t, i = R(this.instance.config.autocapture) ? this.instance.config.autocapture : {};
                    return i.url_allowlist = null == (e = i.url_allowlist) ? void 0 : e.map(e => new RegExp(e)), i.url_ignorelist = null == (t = i.url_ignorelist) ? void 0 : t.map(e => new RegExp(e)), i
                }
                _addDomEventHandlers() {
                    if (this.isBrowserSupported()) {
                        if (r && u) {
                            var e = e => {
                                e = e || (null == r ? void 0 : r.event);
                                try {
                                    this._captureEvent(e)
                                } catch (e) {
                                    tp.error("Failed to capture event", e)
                                }
                            };
                            if (ea(u, "submit", e, {
                                    capture: !0
                                }), ea(u, "change", e, {
                                    capture: !0
                                }), ea(u, "click", e, {
                                    capture: !0
                                }), this._config.capture_copied_text) {
                                var t = e => {
                                    e = e || (null == r ? void 0 : r.event), this._captureEvent(e, m)
                                };
                                ea(u, "copy", t, {
                                    capture: !0
                                }), ea(u, "cut", t, {
                                    capture: !0
                                })
                            }
                        }
                    } else tp.info("Disabling Automatic Event Collection because this browser is not supported")
                }
                startIfEnabled() {
                    this.isEnabled && !this._initialized && (this._addDomEventHandlers(), this._initialized = !0)
                }
                onRemoteConfig(e) {
                    e.elementsChainAsString && (this._elementsChainAsString = e.elementsChainAsString), this.instance.persistence && this.instance.persistence.register({
                        [ed]: !!e.autocapture_opt_out
                    }), this._isDisabledServerSide = !!e.autocapture_opt_out, this.startIfEnabled()
                }
                setElementSelectors(e) {
                    this._elementSelectors = e
                }
                getElementSelectors(e) {
                    var t, i = [];
                    return null == (t = this._elementSelectors) || t.forEach(t => {
                        var s = null == u ? void 0 : u.querySelectorAll(t);
                        null == s || s.forEach(s => {
                            e === s && i.push(t)
                        })
                    }), i
                }
                get isEnabled() {
                    var e, t, i = null == (e = this.instance.persistence) ? void 0 : e.props[ed];
                    if (M(this._isDisabledServerSide) && !q(i) && !this.instance.config.advanced_disable_decide) return !1;
                    var s = null != (t = this._isDisabledServerSide) ? t : !!i;
                    return !!this.instance.config.autocapture && !s
                }
                _captureEvent(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "$autocapture";
                    if (this.isEnabled) {
                        var i, s = e3(e);
                        eK(s) && (s = s.parentNode || null), "$autocapture" === t && "click" === e.type && e instanceof MouseEvent && this.instance.config.rageclick && null != (i = this.rageclicks) && i.isRageClick(e.clientX, e.clientY, (new Date).getTime()) && this._captureEvent(e, "$rageclick");
                        var n = t === m;
                        if (s && function(e, t) {
                                var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
                                    s = arguments.length > 3 ? arguments[3] : void 0,
                                    n = arguments.length > 4 ? arguments[4] : void 0;
                                if (!r || !e || eY(e, "html") || !eJ(e) || null != i && i.url_allowlist && !eZ(i.url_allowlist) || null != i && i.url_ignorelist && eZ(i.url_ignorelist)) return !1;
                                if (null != i && i.dom_event_allowlist) {
                                    var o = i.dom_event_allowlist;
                                    if (o && !o.some(e => t.type === e)) return !1
                                }
                                for (var a = !1, l = [e], c = !0, u = e; u.parentNode && !eY(u, "body");)
                                    if (eX(u.parentNode)) l.push(u.parentNode.host), u = u.parentNode.host;
                                    else {
                                        if (!(c = e6(u))) break;
                                        if (s || e5.indexOf(c.tagName.toLowerCase()) > -1) a = !0;
                                        else {
                                            var d = r.getComputedStyle(c);
                                            d && "pointer" === d.getPropertyValue("cursor") && (a = !0)
                                        }
                                        l.push(c), u = c
                                    }
                                if (! function(e, t) {
                                        var i = null == t ? void 0 : t.element_allowlist;
                                        if ($(i)) return !0;
                                        var s = function(e) {
                                            if (i.some(t => e.tagName.toLowerCase() === t)) return {
                                                v: !0
                                            }
                                        };
                                        for (var r of e) {
                                            var n = s(r);
                                            if ("object" == typeof n) return n.v
                                        }
                                        return !1
                                    }(l, i) || ! function(e, t) {
                                        var i = null == t ? void 0 : t.css_selector_allowlist;
                                        if ($(i)) return !0;
                                        var s = function(e) {
                                            if (i.some(t => e.matches(t))) return {
                                                v: !0
                                            }
                                        };
                                        for (var r of e) {
                                            var n = s(r);
                                            if ("object" == typeof n) return n.v
                                        }
                                        return !1
                                    }(l, i)) return !1;
                                var h = r.getComputedStyle(e);
                                if (h && "pointer" === h.getPropertyValue("cursor") && "click" === t.type) return !0;
                                var _ = e.tagName.toLowerCase();
                                switch (_) {
                                    case "html":
                                        return !1;
                                    case "form":
                                        return (n || ["submit"]).indexOf(t.type) >= 0;
                                    case "input":
                                    case "select":
                                    case "textarea":
                                        return (n || ["change", "click"]).indexOf(t.type) >= 0;
                                    default:
                                        return a ? (n || ["click"]).indexOf(t.type) >= 0 : (n || ["click"]).indexOf(t.type) >= 0 && (e5.indexOf(_) > -1 || "true" === e.getAttribute("contenteditable"))
                                }
                            }(s, e, this._config, n, n ? ["copy", "cut"] : void 0)) {
                            var {
                                props: o,
                                explicitNoCapture: a
                            } = function(e, t) {
                                for (var i, s, {
                                        e: n,
                                        maskAllElementAttributes: o,
                                        maskAllText: a,
                                        elementAttributeIgnoreList: l,
                                        elementsChainAsString: c
                                    } = t, u = [e], d = e; d.parentNode && !eY(d, "body");) eX(d.parentNode) ? (u.push(d.parentNode.host), d = d.parentNode.host) : (u.push(d.parentNode), d = d.parentNode);
                                var h, _ = [],
                                    p = {},
                                    g = !1,
                                    f = !1;
                                if (Q(u, e => {
                                        var t = e4(e);
                                        "a" === e.tagName.toLowerCase() && (g = e.getAttribute("href"), g = t && g && tr(g) && g), w(e0(e), "ph-no-capture") && (f = !0), _.push(function(e, t, i, s) {
                                            var r = e.tagName.toLowerCase(),
                                                n = {
                                                    tag_name: r
                                                };
                                            e5.indexOf(r) > -1 && !i && ("a" === r.toLowerCase() || "button" === r.toLowerCase() ? n.$el_text = tg(1024, tn(e)) : n.$el_text = tg(1024, e2(e)));
                                            var o = e0(e);
                                            o.length > 0 && (n.classes = o.filter(function(e) {
                                                return "" !== e
                                            })), Q(e.attributes, function(i) {
                                                var r;
                                                if ((!e8(e) || -1 !== ["name", "id", "class", "aria-label"].indexOf(i.name)) && (null == s || !s.includes(i.name)) && !t && tr(i.value) && (!O(r = i.name) || "_ngcontent" !== r.substring(0, 10) && "_nghost" !== r.substring(0, 7))) {
                                                    var o = i.value;
                                                    "class" === i.name && (o = eQ(o).join(" ")), n["attr__" + i.name] = tg(1024, o)
                                                }
                                            });
                                            for (var a = 1, l = 1, c = e; c = function(e) {
                                                    if (e.previousElementSibling) return e.previousElementSibling;
                                                    var t = e;
                                                    do t = t.previousSibling; while (t && !eJ(t));
                                                    return t
                                                }(c);) a++, c.tagName === e.tagName && l++;
                                            return n.nth_child = a, n.nth_of_type = l, n
                                        }(e, o, a, l)), Z(p, function(e) {
                                            if (!e4(e)) return {};
                                            var t = {};
                                            return Q(e.attributes, function(e) {
                                                if (e.name && 0 === e.name.indexOf("data-ph-capture-attribute")) {
                                                    var i = e.name.replace("data-ph-capture-attribute-", ""),
                                                        s = e.value;
                                                    i && s && tr(s) && (t[i] = s)
                                                }
                                            }), t
                                        }(e))
                                    }), f) return {
                                    props: {},
                                    explicitNoCapture: f
                                };
                                if (a || ("a" === e.tagName.toLowerCase() || "button" === e.tagName.toLowerCase() ? _[0].$el_text = tn(e) : _[0].$el_text = e2(e)), g) {
                                    _[0].attr__href = g;
                                    var v, m, y = null == (v = tc(g)) ? void 0 : v.host,
                                        b = null == r || null == (m = r.location) ? void 0 : m.host;
                                    y && b && y !== b && (h = g)
                                }
                                return {
                                    props: Z({
                                        $event_type: n.type,
                                        $ce_version: 1
                                    }, c ? {} : {
                                        $elements: _
                                    }, {
                                        $elements_chain: _.map(e => {
                                            var t, i, s, r = {
                                                text: null == (i = e.$el_text) ? void 0 : i.slice(0, 400),
                                                tag_name: e.tag_name,
                                                href: null == (s = e.attr__href) ? void 0 : s.slice(0, 2048),
                                                attr_class: (t = e.attr__class) ? P(t) ? t : eQ(t) : void 0,
                                                attr_id: e.attr__id,
                                                nth_child: e.nth_child,
                                                nth_of_type: e.nth_of_type,
                                                attributes: {}
                                            };
                                            return et(e).filter(e => {
                                                var [t] = e;
                                                return 0 === t.indexOf("attr__")
                                            }).forEach(e => {
                                                var [t, i] = e;
                                                return r.attributes[t] = i
                                            }), r
                                        }).map(e => {
                                            var t, i, s = "";
                                            if (e.tag_name && (s += e.tag_name), e.attr_class)
                                                for (var r of (e.attr_class.sort(), e.attr_class)) s += ".".concat(r.replace(/"/g, ""));
                                            var n = V(V(V(V({}, e.text ? {
                                                    text: e.text
                                                } : {}), {}, {
                                                    "nth-child": null != (t = e.nth_child) ? t : 0,
                                                    "nth-of-type": null != (i = e.nth_of_type) ? i : 0
                                                }, e.href ? {
                                                    href: e.href
                                                } : {}), e.attr_id ? {
                                                    attr_id: e.attr_id
                                                } : {}), e.attributes),
                                                o = {};
                                            return et(n).sort((e, t) => {
                                                var [i] = e, [s] = t;
                                                return i.localeCompare(s)
                                            }).forEach(e => {
                                                var [t, i] = e;
                                                return o[to(t.toString())] = to(i.toString())
                                            }), s += ":", s += et(n).map(e => {
                                                var [t, i] = e;
                                                return "".concat(t, '="').concat(i, '"')
                                            }).join("")
                                        }).join(";")
                                    }, null != (i = _[0]) && i.$el_text ? {
                                        $el_text: null == (s = _[0]) ? void 0 : s.$el_text
                                    } : {}, h && "click" === n.type ? {
                                        $external_click_url: h
                                    } : {}, p)
                                }
                            }(s, {
                                e: e,
                                maskAllElementAttributes: this.instance.config.mask_all_element_attributes,
                                maskAllText: this.instance.config.mask_all_text,
                                elementAttributeIgnoreList: this._config.element_attribute_ignorelist,
                                elementsChainAsString: this._elementsChainAsString
                            });
                            if (a) return !1;
                            var l = this.getElementSelectors(s);
                            if (l && l.length > 0 && (o.$element_selectors = l), t === m) {
                                var c, u = e1(null == r || null == (c = r.getSelection()) ? void 0 : c.toString()),
                                    d = e.type || "clipboard";
                                if (!u) return !1;
                                o.$selected_content = u, o.$copy_type = d
                            }
                            return this.instance.capture(t, o), !0
                        }
                    }
                }
                isBrowserSupported() {
                    return F(null == u ? void 0 : u.querySelectorAll)
                }
            }
            Math.trunc || (Math.trunc = function(e) {
                return e < 0 ? Math.ceil(e) : Math.floor(e)
            }), Number.isInteger || (Number.isInteger = function(e) {
                return D(e) && isFinite(e) && Math.floor(e) === e
            });
            var tv = "0123456789abcdef";
            class tm {
                constructor(e) {
                    if (this.bytes = e, 16 !== e.length) throw TypeError("not 128-bit length")
                }
                static fromFieldsV7(e, t, i, s) {
                    if (!Number.isInteger(e) || !Number.isInteger(t) || !Number.isInteger(i) || !Number.isInteger(s) || e < 0 || t < 0 || i < 0 || s < 0 || e > 0xffffffffffff || t > 4095 || i > 0x3fffffff || s > 0xffffffff) throw RangeError("invalid field value");
                    var r = new Uint8Array(16);
                    return r[0] = e / 0x10000000000, r[1] = e / 0x100000000, r[2] = e / 0x1000000, r[3] = e / 65536, r[4] = e / 256, r[5] = e, r[6] = 112 | t >>> 8, r[7] = t, r[8] = 128 | i >>> 24, r[9] = i >>> 16, r[10] = i >>> 8, r[11] = i, r[12] = s >>> 24, r[13] = s >>> 16, r[14] = s >>> 8, r[15] = s, new tm(r)
                }
                toString() {
                    for (var e = "", t = 0; t < this.bytes.length; t++) e = e + tv.charAt(this.bytes[t] >>> 4) + tv.charAt(15 & this.bytes[t]), 3 !== t && 5 !== t && 7 !== t && 9 !== t || (e += "-");
                    if (36 !== e.length) throw Error("Invalid UUIDv7 was generated");
                    return e
                }
                clone() {
                    return new tm(this.bytes.slice(0))
                }
                equals(e) {
                    return 0 === this.compareTo(e)
                }
                compareTo(e) {
                    for (var t = 0; t < 16; t++) {
                        var i = this.bytes[t] - e.bytes[t];
                        if (0 !== i) return Math.sign(i)
                    }
                    return 0
                }
            }
            class ty {
                constructor() {
                    J(this, "_timestamp", 0), J(this, "_counter", 0), J(this, "_random", new tS)
                }
                generate() {
                    var e = this.generateOrAbort();
                    if ($(e)) {
                        this._timestamp = 0;
                        var t = this.generateOrAbort();
                        if ($(t)) throw Error("Could not generate UUID after timestamp reset");
                        return t
                    }
                    return e
                }
                generateOrAbort() {
                    var e = Date.now();
                    if (e > this._timestamp) this._timestamp = e, this._resetCounter();
                    else {
                        if (!(e + 1e4 > this._timestamp)) return;
                        this._counter++, this._counter > 0x3ffffffffff && (this._timestamp++, this._resetCounter())
                    }
                    return tm.fromFieldsV7(this._timestamp, Math.trunc(this._counter / 0x40000000), 0x3fffffff & this._counter, this._random.nextUint32())
                }
                _resetCounter() {
                    this._counter = 1024 * this._random.nextUint32() + (1023 & this._random.nextUint32())
                }
            }
            var tb, tw = e => {
                if ("undefined" != typeof UUIDV7_DENY_WEAK_RNG && UUIDV7_DENY_WEAK_RNG) throw Error("no cryptographically strong RNG available");
                for (var t = 0; t < e.length; t++) e[t] = 65536 * Math.trunc(65536 * Math.random()) + Math.trunc(65536 * Math.random());
                return e
            };
            r && !$(r.crypto) && crypto.getRandomValues && (tw = e => crypto.getRandomValues(e));
            class tS {
                constructor() {
                    J(this, "_buffer", new Uint32Array(8)), J(this, "_cursor", 1 / 0)
                }
                nextUint32() {
                    return this._cursor >= this._buffer.length && (tw(this._buffer), this._cursor = 0), this._buffer[this._cursor++]
                }
            }
            var tk, tE = () => tx().toString(),
                tx = () => (tb || (tb = new ty)).generate(),
                tI = "",
                tC = /[a-z0-9][a-z0-9-]+\.[a-z]{2,}$/i,
                tP = {
                    is_supported: () => !!u,
                    error: function(e) {
                        j.error("cookieStore error: " + e)
                    },
                    get: function(e) {
                        if (u) {
                            try {
                                for (var t = e + "=", i = u.cookie.split(";").filter(e => e.length), s = 0; s < i.length; s++) {
                                    for (var r = i[s];
                                        " " == r.charAt(0);) r = r.substring(1, r.length);
                                    if (0 === r.indexOf(t)) return decodeURIComponent(r.substring(t.length, r.length))
                                }
                            } catch (e) {}
                            return null
                        }
                    },
                    parse: function(e) {
                        var t;
                        try {
                            t = JSON.parse(tP.get(e)) || {}
                        } catch (e) {}
                        return t
                    },
                    set: function(e, t, i, s, r) {
                        if (u) try {
                            var n = "",
                                o = "",
                                a = function(e, t) {
                                    if (t) {
                                        var i = function(e) {
                                            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : u;
                                            if (tI) return tI;
                                            if (!t || ["localhost", "127.0.0.1"].includes(e)) return "";
                                            for (var i = e.split("."), s = Math.min(i.length, 8), r = "dmn_chk_" + tE(), n = RegExp("(^|;)\\s*" + r + "=1"); !tI && s--;) {
                                                var o = i.slice(s).join("."),
                                                    a = r + "=1;domain=." + o;
                                                t.cookie = a, n.test(t.cookie) && (t.cookie = a + ";expires=Thu, 01 Jan 1970 00:00:00 GMT", tI = o)
                                            }
                                            return tI
                                        }(e);
                                        if (!i) {
                                            var s, r = (s = e.match(tC)) ? s[0] : "";
                                            r !== i && j.info("Warning: cookie subdomain discovery mismatch", r, i), i = r
                                        }
                                        return i ? "; domain=." + i : ""
                                    }
                                    return ""
                                }(u.location.hostname, s);
                            if (i) {
                                var l = new Date;
                                l.setTime(l.getTime() + 24 * i * 36e5), n = "; expires=" + l.toUTCString()
                            }
                            r && (o = "; secure");
                            var c = e + "=" + encodeURIComponent(JSON.stringify(t)) + n + "; SameSite=Lax; path=/" + a + o;
                            return c.length > 3686.4 && j.warn("cookieStore warning: large cookie, len=" + c.length), u.cookie = c, c
                        } catch (e) {
                            return
                        }
                    },
                    remove: function(e, t) {
                        try {
                            tP.set(e, "", -1, t)
                        } catch (e) {
                            return
                        }
                    }
                },
                tF = null,
                tR = {
                    is_supported: function() {
                        if (!M(tF)) return tF;
                        var e = !0;
                        if ($(r)) e = !1;
                        else try {
                            var t = "__mplssupport__";
                            tR.set(t, "xyz"), '"xyz"' !== tR.get(t) && (e = !1), tR.remove(t)
                        } catch (t) {
                            e = !1
                        }
                        return e || j.error("localStorage unsupported; falling back to cookie store"), tF = e, e
                    },
                    error: function(e) {
                        j.error("localStorage error: " + e)
                    },
                    get: function(e) {
                        try {
                            return null == r ? void 0 : r.localStorage.getItem(e)
                        } catch (e) {
                            tR.error(e)
                        }
                        return null
                    },
                    parse: function(e) {
                        try {
                            return JSON.parse(tR.get(e)) || {}
                        } catch (e) {}
                        return null
                    },
                    set: function(e, t) {
                        try {
                            null == r || r.localStorage.setItem(e, JSON.stringify(t))
                        } catch (e) {
                            tR.error(e)
                        }
                    },
                    remove: function(e) {
                        try {
                            null == r || r.localStorage.removeItem(e)
                        } catch (e) {
                            tR.error(e)
                        }
                    }
                },
                tT = ["distinct_id", ex, eI, ez, ej],
                t$ = V(V({}, tR), {}, {
                    parse: function(e) {
                        try {
                            var t = {};
                            try {
                                t = tP.parse(e) || {}
                            } catch (e) {}
                            var i = Z(t, JSON.parse(tR.get(e) || "{}"));
                            return tR.set(e, i), i
                        } catch (e) {}
                        return null
                    },
                    set: function(e, t, i, s, r, n) {
                        try {
                            tR.set(e, t, void 0, void 0, n);
                            var o = {};
                            tT.forEach(e => {
                                t[e] && (o[e] = t[e])
                            }), Object.keys(o).length && tP.set(e, o, i, s, r, n)
                        } catch (e) {
                            tR.error(e)
                        }
                    },
                    remove: function(e, t) {
                        try {
                            null == r || r.localStorage.removeItem(e), tP.remove(e, t)
                        } catch (e) {
                            tR.error(e)
                        }
                    }
                }),
                tO = {},
                tA = {
                    is_supported: function() {
                        return !0
                    },
                    error: function(e) {
                        j.error("memoryStorage error: " + e)
                    },
                    get: function(e) {
                        return tO[e] || null
                    },
                    parse: function(e) {
                        return tO[e] || null
                    },
                    set: function(e, t) {
                        tO[e] = t
                    },
                    remove: function(e) {
                        delete tO[e]
                    }
                },
                tM = null,
                tL = {
                    is_supported: function() {
                        if (!M(tM)) return tM;
                        if (tM = !0, $(r)) tM = !1;
                        else try {
                            var e = "__support__";
                            tL.set(e, "xyz"), '"xyz"' !== tL.get(e) && (tM = !1), tL.remove(e)
                        } catch (e) {
                            tM = !1
                        }
                        return tM
                    },
                    error: function(e) {
                        j.error("sessionStorage error: ", e)
                    },
                    get: function(e) {
                        try {
                            return null == r ? void 0 : r.sessionStorage.getItem(e)
                        } catch (e) {
                            tL.error(e)
                        }
                        return null
                    },
                    parse: function(e) {
                        try {
                            return JSON.parse(tL.get(e)) || null
                        } catch (e) {}
                        return null
                    },
                    set: function(e, t) {
                        try {
                            null == r || r.sessionStorage.setItem(e, JSON.stringify(t))
                        } catch (e) {
                            tL.error(e)
                        }
                    },
                    remove: function(e) {
                        try {
                            null == r || r.sessionStorage.removeItem(e)
                        } catch (e) {
                            tL.error(e)
                        }
                    }
                };
            ! function(e) {
                e[e.PENDING = -1] = "PENDING", e[e.DENIED = 0] = "DENIED", e[e.GRANTED = 1] = "GRANTED"
            }(tk || (tk = {}));
            class tD {
                constructor(e) {
                    this._instance = e
                }
                get _config() {
                    return this._instance.config
                }
                get consent() {
                    return this._getDnt() ? tk.DENIED : this._storedConsent
                }
                isOptedOut() {
                    return this.consent === tk.DENIED || this.consent === tk.PENDING && this._config.opt_out_capturing_by_default
                }
                isOptedIn() {
                    return !this.isOptedOut()
                }
                optInOut(e) {
                    this._storage.set(this._storageKey, +!!e, this._config.cookie_expiration, this._config.cross_subdomain_cookie, this._config.secure_cookie)
                }
                reset() {
                    this._storage.remove(this._storageKey, this._config.cross_subdomain_cookie)
                }
                get _storageKey() {
                    var {
                        token: e,
                        opt_out_capturing_cookie_prefix: t
                    } = this._instance.config;
                    return (t || "__ph_opt_in_out_") + e
                }
                get _storedConsent() {
                    var e = this._storage.get(this._storageKey);
                    return "1" === e ? tk.GRANTED : "0" === e ? tk.DENIED : tk.PENDING
                }
                get _storage() {
                    if (!this._persistentStore) {
                        var e = this._config.opt_out_capturing_persistence_type;
                        this._persistentStore = "localStorage" === e ? tR : tP;
                        var t = "localStorage" === e ? tP : tR;
                        t.get(this._storageKey) && (this._persistentStore.get(this._storageKey) || this.optInOut("1" === t.get(this._storageKey)), t.remove(this._storageKey, this._config.cross_subdomain_cookie))
                    }
                    return this._persistentStore
                }
                _getDnt() {
                    return !!this._config.respect_dnt && !!eo([null == c ? void 0 : c.doNotTrack, null == c ? void 0 : c.msDoNotTrack, f.doNotTrack], e => w([!0, 1, "1", "yes"], e))
                }
            }
            var tq = z("[Dead Clicks]"),
                tN = () => !0,
                tB = e => {
                    var t, i = !(null == (t = e.instance.persistence) || !t.get_property(eg)),
                        s = e.instance.config.capture_dead_clicks;
                    return q(s) ? s : i
                };
            class tH {
                get lazyLoadedDeadClicksAutocapture() {
                    return this._lazyLoadedDeadClicksAutocapture
                }
                constructor(e, t, i) {
                    this.instance = e, this.isEnabled = t, this.onCapture = i, this.startIfEnabled()
                }
                onRemoteConfig(e) {
                    this.instance.persistence && this.instance.persistence.register({
                        [eg]: null == e ? void 0 : e.captureDeadClicks
                    }), this.startIfEnabled()
                }
                startIfEnabled() {
                    this.isEnabled(this) && this._loadScript(() => {
                        this._start()
                    })
                }
                _loadScript(e) {
                    var t, i, s;
                    null != (t = f.__PosthogExtensions__) && t.initDeadClicksAutocapture && e(), null == (i = f.__PosthogExtensions__) || null == (s = i.loadExternalDependency) || s.call(i, this.instance, "dead-clicks-autocapture", t => {
                        t ? tq.error("failed to load script", t) : e()
                    })
                }
                _start() {
                    var e;
                    if (u) {
                        if (!this._lazyLoadedDeadClicksAutocapture && null != (e = f.__PosthogExtensions__) && e.initDeadClicksAutocapture) {
                            var t = R(this.instance.config.capture_dead_clicks) ? this.instance.config.capture_dead_clicks : {};
                            t.__onCapture = this.onCapture, this._lazyLoadedDeadClicksAutocapture = f.__PosthogExtensions__.initDeadClicksAutocapture(this.instance, t), this._lazyLoadedDeadClicksAutocapture.start(u), tq.info("starting...")
                        }
                    } else tq.error("`document` not found. Cannot start.")
                }
                stop() {
                    this._lazyLoadedDeadClicksAutocapture && (this._lazyLoadedDeadClicksAutocapture.stop(), this._lazyLoadedDeadClicksAutocapture = void 0, tq.info("stopping..."))
                }
            }
            var tj = z("[ExceptionAutocapture]");
            class tz {
                constructor(e) {
                    var t;
                    J(this, "_startCapturing", () => {
                        var e;
                        if (r && this.isEnabled && null != (e = f.__PosthogExtensions__) && e.errorWrappingFunctions) {
                            var t = f.__PosthogExtensions__.errorWrappingFunctions.wrapOnError,
                                i = f.__PosthogExtensions__.errorWrappingFunctions.wrapUnhandledRejection,
                                s = f.__PosthogExtensions__.errorWrappingFunctions.wrapConsoleError;
                            try {
                                !this._unwrapOnError && this.config.capture_unhandled_errors && (this._unwrapOnError = t(this.captureException.bind(this))), !this._unwrapUnhandledRejection && this.config.capture_unhandled_rejections && (this._unwrapUnhandledRejection = i(this.captureException.bind(this))), !this._unwrapConsoleError && this.config.capture_console_errors && (this._unwrapConsoleError = s(this.captureException.bind(this)))
                            } catch (e) {
                                tj.error("failed to start", e), this._stopCapturing()
                            }
                        }
                    }), this.instance = e, this.remoteEnabled = !(null == (t = this.instance.persistence) || !t.props[e_]), this.config = this._requiredConfig(), this.startIfEnabled()
                }
                _requiredConfig() {
                    var e = this.instance.config.capture_exceptions,
                        t = {
                            capture_unhandled_errors: !1,
                            capture_unhandled_rejections: !1,
                            capture_console_errors: !1
                        };
                    return R(e) ? t = V(V({}, t), e) : ($(e) ? this.remoteEnabled : e) && (t = V(V({}, t), {}, {
                        capture_unhandled_errors: !0,
                        capture_unhandled_rejections: !0
                    })), t
                }
                get isEnabled() {
                    return this.config.capture_console_errors || this.config.capture_unhandled_errors || this.config.capture_unhandled_rejections
                }
                startIfEnabled() {
                    this.isEnabled && (tj.info("enabled"), this._loadScript(this._startCapturing))
                }
                _loadScript(e) {
                    var t, i, s;
                    null != (t = f.__PosthogExtensions__) && t.errorWrappingFunctions && e(), null == (i = f.__PosthogExtensions__) || null == (s = i.loadExternalDependency) || s.call(i, this.instance, "exception-autocapture", t => {
                        if (t) return tj.error("failed to load script", t);
                        e()
                    })
                }
                _stopCapturing() {
                    var e, t, i;
                    null == (e = this._unwrapOnError) || e.call(this), this._unwrapOnError = void 0, null == (t = this._unwrapUnhandledRejection) || t.call(this), this._unwrapUnhandledRejection = void 0, null == (i = this._unwrapConsoleError) || i.call(this), this._unwrapConsoleError = void 0
                }
                onRemoteConfig(e) {
                    var t = e.autocaptureExceptions;
                    this.remoteEnabled = !!t, this.config = this._requiredConfig(), this.instance.persistence && this.instance.persistence.register({
                        [e_]: this.remoteEnabled
                    }), this.startIfEnabled()
                }
                captureException(e) {
                    var t = this.instance.requestRouter.endpointFor("ui");
                    e.$exception_personURL = "".concat(t, "/project/").concat(this.instance.config.token, "/person/").concat(this.instance.get_distinct_id()), this.instance.exceptions.sendExceptionEvent(e)
                }
            }

            function tU(e) {
                return !$(Event) && tW(e, Event)
            }

            function tW(e, t) {
                try {
                    return e instanceof t
                } catch (e) {
                    return !1
                }
            }

            function tG(e) {
                switch (Object.prototype.toString.call(e)) {
                    case "[object Error]":
                    case "[object Exception]":
                    case "[object DOMException]":
                    case "[object DOMError]":
                        return !0;
                    default:
                        return tW(e, Error)
                }
            }

            function tV(e, t) {
                return Object.prototype.toString.call(e) === "[object ".concat(t, "]")
            }

            function tJ(e) {
                return tV(e, "DOMError")
            }
            var tY = /\(error: (.*)\)/;

            function tK(e, t, i, s) {
                var r = {
                    platform: "web:javascript",
                    filename: e,
                    function: "<anonymous>" === t ? "?" : t,
                    in_app: !0
                };
                return $(i) || (r.lineno = i), $(s) || (r.colno = s), r
            }
            var tX, tQ, tZ, t0 = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i,
                t1 = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
                t2 = /\((\S*)(?::(\d+))(?::(\d+))\)/,
                t3 = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
                t5 = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
                t6 = function() {
                    for (var e = arguments.length, t = Array(e), i = 0; i < e; i++) t[i] = arguments[i];
                    var s = t.sort((e, t) => e[0] - t[0]).map(e => e[1]);
                    return function(e) {
                        for (var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, i = [], r = e.split("\n"), n = t; n < r.length; n++) {
                            var o = r[n];
                            if (!(o.length > 1024)) {
                                var a = tY.test(o) ? o.replace(tY, "$1") : o;
                                if (!a.match(/\S*Error: /)) {
                                    for (var l of s) {
                                        var c = l(a);
                                        if (c) {
                                            i.push(c);
                                            break
                                        }
                                    }
                                    if (i.length >= 50) break
                                }
                            }
                        }
                        if (!i.length) return [];
                        var u = Array.from(i);
                        return u.reverse(), u.slice(0, 50).map(e => {
                            var t;
                            return V(V({}, e), {}, {
                                filename: e.filename || ((t = u)[t.length - 1] || {}).filename,
                                function: e.function || "?"
                            })
                        })
                    }
                }([30, e => {
                    var t = t0.exec(e);
                    if (t) {
                        var [, i, s, r] = t;
                        return tK(i, "?", +s, +r)
                    }
                    var n = t1.exec(e);
                    if (n) {
                        if (n[2] && 0 === n[2].indexOf("eval")) {
                            var o = t2.exec(n[2]);
                            o && (n[2] = o[1], n[3] = o[2], n[4] = o[3])
                        }
                        var [a, l] = t4(n[1] || "?", n[2]);
                        return tK(l, a, n[3] ? +n[3] : void 0, n[4] ? +n[4] : void 0)
                    }
                }], [50, e => {
                    var t = t3.exec(e);
                    if (t) {
                        if (t[3] && t[3].indexOf(" > eval") > -1) {
                            var i = t5.exec(t[3]);
                            i && (t[1] = t[1] || "eval", t[3] = i[1], t[4] = i[2], t[5] = "")
                        }
                        var s = t[3],
                            r = t[1] || "?";
                        return [r, s] = t4(r, s), tK(s, r, t[4] ? +t[4] : void 0, t[5] ? +t[5] : void 0)
                    }
                }]),
                t4 = (e, t) => {
                    var i = -1 !== e.indexOf("safari-extension"),
                        s = -1 !== e.indexOf("safari-web-extension");
                    return i || s ? [-1 !== e.indexOf("@") ? e.split("@")[0] : "?", i ? "safari-extension:".concat(t) : "safari-web-extension:".concat(t)] : [e, t]
                },
                t8 = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/i;

            function t7(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0,
                    i = e.stacktrace || e.stack || "",
                    s = e && t9.test(e.message) ? 1 : 0;
                try {
                    var r, n, o = (r = t6(i, s), n = function(e) {
                        var t = globalThis._posthogChunkIds;
                        if (!t) return {};
                        var i = Object.keys(t);
                        return tZ && i.length === tQ || (tQ = i.length, tZ = i.reduce((i, s) => {
                            tX || (tX = {});
                            var r = tX[s];
                            if (r) i[r[0]] = r[1];
                            else
                                for (var n = e(s), o = n.length - 1; o >= 0; o--) {
                                    var a = n[o],
                                        l = null == a ? void 0 : a.filename,
                                        c = t[s];
                                    if (l && c) {
                                        i[l] = c, tX[s] = [l, c];
                                        break
                                    }
                                }
                            return i
                        }, {})), tZ
                    }(t6), r.forEach(e => {
                        e.filename && (e.chunk_id = n[e.filename])
                    }), r);
                    return o.slice(0, o.length - t)
                } catch (e) {}
                return []
            }
            var t9 = /Minified React error #\d+;/i;

            function ie(e, t) {
                return {
                    $exception_list: function e(t, i) {
                        var s, r, n, o, a, l, c, u, d = (s = t, r = i, l = t7(s), c = null == (o = null == r ? void 0 : r.handled) || o, u = null != (a = null == r ? void 0 : r.synthetic) && a, {
                            type: null != r && r.overrideExceptionType ? r.overrideExceptionType : s.name,
                            value: (n = s.message).error && "string" == typeof n.error.message ? String(n.error.message) : String(n),
                            stacktrace: {
                                frames: l,
                                type: "raw"
                            },
                            mechanism: {
                                handled: c,
                                synthetic: u
                            }
                        });
                        return t.cause && tG(t.cause) && t.cause !== t ? [d, ...e(t.cause, {
                            handled: null == i ? void 0 : i.handled,
                            synthetic: null == i ? void 0 : i.synthetic
                        })] : [d]
                    }(e, t),
                    $exception_level: "error"
                }
            }

            function it(e, t) {
                var i, s, r, n = null == (i = null == t ? void 0 : t.handled) || i,
                    o = null == (s = null == t ? void 0 : t.synthetic) || s,
                    a = {
                        type: null != t && t.overrideExceptionType ? t.overrideExceptionType : null != (r = null == t ? void 0 : t.defaultExceptionType) ? r : "Error",
                        value: e || (null == t ? void 0 : t.defaultExceptionMessage),
                        mechanism: {
                            handled: n,
                            synthetic: o
                        }
                    };
                if (null != t && t.syntheticException) {
                    var l = t7(t.syntheticException, 1);
                    l.length && (a.stacktrace = {
                        frames: l,
                        type: "raw"
                    })
                }
                return {
                    $exception_list: [a],
                    $exception_level: "error"
                }
            }

            function ii(e, t, i) {
                try {
                    if (!(t in e)) return () => {};
                    var s = e[t],
                        r = i(s);
                    return F(r) && (r.prototype = r.prototype || {}, Object.defineProperties(r, {
                        __posthog_wrapped__: {
                            enumerable: !1,
                            value: !0
                        }
                    })), e[t] = r, () => {
                        e[t] = s
                    }
                } catch (e) {
                    return () => {}
                }
            }
            class is {
                constructor(e) {
                    var t;
                    this._instance = e, this._lastPathname = (null == r || null == (t = r.location) ? void 0 : t.pathname) || ""
                }
                get isEnabled() {
                    return "history_change" === this._instance.config.capture_pageview
                }
                startIfEnabled() {
                    this.isEnabled && (j.info("History API monitoring enabled, starting..."), this.monitorHistoryChanges())
                }
                stop() {
                    this._popstateListener && this._popstateListener(), this._popstateListener = void 0, j.info("History API monitoring stopped")
                }
                monitorHistoryChanges() {
                    var e, t;
                    if (r && r.history) {
                        var i = this;
                        null != (e = r.history.pushState) && e.__posthog_wrapped__ || ii(r.history, "pushState", e => function(t, s, r) {
                            e.call(this, t, s, r), i._capturePageview("pushState")
                        }), null != (t = r.history.replaceState) && t.__posthog_wrapped__ || ii(r.history, "replaceState", e => function(t, s, r) {
                            e.call(this, t, s, r), i._capturePageview("replaceState")
                        }), this._setupPopstateListener()
                    }
                }
                _capturePageview(e) {
                    try {
                        var t, i = null == r || null == (t = r.location) ? void 0 : t.pathname;
                        if (!i) return;
                        i !== this._lastPathname && this.isEnabled && this._instance.capture("$pageview", {
                            navigation_type: e
                        }), this._lastPathname = i
                    } catch (t) {
                        j.error("Error capturing ".concat(e, " pageview"), t)
                    }
                }
                _setupPopstateListener() {
                    if (!this._popstateListener) {
                        var e = () => {
                            this._capturePageview("popstate")
                        };
                        ea(r, "popstate", e), this._popstateListener = () => {
                            r && r.removeEventListener("popstate", e)
                        }
                    }
                }
            }

            function ir(e) {
                var t, i;
                return (null == (t = JSON.stringify(e, (i = [], function(e, t) {
                    if (R(t)) {
                        for (; i.length > 0 && i[i.length - 1] !== this;) i.pop();
                        return i.includes(t) ? "[Circular]" : (i.push(t), t)
                    }
                    return t
                }))) ? void 0 : t.length) || 0
            }
            var io = (e => (e[e.DomContentLoaded = 0] = "DomContentLoaded", e[e.Load = 1] = "Load", e[e.FullSnapshot = 2] = "FullSnapshot", e[e.IncrementalSnapshot = 3] = "IncrementalSnapshot", e[e.Meta = 4] = "Meta", e[e.Custom = 5] = "Custom", e[e.Plugin = 6] = "Plugin", e))(io || {}),
                ia = (e => (e[e.Mutation = 0] = "Mutation", e[e.MouseMove = 1] = "MouseMove", e[e.MouseInteraction = 2] = "MouseInteraction", e[e.Scroll = 3] = "Scroll", e[e.ViewportResize = 4] = "ViewportResize", e[e.Input = 5] = "Input", e[e.TouchMove = 6] = "TouchMove", e[e.MediaInteraction = 7] = "MediaInteraction", e[e.StyleSheetRule = 8] = "StyleSheetRule", e[e.CanvasMutation = 9] = "CanvasMutation", e[e.Font = 10] = "Font", e[e.Log = 11] = "Log", e[e.Drag = 12] = "Drag", e[e.StyleDeclaration = 13] = "StyleDeclaration", e[e.Selection = 14] = "Selection", e[e.AdoptedStyleSheet = 15] = "AdoptedStyleSheet", e[e.CustomElement = 16] = "CustomElement", e))(ia || {}),
                il = "[SessionRecording]",
                ic = "redacted",
                iu = {
                    initiatorTypes: ["audio", "beacon", "body", "css", "early-hint", "embed", "fetch", "frame", "iframe", "icon", "image", "img", "input", "link", "navigation", "object", "ping", "script", "track", "video", "xmlhttprequest"],
                    maskRequestFn: e => e,
                    recordHeaders: !1,
                    recordBody: !1,
                    recordInitialRequests: !1,
                    recordPerformance: !1,
                    performanceEntryTypeToObserve: ["first-input", "navigation", "paint", "resource"],
                    payloadSizeLimitBytes: 1e6,
                    payloadHostDenyList: [".lr-ingest.io", ".ingest.sentry.io", ".clarity.ms", "analytics.google.com"]
                },
                id = ["authorization", "x-forwarded-for", "authorization", "cookie", "set-cookie", "x-api-key", "x-real-ip", "remote-addr", "forwarded", "proxy-authorization", "x-csrf-token", "x-csrftoken", "x-xsrf-token"],
                ih = ["password", "secret", "passwd", "api_key", "apikey", "auth", "credentials", "mysql_pwd", "privatekey", "private_key", "token"],
                i_ = ["/s/", "/e/", "/i/"];

            function ip(e, t, i, s) {
                if (L(e)) return e;
                var r = (null == t ? void 0 : t["content-length"]) || new Blob([e]).size;
                return O(r) && (r = parseInt(r)), r > i ? il + " ".concat(s, " body too large to record (").concat(r, " bytes)") : e
            }

            function ig(e, t) {
                if (L(e)) return e;
                var i = e;
                return tr(i, !1) || (i = il + " " + t + " body " + ic), Q(ih, e => {
                    var s, r;
                    null != (s = i) && s.length && -1 !== (null == (r = i) ? void 0 : r.indexOf(e)) && (i = il + " " + t + " body " + ic + " as might contain: " + e)
                }), i
            }
            var iv = (e, t) => {
                var i, s, r = {
                        payloadSizeLimitBytes: iu.payloadSizeLimitBytes,
                        performanceEntryTypeToObserve: [...iu.performanceEntryTypeToObserve],
                        payloadHostDenyList: [...t.payloadHostDenyList || [], ...iu.payloadHostDenyList]
                    },
                    n = !1 !== e.session_recording.recordHeaders && t.recordHeaders,
                    o = !1 !== e.session_recording.recordBody && t.recordBody,
                    a = !1 !== e.capture_performance && t.recordPerformance,
                    l = (s = Math.min(1e6, null != (i = r.payloadSizeLimitBytes) ? i : 1e6), e => (null != e && e.requestBody && (e.requestBody = ip(e.requestBody, e.requestHeaders, s, "Request")), null != e && e.responseBody && (e.responseBody = ip(e.responseBody, e.responseHeaders, s, "Response")), e)),
                    c = t => {
                        var i;
                        return l(((e, t) => {
                            var i, s = tc(e.name),
                                r = 0 === t.indexOf("http") ? null == (i = tc(t)) ? void 0 : i.pathname : t;
                            "/" === r && (r = "");
                            var n = null == s ? void 0 : s.pathname.replace(r || "", "");
                            if (!(s && n && i_.some(e => 0 === n.indexOf(e)))) return e
                        })((L(i = t.requestHeaders) || Q(Object.keys(null != i ? i : {}), e => {
                            id.includes(e.toLowerCase()) && (i[e] = ic)
                        }), t), e.api_host))
                    },
                    u = F(e.session_recording.maskNetworkRequestFn);
                return u && F(e.session_recording.maskCapturedNetworkRequestFn) && j.warn("Both `maskNetworkRequestFn` and `maskCapturedNetworkRequestFn` are defined. `maskNetworkRequestFn` will be ignored."), u && (e.session_recording.maskCapturedNetworkRequestFn = t => {
                    var i = e.session_recording.maskNetworkRequestFn({
                        url: t.name
                    });
                    return V(V({}, t), {}, {
                        name: null == i ? void 0 : i.url
                    })
                }), r.maskRequestFn = F(e.session_recording.maskCapturedNetworkRequestFn) ? t => {
                    var i, s, r, n = c(t);
                    return n && null != (i = null == (s = (r = e.session_recording).maskCapturedNetworkRequestFn) ? void 0 : s.call(r, n)) ? i : void 0
                } : e => (function(e) {
                    if (!$(e)) return e.requestBody = ig(e.requestBody, "Request"), e.responseBody = ig(e.responseBody, "Response"), e
                })(c(e)), V(V(V({}, iu), r), {}, {
                    recordHeaders: n,
                    recordBody: o,
                    recordPerformance: a,
                    recordInitialRequests: a
                })
            };

            function im(e, t, i, s, r) {
                return t > i && (j.warn("min cannot be greater than max."), t = i), D(e) ? e > i ? (s && j.warn(s + " cannot be  greater than max: " + i + ". Using max value instead."), i) : e < t ? (s && j.warn(s + " cannot be less than min: " + t + ". Using min value instead."), t) : e : (s && j.warn(s + " must be a number. using max or fallback. max: " + i + ", fallback: " + r), im(r || i, t, i, s))
            }
            class iy {
                constructor(e) {
                    var t, i, s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    J(this, "_bucketSize", 100), J(this, "_refillRate", 10), J(this, "_mutationBuckets", {}), J(this, "_loggedTracker", {}), J(this, "_refillBuckets", () => {
                        Object.keys(this._mutationBuckets).forEach(e => {
                            this._mutationBuckets[e] = this._mutationBuckets[e] + this._refillRate, this._mutationBuckets[e] >= this._bucketSize && delete this._mutationBuckets[e]
                        })
                    }), J(this, "_getNodeOrRelevantParent", e => {
                        var t = this._rrweb.mirror.getNode(e);
                        if ("svg" !== (null == t ? void 0 : t.nodeName) && t instanceof Element) {
                            var i = t.closest("svg");
                            if (i) return [this._rrweb.mirror.getId(i), i]
                        }
                        return [e, t]
                    }), J(this, "_numberOfChanges", e => {
                        var t, i, s, r, n, o, a, l;
                        return (null != (t = null == (i = e.removes) ? void 0 : i.length) ? t : 0) + (null != (s = null == (r = e.attributes) ? void 0 : r.length) ? s : 0) + (null != (n = null == (o = e.texts) ? void 0 : o.length) ? n : 0) + (null != (a = null == (l = e.adds) ? void 0 : l.length) ? a : 0)
                    }), J(this, "throttleMutations", e => {
                        if (3 !== e.type || 0 !== e.data.source) return e;
                        var t = e.data,
                            i = this._numberOfChanges(t);
                        t.attributes && (t.attributes = t.attributes.filter(e => {
                            var t, i, s, [r, n] = this._getNodeOrRelevantParent(e.id);
                            return 0 !== this._mutationBuckets[r] && (this._mutationBuckets[r] = null != (t = this._mutationBuckets[r]) ? t : this._bucketSize, this._mutationBuckets[r] = Math.max(this._mutationBuckets[r] - 1, 0), 0 === this._mutationBuckets[r] && (this._loggedTracker[r] || (this._loggedTracker[r] = !0, null == (i = (s = this._options).onBlockedNode) || i.call(s, r, n))), e)
                        }));
                        var s = this._numberOfChanges(t);
                        return 0 !== s || i === s ? e : void 0
                    }), this._rrweb = e, this._options = s, this._refillRate = im(null != (t = this._options.refillRate) ? t : this._refillRate, 0, 100, "mutation throttling refill rate"), this._bucketSize = im(null != (i = this._options.bucketSize) ? i : this._bucketSize, 0, 100, "mutation throttling bucket size"), setInterval(() => {
                        this._refillBuckets()
                    }, 1e3)
                }
            }
            var ib = Uint8Array,
                iw = Uint16Array,
                iS = Uint32Array,
                ik = new ib([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 0, 0, 0]),
                iE = new ib([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 0, 0]),
                ix = new ib([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
                iI = function(e, t) {
                    for (var i = new iw(31), s = 0; s < 31; ++s) i[s] = t += 1 << e[s - 1];
                    var r = new iS(i[30]);
                    for (s = 1; s < 30; ++s)
                        for (var n = i[s]; n < i[s + 1]; ++n) r[n] = n - i[s] << 5 | s;
                    return [i, r]
                },
                iC = iI(ik, 2),
                iP = iC[0],
                iF = iC[1];
            iP[28] = 258, iF[258] = 28;
            for (var iR = iI(iE, 0)[1], iT = new iw(32768), i$ = 0; i$ < 32768; ++i$) {
                var iO = (43690 & i$) >>> 1 | (21845 & i$) << 1;
                iO = (61680 & (iO = (52428 & iO) >>> 2 | (13107 & iO) << 2)) >>> 4 | (3855 & iO) << 4, iT[i$] = ((65280 & iO) >>> 8 | (255 & iO) << 8) >>> 1
            }
            var iA = function(e, t, i) {
                    for (var s = e.length, r = 0, n = new iw(t); r < s; ++r) ++n[e[r] - 1];
                    var o, a = new iw(t);
                    for (r = 0; r < t; ++r) a[r] = a[r - 1] + n[r - 1] << 1;
                    if (i) {
                        o = new iw(1 << t);
                        var l = 15 - t;
                        for (r = 0; r < s; ++r)
                            if (e[r])
                                for (var c = r << 4 | e[r], u = t - e[r], d = a[e[r] - 1]++ << u, h = d | (1 << u) - 1; d <= h; ++d) o[iT[d] >>> l] = c
                    } else
                        for (o = new iw(s), r = 0; r < s; ++r) o[r] = iT[a[e[r] - 1]++] >>> 15 - e[r];
                    return o
                },
                iM = new ib(288);
            for (i$ = 0; i$ < 144; ++i$) iM[i$] = 8;
            for (i$ = 144; i$ < 256; ++i$) iM[i$] = 9;
            for (i$ = 256; i$ < 280; ++i$) iM[i$] = 7;
            for (i$ = 280; i$ < 288; ++i$) iM[i$] = 8;
            var iL = new ib(32);
            for (i$ = 0; i$ < 32; ++i$) iL[i$] = 5;
            var iD = iA(iM, 9, 0),
                iq = iA(iL, 5, 0),
                iN = function(e) {
                    return (e / 8 | 0) + (7 & e && 1)
                },
                iB = function(e, t, i) {
                    (null == i || i > e.length) && (i = e.length);
                    var s = new(e instanceof iw ? iw : e instanceof iS ? iS : ib)(i - t);
                    return s.set(e.subarray(t, i)), s
                },
                iH = function(e, t, i) {
                    i <<= 7 & t;
                    var s = t / 8 | 0;
                    e[s] |= i, e[s + 1] |= i >>> 8
                },
                ij = function(e, t, i) {
                    i <<= 7 & t;
                    var s = t / 8 | 0;
                    e[s] |= i, e[s + 1] |= i >>> 8, e[s + 2] |= i >>> 16
                },
                iz = function(e, t) {
                    for (var i = [], s = 0; s < e.length; ++s) e[s] && i.push({
                        s: s,
                        f: e[s]
                    });
                    var r = i.length,
                        n = i.slice();
                    if (!r) return [new ib(0), 0];
                    if (1 == r) {
                        var o = new ib(i[0].s + 1);
                        return o[i[0].s] = 1, [o, 1]
                    }
                    i.sort(function(e, t) {
                        return e.f - t.f
                    }), i.push({
                        s: -1,
                        f: 25001
                    });
                    var a = i[0],
                        l = i[1],
                        c = 0,
                        u = 1,
                        d = 2;
                    for (i[0] = {
                            s: -1,
                            f: a.f + l.f,
                            l: a,
                            r: l
                        }; u != r - 1;) a = i[i[c].f < i[d].f ? c++ : d++], l = i[c != u && i[c].f < i[d].f ? c++ : d++], i[u++] = {
                        s: -1,
                        f: a.f + l.f,
                        l: a,
                        r: l
                    };
                    var h = n[0].s;
                    for (s = 1; s < r; ++s) n[s].s > h && (h = n[s].s);
                    var _ = new iw(h + 1),
                        p = iU(i[u - 1], _, 0);
                    if (p > t) {
                        s = 0;
                        var g = 0,
                            f = p - t,
                            v = 1 << f;
                        for (n.sort(function(e, t) {
                                return _[t.s] - _[e.s] || e.f - t.f
                            }); s < r; ++s) {
                            var m = n[s].s;
                            if (!(_[m] > t)) break;
                            g += v - (1 << p - _[m]), _[m] = t
                        }
                        for (g >>>= f; g > 0;) {
                            var y = n[s].s;
                            _[y] < t ? g -= 1 << t - _[y]++ - 1 : ++s
                        }
                        for (; s >= 0 && g; --s) {
                            var b = n[s].s;
                            _[b] == t && (--_[b], ++g)
                        }
                        p = t
                    }
                    return [new ib(_), p]
                },
                iU = function(e, t, i) {
                    return -1 == e.s ? Math.max(iU(e.l, t, i + 1), iU(e.r, t, i + 1)) : t[e.s] = i
                },
                iW = function(e) {
                    for (var t = e.length; t && !e[--t];);
                    for (var i = new iw(++t), s = 0, r = e[0], n = 1, o = function(e) {
                            i[s++] = e
                        }, a = 1; a <= t; ++a)
                        if (e[a] == r && a != t) ++n;
                        else {
                            if (!r && n > 2) {
                                for (; n > 138; n -= 138) o(32754);
                                n > 2 && (o(n > 10 ? n - 11 << 5 | 28690 : n - 3 << 5 | 12305), n = 0)
                            } else if (n > 3) {
                                for (o(r), --n; n > 6; n -= 6) o(8304);
                                n > 2 && (o(n - 3 << 5 | 8208), n = 0)
                            }
                            for (; n--;) o(r);
                            n = 1, r = e[a]
                        }
                    return [i.subarray(0, s), t]
                },
                iG = function(e, t) {
                    for (var i = 0, s = 0; s < t.length; ++s) i += e[s] * t[s];
                    return i
                },
                iV = function(e, t, i) {
                    var s = i.length,
                        r = iN(t + 2);
                    e[r] = 255 & s, e[r + 1] = s >>> 8, e[r + 2] = 255 ^ e[r], e[r + 3] = 255 ^ e[r + 1];
                    for (var n = 0; n < s; ++n) e[r + n + 4] = i[n];
                    return 8 * (r + 4 + s)
                },
                iJ = function(e, t, i, s, r, n, o, a, l, c, u) {
                    iH(t, u++, i), ++r[256];
                    for (var d = iz(r, 15), h = d[0], _ = d[1], p = iz(n, 15), g = p[0], f = p[1], v = iW(h), m = v[0], y = v[1], b = iW(g), w = b[0], S = b[1], k = new iw(19), E = 0; E < m.length; ++E) k[31 & m[E]]++;
                    for (E = 0; E < w.length; ++E) k[31 & w[E]]++;
                    for (var x = iz(k, 7), I = x[0], C = x[1], P = 19; P > 4 && !I[ix[P - 1]]; --P);
                    var F, R, T, $, O = c + 5 << 3,
                        A = iG(r, iM) + iG(n, iL) + o,
                        M = iG(r, h) + iG(n, g) + o + 14 + 3 * P + iG(k, I) + (2 * k[16] + 3 * k[17] + 7 * k[18]);
                    if (O <= A && O <= M) return iV(t, u, e.subarray(l, l + c));
                    if (iH(t, u, 1 + (M < A)), u += 2, M < A) {
                        F = iA(h, _, 0), R = h, T = iA(g, f, 0), $ = g;
                        var L = iA(I, C, 0);
                        for (iH(t, u, y - 257), iH(t, u + 5, S - 1), iH(t, u + 10, P - 4), u += 14, E = 0; E < P; ++E) iH(t, u + 3 * E, I[ix[E]]);
                        u += 3 * P;
                        for (var D = [m, w], q = 0; q < 2; ++q) {
                            var N = D[q];
                            for (E = 0; E < N.length; ++E) {
                                var B = 31 & N[E];
                                iH(t, u, L[B]), u += I[B], B > 15 && (iH(t, u, N[E] >>> 5 & 127), u += N[E] >>> 12)
                            }
                        }
                    } else F = iD, R = iM, T = iq, $ = iL;
                    for (E = 0; E < a; ++E)
                        if (s[E] > 255) {
                            ij(t, u, F[(B = s[E] >>> 18 & 31) + 257]), u += R[B + 257], B > 7 && (iH(t, u, s[E] >>> 23 & 31), u += ik[B]);
                            var H = 31 & s[E];
                            ij(t, u, T[H]), u += $[H], H > 3 && (ij(t, u, s[E] >>> 5 & 8191), u += iE[H])
                        } else ij(t, u, F[s[E]]), u += R[s[E]];
                    return ij(t, u, F[256]), u + R[256]
                },
                iY = new iS([65540, 131080, 131088, 131104, 262176, 1048704, 1048832, 2114560, 2117632]),
                iK = function() {
                    for (var e = new iS(256), t = 0; t < 256; ++t) {
                        for (var i = t, s = 9; --s;) i = (1 & i && 0xedb88320) ^ i >>> 1;
                        e[t] = i
                    }
                    return e
                }(),
                iX = function() {
                    var e = 0xffffffff;
                    return {
                        p: function(t) {
                            for (var i = e, s = 0; s < t.length; ++s) i = iK[255 & i ^ t[s]] ^ i >>> 8;
                            e = i
                        },
                        d: function() {
                            return 0xffffffff ^ e
                        }
                    }
                },
                iQ = function(e, t, i) {
                    for (; i; ++t) e[t] = i, i >>>= 8
                },
                iZ = function(e, t) {
                    var i = t.filename;
                    if (e[0] = 31, e[1] = 139, e[2] = 8, e[8] = t.level < 2 ? 4 : 2 * (9 == t.level), e[9] = 3, 0 != t.mtime && iQ(e, 4, Math.floor(new Date(t.mtime || Date.now()) / 1e3)), i) {
                        e[3] = 8;
                        for (var s = 0; s <= i.length; ++s) e[s + 10] = i.charCodeAt(s)
                    }
                };

            function i0(e, t) {
                void 0 === t && (t = {});
                var i, s, r, n = iX(),
                    o = e.length;
                n.p(e);
                var a = (s = t, r = 10 + ((i = t).filename && i.filename.length + 1 || 0), function(e, t, i, s, r, n) {
                        var o = e.length,
                            a = new ib(s + o + 5 * (1 + Math.floor(o / 7e3)) + 8),
                            l = a.subarray(s, a.length - r),
                            c = 0;
                        if (!t || o < 8)
                            for (var u = 0; u <= o; u += 65535) {
                                var d = u + 65535;
                                d < o ? c = iV(l, c, e.subarray(u, d)) : (l[u] = n, c = iV(l, c, e.subarray(u, o)))
                            } else {
                                for (var h = iY[t - 1], _ = h >>> 13, p = 8191 & h, g = (1 << i) - 1, f = new iw(32768), v = new iw(g + 1), m = Math.ceil(i / 3), y = 2 * m, b = function(t) {
                                        return (e[t] ^ e[t + 1] << m ^ e[t + 2] << y) & g
                                    }, w = new iS(25e3), S = new iw(288), k = new iw(32), E = 0, x = 0, I = (u = 0, 0), C = 0, P = 0; u < o; ++u) {
                                    var F = b(u),
                                        R = 32767 & u,
                                        T = v[F];
                                    if (f[R] = T, v[F] = R, C <= u) {
                                        var $ = o - u;
                                        if ((E > 7e3 || I > 24576) && $ > 423) {
                                            c = iJ(e, l, 0, w, S, k, x, I, P, u - P, c), I = E = x = 0, P = u;
                                            for (var O = 0; O < 286; ++O) S[O] = 0;
                                            for (O = 0; O < 30; ++O) k[O] = 0
                                        }
                                        var A = 2,
                                            M = 0,
                                            L = p,
                                            D = R - T & 32767;
                                        if ($ > 2 && F == b(u - D))
                                            for (var q = Math.min(_, $) - 1, N = Math.min(32767, u), B = Math.min(258, $); D <= N && --L && R != T;) {
                                                if (e[u + A] == e[u + A - D]) {
                                                    for (var H = 0; H < B && e[u + H] == e[u + H - D]; ++H);
                                                    if (H > A) {
                                                        if (A = H, M = D, H > q) break;
                                                        var j = Math.min(D, H - 2),
                                                            z = 0;
                                                        for (O = 0; O < j; ++O) {
                                                            var U = u - D + O + 32768 & 32767,
                                                                W = U - f[U] + 32768 & 32767;
                                                            W > z && (z = W, T = U)
                                                        }
                                                    }
                                                }
                                                D += (R = T) - (T = f[R]) + 32768 & 32767
                                            }
                                        if (M) {
                                            w[I++] = 0x10000000 | iF[A] << 18 | iR[M];
                                            var G = 31 & iF[A],
                                                V = 31 & iR[M];
                                            x += ik[G] + iE[V], ++S[257 + G], ++k[V], C = u + A, ++E
                                        } else w[I++] = e[u], ++S[e[u]]
                                    }
                                }
                                c = iJ(e, l, n, w, S, k, x, I, P, u - P, c)
                            }
                        return iB(a, 0, s + iN(c) + r)
                    }(e, null == s.level ? 6 : s.level, null == s.mem ? Math.ceil(1.5 * Math.max(8, Math.min(13, Math.log(e.length)))) : 12 + s.mem, r, 8, !0)),
                    l = a.length;
                return iZ(a, t), iQ(a, l - 8, n.d()), iQ(a, l - 4, o), a
            }

            function i1(e, t) {
                var i = e.length;
                if ("undefined" != typeof TextEncoder) return (new TextEncoder).encode(e);
                for (var s = new ib(e.length + (e.length >>> 1)), r = 0, n = function(e) {
                        s[r++] = e
                    }, o = 0; o < i; ++o) {
                    if (r + 5 > s.length) {
                        var a = new ib(r + 8 + (i - o << 1));
                        a.set(s), s = a
                    }
                    var l = e.charCodeAt(o);
                    l < 128 || t ? n(l) : (l < 2048 ? n(192 | l >>> 6) : (l > 55295 && l < 57344 ? (n(240 | (l = 65536 + (1047552 & l) | 1023 & e.charCodeAt(++o)) >>> 18), n(128 | l >>> 12 & 63)) : n(224 | l >>> 12), n(128 | l >>> 6 & 63)), n(128 | 63 & l))
                }
                return iB(s, 0, r)
            }
            var i2 = "[SessionRecording]",
                i3 = z(i2);

            function i5() {
                var e, t;
                return null == f || null == (e = f.__PosthogExtensions__) || null == (t = e.rrweb) ? void 0 : t.record
            }
            var i6 = [ia.MouseMove, ia.MouseInteraction, ia.Scroll, ia.ViewportResize, ia.Input, ia.TouchMove, ia.MediaInteraction, ia.Drag],
                i4 = e => ({
                    rrwebMethod: e,
                    enqueuedAt: Date.now(),
                    attempt: 1
                });

            function i8(e) {
                return function(e, t) {
                    for (var i = "", s = 0; s < e.length;) {
                        var r = e[s++];
                        r < 128 || t ? i += String.fromCharCode(r) : r < 224 ? i += String.fromCharCode((31 & r) << 6 | 63 & e[s++]) : r < 240 ? i += String.fromCharCode((15 & r) << 12 | (63 & e[s++]) << 6 | 63 & e[s++]) : i += String.fromCharCode(55296 | (r = ((15 & r) << 18 | (63 & e[s++]) << 12 | (63 & e[s++]) << 6 | 63 & e[s++]) - 65536) >> 10, 56320 | 1023 & r)
                    }
                    return i
                }(i0(i1(JSON.stringify(e))), !0)
            }

            function i7(e) {
                return e.type === io.Custom && "sessionIdle" === e.data.tag
            }

            function i9(e, t) {
                return t.some(t => "regex" === t.matching && new RegExp(t.url).test(e))
            }
            class se {
                get _sessionIdleThresholdMilliseconds() {
                    return this._instance.config.session_recording.session_idle_threshold_ms || 3e5
                }
                get started() {
                    return this._captureStarted
                }
                get _sessionManager() {
                    if (!this._instance.sessionManager) throw Error(i2 + " must be started with a valid sessionManager.");
                    return this._instance.sessionManager
                }
                get _fullSnapshotIntervalMillis() {
                    var e, t;
                    return "trigger_pending" === this._triggerStatus ? 6e4 : null != (e = null == (t = this._instance.config.session_recording) ? void 0 : t.full_snapshot_interval_millis) ? e : 3e5
                }
                get _isSampled() {
                    var e = this._instance.get_property(eI);
                    return q(e) ? e : null
                }
                get _sessionDuration() {
                    var e, t, i = null == (e = this._buffer) ? void 0 : e.data[(null == (t = this._buffer) ? void 0 : t.data.length) - 1],
                        {
                            sessionStartTimestamp: s
                        } = this._sessionManager.checkAndGetSessionAndWindowId(!0);
                    return i ? i.timestamp - s : null
                }
                get _isRecordingEnabled() {
                    var e = !!this._instance.get_property(ev),
                        t = !this._instance.config.disable_session_recording;
                    return r && e && t
                }
                get _isConsoleLogCaptureEnabled() {
                    var e = !!this._instance.get_property(em),
                        t = this._instance.config.enable_recording_console_log;
                    return null != t ? t : e
                }
                get _canvasRecording() {
                    var e, t, i, s, r, n, o = this._instance.config.session_recording.captureCanvas,
                        a = this._instance.get_property(ew),
                        l = null != (e = null != (t = null == o ? void 0 : o.recordCanvas) ? t : null == a ? void 0 : a.enabled) && e,
                        c = null != (i = null != (s = null == o ? void 0 : o.canvasFps) ? s : null == a ? void 0 : a.fps) ? i : 4,
                        u = null != (r = null != (n = null == o ? void 0 : o.canvasQuality) ? n : null == a ? void 0 : a.quality) ? r : .4;
                    if ("string" == typeof u) {
                        var d = parseFloat(u);
                        u = isNaN(d) ? .4 : d
                    }
                    return {
                        enabled: l,
                        fps: im(c, 0, 12, "canvas recording fps", 4),
                        quality: im(u, 0, 1, "canvas recording quality", .4)
                    }
                }
                get _networkPayloadCapture() {
                    var e, t, i = this._instance.get_property(ey),
                        s = {
                            recordHeaders: null == (e = this._instance.config.session_recording) ? void 0 : e.recordHeaders,
                            recordBody: null == (t = this._instance.config.session_recording) ? void 0 : t.recordBody
                        },
                        r = (null == s ? void 0 : s.recordHeaders) || (null == i ? void 0 : i.recordHeaders),
                        n = (null == s ? void 0 : s.recordBody) || (null == i ? void 0 : i.recordBody),
                        o = R(this._instance.config.capture_performance) ? this._instance.config.capture_performance.network_timing : this._instance.config.capture_performance,
                        a = !!(q(o) ? o : null == i ? void 0 : i.capturePerformance);
                    return r || n || a ? {
                        recordHeaders: r,
                        recordBody: n,
                        recordPerformance: a
                    } : void 0
                }
                get _masking() {
                    var e, t, i, s, r, n, o = this._instance.get_property(eb),
                        a = {
                            maskAllInputs: null == (e = this._instance.config.session_recording) ? void 0 : e.maskAllInputs,
                            maskTextSelector: null == (t = this._instance.config.session_recording) ? void 0 : t.maskTextSelector,
                            blockSelector: null == (i = this._instance.config.session_recording) ? void 0 : i.blockSelector
                        },
                        l = null != (s = null == a ? void 0 : a.maskAllInputs) ? s : null == o ? void 0 : o.maskAllInputs,
                        c = null != (r = null == a ? void 0 : a.maskTextSelector) ? r : null == o ? void 0 : o.maskTextSelector,
                        u = null != (n = null == a ? void 0 : a.blockSelector) ? n : null == o ? void 0 : o.blockSelector;
                    return $(l) && $(c) && $(u) ? void 0 : {
                        maskAllInputs: null == l || l,
                        maskTextSelector: c,
                        blockSelector: u
                    }
                }
                get _sampleRate() {
                    var e = this._instance.get_property(eS);
                    return D(e) ? e : null
                }
                get _minimumDuration() {
                    var e = this._instance.get_property(ek);
                    return D(e) ? e : null
                }
                get status() {
                    return this._receivedDecide ? this._isRecordingEnabled ? !1 === this._isSampled ? "disabled" : this._urlBlocked ? "paused" : L(this._linkedFlag) || this._linkedFlagSeen ? "trigger_pending" === this._triggerStatus ? "buffering" : q(this._isSampled) ? this._isSampled ? "sampled" : "disabled" : "active" : "buffering" : "disabled" : "buffering"
                }
                get _urlTriggerStatus() {
                    var e;
                    return 0 === this._urlTriggers.length ? "trigger_disabled" : (null == (e = this._instance) ? void 0 : e.get_property(eC)) === this._sessionId ? "trigger_activated" : "trigger_pending"
                }
                get _eventTriggerStatus() {
                    var e;
                    return 0 === this._eventTriggers.length ? "trigger_disabled" : (null == (e = this._instance) ? void 0 : e.get_property(eP)) === this._sessionId ? "trigger_activated" : "trigger_pending"
                }
                get _triggerStatus() {
                    var e = "trigger_activated" === this._eventTriggerStatus || "trigger_activated" === this._urlTriggerStatus,
                        t = "trigger_pending" === this._eventTriggerStatus || "trigger_pending" === this._urlTriggerStatus;
                    return e ? "trigger_activated" : t ? "trigger_pending" : "trigger_disabled"
                }
                constructor(e) {
                    if (J(this, "_queuedRRWebEvents", []), J(this, "_isIdle", "unknown"), J(this, "_linkedFlagSeen", !1), J(this, "_lastActivityTimestamp", Date.now()), J(this, "_linkedFlag", null), J(this, "_removePageViewCaptureHook", void 0), J(this, "_onSessionIdListener", void 0), J(this, "_persistDecideOnSessionListener", void 0), J(this, "_samplingSessionListener", void 0), J(this, "_urlTriggers", []), J(this, "_urlBlocklist", []), J(this, "_urlBlocked", !1), J(this, "_eventTriggers", []), J(this, "_removeEventTriggerCaptureHook", void 0), J(this, "_forceAllowLocalhostNetworkCapture", !1), J(this, "_onBeforeUnload", () => {
                            this._flushBuffer()
                        }), J(this, "_onOffline", () => {
                            this._tryAddCustomEvent("browser offline", {})
                        }), J(this, "_onOnline", () => {
                            this._tryAddCustomEvent("browser online", {})
                        }), J(this, "_onVisibilityChange", () => {
                            if (null != u && u.visibilityState) {
                                var e = "window " + u.visibilityState;
                                this._tryAddCustomEvent(e, {})
                            }
                        }), this._instance = e, this._captureStarted = !1, this._endpoint = "/s/", this._stopRrweb = void 0, this._receivedDecide = !1, !this._instance.sessionManager) throw i3.error("started without valid sessionManager"), Error(i2 + " started without valid sessionManager. This is a bug.");
                    if (this._instance.config.__preview_experimental_cookieless_mode) throw Error(i2 + " cannot be used with __preview_experimental_cookieless_mode.");
                    var {
                        sessionId: t,
                        windowId: i
                    } = this._sessionManager.checkAndGetSessionAndWindowId();
                    this._sessionId = t, this._windowId = i, this._buffer = this._clearBuffer(), this._sessionIdleThresholdMilliseconds >= this._sessionManager.sessionTimeoutMs && i3.warn("session_idle_threshold_ms (".concat(this._sessionIdleThresholdMilliseconds, ") is greater than the session timeout (").concat(this._sessionManager.sessionTimeoutMs, "). Session will never be detected as idle"))
                }
                startIfEnabledOrStop(e) {
                    this._isRecordingEnabled ? (this._startCapture(e), ea(r, "beforeunload", this._onBeforeUnload), ea(r, "offline", this._onOffline), ea(r, "online", this._onOnline), ea(r, "visibilitychange", this._onVisibilityChange), this._setupSampling(), this._addEventTriggerListener(), L(this._removePageViewCaptureHook) && (this._removePageViewCaptureHook = this._instance.on("eventCaptured", e => {
                        try {
                            if ("$pageview" === e.event) {
                                var t = null != e && e.properties.$current_url ? this._maskUrl(null == e ? void 0 : e.properties.$current_url) : "";
                                if (!t) return;
                                this._tryAddCustomEvent("$pageview", {
                                    href: t
                                })
                            }
                        } catch (e) {
                            i3.error("Could not add $pageview to rrweb session", e)
                        }
                    })), this._onSessionIdListener || (this._onSessionIdListener = this._sessionManager.onSessionId((e, t, i) => {
                        var s, r, n, o;
                        i && (this._tryAddCustomEvent("$session_id_change", {
                            sessionId: e,
                            windowId: t,
                            changeReason: i
                        }), null == (s = this._instance) || null == (r = s.persistence) || r.unregister(eP), null == (n = this._instance) || null == (o = n.persistence) || o.unregister(eC))
                    }))) : this.stopRecording()
                }
                stopRecording() {
                    var e, t, i, s;
                    this._captureStarted && this._stopRrweb && (this._stopRrweb(), this._stopRrweb = void 0, this._captureStarted = !1, null == r || r.removeEventListener("beforeunload", this._onBeforeUnload), null == r || r.removeEventListener("offline", this._onOffline), null == r || r.removeEventListener("online", this._onOnline), null == r || r.removeEventListener("visibilitychange", this._onVisibilityChange), this._clearBuffer(), clearInterval(this._fullSnapshotTimer), null == (e = this._removePageViewCaptureHook) || e.call(this), this._removePageViewCaptureHook = void 0, null == (t = this._removeEventTriggerCaptureHook) || t.call(this), this._removeEventTriggerCaptureHook = void 0, null == (i = this._onSessionIdListener) || i.call(this), this._onSessionIdListener = void 0, null == (s = this._samplingSessionListener) || s.call(this), this._samplingSessionListener = void 0, i3.info("stopped"))
                }
                _resetSampling() {
                    var e;
                    null == (e = this._instance.persistence) || e.unregister(eI)
                }
                _makeSamplingDecision(e) {
                    var t, i = this._sessionId !== e,
                        s = this._sampleRate;
                    if (D(s)) {
                        var r = this._isSampled,
                            n = i || !q(r),
                            o = n ? function(e) {
                                for (var t = 0, i = 0; i < e.length; i++) t = (t << 5) - t + e.charCodeAt(i) | 0;
                                return Math.abs(t)
                            }(e) % 100 < im(100 * s, 0, 100) : r;
                        n && (o ? this._reportStarted("sampled") : i3.warn("Sample rate (".concat(s, ") has determined that this sessionId (").concat(e, ") will not be sent to the server.")), this._tryAddCustomEvent("samplingDecisionMade", {
                            sampleRate: s,
                            isSampled: o
                        })), null == (t = this._instance.persistence) || t.register({
                            [eI]: o
                        })
                    } else this._resetSampling()
                }
                onRemoteConfig(e) {
                    var t, i, s, r, n, o;
                    if (this._tryAddCustomEvent("$remote_config_received", e), this._persistRemoteConfig(e), this._linkedFlag = (null == (t = e.sessionRecording) ? void 0 : t.linkedFlag) || null, null != (i = e.sessionRecording) && i.endpoint && (this._endpoint = null == (o = e.sessionRecording) ? void 0 : o.endpoint), this._setupSampling(), !L(this._linkedFlag) && !this._linkedFlagSeen) {
                        var a = O(this._linkedFlag) ? this._linkedFlag : this._linkedFlag.flag,
                            l = O(this._linkedFlag) ? null : this._linkedFlag.variant;
                        this._instance.onFeatureFlags((e, t) => {
                            var i = R(t) && a in t,
                                s = l ? t[a] === l : i;
                            s && this._reportStarted("linked_flag_matched", {
                                linkedFlag: a,
                                linkedVariant: l
                            }), this._linkedFlagSeen = s
                        })
                    }
                    null != (s = e.sessionRecording) && s.urlTriggers && (this._urlTriggers = e.sessionRecording.urlTriggers), null != (r = e.sessionRecording) && r.urlBlocklist && (this._urlBlocklist = e.sessionRecording.urlBlocklist), null != (n = e.sessionRecording) && n.eventTriggers && (this._eventTriggers = e.sessionRecording.eventTriggers), this._receivedDecide = !0, this.startIfEnabledOrStop()
                }
                _setupSampling() {
                    D(this._sampleRate) && L(this._samplingSessionListener) && (this._samplingSessionListener = this._sessionManager.onSessionId(e => {
                        this._makeSamplingDecision(e)
                    }))
                }
                _persistRemoteConfig(e) {
                    if (this._instance.persistence) {
                        var t, i = this._instance.persistence,
                            s = () => {
                                var t, s, r, n, o, a, l, c, u, d = null == (t = e.sessionRecording) ? void 0 : t.sampleRate,
                                    h = L(d) ? null : parseFloat(d);
                                L(h) && this._resetSampling();
                                var _ = null == (s = e.sessionRecording) ? void 0 : s.minimumDurationMilliseconds;
                                i.register({
                                    [ev]: !!e.sessionRecording,
                                    [em]: null == (r = e.sessionRecording) ? void 0 : r.consoleLogRecordingEnabled,
                                    [ey]: V({
                                        capturePerformance: e.capturePerformance
                                    }, null == (n = e.sessionRecording) ? void 0 : n.networkPayloadCapture),
                                    [eb]: null == (o = e.sessionRecording) ? void 0 : o.masking,
                                    [ew]: {
                                        enabled: null == (a = e.sessionRecording) ? void 0 : a.recordCanvas,
                                        fps: null == (l = e.sessionRecording) ? void 0 : l.canvasFps,
                                        quality: null == (c = e.sessionRecording) ? void 0 : c.canvasQuality
                                    },
                                    [eS]: h,
                                    [ek]: $(_) ? null : _,
                                    [eE]: null == (u = e.sessionRecording) ? void 0 : u.scriptConfig
                                })
                            };
                        s(), null == (t = this._persistDecideOnSessionListener) || t.call(this), this._persistDecideOnSessionListener = this._sessionManager.onSessionId(s)
                    }
                }
                log(e) {
                    var t, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "log";
                    null == (t = this._instance.sessionRecording) || t.onRRwebEmit({
                        type: 6,
                        data: {
                            plugin: "rrweb/console@1",
                            payload: {
                                level: i,
                                trace: [],
                                payload: [JSON.stringify(e)]
                            }
                        },
                        timestamp: Date.now()
                    })
                }
                _startCapture(e) {
                    if (!$(Object.assign) && !$(Array.from) && !(this._captureStarted || this._instance.config.disable_session_recording || this._instance.consent.isOptedOut())) {
                        var t, i;
                        (this._captureStarted = !0, this._sessionManager.checkAndGetSessionAndWindowId(), i5()) ? this._onScriptLoaded(): null == (t = f.__PosthogExtensions__) || null == (i = t.loadExternalDependency) || i.call(t, this._instance, this._scriptName, e => {
                            if (e) return i3.error("could not load recorder", e);
                            this._onScriptLoaded()
                        }), i3.info("starting"), "active" === this.status && this._reportStarted(e || "recording_initialized")
                    }
                }
                get _scriptName() {
                    var e, t, i;
                    return (null == (e = this._instance) || null == (t = e.persistence) || null == (i = t.get_property(eE)) ? void 0 : i.script) || "recorder"
                }
                _isInteractiveEvent(e) {
                    var t;
                    return 3 === e.type && -1 !== i6.indexOf(null == (t = e.data) ? void 0 : t.source)
                }
                _updateWindowAndSessionIds(e) {
                    var t = this._isInteractiveEvent(e);
                    t || this._isIdle || e.timestamp - this._lastActivityTimestamp > this._sessionIdleThresholdMilliseconds && (this._isIdle = !0, clearInterval(this._fullSnapshotTimer), this._tryAddCustomEvent("sessionIdle", {
                        eventTimestamp: e.timestamp,
                        lastActivityTimestamp: this._lastActivityTimestamp,
                        threshold: this._sessionIdleThresholdMilliseconds,
                        bufferLength: this._buffer.data.length,
                        bufferSize: this._buffer.size
                    }), this._flushBuffer());
                    var i = !1;
                    if (t && (this._lastActivityTimestamp = e.timestamp, this._isIdle)) {
                        var s = "unknown" === this._isIdle;
                        this._isIdle = !1, s || (this._tryAddCustomEvent("sessionNoLongerIdle", {
                            reason: "user activity",
                            type: e.type
                        }), i = !0)
                    }
                    if (!this._isIdle) {
                        var {
                            windowId: r,
                            sessionId: n
                        } = this._sessionManager.checkAndGetSessionAndWindowId(!t, e.timestamp), o = this._sessionId !== n, a = this._windowId !== r;
                        this._windowId = r, this._sessionId = n, o || a ? (this.stopRecording(), this.startIfEnabledOrStop("session_id_changed")) : i && this._scheduleFullSnapshot()
                    }
                }
                _tryRRWebMethod(e) {
                    try {
                        return e.rrwebMethod(), !0
                    } catch (t) {
                        return this._queuedRRWebEvents.length < 10 ? this._queuedRRWebEvents.push({
                            enqueuedAt: e.enqueuedAt || Date.now(),
                            attempt: e.attempt++,
                            rrwebMethod: e.rrwebMethod
                        }) : i3.warn("could not emit queued rrweb event.", t, e), !1
                    }
                }
                _tryAddCustomEvent(e, t) {
                    return this._tryRRWebMethod(i4(() => i5().addCustomEvent(e, t)))
                }
                _tryTakeFullSnapshot() {
                    return this._tryRRWebMethod(i4(() => i5().takeFullSnapshot()))
                }
                _onScriptLoaded() {
                    var e, t, i, s, r = {
                        blockClass: "ph-no-capture",
                        blockSelector: void 0,
                        ignoreClass: "ph-ignore-input",
                        maskTextClass: "ph-mask",
                        maskTextSelector: void 0,
                        maskTextFn: void 0,
                        maskAllInputs: !0,
                        maskInputOptions: {
                            password: !0
                        },
                        maskInputFn: void 0,
                        slimDOMOptions: {},
                        collectFonts: !1,
                        inlineStylesheet: !0,
                        recordCrossOriginIframes: !1
                    };
                    for (var [n, o] of Object.entries(this._instance.config.session_recording || {})) n in r && ("maskInputOptions" === n ? r.maskInputOptions = V({
                        password: !0
                    }, o) : r[n] = o);
                    this._canvasRecording && this._canvasRecording.enabled && (r.recordCanvas = !0, r.sampling = {
                        canvas: this._canvasRecording.fps
                    }, r.dataURLOptions = {
                        type: "image/webp",
                        quality: this._canvasRecording.quality
                    }), this._masking && (r.maskAllInputs = null == (t = this._masking.maskAllInputs) || t, r.maskTextSelector = null != (i = this._masking.maskTextSelector) ? i : void 0, r.blockSelector = null != (s = this._masking.blockSelector) ? s : void 0);
                    var a = i5();
                    if (a) {
                        this._mutationRateLimiter = null != (e = this._mutationRateLimiter) ? e : new iy(a, {
                            refillRate: this._instance.config.session_recording.__mutationRateLimiterRefillRate,
                            bucketSize: this._instance.config.session_recording.__mutationRateLimiterBucketSize,
                            onBlockedNode: (e, t) => {
                                var i = "Too many mutations on node '".concat(e, "'. Rate limiting. This could be due to SVG animations or something similar");
                                i3.info(i, {
                                    node: t
                                }), this.log(i2 + " " + i, "warn")
                            }
                        });
                        var l = this._gatherRRWebPlugins();
                        this._stopRrweb = a(V({
                            emit: e => {
                                this.onRRwebEmit(e)
                            },
                            plugins: l
                        }, r)), this._lastActivityTimestamp = Date.now(), this._isIdle = q(this._isIdle) ? this._isIdle : "unknown", this._tryAddCustomEvent("$session_options", {
                            sessionRecordingOptions: r,
                            activePlugins: l.map(e => null == e ? void 0 : e.name)
                        }), this._tryAddCustomEvent("$posthog_config", {
                            config: this._instance.config
                        })
                    } else i3.error("onScriptLoaded was called but rrwebRecord is not available. This indicates something has gone wrong.")
                }
                _scheduleFullSnapshot() {
                    if (this._fullSnapshotTimer && clearInterval(this._fullSnapshotTimer), !0 !== this._isIdle) {
                        var e = this._fullSnapshotIntervalMillis;
                        e && (this._fullSnapshotTimer = setInterval(() => {
                            this._tryTakeFullSnapshot()
                        }, e))
                    }
                }
                _gatherRRWebPlugins() {
                    var e, t, i, s, r = [],
                        n = null == (e = f.__PosthogExtensions__) || null == (t = e.rrwebPlugins) ? void 0 : t.getRecordConsolePlugin;
                    n && this._isConsoleLogCaptureEnabled && r.push(n());
                    var o = null == (i = f.__PosthogExtensions__) || null == (s = i.rrwebPlugins) ? void 0 : s.getRecordNetworkPlugin;
                    return this._networkPayloadCapture && F(o) && (!tl.includes(location.hostname) || this._forceAllowLocalhostNetworkCapture ? r.push(o(iv(this._instance.config, this._networkPayloadCapture))) : i3.info("NetworkCapture not started because we are on localhost.")), r
                }
                onRRwebEmit(e) {
                    var t;
                    if (this._processQueuedEvents(), e && R(e)) {
                        if (e.type === io.Meta) {
                            var i = this._maskUrl(e.data.href);
                            if (this._lastHref = i, !i) return;
                            e.data.href = i
                        } else this._pageViewFallBack();
                        if (this._checkUrlTriggerConditions(), !this._urlBlocked || e.type === io.Custom && "recording paused" === e.data.tag) {
                            e.type === io.FullSnapshot && this._scheduleFullSnapshot(), e.type === io.FullSnapshot && "trigger_pending" === this._triggerStatus && this._clearBuffer();
                            var s = this._mutationRateLimiter ? this._mutationRateLimiter.throttleMutations(e) : e;
                            if (s) {
                                var r = function(e) {
                                    if (e && R(e) && 6 === e.type && R(e.data) && "rrweb/console@1" === e.data.plugin) {
                                        e.data.payload.payload.length > 10 && (e.data.payload.payload = e.data.payload.payload.slice(0, 10), e.data.payload.payload.push("...[truncated]"));
                                        for (var t = [], i = 0; i < e.data.payload.payload.length; i++) e.data.payload.payload[i] && e.data.payload.payload[i].length > 2e3 ? t.push(e.data.payload.payload[i].slice(0, 2e3) + "...[truncated]") : t.push(e.data.payload.payload[i]);
                                        return e.data.payload.payload = t, e
                                    }
                                    return e
                                }(s);
                                if (this._updateWindowAndSessionIds(r), !0 !== this._isIdle || i7(r)) {
                                    if (i7(r)) {
                                        var n = r.data.payload;
                                        n && (r.timestamp = n.lastActivityTimestamp + n.threshold)
                                    }
                                    var o = null == (t = this._instance.config.session_recording.compress_events) || t ? function(e) {
                                            if (1024 > ir(e)) return e;
                                            try {
                                                if (e.type === io.FullSnapshot) return V(V({}, e), {}, {
                                                    data: i8(e.data),
                                                    cv: "2024-10"
                                                });
                                                if (e.type === io.IncrementalSnapshot && e.data.source === ia.Mutation) return V(V({}, e), {}, {
                                                    cv: "2024-10",
                                                    data: V(V({}, e.data), {}, {
                                                        texts: i8(e.data.texts),
                                                        attributes: i8(e.data.attributes),
                                                        removes: i8(e.data.removes),
                                                        adds: i8(e.data.adds)
                                                    })
                                                });
                                                if (e.type === io.IncrementalSnapshot && e.data.source === ia.StyleSheetRule) return V(V({}, e), {}, {
                                                    cv: "2024-10",
                                                    data: V(V({}, e.data), {}, {
                                                        adds: e.data.adds ? i8(e.data.adds) : void 0,
                                                        removes: e.data.removes ? i8(e.data.removes) : void 0
                                                    })
                                                })
                                            } catch (e) {
                                                i3.error("could not compress event - will use uncompressed event", e)
                                            }
                                            return e
                                        }(r) : r,
                                        a = {
                                            $snapshot_bytes: ir(o),
                                            $snapshot_data: o,
                                            $session_id: this._sessionId,
                                            $window_id: this._windowId
                                        };
                                    "disabled" !== this.status ? this._captureSnapshotBuffered(a) : this._clearBuffer()
                                }
                            }
                        }
                    }
                }
                _pageViewFallBack() {
                    if (!this._instance.config.capture_pageview && r) {
                        var e = this._maskUrl(r.location.href);
                        this._lastHref !== e && (this._tryAddCustomEvent("$url_changed", {
                            href: e
                        }), this._lastHref = e)
                    }
                }
                _processQueuedEvents() {
                    if (this._queuedRRWebEvents.length) {
                        var e = [...this._queuedRRWebEvents];
                        this._queuedRRWebEvents = [], e.forEach(e => {
                            Date.now() - e.enqueuedAt <= 2e3 && this._tryRRWebMethod(e)
                        })
                    }
                }
                _maskUrl(e) {
                    var t = this._instance.config.session_recording;
                    if (t.maskNetworkRequestFn) {
                        var i, s = {
                            url: e
                        };
                        return null == (i = s = t.maskNetworkRequestFn(s)) ? void 0 : i.url
                    }
                    return e
                }
                _clearBuffer() {
                    return this._buffer = {
                        size: 0,
                        data: [],
                        sessionId: this._sessionId,
                        windowId: this._windowId
                    }, this._buffer
                }
                _flushBuffer() {
                    this._flushBufferTimer && (clearTimeout(this._flushBufferTimer), this._flushBufferTimer = void 0);
                    var e = this._minimumDuration,
                        t = this._sessionDuration,
                        i = D(t) && t >= 0,
                        s = D(e) && i && t < e;
                    return "buffering" === this.status || "paused" === this.status || "disabled" === this.status || s ? (this._flushBufferTimer = setTimeout(() => {
                        this._flushBuffer()
                    }, 2e3), this._buffer) : (this._buffer.data.length > 0 && (function e(t) {
                        var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 6606028.8;
                        if (t.size >= i && t.data.length > 1) {
                            var s = Math.floor(t.data.length / 2),
                                r = t.data.slice(0, s),
                                n = t.data.slice(s);
                            return [e({
                                size: ir(r),
                                data: r,
                                sessionId: t.sessionId,
                                windowId: t.windowId
                            }), e({
                                size: ir(n),
                                data: n,
                                sessionId: t.sessionId,
                                windowId: t.windowId
                            })].flatMap(e => e)
                        }
                        return [t]
                    })(this._buffer).forEach(e => {
                        this._captureSnapshot({
                            $snapshot_bytes: e.size,
                            $snapshot_data: e.data,
                            $session_id: e.sessionId,
                            $window_id: e.windowId,
                            $lib: "web",
                            $lib_version: v.LIB_VERSION
                        })
                    }), this._clearBuffer())
                }
                _captureSnapshotBuffered(e) {
                    var t, i = 2 + ((null == (t = this._buffer) ? void 0 : t.data.length) || 0);
                    !this._isIdle && (this._buffer.size + e.$snapshot_bytes + i > 943718.4 || this._buffer.sessionId !== this._sessionId) && (this._buffer = this._flushBuffer()), this._buffer.size += e.$snapshot_bytes, this._buffer.data.push(e.$snapshot_data), this._flushBufferTimer || this._isIdle || (this._flushBufferTimer = setTimeout(() => {
                        this._flushBuffer()
                    }, 2e3))
                }
                _captureSnapshot(e) {
                    this._instance.capture("$snapshot", e, {
                        _url: this._instance.requestRouter.endpointFor("api", this._endpoint),
                        _noTruncate: !0,
                        _batchKey: "recordings",
                        skip_client_rate_limiting: !0
                    })
                }
                _checkUrlTriggerConditions() {
                    if (void 0 !== r && r.location.href) {
                        var e = r.location.href,
                            t = this._urlBlocked,
                            i = i9(e, this._urlBlocklist);
                        i && !t ? this._pauseRecording() : !i && t && this._resumeRecording(), i9(e, this._urlTriggers) && this._activateTrigger("url")
                    }
                }
                _activateTrigger(e) {
                    var t, i;
                    "trigger_pending" === this._triggerStatus && (null == (t = this._instance) || null == (i = t.persistence) || i.register({
                        ["url" === e ? eC : eP]: this._sessionId
                    }), this._flushBuffer(), this._reportStarted(e + "_trigger_matched"))
                }
                _pauseRecording() {
                    this._urlBlocked || (this._urlBlocked = !0, clearInterval(this._fullSnapshotTimer), i3.info("recording paused due to URL blocker"), this._tryAddCustomEvent("recording paused", {
                        reason: "url blocker"
                    }))
                }
                _resumeRecording() {
                    this._urlBlocked && (this._urlBlocked = !1, this._tryTakeFullSnapshot(), this._scheduleFullSnapshot(), this._tryAddCustomEvent("recording resumed", {
                        reason: "left blocked url"
                    }), i3.info("recording resumed"))
                }
                _addEventTriggerListener() {
                    0 !== this._eventTriggers.length && L(this._removeEventTriggerCaptureHook) && (this._removeEventTriggerCaptureHook = this._instance.on("eventCaptured", e => {
                        try {
                            this._eventTriggers.includes(e.event) && this._activateTrigger("event")
                        } catch (e) {
                            i3.error("Could not activate event trigger", e)
                        }
                    }))
                }
                overrideLinkedFlag() {
                    this._linkedFlagSeen = !0, this._tryTakeFullSnapshot(), this._reportStarted("linked_flag_overridden")
                }
                overrideSampling() {
                    var e;
                    null == (e = this._instance.persistence) || e.register({
                        [eI]: !0
                    }), this._tryTakeFullSnapshot(), this._reportStarted("sampling_overridden")
                }
                overrideTrigger(e) {
                    this._activateTrigger(e)
                }
                _reportStarted(e, t) {
                    this._instance.register_for_session({
                        $session_recording_start_reason: e
                    }), i3.info(e.replace("_", " "), t), w(["recording_initialized", "session_id_changed"], e) || this._tryAddCustomEvent(e, t)
                }
                get sdkDebugProperties() {
                    var {
                        sessionStartTimestamp: e
                    } = this._sessionManager.checkAndGetSessionAndWindowId(!0);
                    return {
                        $recording_status: this.status,
                        $sdk_debug_replay_internal_buffer_length: this._buffer.data.length,
                        $sdk_debug_replay_internal_buffer_size: this._buffer.size,
                        $sdk_debug_current_session_duration: this._sessionDuration,
                        $sdk_debug_session_start: e
                    }
                }
            }
            var st = z("[SegmentIntegration]"),
                si = "posthog-js";

            function ss(e) {
                var {
                    organization: t,
                    projectId: i,
                    prefix: s,
                    severityAllowList: r = ["error"]
                } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return n => {
                    if (!("*" === r || r.includes(n.level)) || !e.__loaded) return n;
                    n.tags || (n.tags = {});
                    var o, a, l, c, u, d = e.requestRouter.endpointFor("ui", "/project/".concat(e.config.token, "/person/").concat(e.get_distinct_id()));
                    n.tags["PostHog Person URL"] = d, e.sessionRecordingStarted() && (n.tags["PostHog Recording URL"] = e.get_session_replay_url({
                        withTimestamp: !0
                    }));
                    var h = (null == (o = n.exception) ? void 0 : o.values) || [],
                        _ = h.map(e => V(V({}, e), {}, {
                            stacktrace: e.stacktrace ? V(V({}, e.stacktrace), {}, {
                                type: "raw",
                                frames: (e.stacktrace.frames || []).map(e => V(V({}, e), {}, {
                                    platform: "web:javascript"
                                }))
                            }) : void 0
                        })),
                        p = {
                            $exception_message: (null == (a = h[0]) ? void 0 : a.value) || n.message,
                            $exception_type: null == (l = h[0]) ? void 0 : l.type,
                            $exception_personURL: d,
                            $exception_level: n.level,
                            $exception_list: _,
                            $sentry_event_id: n.event_id,
                            $sentry_exception: n.exception,
                            $sentry_exception_message: (null == (c = h[0]) ? void 0 : c.value) || n.message,
                            $sentry_exception_type: null == (u = h[0]) ? void 0 : u.type,
                            $sentry_tags: n.tags
                        };
                    return t && i && (p.$sentry_url = (s || "https://sentry.io/organizations/") + t + "/issues/?project=" + i + "&query=" + n.event_id), e.exceptions.sendExceptionEvent(p), n
                }
            }
            class sr {
                constructor(e, t, i, s, r) {
                    this.name = si, this.setupOnce = function(n) {
                        n(ss(e, {
                            organization: t,
                            projectId: i,
                            prefix: s,
                            severityAllowList: r
                        }))
                    }
                }
            }
            var sn, so = null != r && r.location ? t_(r.location.hash, "__posthog") || t_(location.hash, "state") : null,
                sa = "_postHogToolbarParams",
                sl = z("[Toolbar]");
            ! function(e) {
                e[e.UNINITIALIZED = 0] = "UNINITIALIZED", e[e.LOADING = 1] = "LOADING", e[e.LOADED = 2] = "LOADED"
            }(sn || (sn = {}));
            class sc {
                constructor(e) {
                    this.instance = e
                }
                _setToolbarState(e) {
                    f.ph_toolbar_state = e
                }
                _getToolbarState() {
                    var e;
                    return null != (e = f.ph_toolbar_state) ? e : sn.UNINITIALIZED
                }
                maybeLoadToolbar() {
                    var e, t, i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0,
                        s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0,
                        n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0;
                    if (!r || !u) return !1;
                    i = null != (e = i) ? e : r.location, n = null != (t = n) ? t : r.history;
                    try {
                        if (!s) {
                            try {
                                r.localStorage.setItem("test", "test"), r.localStorage.removeItem("test")
                            } catch (e) {
                                return !1
                            }
                            s = null == r ? void 0 : r.localStorage
                        }
                        var o, a = so || t_(i.hash, "__posthog") || t_(i.hash, "state"),
                            l = a ? ei(() => JSON.parse(atob(decodeURIComponent(a)))) || ei(() => JSON.parse(decodeURIComponent(a))) : null;
                        return l && "ph_authorize" === l.action ? ((o = l).source = "url", o && Object.keys(o).length > 0 && (l.desiredHash ? i.hash = l.desiredHash : n ? n.replaceState(n.state, "", i.pathname + i.search) : i.hash = "")) : ((o = JSON.parse(s.getItem(sa) || "{}")).source = "localstorage", delete o.userIntent), !(!o.token || this.instance.config.token !== o.token) && (this.loadToolbar(o), !0)
                    } catch (e) {
                        return !1
                    }
                }
                _callLoadToolbar(e) {
                    var t = f.ph_load_toolbar || f.ph_load_editor;
                    !L(t) && F(t) ? t(e, this.instance) : sl.warn("No toolbar load function found")
                }
                loadToolbar(e) {
                    var t, i, s = !(null == u || !u.getElementById(eU));
                    if (!r || s) return !1;
                    var n = "custom" === this.instance.requestRouter.region && this.instance.config.advanced_disable_toolbar_metrics,
                        o = V(V({
                            token: this.instance.config.token
                        }, e), {}, {
                            apiURL: this.instance.requestRouter.endpointFor("ui")
                        }, n ? {
                            instrument: !1
                        } : {});
                    return (r.localStorage.setItem(sa, JSON.stringify(V(V({}, o), {}, {
                        source: void 0
                    }))), this._getToolbarState() === sn.LOADED) ? this._callLoadToolbar(o) : this._getToolbarState() === sn.UNINITIALIZED && (this._setToolbarState(sn.LOADING), null == (t = f.__PosthogExtensions__) || null == (i = t.loadExternalDependency) || i.call(t, this.instance, "toolbar", e => {
                        if (e) return sl.error("[Toolbar] Failed to load", e), void this._setToolbarState(sn.UNINITIALIZED);
                        this._setToolbarState(sn.LOADED), this._callLoadToolbar(o)
                    }), ea(r, "turbolinks:load", () => {
                        this._setToolbarState(sn.UNINITIALIZED), this.loadToolbar(o)
                    })), !0
                }
                _loadEditor(e) {
                    return this.loadToolbar(e)
                }
                maybeLoadEditor() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : void 0,
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0,
                        i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0;
                    return this.maybeLoadToolbar(e, t, i)
                }
            }
            var su = z("[TracingHeaders]");
            class sd {
                constructor(e) {
                    J(this, "_restoreXHRPatch", void 0), J(this, "_restoreFetchPatch", void 0), J(this, "_startCapturing", () => {
                        var e, t, i, s;
                        $(this._restoreXHRPatch) && (null == (e = f.__PosthogExtensions__) || null == (t = e.tracingHeadersPatchFns) || t._patchXHR(this._instance.sessionManager)), $(this._restoreFetchPatch) && (null == (i = f.__PosthogExtensions__) || null == (s = i.tracingHeadersPatchFns) || s._patchFetch(this._instance.sessionManager))
                    }), this._instance = e
                }
                _loadScript(e) {
                    var t, i, s;
                    null != (t = f.__PosthogExtensions__) && t.tracingHeadersPatchFns && e(), null == (i = f.__PosthogExtensions__) || null == (s = i.loadExternalDependency) || s.call(i, this._instance, "tracing-headers", t => {
                        if (t) return su.error("failed to load script", t);
                        e()
                    })
                }
                startIfEnabledOrStop() {
                    var e, t;
                    this._instance.config.__add_tracing_headers ? this._loadScript(this._startCapturing) : (null == (e = this._restoreXHRPatch) || e.call(this), null == (t = this._restoreFetchPatch) || t.call(this), this._restoreXHRPatch = void 0, this._restoreFetchPatch = void 0)
                }
            }
            var sh = z("[Web Vitals]");
            class s_ {
                constructor(e) {
                    var t;
                    J(this, "_enabledServerSide", !1), J(this, "_initialized", !1), J(this, "_buffer", {
                        url: void 0,
                        metrics: [],
                        firstMetricTimestamp: void 0
                    }), J(this, "_flushToCapture", () => {
                        clearTimeout(this._delayedFlushTimer), 0 !== this._buffer.metrics.length && (this._instance.capture("$web_vitals", this._buffer.metrics.reduce((e, t) => V(V({}, e), {}, {
                            ["$web_vitals_".concat(t.name, "_event")]: V({}, t),
                            ["$web_vitals_".concat(t.name, "_value")]: t.value
                        }), {})), this._buffer = {
                            url: void 0,
                            metrics: [],
                            firstMetricTimestamp: void 0
                        })
                    }), J(this, "_addToBuffer", e => {
                        var t, i = null == (t = this._instance.sessionManager) ? void 0 : t.checkAndGetSessionAndWindowId(!0);
                        if ($(i)) sh.error("Could not read session ID. Dropping metrics!");
                        else {
                            this._buffer = this._buffer || {
                                url: void 0,
                                metrics: [],
                                firstMetricTimestamp: void 0
                            };
                            var s = this._currentURL();
                            $(s) || (L(null == e ? void 0 : e.name) || L(null == e ? void 0 : e.value) ? sh.error("Invalid metric received", e) : this._maxAllowedValue && e.value >= this._maxAllowedValue ? sh.error("Ignoring metric with value >= " + this._maxAllowedValue, e) : (this._buffer.url !== s && (this._flushToCapture(), this._delayedFlushTimer = setTimeout(this._flushToCapture, this.flushToCaptureTimeoutMs)), $(this._buffer.url) && (this._buffer.url = s), this._buffer.firstMetricTimestamp = $(this._buffer.firstMetricTimestamp) ? Date.now() : this._buffer.firstMetricTimestamp, e.attribution && e.attribution.interactionTargetElement && (e.attribution.interactionTargetElement = void 0), this._buffer.metrics.push(V(V({}, e), {}, {
                                $current_url: s,
                                $session_id: i.sessionId,
                                $window_id: i.windowId,
                                timestamp: Date.now()
                            })), this._buffer.metrics.length === this.allowedMetrics.length && this._flushToCapture()))
                        }
                    }), J(this, "_startCapturing", () => {
                        var e, t, i, s, r = f.__PosthogExtensions__;
                        $(r) || $(r.postHogWebVitalsCallbacks) || ({
                            onLCP: e,
                            onCLS: t,
                            onFCP: i,
                            onINP: s
                        } = r.postHogWebVitalsCallbacks), e && t && i && s ? (this.allowedMetrics.indexOf("LCP") > -1 && e(this._addToBuffer.bind(this)), this.allowedMetrics.indexOf("CLS") > -1 && t(this._addToBuffer.bind(this)), this.allowedMetrics.indexOf("FCP") > -1 && i(this._addToBuffer.bind(this)), this.allowedMetrics.indexOf("INP") > -1 && s(this._addToBuffer.bind(this)), this._initialized = !0) : sh.error("web vitals callbacks not loaded - not starting")
                    }), this._instance = e, this._enabledServerSide = !(null == (t = this._instance.persistence) || !t.props[ep]), this.startIfEnabled()
                }
                get allowedMetrics() {
                    var e, t, i = R(this._instance.config.capture_performance) ? null == (e = this._instance.config.capture_performance) ? void 0 : e.web_vitals_allowed_metrics : void 0;
                    return $(i) ? (null == (t = this._instance.persistence) ? void 0 : t.props[ef]) || ["CLS", "FCP", "INP", "LCP"] : i
                }
                get flushToCaptureTimeoutMs() {
                    return (R(this._instance.config.capture_performance) ? this._instance.config.capture_performance.web_vitals_delayed_flush_ms : void 0) || 5e3
                }
                get _maxAllowedValue() {
                    var e = R(this._instance.config.capture_performance) && D(this._instance.config.capture_performance.__web_vitals_max_value) ? this._instance.config.capture_performance.__web_vitals_max_value : 9e5;
                    return 0 < e && e <= 6e4 ? 9e5 : e
                }
                get isEnabled() {
                    var e = null == d ? void 0 : d.protocol;
                    if ("http:" !== e && "https:" !== e) return sh.info("Web Vitals are disabled on non-http/https protocols"), !1;
                    var t = R(this._instance.config.capture_performance) ? this._instance.config.capture_performance.web_vitals : q(this._instance.config.capture_performance) ? this._instance.config.capture_performance : void 0;
                    return q(t) ? t : this._enabledServerSide
                }
                startIfEnabled() {
                    this.isEnabled && !this._initialized && (sh.info("enabled, starting..."), this._loadScript(this._startCapturing))
                }
                onRemoteConfig(e) {
                    var t = R(e.capturePerformance) && !!e.capturePerformance.web_vitals,
                        i = R(e.capturePerformance) ? e.capturePerformance.web_vitals_allowed_metrics : void 0;
                    this._instance.persistence && (this._instance.persistence.register({
                        [ep]: t
                    }), this._instance.persistence.register({
                        [ef]: i
                    })), this._enabledServerSide = t, this.startIfEnabled()
                }
                _loadScript(e) {
                    var t, i, s;
                    null != (t = f.__PosthogExtensions__) && t.postHogWebVitalsCallbacks && e(), null == (i = f.__PosthogExtensions__) || null == (s = i.loadExternalDependency) || s.call(i, this._instance, "web-vitals", t => {
                        t ? sh.error("failed to load script", t) : e()
                    })
                }
                _currentURL() {
                    var e = r ? r.location.href : void 0;
                    return e || sh.error("Could not determine current URL"), e
                }
            }
            var sp = z("[Heatmaps]");

            function sg(e) {
                return R(e) && "clientX" in e && "clientY" in e && D(e.clientX) && D(e.clientY)
            }
            class sf {
                constructor(e) {
                    var t;
                    J(this, "rageclicks", new ta), J(this, "_enabledServerSide", !1), J(this, "_initialized", !1), J(this, "_flushInterval", null), this.instance = e, this._enabledServerSide = !(null == (t = this.instance.persistence) || !t.props[eh])
                }
                get flushIntervalMilliseconds() {
                    var e = 5e3;
                    return R(this.instance.config.capture_heatmaps) && this.instance.config.capture_heatmaps.flush_interval_milliseconds && (e = this.instance.config.capture_heatmaps.flush_interval_milliseconds), e
                }
                get isEnabled() {
                    return $(this.instance.config.capture_heatmaps) ? $(this.instance.config.enable_heatmaps) ? this._enabledServerSide : this.instance.config.enable_heatmaps : !1 !== this.instance.config.capture_heatmaps
                }
                startIfEnabled() {
                    if (this.isEnabled) this._initialized || (sp.info("starting..."), this._setupListeners(), this._flushInterval = setInterval(this._flush.bind(this), this.flushIntervalMilliseconds));
                    else {
                        var e, t;
                        clearInterval(null != (e = this._flushInterval) ? e : void 0), null == (t = this._deadClicksCapture) || t.stop(), this.getAndClearBuffer()
                    }
                }
                onRemoteConfig(e) {
                    var t = !!e.heatmaps;
                    this.instance.persistence && this.instance.persistence.register({
                        [eh]: t
                    }), this._enabledServerSide = t, this.startIfEnabled()
                }
                getAndClearBuffer() {
                    var e = this._buffer;
                    return this._buffer = void 0, e
                }
                _onDeadClick(e) {
                    this._onClick(e.originalEvent, "deadclick")
                }
                _setupListeners() {
                    r && u && (ea(r, "beforeunload", this._flush.bind(this)), ea(u, "click", e => this._onClick(e || (null == r ? void 0 : r.event)), {
                        capture: !0
                    }), ea(u, "mousemove", e => this._onMouseMove(e || (null == r ? void 0 : r.event)), {
                        capture: !0
                    }), this._deadClicksCapture = new tH(this.instance, tN, this._onDeadClick.bind(this)), this._deadClicksCapture.startIfEnabled(), this._initialized = !0)
                }
                _getProperties(e, t) {
                    var i = this.instance.scrollManager.scrollY(),
                        s = this.instance.scrollManager.scrollX(),
                        n = this.instance.scrollManager.scrollElement(),
                        o = function(e, t, i) {
                            for (var s = e; s && eJ(s) && !eY(s, "body") && s !== i;) {
                                if (w(t, null == r ? void 0 : r.getComputedStyle(s).position)) return !0;
                                s = e6(s)
                            }
                            return !1
                        }(e3(e), ["fixed", "sticky"], n);
                    return {
                        x: e.clientX + (o ? 0 : s),
                        y: e.clientY + (o ? 0 : i),
                        target_fixed: o,
                        type: t
                    }
                }
                _onClick(e) {
                    var t, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "click";
                    if (!eV(e.target) && sg(e)) {
                        var s = this._getProperties(e, i);
                        null != (t = this.rageclicks) && t.isRageClick(e.clientX, e.clientY, (new Date).getTime()) && this._capture(V(V({}, s), {}, {
                            type: "rageclick"
                        })), this._capture(s)
                    }
                }
                _onMouseMove(e) {
                    !eV(e.target) && sg(e) && (clearTimeout(this._mouseMoveTimeout), this._mouseMoveTimeout = setTimeout(() => {
                        this._capture(this._getProperties(e, "mousemove"))
                    }, 500))
                }
                _capture(e) {
                    if (r) {
                        var t = r.location.href;
                        this._buffer = this._buffer || {}, this._buffer[t] || (this._buffer[t] = []), this._buffer[t].push(e)
                    }
                }
                _flush() {
                    this._buffer && !T(this._buffer) && this.instance.capture("$$heatmap", {
                        $heatmap_data: this.getAndClearBuffer()
                    })
                }
            }
            class sv {
                constructor(e) {
                    this._instance = e
                }
                doPageView(e, t) {
                    var i, s = this._previousPageViewProperties(e, t);
                    return this._currentPageview = {
                        pathname: null != (i = null == r ? void 0 : r.location.pathname) ? i : "",
                        pageViewId: t,
                        timestamp: e
                    }, this._instance.scrollManager.resetContext(), s
                }
                doPageLeave(e) {
                    var t;
                    return this._previousPageViewProperties(e, null == (t = this._currentPageview) ? void 0 : t.pageViewId)
                }
                doEvent() {
                    var e;
                    return {
                        $pageview_id: null == (e = this._currentPageview) ? void 0 : e.pageViewId
                    }
                }
                _previousPageViewProperties(e, t) {
                    var i = this._currentPageview;
                    if (!i) return {
                        $pageview_id: t
                    };
                    var s = {
                            $pageview_id: t,
                            $prev_pageview_id: i.pageViewId
                        },
                        r = this._instance.scrollManager.getContext();
                    if (r && !this._instance.config.disable_scroll_properties) {
                        var {
                            maxScrollHeight: n,
                            lastScrollY: o,
                            maxScrollY: a,
                            maxContentHeight: l,
                            lastContentY: c,
                            maxContentY: u
                        } = r;
                        if (!($(n) || $(o) || $(a) || $(l) || $(c) || $(u))) {
                            n = Math.ceil(n), o = Math.ceil(o), a = Math.ceil(a), l = Math.ceil(l), c = Math.ceil(c), u = Math.ceil(u);
                            var d = n <= 1 ? 1 : im(o / n, 0, 1),
                                h = n <= 1 ? 1 : im(a / n, 0, 1),
                                _ = l <= 1 ? 1 : im(c / l, 0, 1),
                                p = l <= 1 ? 1 : im(u / l, 0, 1);
                            s = Z(s, {
                                $prev_pageview_last_scroll: o,
                                $prev_pageview_last_scroll_percentage: d,
                                $prev_pageview_max_scroll: a,
                                $prev_pageview_max_scroll_percentage: h,
                                $prev_pageview_last_content: c,
                                $prev_pageview_last_content_percentage: _,
                                $prev_pageview_max_content: u,
                                $prev_pageview_max_content_percentage: p
                            })
                        }
                    }
                    return i.pathname && (s.$prev_pageview_pathname = i.pathname), i.timestamp && (s.$prev_pageview_duration = (e.getTime() - i.timestamp.getTime()) / 1e3), s
                }
            }
            class sm {
                constructor(e) {
                    this._instance = e
                }
                sendExceptionEvent(e) {
                    this._instance.capture("$exception", e, {
                        _noTruncate: !0,
                        _batchKey: "exceptionEvent"
                    })
                }
            }
            var sy = "Mobile",
                sb = "Android",
                sw = "Tablet",
                sS = sb + " " + sw,
                sk = "iPad",
                sE = "Apple",
                sx = sE + " Watch",
                sI = "Safari",
                sC = "BlackBerry",
                sP = "Samsung",
                sF = sP + "Browser",
                sR = sP + " Internet",
                sT = "Chrome",
                s$ = sT + " OS",
                sO = sT + " iOS",
                sA = "Internet Explorer",
                sM = sA + " " + sy,
                sL = "Opera",
                sD = sL + " Mini",
                sq = "Edge",
                sN = "Microsoft " + sq,
                sB = "Firefox",
                sH = sB + " iOS",
                sj = "Nintendo",
                sz = "PlayStation",
                sU = "Xbox",
                sW = sb + " " + sy,
                sG = sy + " " + sI,
                sV = "Windows",
                sJ = sV + " Phone",
                sY = "Nokia",
                sK = "Ouya",
                sX = "Generic",
                sQ = sX + " " + sy.toLowerCase(),
                sZ = sX + " " + sw.toLowerCase(),
                s0 = "Konqueror",
                s1 = "(\\d+(\\.\\d+)?)",
                s2 = RegExp("Version/" + s1),
                s3 = RegExp(sU, "i"),
                s5 = RegExp(sz + " \\w+", "i"),
                s6 = RegExp(sj + " \\w+", "i"),
                s4 = RegExp(sC + "|PlayBook|BB10", "i"),
                s8 = {
                    "NT3.51": "NT 3.11",
                    "NT4.0": "NT 4.0",
                    "5.0": "2000",
                    5.1: "XP",
                    5.2: "XP",
                    "6.0": "Vista",
                    6.1: "7",
                    6.2: "8",
                    6.3: "8.1",
                    6.4: "10",
                    "10.0": "10"
                },
                s7 = (e, t) => t && w(t, sE) || function(e) {
                    return w(e, sI) && !w(e, sT) && !w(e, sb)
                }(e),
                s9 = function(e, t) {
                    return t = t || "", w(e, " OPR/") && w(e, "Mini") ? sD : w(e, " OPR/") ? sL : s4.test(e) ? sC : w(e, "IE" + sy) || w(e, "WPDesktop") ? sM : w(e, sF) ? sR : w(e, sq) || w(e, "Edg/") ? sN : w(e, "FBIOS") ? "Facebook " + sy : w(e, "UCWEB") || w(e, "UCBrowser") ? "UC Browser" : w(e, "CriOS") ? sO : w(e, "CrMo") || w(e, sT) ? sT : w(e, sb) && w(e, sI) ? sW : w(e, "FxiOS") ? sH : w(e.toLowerCase(), s0.toLowerCase()) ? s0 : s7(e, t) ? w(e, sy) ? sG : sI : w(e, sB) ? sB : w(e, "MSIE") || w(e, "Trident/") ? sA : w(e, "Gecko") ? sB : ""
                },
                re = {
                    [sM]: [RegExp("rv:" + s1)],
                    [sN]: [RegExp(sq + "?\\/" + s1)],
                    [sT]: [RegExp("(" + sT + "|CrMo)\\/" + s1)],
                    [sO]: [RegExp("CriOS\\/" + s1)],
                    "UC Browser": [RegExp("(UCBrowser|UCWEB)\\/" + s1)],
                    [sI]: [s2],
                    [sG]: [s2],
                    [sL]: [RegExp("(Opera|OPR)\\/" + s1)],
                    [sB]: [RegExp(sB + "\\/" + s1)],
                    [sH]: [RegExp("FxiOS\\/" + s1)],
                    [s0]: [RegExp("Konqueror[:/]?" + s1, "i")],
                    [sC]: [RegExp(sC + " " + s1), s2],
                    [sW]: [RegExp("android\\s" + s1, "i")],
                    [sR]: [RegExp(sF + "\\/" + s1)],
                    [sA]: [RegExp("(rv:|MSIE )" + s1)],
                    Mozilla: [RegExp("rv:" + s1)]
                },
                rt = function(e, t) {
                    var i = re[s9(e, t)];
                    if ($(i)) return null;
                    for (var s = 0; s < i.length; s++) {
                        var r = i[s],
                            n = e.match(r);
                        if (n) return parseFloat(n[n.length - 2])
                    }
                    return null
                },
                ri = [
                    [RegExp(sU + "; " + sU + " (.*?)[);]", "i"), e => [sU, e && e[1] || ""]],
                    [RegExp(sj, "i"), [sj, ""]],
                    [RegExp(sz, "i"), [sz, ""]],
                    [s4, [sC, ""]],
                    [RegExp(sV, "i"), (e, t) => {
                        if (/Phone/.test(t) || /WPDesktop/.test(t)) return [sJ, ""];
                        if (new RegExp(sy).test(t) && !/IEMobile\b/.test(t)) return [sV + " " + sy, ""];
                        var i = /Windows NT ([0-9.]+)/i.exec(t);
                        if (i && i[1]) {
                            var s = s8[i[1]] || "";
                            return /arm/i.test(t) && (s = "RT"), [sV, s]
                        }
                        return [sV, ""]
                    }],
                    [/((iPhone|iPad|iPod).*?OS (\d+)_(\d+)_?(\d+)?|iPhone)/, e => e && e[3] ? ["iOS", [e[3], e[4], e[5] || "0"].join(".")] : ["iOS", ""]],
                    [/(watch.*\/(\d+\.\d+\.\d+)|watch os,(\d+\.\d+),)/i, e => {
                        var t = "";
                        return e && e.length >= 3 && (t = $(e[2]) ? e[3] : e[2]), ["watchOS", t]
                    }],
                    [RegExp("(" + sb + " (\\d+)\\.(\\d+)\\.?(\\d+)?|" + sb + ")", "i"), e => e && e[2] ? [sb, [e[2], e[3], e[4] || "0"].join(".")] : [sb, ""]],
                    [/Mac OS X (\d+)[_.](\d+)[_.]?(\d+)?/i, e => {
                        var t = ["Mac OS X", ""];
                        if (e && e[1]) {
                            var i = [e[1], e[2], e[3] || "0"];
                            t[1] = i.join(".")
                        }
                        return t
                    }],
                    [/Mac/i, ["Mac OS X", ""]],
                    [/CrOS/, [s$, ""]],
                    [/Linux|debian/i, ["Linux", ""]]
                ],
                rs = function(e) {
                    return s6.test(e) ? sj : s5.test(e) ? sz : s3.test(e) ? sU : RegExp(sK, "i").test(e) ? sK : RegExp("(" + sJ + "|WPDesktop)", "i").test(e) ? sJ : /iPad/.test(e) ? sk : /iPod/.test(e) ? "iPod Touch" : /iPhone/.test(e) ? "iPhone" : /(watch)(?: ?os[,/]|\d,\d\/)[\d.]+/i.test(e) ? sx : s4.test(e) ? sC : /(kobo)\s(ereader|touch)/i.test(e) ? "Kobo" : RegExp(sY, "i").test(e) ? sY : /(kf[a-z]{2}wi|aeo[c-r]{2})( bui|\))/i.test(e) || /(kf[a-z]+)( bui|\)).+silk\//i.test(e) ? "Kindle Fire" : /(Android|ZTE)/i.test(e) ? !new RegExp(sy).test(e) || /(9138B|TB782B|Nexus [97]|pixel c|HUAWEISHT|BTV|noble nook|smart ultra 6)/i.test(e) ? /pixel[\daxl ]{1,6}/i.test(e) && !/pixel c/i.test(e) || /(huaweimed-al00|tah-|APA|SM-G92|i980|zte|U304AA)/i.test(e) || /lmy47v/i.test(e) && !/QTAQZ3/i.test(e) ? sb : sS : sb : RegExp("(pda|" + sy + ")", "i").test(e) ? sQ : RegExp(sw, "i").test(e) && !RegExp(sw + " pc", "i").test(e) ? sZ : ""
                },
                rr = "https?://(.*)",
                rn = ["gclid", "gclsrc", "dclid", "gbraid", "wbraid", "fbclid", "msclkid", "twclid", "li_fat_id", "igshid", "ttclid", "rdt_cid", "epik", "qclid", "sccid", "irclid", "_kx"],
                ro = ee(["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term", "gad_source", "mc_cid"], rn),
                ra = "<masked>";

            function rl(e, t, i) {
                if (!u) return {};
                var s = t ? ee([], rn, i || []) : [];
                return rc(th(u.URL, s, ra), e)
            }

            function rc(e, t) {
                var i = ro.concat(t || []),
                    s = {};
                return Q(i, function(t) {
                    var i = td(e, t);
                    s[t] = i || null
                }), s
            }

            function ru(e) {
                var t = e ? 0 === e.search(rr + "google.([^/?]*)") ? "google" : 0 === e.search(rr + "bing.com") ? "bing" : 0 === e.search(rr + "yahoo.com") ? "yahoo" : 0 === e.search(rr + "duckduckgo.com") ? "duckduckgo" : null : null,
                    i = {};
                if (!M(t)) {
                    i.$search_engine = t;
                    var s = u ? td(u.referrer, "yahoo" != t ? "q" : "p") : "";
                    s.length && (i.ph_keyword = s)
                }
                return i
            }

            function rd() {
                return navigator.language || navigator.userLanguage
            }

            function rh() {
                return (null == u ? void 0 : u.referrer) || "$direct"
            }

            function r_(e, t) {
                var i = e ? ee([], rn, t || []) : [],
                    s = null == d ? void 0 : d.href.substring(0, 1e3);
                return {
                    r: rh().substring(0, 1e3),
                    u: s ? th(s, i, ra) : void 0
                }
            }

            function rp(e) {
                var t, {
                        r: i,
                        u: s
                    } = e,
                    r = {
                        $referrer: i,
                        $referring_domain: null == i ? void 0 : "$direct" == i ? "$direct" : null == (t = tc(i)) ? void 0 : t.host
                    };
                if (s) {
                    r.$current_url = s;
                    var n = tc(s);
                    r.$host = null == n ? void 0 : n.host, r.$pathname = null == n ? void 0 : n.pathname, Z(r, rc(s))
                }
                return i && Z(r, ru(i)), r
            }

            function rg() {
                try {
                    return Intl.DateTimeFormat().resolvedOptions().timeZone
                } catch (e) {
                    return
                }
            }
            var rf, rv = z("[FeatureFlags]"),
                rm = "$active_feature_flags",
                ry = "$override_feature_flags",
                rb = "$feature_flag_payloads",
                rw = "$override_feature_flag_payloads",
                rS = "$feature_flag_request_id",
                rk = e => {
                    var t = {};
                    for (var [i, s] of et(e || {})) s && (t[i] = s);
                    return t
                },
                rE = e => {
                    var t = e.flags;
                    return t ? (e.featureFlags = Object.fromEntries(Object.keys(t).map(e => {
                        var i;
                        return [e, null != (i = t[e].variant) ? i : t[e].enabled]
                    })), e.featureFlagPayloads = Object.fromEntries(Object.keys(t).filter(e => t[e].enabled).filter(e => {
                        var i;
                        return null == (i = t[e].metadata) ? void 0 : i.payload
                    }).map(e => {
                        var i;
                        return [e, null == (i = t[e].metadata) ? void 0 : i.payload]
                    }))) : rv.warn("Using an older version of the feature flags endpoint. Please upgrade your PostHog server to the latest version"), e
                };
            ! function(e) {
                e.FeatureFlags = "feature_flags", e.Recordings = "recordings"
            }(rf || (rf = {}));
            class rx {
                constructor(e) {
                    J(this, "_override_warning", !1), J(this, "_hasLoadedFlags", !1), J(this, "_requestInFlight", !1), J(this, "_reloadingDisabled", !1), J(this, "_additionalReloadRequested", !1), J(this, "_decideCalled", !1), J(this, "_flagsLoadedFromRemote", !1), this._instance = e, this.featureFlagEventHandlers = []
                }
                decide() {
                    if (this._instance.config.__preview_remote_config) this._decideCalled = !0;
                    else {
                        var e = !this._reloadDebouncer && (this._instance.config.advanced_disable_feature_flags || this._instance.config.advanced_disable_feature_flags_on_first_load);
                        this._callDecideEndpoint({
                            disableFlags: e
                        })
                    }
                }
                get hasLoadedFlags() {
                    return this._hasLoadedFlags
                }
                getFlags() {
                    return Object.keys(this.getFlagVariants())
                }
                getFlagsWithDetails() {
                    var e = this._instance.get_property(eT),
                        t = this._instance.get_property(ry),
                        i = this._instance.get_property(rw);
                    if (!i && !t) return e || {};
                    var s = Z({}, e || {});
                    for (var r of [...new Set([...Object.keys(i || {}), ...Object.keys(t || {})])]) {
                        var n, o, a = s[r],
                            l = null == t ? void 0 : t[r],
                            c = $(l) ? null != (n = null == a ? void 0 : a.enabled) && n : !!l,
                            u = $(l) ? a.variant : "string" == typeof l ? l : void 0,
                            d = null == i ? void 0 : i[r],
                            h = V(V({}, a), {}, {
                                enabled: c,
                                variant: c ? null != u ? u : null == a ? void 0 : a.variant : void 0
                            });
                        c !== (null == a ? void 0 : a.enabled) && (h.original_enabled = null == a ? void 0 : a.enabled), u !== (null == a ? void 0 : a.variant) && (h.original_variant = null == a ? void 0 : a.variant), d && (h.metadata = V(V({}, null == a ? void 0 : a.metadata), {}, {
                            payload: d,
                            original_payload: null == a || null == (o = a.metadata) ? void 0 : o.payload
                        })), s[r] = h
                    }
                    return this._override_warning || (rv.warn(" Overriding feature flag details!", {
                        flagDetails: e,
                        overriddenPayloads: i,
                        finalDetails: s
                    }), this._override_warning = !0), s
                }
                getFlagVariants() {
                    var e = this._instance.get_property(eF),
                        t = this._instance.get_property(ry);
                    if (!t) return e || {};
                    for (var i = Z({}, e), s = Object.keys(t), r = 0; r < s.length; r++) i[s[r]] = t[s[r]];
                    return this._override_warning || (rv.warn(" Overriding feature flags!", {
                        enabledFlags: e,
                        overriddenFlags: t,
                        finalFlags: i
                    }), this._override_warning = !0), i
                }
                getFlagPayloads() {
                    var e = this._instance.get_property(rb),
                        t = this._instance.get_property(rw);
                    if (!t) return e || {};
                    for (var i = Z({}, e || {}), s = Object.keys(t), r = 0; r < s.length; r++) i[s[r]] = t[s[r]];
                    return this._override_warning || (rv.warn(" Overriding feature flag payloads!", {
                        flagPayloads: e,
                        overriddenPayloads: t,
                        finalPayloads: i
                    }), this._override_warning = !0), i
                }
                reloadFeatureFlags() {
                    this._reloadingDisabled || this._instance.config.advanced_disable_feature_flags || this._reloadDebouncer || (this._reloadDebouncer = setTimeout(() => {
                        this._callDecideEndpoint()
                    }, 5))
                }
                _clearDebouncer() {
                    clearTimeout(this._reloadDebouncer), this._reloadDebouncer = void 0
                }
                ensureFlagsLoaded() {
                    this._hasLoadedFlags || this._requestInFlight || this._reloadDebouncer || this.reloadFeatureFlags()
                }
                setAnonymousDistinctId(e) {
                    this.$anon_distinct_id = e
                }
                setReloadingPaused(e) {
                    this._reloadingDisabled = e
                }
                _callDecideEndpoint(e) {
                    var t;
                    if (this._clearDebouncer(), !this._instance.config.advanced_disable_decide)
                        if (this._requestInFlight) this._additionalReloadRequested = !0;
                        else {
                            var i = {
                                token: this._instance.config.token,
                                distinct_id: this._instance.get_distinct_id(),
                                groups: this._instance.getGroups(),
                                $anon_distinct_id: this.$anon_distinct_id,
                                person_properties: V(V({}, (null == (t = this._instance.persistence) ? void 0 : t.get_initial_props()) || {}), this._instance.get_property(e$) || {}),
                                group_properties: this._instance.get_property(eO)
                            };
                            (null != e && e.disableFlags || this._instance.config.advanced_disable_feature_flags) && (i.disable_flags = !0);
                            var r = this._instance.config.__preview_flags_v2 && this._instance.config.__preview_remote_config;
                            r && (i.timezone = rg()), this._requestInFlight = !0, this._instance._send_request({
                                method: "POST",
                                url: this._instance.requestRouter.endpointFor("api", r ? "/flags/?v=2" : "/decide/?v=4"),
                                data: i,
                                compression: this._instance.config.disable_compression ? void 0 : s.Base64,
                                timeout: this._instance.config.feature_flag_request_timeout_ms,
                                callback: e => {
                                    var t, s, r, n = !0;
                                    200 === e.statusCode && (this._additionalReloadRequested || (this.$anon_distinct_id = void 0), n = !1), this._requestInFlight = !1, this._decideCalled || (this._decideCalled = !0, this._instance._onRemoteConfig(null != (r = e.json) ? r : {})), i.disable_flags && !this._additionalReloadRequested || (this._flagsLoadedFromRemote = !n, e.json && null != (t = e.json.quotaLimited) && t.includes(rf.FeatureFlags) ? rv.warn("You have hit your feature flags quota limit, and will not be able to load feature flags until the quota is reset.  Please visit https://posthog.com/docs/billing/limits-alerts to learn more.") : (this.receivedFeatureFlags(null != (s = e.json) ? s : {}, n), this._additionalReloadRequested && (this._additionalReloadRequested = !1, this._callDecideEndpoint())))
                                }
                            })
                        }
                }
                getFeatureFlag(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    if (this._hasLoadedFlags || this.getFlags() && this.getFlags().length > 0) {
                        var i = this.getFlagVariants()[e],
                            s = "".concat(i),
                            r = this._instance.get_property(rS) || void 0,
                            n = this._instance.get_property(eL) || {};
                        if ((t.send_event || !("send_event" in t)) && (!(e in n) || !n[e].includes(s))) {
                            P(n[e]) ? n[e].push(s) : n[e] = [s], null == (l = this._instance.persistence) || l.register({
                                [eL]: n
                            });
                            var o = this.getFeatureFlagDetails(e),
                                a = {
                                    $feature_flag: e,
                                    $feature_flag_response: i,
                                    $feature_flag_payload: this.getFeatureFlagPayload(e) || null,
                                    $feature_flag_request_id: r,
                                    $feature_flag_bootstrapped_response: (null == (c = this._instance.config.bootstrap) || null == (u = c.featureFlags) ? void 0 : u[e]) || null,
                                    $feature_flag_bootstrapped_payload: (null == (d = this._instance.config.bootstrap) || null == (h = d.featureFlagPayloads) ? void 0 : h[e]) || null,
                                    $used_bootstrap_value: !this._flagsLoadedFromRemote
                                };
                            $(null == o || null == (_ = o.metadata) ? void 0 : _.version) || (a.$feature_flag_version = o.metadata.version);
                            var l, c, u, d, h, _, p, g, f, v, m, y, b = null != (p = null == o || null == (g = o.reason) ? void 0 : g.description) ? p : null == o || null == (f = o.reason) ? void 0 : f.code;
                            b && (a.$feature_flag_reason = b), null != o && null != (v = o.metadata) && v.id && (a.$feature_flag_id = o.metadata.id), $(null == o ? void 0 : o.original_variant) && $(null == o ? void 0 : o.original_enabled) || (a.$feature_flag_original_response = $(o.original_variant) ? o.original_enabled : o.original_variant), null != o && null != (m = o.metadata) && m.original_payload && (a.$feature_flag_original_payload = null == o || null == (y = o.metadata) ? void 0 : y.original_payload), this._instance.capture("$feature_flag_called", a)
                        }
                        return i
                    }
                    rv.warn('getFeatureFlag for key "' + e + "\" failed. Feature flags didn't load in time.")
                }
                getFeatureFlagDetails(e) {
                    return this.getFlagsWithDetails()[e]
                }
                getFeatureFlagPayload(e) {
                    return this.getFlagPayloads()[e]
                }
                getRemoteConfigPayload(e, t) {
                    var i = this._instance.config.token;
                    this._instance._send_request({
                        method: "POST",
                        url: this._instance.requestRouter.endpointFor("api", "/decide/?v=4"),
                        data: {
                            distinct_id: this._instance.get_distinct_id(),
                            token: i
                        },
                        compression: this._instance.config.disable_compression ? void 0 : s.Base64,
                        timeout: this._instance.config.feature_flag_request_timeout_ms,
                        callback: i => {
                            var s, r = null == (s = i.json) ? void 0 : s.featureFlagPayloads;
                            t((null == r ? void 0 : r[e]) || void 0)
                        }
                    })
                }
                isFeatureEnabled(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    if (this._hasLoadedFlags || this.getFlags() && this.getFlags().length > 0) return !!this.getFeatureFlag(e, t);
                    rv.warn('isFeatureEnabled for key "' + e + "\" failed. Feature flags didn't load in time.")
                }
                addFeatureFlagsHandler(e) {
                    this.featureFlagEventHandlers.push(e)
                }
                removeFeatureFlagsHandler(e) {
                    this.featureFlagEventHandlers = this.featureFlagEventHandlers.filter(t => t !== e)
                }
                receivedFeatureFlags(e, t) {
                    if (this._instance.persistence) {
                        this._hasLoadedFlags = !0;
                        var i = this.getFlagVariants(),
                            s = this.getFlagPayloads(),
                            r = this.getFlagsWithDetails();
                        ! function(e, t) {
                            var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                                s = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {},
                                r = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : {},
                                n = rE(e),
                                o = n.flags,
                                a = n.featureFlags,
                                l = n.featureFlagPayloads;
                            if (a) {
                                var c = e.requestId;
                                if (P(a)) {
                                    rv.warn("v1 of the feature flags endpoint is deprecated. Please use the latest version.");
                                    var u = {};
                                    if (a)
                                        for (var d = 0; d < a.length; d++) u[a[d]] = !0;
                                    t && t.register({
                                        [rm]: a,
                                        [eF]: u
                                    })
                                } else {
                                    var h = a,
                                        _ = l,
                                        p = o;
                                    e.errorsWhileComputingFlags && (h = V(V({}, i), h), _ = V(V({}, s), _), p = V(V({}, r), p)), t && t.register(V({
                                        [rm]: Object.keys(rk(h)),
                                        [eF]: h || {},
                                        [rb]: _ || {},
                                        [eT]: p || {}
                                    }, c ? {
                                        [rS]: c
                                    } : {}))
                                }
                            }
                        }(e, this._instance.persistence, i, s, r), this._fireFeatureFlagsCallbacks(t)
                    }
                }
                override(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    rv.warn("override is deprecated. Please use overrideFeatureFlags instead."), this.overrideFeatureFlags({
                        flags: e,
                        suppressWarning: t
                    })
                }
                overrideFeatureFlags(e) {
                    if (!this._instance.__loaded || !this._instance.persistence) return rv.uninitializedWarning("posthog.featureFlags.overrideFeatureFlags");
                    if (!1 === e) return this._instance.persistence.unregister(ry), this._instance.persistence.unregister(rw), void this._fireFeatureFlagsCallbacks();
                    if (e && "object" == typeof e && ("flags" in e || "payloads" in e)) {
                        var t;
                        if (this._override_warning = !!(null != (t = e.suppressWarning) && t), "flags" in e) {
                            if (!1 === e.flags) this._instance.persistence.unregister(ry);
                            else if (e.flags)
                                if (P(e.flags)) {
                                    for (var i = {}, s = 0; s < e.flags.length; s++) i[e.flags[s]] = !0;
                                    this._instance.persistence.register({
                                        [ry]: i
                                    })
                                } else this._instance.persistence.register({
                                    [ry]: e.flags
                                })
                        }
                        return "payloads" in e && (!1 === e.payloads ? this._instance.persistence.unregister(rw) : e.payloads && this._instance.persistence.register({
                            [rw]: e.payloads
                        })), void this._fireFeatureFlagsCallbacks()
                    }
                    this._fireFeatureFlagsCallbacks()
                }
                onFeatureFlags(e) {
                    if (this.addFeatureFlagsHandler(e), this._hasLoadedFlags) {
                        var {
                            flags: t,
                            flagVariants: i
                        } = this._prepareFeatureFlagsForCallbacks();
                        e(t, i)
                    }
                    return () => this.removeFeatureFlagsHandler(e)
                }
                updateEarlyAccessFeatureEnrollment(e, t) {
                    var i, s = (this._instance.get_property(eR) || []).find(t => t.flagKey === e),
                        r = {
                            ["$feature_enrollment/".concat(e)]: t
                        },
                        n = {
                            $feature_flag: e,
                            $feature_enrollment: t,
                            $set: r
                        };
                    s && (n.$early_access_feature_name = s.name), this._instance.capture("$feature_enrollment_update", n), this.setPersonPropertiesForFlags(r, !1);
                    var o = V(V({}, this.getFlagVariants()), {}, {
                        [e]: t
                    });
                    null == (i = this._instance.persistence) || i.register({
                        [rm]: Object.keys(rk(o)),
                        [eF]: o
                    }), this._fireFeatureFlagsCallbacks()
                }
                getEarlyAccessFeatures(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        i = arguments.length > 2 ? arguments[2] : void 0,
                        s = this._instance.get_property(eR),
                        r = i ? "&".concat(i.map(e => "stage=".concat(e)).join("&")) : "";
                    if (s && !t) return e(s);
                    this._instance._send_request({
                        url: this._instance.requestRouter.endpointFor("api", "/api/early_access_features/?token=".concat(this._instance.config.token).concat(r)),
                        method: "GET",
                        callback: t => {
                            var i;
                            if (t.json) {
                                var s = t.json.earlyAccessFeatures;
                                return null == (i = this._instance.persistence) || i.register({
                                    [eR]: s
                                }), e(s)
                            }
                        }
                    })
                }
                _prepareFeatureFlagsForCallbacks() {
                    var e = this.getFlags(),
                        t = this.getFlagVariants();
                    return {
                        flags: e.filter(e => t[e]),
                        flagVariants: Object.keys(t).filter(e => t[e]).reduce((e, i) => (e[i] = t[i], e), {})
                    }
                }
                _fireFeatureFlagsCallbacks(e) {
                    var {
                        flags: t,
                        flagVariants: i
                    } = this._prepareFeatureFlagsForCallbacks();
                    this.featureFlagEventHandlers.forEach(s => s(t, i, {
                        errorsLoading: e
                    }))
                }
                setPersonPropertiesForFlags(e) {
                    var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                        i = this._instance.get_property(e$) || {};
                    this._instance.register({
                        [e$]: V(V({}, i), e)
                    }), t && this._instance.reloadFeatureFlags()
                }
                resetPersonPropertiesForFlags() {
                    this._instance.unregister(e$)
                }
                setGroupPropertiesForFlags(e) {
                    var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
                        i = this._instance.get_property(eO) || {};
                    0 !== Object.keys(i).length && Object.keys(i).forEach(t => {
                        i[t] = V(V({}, i[t]), e[t]), delete e[t]
                    }), this._instance.register({
                        [eO]: V(V({}, i), e)
                    }), t && this._instance.reloadFeatureFlags()
                }
                resetGroupPropertiesForFlags(e) {
                    if (e) {
                        var t = this._instance.get_property(eO) || {};
                        this._instance.register({
                            [eO]: V(V({}, t), {}, {
                                [e]: {}
                            })
                        })
                    } else this._instance.unregister(eO)
                }
            }
            var rI = ["cookie", "localstorage", "localstorage+cookie", "sessionstorage", "memory"];
            class rC {
                constructor(e) {
                    this._config = e, this.props = {}, this.campaign_params_saved = !1, this.name = (e => {
                        var t = "";
                        return e.token && (t = e.token.replace(/\+/g, "PL").replace(/\//g, "SL").replace(/=/g, "EQ")), e.persistence_name ? "ph_" + e.persistence_name : "ph_" + t + "_posthog"
                    })(e), this.storage = this._buildStorage(e), this.load(), e.debug && j.info("Persistence loaded", e.persistence, V({}, this.props)), this.update_config(e, e), this.save()
                }
                _buildStorage(e) {
                    -1 === rI.indexOf(e.persistence.toLowerCase()) && (j.critical("Unknown persistence type " + e.persistence + "; falling back to localStorage+cookie"), e.persistence = "localStorage+cookie");
                    var t = e.persistence.toLowerCase();
                    return "localstorage" === t && tR.is_supported() ? tR : "localstorage+cookie" === t && t$.is_supported() ? t$ : "sessionstorage" === t && tL.is_supported() ? tL : "memory" === t ? tA : "cookie" === t ? tP : t$.is_supported() ? t$ : tP
                }
                properties() {
                    var e = {};
                    return Q(this.props, function(t, i) {
                        if (i === eF && R(t))
                            for (var s, r = Object.keys(t), n = 0; n < r.length; n++) e["$feature/".concat(r[n])] = t[r[n]];
                        else s = !1, (M(eG) ? s : l && eG.indexOf === l ? -1 != eG.indexOf(i) : (Q(eG, function(e) {
                            if (s || (s = e === i)) return K
                        }), s)) || (e[i] = t)
                    }), e
                }
                load() {
                    if (!this.disabled) {
                        var e = this.storage.parse(this.name);
                        e && (this.props = Z({}, e))
                    }
                }
                save() {
                    this.disabled || this.storage.set(this.name, this.props, this.expire_days, this.cross_subdomain, this.secure, this._config.debug)
                }
                remove() {
                    this.storage.remove(this.name, !1), this.storage.remove(this.name, !0)
                }
                clear() {
                    this.remove(), this.props = {}
                }
                register_once(e, t, i) {
                    if (R(e)) {
                        $(t) && (t = "None"), this.expire_days = $(i) ? this.default_expiry : i;
                        var s = !1;
                        if (Q(e, (e, i) => {
                                this.props.hasOwnProperty(i) && this.props[i] !== t || (this.props[i] = e, s = !0)
                            }), s) return this.save(), !0
                    }
                    return !1
                }
                register(e, t) {
                    if (R(e)) {
                        this.expire_days = $(t) ? this.default_expiry : t;
                        var i = !1;
                        if (Q(e, (t, s) => {
                                e.hasOwnProperty(s) && this.props[s] !== t && (this.props[s] = t, i = !0)
                            }), i) return this.save(), !0
                    }
                    return !1
                }
                unregister(e) {
                    e in this.props && (delete this.props[e], this.save())
                }
                update_campaign_params() {
                    if (!this.campaign_params_saved) {
                        var e = rl(this._config.custom_campaign_params, this._config.mask_personal_data_properties, this._config.custom_personal_data_properties);
                        T(er(e)) || this.register(e), this.campaign_params_saved = !0
                    }
                }
                update_search_keyword() {
                    var e;
                    this.register((e = null == u ? void 0 : u.referrer) ? ru(e) : {})
                }
                update_referrer_info() {
                    var e;
                    this.register_once({
                        $referrer: rh(),
                        $referring_domain: null != u && u.referrer && (null == (e = tc(u.referrer)) ? void 0 : e.host) || "$direct"
                    }, void 0)
                }
                set_initial_person_info() {
                    this.props[eB] || this.props[eH] || this.register_once({
                        [ej]: r_(this._config.mask_personal_data_properties, this._config.custom_personal_data_properties)
                    }, void 0)
                }
                get_referrer_info() {
                    return er({
                        $referrer: this.props.$referrer,
                        $referring_domain: this.props.$referring_domain
                    })
                }
                get_initial_props() {
                    var e = {};
                    Q([eH, eB], t => {
                        var i = this.props[t];
                        i && Q(i, function(t, i) {
                            e["$initial_" + k(i)] = t
                        })
                    });
                    var t, i, s = this.props[ej];
                    return s && Z(e, (t = rp(s), i = {}, Q(t, function(e, t) {
                        i["$initial_".concat(k(t))] = e
                    }), i)), e
                }
                safe_merge(e) {
                    return Q(this.props, function(t, i) {
                        i in e || (e[i] = t)
                    }), e
                }
                update_config(e, t) {
                    if (this.default_expiry = this.expire_days = e.cookie_expiration, this.set_disabled(e.disable_persistence), this.set_cross_subdomain(e.cross_subdomain_cookie), this.set_secure(e.secure_cookie), e.persistence !== t.persistence) {
                        var i = this._buildStorage(e),
                            s = this.props;
                        this.clear(), this.storage = i, this.props = s, this.save()
                    }
                }
                set_disabled(e) {
                    this.disabled = e, this.disabled ? this.remove() : this.save()
                }
                set_cross_subdomain(e) {
                    e !== this.cross_subdomain && (this.cross_subdomain = e, this.remove(), this.save())
                }
                get_cross_subdomain() {
                    return !!this.cross_subdomain
                }
                set_secure(e) {
                    e !== this.secure && (this.secure = e, this.remove(), this.save())
                }
                set_event_timer(e, t) {
                    var i = this.props[eu] || {};
                    i[e] = t, this.props[eu] = i, this.save()
                }
                remove_event_timer(e) {
                    var t = (this.props[eu] || {})[e];
                    return $(t) || (delete this.props[eu][e], this.save()), t
                }
                get_property(e) {
                    return this.props[e]
                }
                set_property(e, t) {
                    this.props[e] = t, this.save()
                }
            }
            class rP {
                constructor() {
                    J(this, "_events", {}), this._events = {}
                }
                on(e, t) {
                    return this._events[e] || (this._events[e] = []), this._events[e].push(t), () => {
                        this._events[e] = this._events[e].filter(e => e !== t)
                    }
                }
                emit(e, t) {
                    for (var i of this._events[e] || []) i(t);
                    for (var s of this._events["*"] || []) s(e, t)
                }
            }
            var rF = function(e, t) {
                if (! function(e) {
                        try {
                            new RegExp(e)
                        } catch (e) {
                            return !1
                        }
                        return !0
                    }(t)) return !1;
                try {
                    return new RegExp(t).test(e)
                } catch (e) {
                    return !1
                }
            };
            class rR {
                constructor(e) {
                    J(this, "_debugEventEmitter", new rP), J(this, "_checkStep", (e, t) => this._checkStepEvent(e, t) && this._checkStepUrl(e, t) && this._checkStepElement(e, t)), J(this, "_checkStepEvent", (e, t) => null == t || !t.event || (null == e ? void 0 : e.event) === (null == t ? void 0 : t.event)), this._instance = e, this._actionEvents = new Set, this._actionRegistry = new Set
                }
                init() {
                    var e, t;
                    $(null == (e = this._instance) ? void 0 : e._addCaptureHook) || null == (t = this._instance) || t._addCaptureHook((e, t) => {
                        this.on(e, t)
                    })
                }
                register(e) {
                    var t, i;
                    if (!$(null == (t = this._instance) ? void 0 : t._addCaptureHook) && (e.forEach(e => {
                            var t, i;
                            null == (t = this._actionRegistry) || t.add(e), null == (i = e.steps) || i.forEach(e => {
                                var t;
                                null == (t = this._actionEvents) || t.add((null == e ? void 0 : e.event) || "")
                            })
                        }), null != (i = this._instance) && i.autocapture)) {
                        var s, r = new Set;
                        e.forEach(e => {
                            var t;
                            null == (t = e.steps) || t.forEach(e => {
                                null != e && e.selector && r.add(null == e ? void 0 : e.selector)
                            })
                        }), null == (s = this._instance) || s.autocapture.setElementSelectors(r)
                    }
                }
                on(e, t) {
                    var i;
                    null != t && 0 != e.length && (this._actionEvents.has(e) || this._actionEvents.has(null == t ? void 0 : t.event)) && this._actionRegistry && (null == (i = this._actionRegistry) ? void 0 : i.size) > 0 && this._actionRegistry.forEach(e => {
                        this._checkAction(t, e) && this._debugEventEmitter.emit("actionCaptured", e.name)
                    })
                }
                _addActionHook(e) {
                    this.onAction("actionCaptured", t => e(t))
                }
                _checkAction(e, t) {
                    if (null == (null == t ? void 0 : t.steps)) return !1;
                    for (var i of t.steps)
                        if (this._checkStep(e, i)) return !0;
                    return !1
                }
                onAction(e, t) {
                    return this._debugEventEmitter.on(e, t)
                }
                _checkStepUrl(e, t) {
                    if (null != t && t.url) {
                        var i, s = null == e || null == (i = e.properties) ? void 0 : i.$current_url;
                        if (!s || "string" != typeof s || !rR._matchString(s, null == t ? void 0 : t.url, (null == t ? void 0 : t.url_matching) || "contains")) return !1
                    }
                    return !0
                }
                static _matchString(e, t, i) {
                    switch (i) {
                        case "regex":
                            return !!r && rF(e, t);
                        case "exact":
                            return t === e;
                        case "contains":
                            return rF(e, rR._escapeStringRegexp(t).replace(/_/g, ".").replace(/%/g, ".*"));
                        default:
                            return !1
                    }
                }
                static _escapeStringRegexp(e) {
                    return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d")
                }
                _checkStepElement(e, t) {
                    if ((null != t && t.href || null != t && t.tag_name || null != t && t.text) && !this._getElementsList(e).some(e => !(null != t && t.href && !rR._matchString(e.href || "", null == t ? void 0 : t.href, (null == t ? void 0 : t.href_matching) || "exact")) && (null == t || !t.tag_name || e.tag_name === (null == t ? void 0 : t.tag_name)) && !(null != t && t.text && !rR._matchString(e.text || "", null == t ? void 0 : t.text, (null == t ? void 0 : t.text_matching) || "exact") && !rR._matchString(e.$el_text || "", null == t ? void 0 : t.text, (null == t ? void 0 : t.text_matching) || "exact")))) return !1;
                    if (null != t && t.selector) {
                        var i, s = null == e || null == (i = e.properties) ? void 0 : i.$element_selectors;
                        if (!s || !s.includes(null == t ? void 0 : t.selector)) return !1
                    }
                    return !0
                }
                _getElementsList(e) {
                    return null == (null == e ? void 0 : e.properties.$elements) ? [] : null == e ? void 0 : e.properties.$elements
                }
            }
            var rT = z("[Surveys]");
            class r$ {
                constructor(e) {
                    this._instance = e, this._eventToSurveys = new Map, this._actionToSurveys = new Map
                }
                register(e) {
                    var t;
                    $(null == (t = this._instance) ? void 0 : t._addCaptureHook) || (this._setupEventBasedSurveys(e), this._setupActionBasedSurveys(e))
                }
                _setupActionBasedSurveys(e) {
                    var t = e.filter(e => {
                        var t, i, s, r;
                        return (null == (t = e.conditions) ? void 0 : t.actions) && (null == (i = e.conditions) || null == (s = i.actions) || null == (r = s.values) ? void 0 : r.length) > 0
                    });
                    0 !== t.length && (null == this._actionMatcher && (this._actionMatcher = new rR(this._instance), this._actionMatcher.init(), this._actionMatcher._addActionHook(e => {
                        this.onAction(e)
                    })), t.forEach(e => {
                        var t, i, s, r, n, o, a, l, c, u;
                        e.conditions && null != (t = e.conditions) && t.actions && null != (i = e.conditions) && null != (s = i.actions) && s.values && (null == (r = e.conditions) || null == (n = r.actions) || null == (o = n.values) ? void 0 : o.length) > 0 && (null == (a = this._actionMatcher) || a.register(e.conditions.actions.values), null == (l = e.conditions) || null == (c = l.actions) || null == (u = c.values) || u.forEach(t => {
                            if (t && t.name) {
                                var i = this._actionToSurveys.get(t.name);
                                i && i.push(e.id), this._actionToSurveys.set(t.name, i || [e.id])
                            }
                        }))
                    }))
                }
                _setupEventBasedSurveys(e) {
                    var t;
                    0 !== e.filter(e => {
                        var t, i, s, r;
                        return (null == (t = e.conditions) ? void 0 : t.events) && (null == (i = e.conditions) || null == (s = i.events) || null == (r = s.values) ? void 0 : r.length) > 0
                    }).length && (null == (t = this._instance) || t._addCaptureHook((e, t) => {
                        this.onEvent(e, t)
                    }), e.forEach(e => {
                        var t, i, s;
                        null == (t = e.conditions) || null == (i = t.events) || null == (s = i.values) || s.forEach(t => {
                            if (t && t.name) {
                                var i = this._eventToSurveys.get(t.name);
                                i && i.push(e.id), this._eventToSurveys.set(t.name, i || [e.id])
                            }
                        })
                    }))
                }
                onEvent(e, t) {
                    var i, s, r = (null == (i = this._instance) || null == (s = i.persistence) ? void 0 : s.props[eM]) || [];
                    if ("survey shown" === e && t && r.length > 0) {
                        rT.info("survey event matched, removing survey from activated surveys", {
                            event: e,
                            eventPayload: t,
                            existingActivatedSurveys: r
                        });
                        var n, o = null == t || null == (n = t.properties) ? void 0 : n.$survey_id;
                        if (o) {
                            var a = r.indexOf(o);
                            a >= 0 && (r.splice(a, 1), this._updateActivatedSurveys(r))
                        }
                    } else this._eventToSurveys.has(e) && (rT.info("survey event matched, updating activated surveys", {
                        event: e,
                        surveys: this._eventToSurveys.get(e)
                    }), this._updateActivatedSurveys(r.concat(this._eventToSurveys.get(e) || [])))
                }
                onAction(e) {
                    var t, i, s = (null == (t = this._instance) || null == (i = t.persistence) ? void 0 : i.props[eM]) || [];
                    this._actionToSurveys.has(e) && this._updateActivatedSurveys(s.concat(this._actionToSurveys.get(e) || []))
                }
                _updateActivatedSurveys(e) {
                    var t, i;
                    null == (t = this._instance) || null == (i = t.persistence) || i.register({
                        [eM]: [...new Set(e)]
                    })
                }
                getSurveys() {
                    var e, t;
                    return (null == (e = this._instance) || null == (t = e.persistence) ? void 0 : t.props[eM]) || []
                }
                getEventToSurveys() {
                    return this._eventToSurveys
                }
                _getActionMatcher() {
                    return this._actionMatcher
                }
            }
            class rO {
                constructor(e) {
                    J(this, "_surveyManager", null), J(this, "_isFetchingSurveys", !1), J(this, "_isInitializingSurveys", !1), J(this, "_surveyCallbacks", []), this._instance = e, this._surveyEventReceiver = null
                }
                onRemoteConfig(e) {
                    var t = e.surveys;
                    if (L(t)) return rT.warn("Decide not loaded yet. Not loading surveys.");
                    var i = P(t);
                    this._hasSurveys = i ? t.length > 0 : t, rT.info("decide response received, hasSurveys: ".concat(this._hasSurveys)), this._hasSurveys && this.loadIfEnabled()
                }
                reset() {
                    localStorage.removeItem("lastSeenSurveyDate");
                    for (var e = [], t = 0; t < localStorage.length; t++) {
                        var i = localStorage.key(t);
                        null != i && i.startsWith("seenSurvey_") && e.push(i)
                    }
                    e.forEach(e => localStorage.removeItem(e))
                }
                loadIfEnabled() {
                    if (!this._surveyManager)
                        if (this._isInitializingSurveys) rT.info("Already initializing surveys, skipping...");
                        else if (this._instance.config.disable_surveys) rT.info("Disabled. Not loading surveys.");
                    else if (this._hasSurveys) {
                        var e = null == f ? void 0 : f.__PosthogExtensions__;
                        if (e) {
                            this._isInitializingSurveys = !0;
                            try {
                                var t = e.generateSurveys;
                                if (t) return void this._completeSurveyInitialization(t);
                                var i = e.loadExternalDependency;
                                if (!i) return void this._handleSurveyLoadError("PostHog loadExternalDependency extension not found.");
                                i(this._instance, "surveys", t => {
                                    t || !e.generateSurveys ? this._handleSurveyLoadError("Could not load surveys script", t) : this._completeSurveyInitialization(e.generateSurveys)
                                })
                            } catch (e) {
                                throw this._handleSurveyLoadError("Error initializing surveys", e), e
                            } finally {
                                this._isInitializingSurveys = !1
                            }
                        } else rT.error("PostHog Extensions not found.")
                    } else rT.info("No surveys to load.")
                }
                _completeSurveyInitialization(e) {
                    this._surveyManager = e(this._instance), this._surveyEventReceiver = new r$(this._instance), rT.info("Surveys loaded successfully"), this._notifySurveyCallbacks({
                        isLoaded: !0
                    })
                }
                _handleSurveyLoadError(e, t) {
                    rT.error(e, t), this._notifySurveyCallbacks({
                        isLoaded: !1,
                        error: e
                    })
                }
                onSurveysLoaded(e) {
                    return this._surveyCallbacks.push(e), this._surveyManager && this._notifySurveyCallbacks({
                        isLoaded: !0
                    }), () => {
                        this._surveyCallbacks = this._surveyCallbacks.filter(t => t !== e)
                    }
                }
                getSurveys(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    if (this._instance.config.disable_surveys) return rT.info("Disabled. Not loading surveys."), e([]);
                    var i = this._instance.get_property(eA);
                    if (i && !t) return e(i, {
                        isLoaded: !0
                    });
                    if (this._isFetchingSurveys) return e([], {
                        isLoaded: !1,
                        error: "Surveys are already being loaded"
                    });
                    try {
                        this._isFetchingSurveys = !0, this._instance._send_request({
                            url: this._instance.requestRouter.endpointFor("api", "/api/surveys/?token=".concat(this._instance.config.token)),
                            method: "GET",
                            timeout: this._instance.config.surveys_request_timeout_ms,
                            callback: t => {
                                this._isFetchingSurveys = !1;
                                var i = t.statusCode;
                                if (200 !== i || !t.json) {
                                    var s = "Surveys API could not be loaded, status: ".concat(i);
                                    return rT.error(s), e([], {
                                        isLoaded: !1,
                                        error: s
                                    })
                                }
                                var r, n, o = t.json.surveys || [],
                                    a = o.filter(e => {
                                        var t, i, s, r, n, o;
                                        return !(!e.start_date || e.end_date) && (!(null == (t = e.conditions) || null == (i = t.events) || null == (s = i.values) || !s.length) || !(null == (r = e.conditions) || null == (n = r.actions) || null == (o = n.values) || !o.length))
                                    });
                                return a.length > 0 && (null == (n = this._surveyEventReceiver) || n.register(a)), null == (r = this._instance.persistence) || r.register({
                                    [eA]: o
                                }), e(o, {
                                    isLoaded: !0
                                })
                            }
                        })
                    } catch (e) {
                        throw this._isFetchingSurveys = !1, e
                    }
                }
                _notifySurveyCallbacks(e) {
                    for (var t of this._surveyCallbacks) try {
                        e.isLoaded ? this.getSurveys(t) : t([], e)
                    } catch (e) {
                        rT.error("Error in survey callback", e)
                    }
                }
                getActiveMatchingSurveys(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    if (!L(this._surveyManager)) return this._surveyManager.getActiveMatchingSurveys(e, t);
                    rT.warn("init was not called")
                }
                _getSurveyById(e) {
                    var t = null;
                    return this.getSurveys(i => {
                        var s;
                        t = null != (s = i.find(t => t.id === e)) ? s : null
                    }), t
                }
                _checkSurveyEligibility(e) {
                    if (L(this._surveyManager)) return {
                        eligible: !1,
                        reason: "SDK is not enabled or survey functionality is not yet loaded"
                    };
                    var t = "string" == typeof e ? this._getSurveyById(e) : e;
                    return t ? this._surveyManager.checkSurveyEligibility(t) : {
                        eligible: !1,
                        reason: "Survey not found"
                    }
                }
                canRenderSurvey(e) {
                    if (!L(this._surveyManager)) return rT.warn("init was not called"), {
                        visible: !1,
                        disabledReason: "SDK is not enabled or survey functionality is not yet loaded"
                    };
                    var t = this._checkSurveyEligibility(e);
                    return {
                        visible: t.eligible,
                        disabledReason: t.reason
                    }
                }
                canRenderSurveyAsync(e, t) {
                    return L(this._surveyManager) ? (rT.warn("init was not called"), Promise.resolve({
                        visible: !1,
                        disabledReason: "SDK is not enabled or survey functionality is not yet loaded"
                    })) : new Promise(i => {
                        this.getSurveys(t => {
                            var s, r = null != (s = t.find(t => t.id === e)) ? s : null;
                            if (r) {
                                var n = this._checkSurveyEligibility(r);
                                i({
                                    visible: n.eligible,
                                    disabledReason: n.reason
                                })
                            } else i({
                                visible: !1,
                                disabledReason: "Survey not found"
                            })
                        }, t)
                    })
                }
                renderSurvey(e, t) {
                    if (L(this._surveyManager)) rT.warn("init was not called");
                    else {
                        var i = this._getSurveyById(e),
                            s = null == u ? void 0 : u.querySelector(t);
                        i ? s ? this._surveyManager.renderSurvey(i, s) : rT.warn("Survey element not found") : rT.warn("Survey not found")
                    }
                }
            }
            var rA = z("[RateLimiter]");
            class rM {
                constructor(e) {
                    var t, i;
                    J(this, "serverLimits", {}), J(this, "lastEventRateLimited", !1), J(this, "checkForLimiting", e => {
                        var t = e.text;
                        if (t && t.length) try {
                            (JSON.parse(t).quota_limited || []).forEach(e => {
                                rA.info("".concat(e || "events", " is quota limited.")), this.serverLimits[e] = (new Date).getTime() + 6e4
                            })
                        } catch (e) {
                            return void rA.warn('could not rate limit - continuing. Error: "'.concat(null == e ? void 0 : e.message, '"'), {
                                text: t
                            })
                        }
                    }), this.instance = e, this.captureEventsPerSecond = (null == (t = e.config.rate_limiting) ? void 0 : t.events_per_second) || 10, this.captureEventsBurstLimit = Math.max((null == (i = e.config.rate_limiting) ? void 0 : i.events_burst_limit) || 10 * this.captureEventsPerSecond, this.captureEventsPerSecond), this.lastEventRateLimited = this.clientRateLimitContext(!0).isRateLimited
                }
                clientRateLimitContext() {
                    var e, t, i, s = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                        r = (new Date).getTime(),
                        n = null != (e = null == (t = this.instance.persistence) ? void 0 : t.get_property(eN)) ? e : {
                            tokens: this.captureEventsBurstLimit,
                            last: r
                        };
                    n.tokens += (r - n.last) / 1e3 * this.captureEventsPerSecond, n.last = r, n.tokens > this.captureEventsBurstLimit && (n.tokens = this.captureEventsBurstLimit);
                    var o = n.tokens < 1;
                    return o || s || (n.tokens = Math.max(0, n.tokens - 1)), !o || this.lastEventRateLimited || s || this.instance.capture("$$client_ingestion_warning", {
                        $$client_ingestion_warning_message: "posthog-js client rate limited. Config is set to ".concat(this.captureEventsPerSecond, " events per second and ").concat(this.captureEventsBurstLimit, " events burst limit.")
                    }, {
                        skip_client_rate_limiting: !0
                    }), this.lastEventRateLimited = o, null == (i = this.instance.persistence) || i.set_property(eN, n), {
                        isRateLimited: o,
                        remainingTokens: n.tokens
                    }
                }
                isServerRateLimited(e) {
                    var t = this.serverLimits[e || "events"] || !1;
                    return !1 !== t && (new Date).getTime() < t
                }
            }
            var rL = z("[RemoteConfig]");
            class rD {
                constructor(e) {
                    this._instance = e
                }
                get remoteConfig() {
                    var e, t;
                    return null == (e = f._POSTHOG_REMOTE_CONFIG) || null == (t = e[this._instance.config.token]) ? void 0 : t.config
                }
                _loadRemoteConfigJs(e) {
                    var t, i, s;
                    null != (t = f.__PosthogExtensions__) && t.loadExternalDependency ? null == (i = f.__PosthogExtensions__) || null == (s = i.loadExternalDependency) || s.call(i, this._instance, "remote-config", () => e(this.remoteConfig)) : (rL.error("PostHog Extensions not found. Cannot load remote config."), e())
                }
                _loadRemoteConfigJSON(e) {
                    this._instance._send_request({
                        method: "GET",
                        url: this._instance.requestRouter.endpointFor("assets", "/array/".concat(this._instance.config.token, "/config")),
                        callback: t => {
                            e(t.json)
                        }
                    })
                }
                load() {
                    try {
                        if (this.remoteConfig) return rL.info("Using preloaded remote config", this.remoteConfig), void this._onRemoteConfig(this.remoteConfig);
                        if (this._instance.config.advanced_disable_decide) return void rL.warn("Remote config is disabled. Falling back to local config.");
                        this._loadRemoteConfigJs(e => {
                            if (!e) return rL.info("No config found after loading remote JS config. Falling back to JSON."), void this._loadRemoteConfigJSON(e => {
                                this._onRemoteConfig(e)
                            });
                            this._onRemoteConfig(e)
                        })
                    } catch (e) {
                        rL.error("Error loading remote config", e)
                    }
                }
                _onRemoteConfig(e) {
                    e ? this._instance.config.__preview_remote_config ? (this._instance._onRemoteConfig(e), !1 !== e.hasFeatureFlags && this._instance.featureFlags.ensureFlagsLoaded()) : rL.info("__preview_remote_config is disabled. Logging config instead", e) : rL.error("Failed to fetch remote config from PostHog.")
                }
            }
            var rq = function(e) {
                    var t, i, s, r, n = "";
                    for (t = i = 0, s = (e = (e + "").replace(/\r\n/g, "\n").replace(/\r/g, "\n")).length, r = 0; r < s; r++) {
                        var o = e.charCodeAt(r),
                            a = null;
                        o < 128 ? i++ : a = o > 127 && o < 2048 ? String.fromCharCode(o >> 6 | 192, 63 & o | 128) : String.fromCharCode(o >> 12 | 224, o >> 6 & 63 | 128, 63 & o | 128), M(a) || (i > t && (n += e.substring(t, i)), n += a, t = i = r + 1)
                    }
                    return i > t && (n += e.substring(t, e.length)), n
                },
                rN = !!_ || !!h,
                rB = "text/plain",
                rH = (e, t) => {
                    var [i, s] = e.split("?"), r = V({}, t);
                    null == s || s.split("&").forEach(e => {
                        var [t] = e.split("=");
                        delete r[t]
                    });
                    var n = tu(r);
                    return n = n ? (s ? s + "&" : "") + n : s, "".concat(i, "?").concat(n)
                },
                rj = (e, t) => JSON.stringify(e, (e, t) => "bigint" == typeof t ? t.toString() : t, t),
                rz = e => {
                    var {
                        data: t,
                        compression: i
                    } = e;
                    if (t) {
                        if (i === s.GZipJS) {
                            var r = new Blob([i0(i1(rj(t)), {
                                mtime: 0
                            })], {
                                type: rB
                            });
                            return {
                                contentType: rB,
                                body: r,
                                estimatedSize: r.size
                            }
                        }
                        if (i === s.Base64) {
                            var n = (e => "data=" + encodeURIComponent("string" == typeof e ? e : rj(e)))(function(e) {
                                var t, i, s, r, n, o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                                    a = 0,
                                    l = 0,
                                    c = "",
                                    u = [];
                                if (!e) return e;
                                e = rq(e);
                                do t = (n = e.charCodeAt(a++) << 16 | e.charCodeAt(a++) << 8 | e.charCodeAt(a++)) >> 18 & 63, i = n >> 12 & 63, s = n >> 6 & 63, r = 63 & n, u[l++] = o.charAt(t) + o.charAt(i) + o.charAt(s) + o.charAt(r); while (a < e.length);
                                switch (c = u.join(""), e.length % 3) {
                                    case 1:
                                        c = c.slice(0, -2) + "==";
                                        break;
                                    case 2:
                                        c = c.slice(0, -1) + "="
                                }
                                return c
                            }(rj(t)));
                            return {
                                contentType: "application/x-www-form-urlencoded",
                                body: n,
                                estimatedSize: new Blob([n]).size
                            }
                        }
                        var o = rj(t);
                        return {
                            contentType: "application/json",
                            body: o,
                            estimatedSize: new Blob([o]).size
                        }
                    }
                },
                rU = [];
            h && rU.push({
                transport: "fetch",
                method: e => {
                    var t, i, {
                            contentType: s,
                            body: r,
                            estimatedSize: n
                        } = null != (t = rz(e)) ? t : {},
                        o = new Headers;
                    Q(e.headers, function(e, t) {
                        o.append(t, e)
                    }), s && o.append("Content-Type", s);
                    var a = e.url,
                        l = null;
                    if (p) {
                        var c = new p;
                        l = {
                            signal: c.signal,
                            timeout: setTimeout(() => c.abort(), e.timeout)
                        }
                    }
                    h(a, V({
                        method: (null == e ? void 0 : e.method) || "GET",
                        headers: o,
                        keepalive: "POST" === e.method && 52428.8 > (n || 0),
                        body: r,
                        signal: null == (i = l) ? void 0 : i.signal
                    }, e.fetchOptions)).then(t => t.text().then(i => {
                        var s, r = {
                            statusCode: t.status,
                            text: i
                        };
                        if (200 === t.status) try {
                            r.json = JSON.parse(i)
                        } catch (e) {
                            j.error(e)
                        }
                        null == (s = e.callback) || s.call(e, r)
                    })).catch(t => {
                        var i;
                        j.error(t), null == (i = e.callback) || i.call(e, {
                            statusCode: 0,
                            text: t
                        })
                    }).finally(() => l ? clearTimeout(l.timeout) : null)
                }
            }), _ && rU.push({
                transport: "XHR",
                method: e => {
                    var t, i = new _;
                    i.open(e.method || "GET", e.url, !0);
                    var {
                        contentType: s,
                        body: r
                    } = null != (t = rz(e)) ? t : {};
                    Q(e.headers, function(e, t) {
                        i.setRequestHeader(t, e)
                    }), s && i.setRequestHeader("Content-Type", s), e.timeout && (i.timeout = e.timeout), i.withCredentials = !0, i.onreadystatechange = () => {
                        if (4 === i.readyState) {
                            var t, s = {
                                statusCode: i.status,
                                text: i.responseText
                            };
                            if (200 === i.status) try {
                                s.json = JSON.parse(i.responseText)
                            } catch (e) {}
                            null == (t = e.callback) || t.call(e, s)
                        }
                    }, i.send(r)
                }
            }), null != c && c.sendBeacon && rU.push({
                transport: "sendBeacon",
                method: e => {
                    var t = rH(e.url, {
                        beacon: "1"
                    });
                    try {
                        var i, {
                                contentType: s,
                                body: r
                            } = null != (i = rz(e)) ? i : {},
                            n = "string" == typeof r ? new Blob([r], {
                                type: s
                            }) : r;
                        c.sendBeacon(t, n)
                    } catch (e) {}
                }
            });
            class rW {
                constructor(e, t) {
                    J(this, "_isPaused", !0), J(this, "_queue", []), this._flushTimeoutMs = im((null == t ? void 0 : t.flush_interval_ms) || 3e3, 250, 5e3, "flush interval", 3e3), this._sendRequest = e
                }
                enqueue(e) {
                    this._queue.push(e), this._flushTimeout || this._setFlushTimeout()
                }
                unload() {
                    this._clearFlushTimeout();
                    var e = Object.values(this._queue.length > 0 ? this._formatQueue() : {});
                    [...e.filter(e => 0 === e.url.indexOf("/e")), ...e.filter(e => 0 !== e.url.indexOf("/e"))].map(e => {
                        this._sendRequest(V(V({}, e), {}, {
                            transport: "sendBeacon"
                        }))
                    })
                }
                enable() {
                    this._isPaused = !1, this._setFlushTimeout()
                }
                _setFlushTimeout() {
                    var e = this;
                    this._isPaused || (this._flushTimeout = setTimeout(() => {
                        if (this._clearFlushTimeout(), this._queue.length > 0) {
                            var t = this._formatQueue();
                            for (var i in t) ! function(i) {
                                var s = t[i],
                                    r = (new Date).getTime();
                                s.data && P(s.data) && Q(s.data, e => {
                                    e.offset = Math.abs(e.timestamp - r), delete e.timestamp
                                }), e._sendRequest(s)
                            }(i)
                        }
                    }, this._flushTimeoutMs))
                }
                _clearFlushTimeout() {
                    clearTimeout(this._flushTimeout), this._flushTimeout = void 0
                }
                _formatQueue() {
                    var e = {};
                    return Q(this._queue, t => {
                        var i, s = (t ? t.batchKey : null) || t.url;
                        $(e[s]) && (e[s] = V(V({}, t), {}, {
                            data: []
                        })), null == (i = e[s].data) || i.push(t.data)
                    }), this._queue = [], e
                }
            }
            var rG = ["retriesPerformedSoFar"];
            class rV {
                constructor(e) {
                    J(this, "_isPolling", !1), J(this, "_pollIntervalMs", 3e3), J(this, "_queue", []), this._instance = e, this._queue = [], this._areWeOnline = !0, !$(r) && "onLine" in r.navigator && (this._areWeOnline = r.navigator.onLine, ea(r, "online", () => {
                        this._areWeOnline = !0, this._flush()
                    }), ea(r, "offline", () => {
                        this._areWeOnline = !1
                    }))
                }
                get length() {
                    return this._queue.length
                }
                retriableRequest(e) {
                    var {
                        retriesPerformedSoFar: t
                    } = e, i = Y(e, rG);
                    D(t) && t > 0 && (i.url = rH(i.url, {
                        retry_count: t
                    })), this._instance._send_request(V(V({}, i), {}, {
                        callback: e => {
                            var s;
                            200 !== e.statusCode && (e.statusCode < 400 || e.statusCode >= 500) && (null != t ? t : 0) < 10 ? this._enqueue(V({
                                retriesPerformedSoFar: t
                            }, i)) : null == (s = i.callback) || s.call(i, e)
                        }
                    }))
                }
                _enqueue(e) {
                    var t, i, s, r = e.retriesPerformedSoFar || 0;
                    e.retriesPerformedSoFar = r + 1;
                    var n = (s = (Math.random() - .5) * ((i = Math.min(18e5, t = 3e3 * Math.pow(2, r))) - t / 2), Math.ceil(i + s)),
                        o = Date.now() + n;
                    this._queue.push({
                        retryAt: o,
                        requestOptions: e
                    });
                    var a = "Enqueued failed request for retry in ".concat(n);
                    navigator.onLine || (a += " (Browser is offline)"), j.warn(a), this._isPolling || (this._isPolling = !0, this._poll())
                }
                _poll() {
                    this._poller && clearTimeout(this._poller), this._poller = setTimeout(() => {
                        this._areWeOnline && this._queue.length > 0 && this._flush(), this._poll()
                    }, this._pollIntervalMs)
                }
                _flush() {
                    var e = Date.now(),
                        t = [],
                        i = this._queue.filter(i => i.retryAt < e || (t.push(i), !1));
                    if (this._queue = t, i.length > 0)
                        for (var {
                                requestOptions: s
                            } of i) this.retriableRequest(s)
                }
                unload() {
                    for (var {
                            requestOptions: e
                        } of (this._poller && (clearTimeout(this._poller), this._poller = void 0), this._queue)) try {
                        this._instance._send_request(V(V({}, e), {}, {
                            transport: "sendBeacon"
                        }))
                    } catch (e) {
                        j.error(e)
                    }
                    this._queue = []
                }
            }
            class rJ {
                constructor(e) {
                    J(this, "_updateScrollData", () => {
                        this._context || (this._context = {});
                        var e, t, i, s, r = this.scrollElement(),
                            n = this.scrollY(),
                            o = r ? Math.max(0, r.scrollHeight - r.clientHeight) : 0,
                            a = n + ((null == r ? void 0 : r.clientHeight) || 0),
                            l = (null == r ? void 0 : r.scrollHeight) || 0;
                        this._context.lastScrollY = Math.ceil(n), this._context.maxScrollY = Math.max(n, null != (e = this._context.maxScrollY) ? e : 0), this._context.maxScrollHeight = Math.max(o, null != (t = this._context.maxScrollHeight) ? t : 0), this._context.lastContentY = a, this._context.maxContentY = Math.max(a, null != (i = this._context.maxContentY) ? i : 0), this._context.maxContentHeight = Math.max(l, null != (s = this._context.maxContentHeight) ? s : 0)
                    }), this._instance = e
                }
                getContext() {
                    return this._context
                }
                resetContext() {
                    var e = this._context;
                    return setTimeout(this._updateScrollData, 0), e
                }
                startMeasuringScrollPosition() {
                    ea(r, "scroll", this._updateScrollData, {
                        capture: !0
                    }), ea(r, "scrollend", this._updateScrollData, {
                        capture: !0
                    }), ea(r, "resize", this._updateScrollData)
                }
                scrollElement() {
                    if (!this._instance.config.scroll_root_selector) return null == r ? void 0 : r.document.documentElement;
                    for (var e of P(this._instance.config.scroll_root_selector) ? this._instance.config.scroll_root_selector : [this._instance.config.scroll_root_selector]) {
                        var t = null == r ? void 0 : r.document.querySelector(e);
                        if (t) return t
                    }
                }
                scrollY() {
                    if (this._instance.config.scroll_root_selector) {
                        var e = this.scrollElement();
                        return e && e.scrollTop || 0
                    }
                    return r && (r.scrollY || r.pageYOffset || r.document.documentElement.scrollTop) || 0
                }
                scrollX() {
                    if (this._instance.config.scroll_root_selector) {
                        var e = this.scrollElement();
                        return e && e.scrollLeft || 0
                    }
                    return r && (r.scrollX || r.pageXOffset || r.document.documentElement.scrollLeft) || 0
                }
            }
            var rY = e => r_(null == e ? void 0 : e.config.mask_personal_data_properties, null == e ? void 0 : e.config.custom_personal_data_properties);
            class rK {
                constructor(e, t, i, s) {
                    J(this, "_onSessionIdCallback", e => {
                        var t = this._getStored();
                        if (!t || t.sessionId !== e) {
                            var i = {
                                sessionId: e,
                                props: this._sessionSourceParamGenerator(this._instance)
                            };
                            this._persistence.register({
                                [eq]: i
                            })
                        }
                    }), this._instance = e, this._sessionIdManager = t, this._persistence = i, this._sessionSourceParamGenerator = s || rY, this._sessionIdManager.onSessionId(this._onSessionIdCallback)
                }
                _getStored() {
                    return this._persistence.props[eq]
                }
                getSetOnceProps() {
                    var e, t = null == (e = this._getStored()) ? void 0 : e.props;
                    return t ? "r" in t ? rp(t) : {
                        $referring_domain: t.referringDomain,
                        $pathname: t.initialPathName,
                        utm_source: t.utm_source,
                        utm_campaign: t.utm_campaign,
                        utm_medium: t.utm_medium,
                        utm_content: t.utm_content,
                        utm_term: t.utm_term
                    } : {}
                }
                getSessionProps() {
                    var e = {};
                    return Q(er(this.getSetOnceProps()), (t, i) => {
                        "$current_url" === i && (i = "url"), e["$session_entry_".concat(k(i))] = t
                    }), e
                }
            }
            var rX = z("[SessionId]");
            class rQ {
                constructor(e, t, i) {
                    if (J(this, "_sessionIdChangedHandlers", []), !e.persistence) throw Error("SessionIdManager requires a PostHogPersistence instance");
                    if (e.config.__preview_experimental_cookieless_mode) throw Error("SessionIdManager cannot be used with __preview_experimental_cookieless_mode");
                    this._config = e.config, this._persistence = e.persistence, this._windowId = void 0, this._sessionId = void 0, this._sessionStartTimestamp = null, this._sessionActivityTimestamp = null, this._sessionIdGenerator = t || tE, this._windowIdGenerator = i || tE;
                    var s, r = this._config.persistence_name || this._config.token,
                        n = this._config.session_idle_timeout_seconds || 1800;
                    if (this._sessionTimeoutMs = 1e3 * im(n, 60, 36e3, "session_idle_timeout_seconds", 1800), e.register({
                            $configured_session_timeout_ms: this._sessionTimeoutMs
                        }), this._resetIdleTimer(), this._window_id_storage_key = "ph_" + r + "_window_id", this._primary_window_exists_storage_key = "ph_" + r + "_primary_window_exists", this._canUseSessionStorage()) {
                        var o = tL.parse(this._window_id_storage_key),
                            a = tL.parse(this._primary_window_exists_storage_key);
                        o && !a ? this._windowId = o : tL.remove(this._window_id_storage_key), tL.set(this._primary_window_exists_storage_key, !0)
                    }
                    if (null != (s = this._config.bootstrap) && s.sessionID) try {
                        var l = (e => {
                            var t = e.replace(/-/g, "");
                            if (32 !== t.length) throw Error("Not a valid UUID");
                            if ("7" !== t[12]) throw Error("Not a UUIDv7");
                            return parseInt(t.substring(0, 12), 16)
                        })(this._config.bootstrap.sessionID);
                        this._setSessionId(this._config.bootstrap.sessionID, (new Date).getTime(), l)
                    } catch (e) {
                        rX.error("Invalid sessionID in bootstrap", e)
                    }
                    this._listenToReloadWindow()
                }
                get sessionTimeoutMs() {
                    return this._sessionTimeoutMs
                }
                onSessionId(e) {
                    return $(this._sessionIdChangedHandlers) && (this._sessionIdChangedHandlers = []), this._sessionIdChangedHandlers.push(e), this._sessionId && e(this._sessionId, this._windowId), () => {
                        this._sessionIdChangedHandlers = this._sessionIdChangedHandlers.filter(t => t !== e)
                    }
                }
                _canUseSessionStorage() {
                    return "memory" !== this._config.persistence && !this._persistence.disabled && tL.is_supported()
                }
                _setWindowId(e) {
                    e !== this._windowId && (this._windowId = e, this._canUseSessionStorage() && tL.set(this._window_id_storage_key, e))
                }
                _getWindowId() {
                    return this._windowId ? this._windowId : this._canUseSessionStorage() ? tL.parse(this._window_id_storage_key) : null
                }
                _setSessionId(e, t, i) {
                    e === this._sessionId && t === this._sessionActivityTimestamp && i === this._sessionStartTimestamp || (this._sessionStartTimestamp = i, this._sessionActivityTimestamp = t, this._sessionId = e, this._persistence.register({
                        [ex]: [t, e, i]
                    }))
                }
                _getSessionId() {
                    if (this._sessionId && this._sessionActivityTimestamp && this._sessionStartTimestamp) return [this._sessionActivityTimestamp, this._sessionId, this._sessionStartTimestamp];
                    var e = this._persistence.props[ex];
                    return P(e) && 2 === e.length && e.push(e[0]), e || [0, null, 0]
                }
                resetSessionId() {
                    this._setSessionId(null, null, null)
                }
                _listenToReloadWindow() {
                    ea(r, "beforeunload", () => {
                        this._canUseSessionStorage() && tL.remove(this._primary_window_exists_storage_key)
                    }, {
                        capture: !1
                    })
                }
                checkAndGetSessionAndWindowId() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                    if (this._config.__preview_experimental_cookieless_mode) throw Error("checkAndGetSessionAndWindowId should not be called in __preview_experimental_cookieless_mode");
                    var i = t || (new Date).getTime(),
                        [s, r, n] = this._getSessionId(),
                        o = this._getWindowId(),
                        a = D(n) && n > 0 && Math.abs(i - n) > 864e5,
                        l = !1,
                        c = !r,
                        u = !e && Math.abs(i - s) > this.sessionTimeoutMs;
                    c || u || a ? (r = this._sessionIdGenerator(), o = this._windowIdGenerator(), rX.info("new session ID generated", {
                        sessionId: r,
                        windowId: o,
                        changeReason: {
                            noSessionId: c,
                            activityTimeout: u,
                            sessionPastMaximumLength: a
                        }
                    }), n = i, l = !0) : o || (o = this._windowIdGenerator(), l = !0);
                    var d = 0 === s || !e || a ? i : s,
                        h = 0 === n ? (new Date).getTime() : n;
                    return this._setWindowId(o), this._setSessionId(r, d, h), e || this._resetIdleTimer(), l && this._sessionIdChangedHandlers.forEach(e => e(r, o, l ? {
                        noSessionId: c,
                        activityTimeout: u,
                        sessionPastMaximumLength: a
                    } : void 0)), {
                        sessionId: r,
                        windowId: o,
                        sessionStartTimestamp: h,
                        changeReason: l ? {
                            noSessionId: c,
                            activityTimeout: u,
                            sessionPastMaximumLength: a
                        } : void 0,
                        lastActivityTimestamp: s
                    }
                }
                _resetIdleTimer() {
                    clearTimeout(this._enforceIdleTimeout), this._enforceIdleTimeout = setTimeout(() => {
                        this.resetSessionId()
                    }, 1.1 * this.sessionTimeoutMs)
                }
            }
            var rZ = ["$set_once", "$set"],
                r0 = z("[SiteApps]");
            class r1 {
                constructor(e) {
                    this._instance = e, this._bufferedInvocations = [], this.apps = {}
                }
                get isEnabled() {
                    return !!this._instance.config.opt_in_site_apps
                }
                _eventCollector(e, t) {
                    if (t) {
                        var i = this.globalsForEvent(t);
                        this._bufferedInvocations.push(i), this._bufferedInvocations.length > 1e3 && (this._bufferedInvocations = this._bufferedInvocations.slice(10))
                    }
                }
                get siteAppLoaders() {
                    var e, t;
                    return null == (e = f._POSTHOG_REMOTE_CONFIG) || null == (t = e[this._instance.config.token]) ? void 0 : t.siteApps
                }
                init() {
                    if (this.isEnabled) {
                        var e = this._instance._addCaptureHook(this._eventCollector.bind(this));
                        this._stopBuffering = () => {
                            e(), this._bufferedInvocations = [], this._stopBuffering = void 0
                        }
                    }
                }
                globalsForEvent(e) {
                    if (!e) throw Error("Event payload is required");
                    var t, i, s, r, n, o, a, l = {},
                        c = this._instance.get_property("$groups") || [];
                    for (var [u, d] of Object.entries(this._instance.get_property("$stored_group_properties") || {})) l[u] = {
                        id: c[u],
                        type: u,
                        properties: d
                    };
                    var {
                        $set_once: h,
                        $set: _
                    } = e;
                    return {
                        event: V(V({}, Y(e, rZ)), {}, {
                            properties: V(V(V({}, e.properties), _ ? {
                                $set: V(V({}, null != (t = null == (i = e.properties) ? void 0 : i.$set) ? t : {}), _)
                            } : {}), h ? {
                                $set_once: V(V({}, null != (s = null == (r = e.properties) ? void 0 : r.$set_once) ? s : {}), h)
                            } : {}),
                            elements_chain: null != (n = null == (o = e.properties) ? void 0 : o.$elements_chain) ? n : "",
                            distinct_id: null == (a = e.properties) ? void 0 : a.distinct_id
                        }),
                        person: {
                            properties: this._instance.get_property("$stored_person_properties")
                        },
                        groups: l
                    }
                }
                setupSiteApp(e) {
                    var t = this.apps[e.id],
                        i = () => {
                            var i;
                            !t.errored && this._bufferedInvocations.length && (r0.info("Processing ".concat(this._bufferedInvocations.length, " events for site app with id ").concat(e.id)), this._bufferedInvocations.forEach(e => {
                                var i;
                                return null == (i = t.processEvent) ? void 0 : i.call(t, e)
                            }), t.processedBuffer = !0), Object.values(this.apps).every(e => e.processedBuffer || e.errored) && (null == (i = this._stopBuffering) || i.call(this))
                        },
                        s = !1,
                        r = r => {
                            t.errored = !r, t.loaded = !0, r0.info("Site app with id ".concat(e.id, " ").concat(r ? "loaded" : "errored")), s && i()
                        };
                    try {
                        var {
                            processEvent: n
                        } = e.init({
                            posthog: this._instance,
                            callback: e => {
                                r(e)
                            }
                        });
                        n && (t.processEvent = n), s = !0
                    } catch (t) {
                        r0.error("Error while initializing PostHog app with config id ".concat(e.id), t), r(!1)
                    }
                    if (s && t.loaded) try {
                        i()
                    } catch (i) {
                        r0.error("Error while processing buffered events PostHog app with config id ".concat(e.id), i), t.errored = !0
                    }
                }
                _setupSiteApps() {
                    var e = this.siteAppLoaders || [];
                    for (var t of e) this.apps[t.id] = {
                        id: t.id,
                        loaded: !1,
                        errored: !1,
                        processedBuffer: !1
                    };
                    for (var i of e) this.setupSiteApp(i)
                }
                _onCapturedEvent(e) {
                    if (0 !== Object.keys(this.apps).length) {
                        var t, i = this.globalsForEvent(e);
                        for (var s of Object.values(this.apps)) try {
                            null == (t = s.processEvent) || t.call(s, i)
                        } catch (t) {
                            r0.error("Error while processing event ".concat(e.event, " for site app ").concat(s.id), t)
                        }
                    }
                }
                onRemoteConfig(e) {
                    var t, i, s, r = this;
                    if (null != (t = this.siteAppLoaders) && t.length) return this.isEnabled ? (this._setupSiteApps(), void this._instance.on("eventCaptured", e => this._onCapturedEvent(e))) : void r0.error('PostHog site apps are disabled. Enable the "opt_in_site_apps" config to proceed.');
                    if (null == (i = this._stopBuffering) || i.call(this), null != (s = e.siteApps) && s.length)
                        if (this.isEnabled) {
                            var n = function(e, t) {
                                var i, s;
                                f["__$$ph_site_app_".concat(e)] = r._instance, null == (i = f.__PosthogExtensions__) || null == (s = i.loadSiteApp) || s.call(i, r._instance, t, t => {
                                    if (t) return r0.error("Error while initializing PostHog app with config id ".concat(e), t)
                                })
                            };
                            for (var {
                                    id: o,
                                    url: a
                                } of e.siteApps) n(o, a)
                        } else r0.error('PostHog site apps are disabled. Enable the "opt_in_site_apps" config to proceed.')
                }
            }
            var r2, r3 = ["amazonbot", "amazonproductbot", "app.hypefactors.com", "applebot", "archive.org_bot", "awariobot", "backlinksextendedbot", "baiduspider", "bingbot", "bingpreview", "chrome-lighthouse", "dataforseobot", "deepscan", "duckduckbot", "facebookexternal", "facebookcatalog", "http://yandex.com/bots", "hubspot", "ia_archiver", "linkedinbot", "meta-externalagent", "mj12bot", "msnbot", "nessus", "petalbot", "pinterest", "prerender", "rogerbot", "screaming frog", "sebot-wa", "sitebulb", "slackbot", "slurp", "trendictionbot", "turnitin", "twitterbot", "vercelbot", "yahoo! slurp", "yandexbot", "zoombot", "bot.htm", "bot.php", "(bot;", "bot/", "crawler", "ahrefsbot", "ahrefssiteaudit", "semrushbot", "siteauditbot", "splitsignalbot", "gptbot", "oai-searchbot", "chatgpt-user", "perplexitybot", "better uptime bot", "sentryuptimebot", "uptimerobot", "headlesschrome", "cypress", "google-hoteladsverifier", "adsbot-google", "apis-google", "duplexweb-google", "feedfetcher-google", "google favicon", "google web preview", "google-read-aloud", "googlebot", "googleweblight", "mediapartners-google", "storebot-google", "bytespider"],
                r5 = function(e, t) {
                    if (!e) return !1;
                    var i = e.toLowerCase();
                    return r3.concat(t || []).some(e => {
                        var t = e.toLowerCase();
                        return -1 !== i.indexOf(t)
                    })
                },
                r6 = function(e, t) {
                    if (!e) return !1;
                    var i = e.userAgent;
                    if (i && r5(i, t)) return !0;
                    try {
                        var s = null == e ? void 0 : e.userAgentData;
                        if (null != s && s.brands && s.brands.some(e => r5(null == e ? void 0 : e.brand, t))) return !0
                    } catch (e) {}
                    return !!e.webdriver
                };

            function r4(e, t, i) {
                return rj({
                    distinct_id: e,
                    userPropertiesToSet: t,
                    userPropertiesToSetOnce: i
                })
            }! function(e) {
                e.US = "us", e.EU = "eu", e.CUSTOM = "custom"
            }(r2 || (r2 = {}));
            var r8 = "i.posthog.com";
            class r7 {
                constructor(e) {
                    J(this, "_regionCache", {}), this.instance = e
                }
                get apiHost() {
                    var e = this.instance.config.api_host.trim().replace(/\/$/, "");
                    return "https://app.posthog.com" === e ? "https://us.i.posthog.com" : e
                }
                get uiHost() {
                    var e, t = null == (e = this.instance.config.ui_host) ? void 0 : e.replace(/\/$/, "");
                    return t || (t = this.apiHost.replace(".".concat(r8), ".posthog.com")), "https://app.posthog.com" === t ? "https://us.posthog.com" : t
                }
                get region() {
                    return this._regionCache[this.apiHost] || (/https:\/\/(app|us|us-assets)(\.i)?\.posthog\.com/i.test(this.apiHost) ? this._regionCache[this.apiHost] = r2.US : /https:\/\/(eu|eu-assets)(\.i)?\.posthog\.com/i.test(this.apiHost) ? this._regionCache[this.apiHost] = r2.EU : this._regionCache[this.apiHost] = r2.CUSTOM), this._regionCache[this.apiHost]
                }
                endpointFor(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                    if (t && (t = "/" === t[0] ? t : "/".concat(t)), "ui" === e) return this.uiHost + t;
                    if (this.region === r2.CUSTOM) return this.apiHost + t;
                    var i = r8 + t;
                    switch (e) {
                        case "assets":
                            return "https://".concat(this.region, "-assets.").concat(i);
                        case "api":
                            return "https://".concat(this.region, ".").concat(i)
                    }
                }
            }
            var r9 = {
                icontains: (e, t) => !!r && t.href.toLowerCase().indexOf(e.toLowerCase()) > -1,
                not_icontains: (e, t) => !!r && -1 === t.href.toLowerCase().indexOf(e.toLowerCase()),
                regex: (e, t) => !!r && rF(t.href, e),
                not_regex: (e, t) => !!r && !rF(t.href, e),
                exact: (e, t) => t.href === e,
                is_not: (e, t) => t.href !== e
            };
            class ne {
                constructor(e) {
                    var t = this;
                    J(this, "getWebExperimentsAndEvaluateDisplayLogic", function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                        t.getWebExperiments(e => {
                            ne._logInfo("retrieved web experiments from the server"), t._flagToExperiments = new Map, e.forEach(e => {
                                if (e.feature_flag_key) {
                                    t._flagToExperiments && (ne._logInfo("setting flag key ", e.feature_flag_key, " to web experiment ", e), null == (i = t._flagToExperiments) || i.set(e.feature_flag_key, e));
                                    var i, s = t._instance.getFeatureFlag(e.feature_flag_key);
                                    O(s) && e.variants[s] && t._applyTransforms(e.name, s, e.variants[s].transforms)
                                } else if (e.variants)
                                    for (var r in e.variants) {
                                        var n = e.variants[r];
                                        ne._matchesTestVariant(n) && t._applyTransforms(e.name, r, n.transforms)
                                    }
                            })
                        }, e)
                    }), this._instance = e, this._instance.onFeatureFlags(e => {
                        this.onFeatureFlags(e)
                    })
                }
                onFeatureFlags(e) {
                    if (this._is_bot()) ne._logInfo("Refusing to render web experiment since the viewer is a likely bot");
                    else if (!this._instance.config.disable_web_experiments) {
                        if (L(this._flagToExperiments)) return this._flagToExperiments = new Map, this.loadIfEnabled(), void this.previewWebExperiment();
                        ne._logInfo("applying feature flags", e), e.forEach(e => {
                            var t;
                            if (this._flagToExperiments && null != (t = this._flagToExperiments) && t.has(e)) {
                                var i, s = this._instance.getFeatureFlag(e),
                                    r = null == (i = this._flagToExperiments) ? void 0 : i.get(e);
                                s && null != r && r.variants[s] && this._applyTransforms(r.name, s, r.variants[s].transforms)
                            }
                        })
                    }
                }
                previewWebExperiment() {
                    var e = ne.getWindowLocation();
                    if (null != e && e.search) {
                        var t = td(null == e ? void 0 : e.search, "__experiment_id"),
                            i = td(null == e ? void 0 : e.search, "__experiment_variant");
                        t && i && (ne._logInfo("previewing web experiments ".concat(t, " && ").concat(i)), this.getWebExperiments(e => {
                            this._showPreviewWebExperiment(parseInt(t), i, e)
                        }, !1, !0))
                    }
                }
                loadIfEnabled() {
                    this._instance.config.disable_web_experiments || this.getWebExperimentsAndEvaluateDisplayLogic()
                }
                getWebExperiments(e, t, i) {
                    if (this._instance.config.disable_web_experiments && !i) return e([]);
                    var s = this._instance.get_property("$web_experiments");
                    if (s && !t) return e(s);
                    this._instance._send_request({
                        url: this._instance.requestRouter.endpointFor("api", "/api/web_experiments/?token=".concat(this._instance.config.token)),
                        method: "GET",
                        callback: t => 200 === t.statusCode && t.json ? e(t.json.experiments || []) : e([])
                    })
                }
                _showPreviewWebExperiment(e, t, i) {
                    var s = i.filter(t => t.id === e);
                    s && s.length > 0 && (ne._logInfo("Previewing web experiment [".concat(s[0].name, "] with variant [").concat(t, "]")), this._applyTransforms(s[0].name, t, s[0].variants[t].transforms))
                }
                static _matchesTestVariant(e) {
                    return !L(e.conditions) && ne._matchUrlConditions(e) && ne._matchUTMConditions(e)
                }
                static _matchUrlConditions(e) {
                    if (L(e.conditions) || L(null == (t = e.conditions) ? void 0 : t.url)) return !0;
                    var t, i, s, r, n = ne.getWindowLocation();
                    return !!n && (null == (i = e.conditions) || !i.url || r9[null != (s = null == (r = e.conditions) ? void 0 : r.urlMatchType) ? s : "icontains"](e.conditions.url, n))
                }
                static getWindowLocation() {
                    return null == r ? void 0 : r.location
                }
                static _matchUTMConditions(e) {
                    if (L(e.conditions) || L(null == (i = e.conditions) ? void 0 : i.utm)) return !0;
                    var t = rl();
                    if (t.utm_source) {
                        var i, s, r, n, o, a, l, c, u, d, h, _, p, g, f, v, m, y = null == (s = e.conditions) || null == (r = s.utm) || !r.utm_campaign || (null == (n = e.conditions) || null == (o = n.utm) ? void 0 : o.utm_campaign) == t.utm_campaign,
                            b = null == (a = e.conditions) || null == (l = a.utm) || !l.utm_source || (null == (c = e.conditions) || null == (u = c.utm) ? void 0 : u.utm_source) == t.utm_source,
                            w = null == (d = e.conditions) || null == (h = d.utm) || !h.utm_medium || (null == (_ = e.conditions) || null == (p = _.utm) ? void 0 : p.utm_medium) == t.utm_medium,
                            S = null == (g = e.conditions) || null == (f = g.utm) || !f.utm_term || (null == (v = e.conditions) || null == (m = v.utm) ? void 0 : m.utm_term) == t.utm_term;
                        return y && w && S && b
                    }
                    return !1
                }
                static _logInfo(e) {
                    for (var t = arguments.length, i = Array(t > 1 ? t - 1 : 0), s = 1; s < t; s++) i[s - 1] = arguments[s];
                    j.info("[WebExperiments] ".concat(e), i)
                }
                _applyTransforms(e, t, i) {
                    this._is_bot() ? ne._logInfo("Refusing to render web experiment since the viewer is a likely bot") : "control" !== t ? i.forEach(i => {
                        if (i.selector) {
                            ne._logInfo("applying transform of variant ".concat(t, " for experiment ").concat(e, " "), i);
                            var s, r = null == (s = document) ? void 0 : s.querySelectorAll(i.selector);
                            null == r || r.forEach(e => {
                                i.html && (e.innerHTML = i.html), i.css && e.setAttribute("style", i.css)
                            })
                        }
                    }) : ne._logInfo("Control variants leave the page unmodified.")
                }
                _is_bot() {
                    return c && this._instance ? r6(c, this._instance.config.custom_blocked_useragents) : void 0
                }
            }
            var nt = {},
                ni = () => {},
                ns = "posthog",
                nr = !rN && -1 === (null == g ? void 0 : g.indexOf("MSIE")) && -1 === (null == g ? void 0 : g.indexOf("Mozilla")),
                nn = () => {
                    var e;
                    return {
                        api_host: "https://us.i.posthog.com",
                        ui_host: null,
                        token: "",
                        autocapture: !0,
                        rageclick: !0,
                        cross_subdomain_cookie: function(e) {
                            var t = null == e ? void 0 : e.hostname;
                            if (!O(t)) return !1;
                            var i = t.split(".").slice(-2).join(".");
                            for (var s of en)
                                if (i === s) return !1;
                            return !0
                        }(null == u ? void 0 : u.location),
                        persistence: "localStorage+cookie",
                        persistence_name: "",
                        loaded: ni,
                        save_campaign_params: !0,
                        custom_campaign_params: [],
                        custom_blocked_useragents: [],
                        save_referrer: !0,
                        capture_pageview: !0,
                        capture_pageleave: "if_capture_pageview",
                        debug: d && O(null == d ? void 0 : d.search) && -1 !== d.search.indexOf("__posthog_debug=true") || !1,
                        cookie_expiration: 365,
                        upgrade: !1,
                        disable_session_recording: !1,
                        disable_persistence: !1,
                        disable_web_experiments: !0,
                        disable_surveys: !1,
                        disable_external_dependency_loading: !1,
                        enable_recording_console_log: void 0,
                        secure_cookie: "https:" === (null == r || null == (e = r.location) ? void 0 : e.protocol),
                        ip: !0,
                        opt_out_capturing_by_default: !1,
                        opt_out_persistence_by_default: !1,
                        opt_out_useragent_filter: !1,
                        opt_out_capturing_persistence_type: "localStorage",
                        opt_out_capturing_cookie_prefix: null,
                        opt_in_site_apps: !1,
                        property_denylist: [],
                        respect_dnt: !1,
                        sanitize_properties: null,
                        request_headers: {},
                        request_batching: !0,
                        properties_string_max_length: 65535,
                        session_recording: {},
                        mask_all_element_attributes: !1,
                        mask_all_text: !1,
                        mask_personal_data_properties: !1,
                        custom_personal_data_properties: [],
                        advanced_disable_decide: !1,
                        advanced_disable_feature_flags: !1,
                        advanced_disable_feature_flags_on_first_load: !1,
                        advanced_disable_toolbar_metrics: !1,
                        feature_flag_request_timeout_ms: 3e3,
                        surveys_request_timeout_ms: 1e4,
                        on_request_error: e => {
                            var t = "Bad HTTP status: " + e.statusCode + " " + e.text;
                            j.error(t)
                        },
                        get_device_id: e => e,
                        capture_performance: void 0,
                        name: "posthog",
                        bootstrap: {},
                        disable_compression: !1,
                        session_idle_timeout_seconds: 1800,
                        person_profiles: "identified_only",
                        before_send: void 0,
                        request_queue_config: {
                            flush_interval_ms: 3e3
                        },
                        _onCapture: ni
                    }
                },
                no = e => {
                    var t = {};
                    $(e.process_person) || (t.person_profiles = e.process_person), $(e.xhr_headers) || (t.request_headers = e.xhr_headers), $(e.cookie_name) || (t.persistence_name = e.cookie_name), $(e.disable_cookie) || (t.disable_persistence = e.disable_cookie), $(e.store_google) || (t.save_campaign_params = e.store_google), $(e.verbose) || (t.debug = e.verbose);
                    var i = Z({}, t, e);
                    return P(e.property_blacklist) && ($(e.property_denylist) ? i.property_denylist = e.property_blacklist : P(e.property_denylist) ? i.property_denylist = [...e.property_blacklist, ...e.property_denylist] : j.error("Invalid value for property_denylist config: " + e.property_denylist)), i
                };
            class na {
                constructor() {
                    J(this, "__forceAllowLocalhost", !1)
                }
                get _forceAllowLocalhost() {
                    return this.__forceAllowLocalhost
                }
                set _forceAllowLocalhost(e) {
                    j.error("WebPerformanceObserver is deprecated and has no impact on network capture. Use `_forceAllowLocalhostNetworkCapture` on `posthog.sessionRecording`"), this.__forceAllowLocalhost = e
                }
            }
            class nl {
                get decideEndpointWasHit() {
                    var e, t;
                    return null != (e = null == (t = this.featureFlags) ? void 0 : t.hasLoadedFlags) && e
                }
                constructor() {
                    J(this, "webPerformance", new na), J(this, "_personProcessingSetOncePropertiesSent", !1), J(this, "version", v.LIB_VERSION), J(this, "_internalEventEmitter", new rP), this.config = nn(), this.SentryIntegration = sr, this.sentryIntegration = e => (function(e, t) {
                        var i = ss(e, t);
                        return {
                            name: si,
                            processEvent: e => i(e)
                        }
                    })(this, e), this.__request_queue = [], this.__loaded = !1, this.analyticsDefaultEndpoint = "/e/", this._initialPageviewCaptured = !1, this._initialPersonProfilesConfig = null, this._cachedPersonProperties = null, this.featureFlags = new rx(this), this.toolbar = new sc(this), this.scrollManager = new rJ(this), this.pageViewManager = new sv(this), this.surveys = new rO(this), this.experiments = new ne(this), this.exceptions = new sm(this), this.rateLimiter = new rM(this), this.requestRouter = new r7(this), this.consent = new tD(this), this.people = {
                        set: (e, t, i) => {
                            var s = O(e) ? {
                                [e]: t
                            } : e;
                            this.setPersonProperties(s), null == i || i({})
                        },
                        set_once: (e, t, i) => {
                            var s = O(e) ? {
                                [e]: t
                            } : e;
                            this.setPersonProperties(void 0, s), null == i || i({})
                        }
                    }, this.on("eventCaptured", e => j.info('send "'.concat(null == e ? void 0 : e.event, '"'), e))
                }
                init(e, t, i) {
                    if (i && i !== ns) {
                        var s, r = null != (s = nt[i]) ? s : new nl;
                        return r._init(e, t, i), nt[i] = r, nt[ns][i] = r, r
                    }
                    return this._init(e, t, i)
                }
                _init(e) {
                    var t, i, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        o = arguments.length > 2 ? arguments[2] : void 0;
                    if ($(e) || A(e)) return j.critical("PostHog was initialized without a token. This likely indicates a misconfiguration. Please check the first argument passed to posthog.init()"), this;
                    if (this.__loaded) return j.warn("You have already initialized PostHog! Re-initializing is a no-op"), this;
                    this.__loaded = !0, this.config = {}, this._triggered_notifs = [], n.person_profiles && (this._initialPersonProfilesConfig = n.person_profiles), this.set_config(Z({}, nn(), no(n), {
                        name: o,
                        token: e
                    })), this.config.on_xhr_error && j.error("on_xhr_error is deprecated. Use on_request_error instead"), this.compression = n.disable_compression ? void 0 : s.GZipJS, this.persistence = new rC(this.config), this.sessionPersistence = "sessionStorage" === this.config.persistence || "memory" === this.config.persistence ? this.persistence : new rC(V(V({}, this.config), {}, {
                        persistence: "sessionStorage"
                    }));
                    var a = V({}, this.persistence.props),
                        l = V({}, this.sessionPersistence.props);
                    if (this._requestQueue = new rW(e => this._send_retriable_request(e), this.config.request_queue_config), this._retryQueue = new rV(this), this.__request_queue = [], this.config.__preview_experimental_cookieless_mode || (this.sessionManager = new rQ(this), this.sessionPropsManager = new rK(this, this.sessionManager, this.persistence)), new sd(this).startIfEnabledOrStop(), this.siteApps = new r1(this), null == (t = this.siteApps) || t.init(), this.config.__preview_experimental_cookieless_mode || (this.sessionRecording = new se(this), this.sessionRecording.startIfEnabledOrStop()), this.config.disable_scroll_properties || this.scrollManager.startMeasuringScrollPosition(), this.autocapture = new tf(this), this.autocapture.startIfEnabled(), this.surveys.loadIfEnabled(), this.heatmaps = new sf(this), this.heatmaps.startIfEnabled(), this.webVitalsAutocapture = new s_(this), this.exceptionObserver = new tz(this), this.exceptionObserver.startIfEnabled(), this.deadClicksAutocapture = new tH(this, tB), this.deadClicksAutocapture.startIfEnabled(), this.historyAutocapture = new is(this), this.historyAutocapture.startIfEnabled(), v.DEBUG = v.DEBUG || this.config.debug, v.DEBUG && j.info("Starting in debug mode", {
                            this: this,
                            config: n,
                            thisC: V({}, this.config),
                            p: a,
                            s: l
                        }), this._sync_opt_out_with_persistence(), void 0 !== (null == (i = n.bootstrap) ? void 0 : i.distinctID)) {
                        var c, u, d = this.config.get_device_id(tE()),
                            h = null != (c = n.bootstrap) && c.isIdentifiedID ? d : n.bootstrap.distinctID;
                        this.persistence.set_property(eD, null != (u = n.bootstrap) && u.isIdentifiedID ? "identified" : "anonymous"), this.register({
                            distinct_id: n.bootstrap.distinctID,
                            $device_id: h
                        })
                    }
                    if (this._hasBootstrappedFeatureFlags()) {
                        var _, p, g = Object.keys((null == (_ = n.bootstrap) ? void 0 : _.featureFlags) || {}).filter(e => {
                                var t, i;
                                return !(null == (t = n.bootstrap) || null == (i = t.featureFlags) || !i[e])
                            }).reduce((e, t) => {
                                var i, s;
                                return e[t] = (null == (i = n.bootstrap) || null == (s = i.featureFlags) ? void 0 : s[t]) || !1, e
                            }, {}),
                            f = Object.keys((null == (p = n.bootstrap) ? void 0 : p.featureFlagPayloads) || {}).filter(e => g[e]).reduce((e, t) => {
                                var i, s, r, o;
                                return null != (i = n.bootstrap) && null != (s = i.featureFlagPayloads) && s[t] && (e[t] = null == (r = n.bootstrap) || null == (o = r.featureFlagPayloads) ? void 0 : o[t]), e
                            }, {});
                        this.featureFlags.receivedFeatureFlags({
                            featureFlags: g,
                            featureFlagPayloads: f
                        })
                    }
                    if (this.config.__preview_experimental_cookieless_mode) this.register_once({
                        distinct_id: eW,
                        $device_id: null
                    }, "");
                    else if (!this.get_distinct_id()) {
                        var m = this.config.get_device_id(tE());
                        this.register_once({
                            distinct_id: m,
                            $device_id: m
                        }, ""), this.persistence.set_property(eD, "anonymous")
                    }
                    return ea(r, "onpagehide" in self ? "pagehide" : "unload", this._handle_unload.bind(this), {
                        passive: !1
                    }), this.toolbar.maybeLoadToolbar(), n.segment ? function(e, t) {
                        var i = e.config.segment;
                        if (!i) return t();
                        ! function(e, t) {
                            var i = e.config.segment;
                            if (!i) return t();
                            var s = i => {
                                    var s = () => i.anonymousId() || tE();
                                    e.config.get_device_id = s, i.id() && (e.register({
                                        distinct_id: i.id(),
                                        $device_id: s()
                                    }), e.persistence.set_property(eD, "identified")), t()
                                },
                                r = i.user();
                            "then" in r && F(r.then) ? r.then(e => s(e)) : s(r)
                        }(e, () => {
                            var s;
                            i.register((Promise && Promise.resolve || st.warn("This browser does not have Promise support, and can not use the segment integration"), s = (t, i) => {
                                if (!i) return t;
                                t.event.userId || t.event.anonymousId === e.get_distinct_id() || (st.info("No userId set, resetting PostHog"), e.reset()), t.event.userId && t.event.userId !== e.get_distinct_id() && (st.info("UserId set, identifying with PostHog"), e.identify(t.event.userId));
                                var s, r = e._calculate_event_properties(i, null != (s = t.event.properties) ? s : {}, new Date);
                                return t.event.properties = Object.assign({}, r, t.event.properties), t
                            }, {
                                name: "PostHog JS",
                                type: "enrichment",
                                version: "1.0.0",
                                isLoaded: () => !0,
                                load: () => Promise.resolve(),
                                track: e => s(e, e.event.event),
                                page: e => s(e, "$pageview"),
                                identify: e => s(e, "$identify"),
                                screen: e => s(e, "$screen")
                            })).then(() => {
                                t()
                            })
                        })
                    }(this, () => this._loaded()) : this._loaded(), F(this.config._onCapture) && this.config._onCapture !== ni && (j.warn("onCapture is deprecated. Please use `before_send` instead"), this.on("eventCaptured", e => this.config._onCapture(e.event, e))), this
                }
                _onRemoteConfig(e) {
                    var t, i, r, n, o, a, l, c;
                    if (!u || !u.body) return j.info("document not ready yet, trying again in 500 milliseconds..."), void setTimeout(() => {
                        this._onRemoteConfig(e)
                    }, 500);
                    this.compression = void 0, e.supportedCompression && !this.config.disable_compression && (this.compression = w(e.supportedCompression, s.GZipJS) ? s.GZipJS : w(e.supportedCompression, s.Base64) ? s.Base64 : void 0), null != (t = e.analytics) && t.endpoint && (this.analyticsDefaultEndpoint = e.analytics.endpoint), this.set_config({
                        person_profiles: this._initialPersonProfilesConfig ? this._initialPersonProfilesConfig : "identified_only"
                    }), null == (i = this.siteApps) || i.onRemoteConfig(e), null == (r = this.sessionRecording) || r.onRemoteConfig(e), null == (n = this.autocapture) || n.onRemoteConfig(e), null == (o = this.heatmaps) || o.onRemoteConfig(e), this.surveys.onRemoteConfig(e), null == (a = this.webVitalsAutocapture) || a.onRemoteConfig(e), null == (l = this.exceptionObserver) || l.onRemoteConfig(e), null == (c = this.deadClicksAutocapture) || c.onRemoteConfig(e)
                }
                _loaded() {
                    try {
                        this.config.loaded(this)
                    } catch (e) {
                        j.critical("`loaded` function failed", e)
                    }
                    this._start_queue_if_opted_in(), this.config.capture_pageview && setTimeout(() => {
                        this.consent.isOptedIn() && this._captureInitialPageview()
                    }, 1), new rD(this).load(), this.featureFlags.decide()
                }
                _start_queue_if_opted_in() {
                    var e;
                    this.has_opted_out_capturing() || this.config.request_batching && (null == (e = this._requestQueue) || e.enable())
                }
                _dom_loaded() {
                    this.has_opted_out_capturing() || X(this.__request_queue, e => this._send_retriable_request(e)), this.__request_queue = [], this._start_queue_if_opted_in()
                }
                _handle_unload() {
                    var e, t;
                    this.config.request_batching ? (this._shouldCapturePageleave() && this.capture("$pageleave"), null == (e = this._requestQueue) || e.unload(), null == (t = this._retryQueue) || t.unload()) : this._shouldCapturePageleave() && this.capture("$pageleave", null, {
                        transport: "sendBeacon"
                    })
                }
                _send_request(e) {
                    this.__loaded && (nr ? this.__request_queue.push(e) : this.rateLimiter.isServerRateLimited(e.batchKey) || (e.transport = e.transport || this.config.api_transport, e.url = rH(e.url, {
                        ip: +!!this.config.ip
                    }), e.headers = V({}, this.config.request_headers), e.compression = "best-available" === e.compression ? this.compression : e.compression, e.fetchOptions = e.fetchOptions || this.config.fetch_options, (e => {
                        var t, i, s, r = V({}, e);
                        r.timeout = r.timeout || 6e4, r.url = rH(r.url, {
                            _: (new Date).getTime().toString(),
                            ver: v.LIB_VERSION,
                            compression: r.compression
                        });
                        var n = null != (t = r.transport) ? t : "fetch",
                            o = null != (i = null == (s = eo(rU, e => e.transport === n)) ? void 0 : s.method) ? i : rU[0].method;
                        if (!o) throw Error("No available transport method");
                        o(r)
                    })(V(V({}, e), {}, {
                        callback: t => {
                            var i, s, r;
                            this.rateLimiter.checkForLimiting(t), t.statusCode >= 400 && (null == (s = (r = this.config).on_request_error) || s.call(r, t)), null == (i = e.callback) || i.call(e, t)
                        }
                    }))))
                }
                _send_retriable_request(e) {
                    this._retryQueue ? this._retryQueue.retriableRequest(e) : this._send_request(e)
                }
                _execute_array(e) {
                    var t, i = [],
                        s = [],
                        r = [];
                    X(e, e => {
                        e && (P(t = e[0]) ? r.push(e) : F(e) ? e.call(this) : P(e) && "alias" === t ? i.push(e) : P(e) && -1 !== t.indexOf("capture") && F(this[t]) ? r.push(e) : s.push(e))
                    });
                    var n = function(e, t) {
                        X(e, function(e) {
                            if (P(e[0])) {
                                var i = t;
                                Q(e, function(e) {
                                    i = i[e[0]].apply(i, e.slice(1))
                                })
                            } else this[e[0]].apply(this, e.slice(1))
                        }, t)
                    };
                    n(i, this), n(s, this), n(r, this)
                }
                _hasBootstrappedFeatureFlags() {
                    var e, t;
                    return (null == (e = this.config.bootstrap) ? void 0 : e.featureFlags) && Object.keys(null == (t = this.config.bootstrap) ? void 0 : t.featureFlags).length > 0 || !1
                }
                push(e) {
                    this._execute_array([e])
                }
                capture(e, t, i) {
                    var s;
                    if (this.__loaded && this.persistence && this.sessionPersistence && this._requestQueue) {
                        if (!this.consent.isOptedOut())
                            if (!$(e) && O(e)) {
                                if (this.config.opt_out_useragent_filter || !this._is_bot()) {
                                    var r = null != i && i.skip_client_rate_limiting ? void 0 : this.rateLimiter.clientRateLimitContext();
                                    if (null == r || !r.isRateLimited) {
                                        null != t && t.$current_url && !O(null == t ? void 0 : t.$current_url) && (j.error("Invalid `$current_url` property provided to `posthog.capture`. Input must be a string. Ignoring provided value."), null == t || delete t.$current_url), this.sessionPersistence.update_search_keyword(), this.config.save_campaign_params && this.sessionPersistence.update_campaign_params(), this.config.save_referrer && this.sessionPersistence.update_referrer_info(), (this.config.save_campaign_params || this.config.save_referrer) && this.persistence.set_initial_person_info();
                                        var n, o, a, l, c = new Date,
                                            u = (null == i ? void 0 : i.timestamp) || c,
                                            d = tE(),
                                            h = {
                                                uuid: d,
                                                event: e,
                                                properties: this._calculate_event_properties(e, t || {}, u, d)
                                            };
                                        r && (h.properties.$lib_rate_limit_remaining_tokens = r.remainingTokens), (null == i ? void 0 : i.$set) && (h.$set = null == i ? void 0 : i.$set);
                                        var _ = this._calculate_set_once_properties(null == i ? void 0 : i.$set_once);
                                        _ && (h.$set_once = _), (n = h, o = null != i && i._noTruncate ? null : this.config.properties_string_max_length, a = e => O(e) && !M(o) ? e.slice(0, o) : e, l = new Set, h = function e(t, i) {
                                            var s;
                                            return t !== Object(t) ? a ? a(t, i) : t : l.has(t) ? void 0 : (l.add(t), P(t) ? (s = [], X(t, t => {
                                                s.push(e(t))
                                            })) : (s = {}, Q(t, (t, i) => {
                                                l.has(t) || (s[i] = e(t, i))
                                            })), s)
                                        }(n)).timestamp = u, $(null == i ? void 0 : i.timestamp) || (h.properties.$event_time_override_provided = !0, h.properties.$event_time_override_system_time = c);
                                        var p = V(V({}, h.properties.$set), h.$set);
                                        if (T(p) || this.setPersonPropertiesForFlags(p), !L(this.config.before_send)) {
                                            var g = this._runBeforeSend(h);
                                            if (!g) return;
                                            h = g
                                        }
                                        this._internalEventEmitter.emit("eventCaptured", h);
                                        var f = {
                                            method: "POST",
                                            url: null != (s = null == i ? void 0 : i._url) ? s : this.requestRouter.endpointFor("api", this.analyticsDefaultEndpoint),
                                            data: h,
                                            compression: "best-available",
                                            batchKey: null == i ? void 0 : i._batchKey
                                        };
                                        return !this.config.request_batching || i && (null == i || !i._batchKey) || null != i && i.send_instantly ? this._send_retriable_request(f) : this._requestQueue.enqueue(f), h
                                    }
                                    j.critical("This capture call is ignored due to client rate limiting.")
                                }
                            } else j.error("No event name provided to posthog.capture")
                    } else j.uninitializedWarning("posthog.capture")
                }
                _addCaptureHook(e) {
                    return this.on("eventCaptured", t => e(t.event, t))
                }
                _calculate_event_properties(e, t, i, s) {
                    if (i = i || new Date, !this.persistence || !this.sessionPersistence) return t;
                    var n, o = this.persistence.remove_event_timer(e),
                        a = V({}, t);
                    if (a.token = this.config.token, this.config.__preview_experimental_cookieless_mode && (a.$cookieless_mode = !0), "$snapshot" === e) {
                        var l = V(V({}, this.persistence.properties()), this.sessionPersistence.properties());
                        return a.distinct_id = l.distinct_id, (!O(a.distinct_id) && !D(a.distinct_id) || A(a.distinct_id)) && j.error("Invalid distinct_id for replay event. This indicates a bug in your implementation"), a
                    }
                    var c, h = function(e, t) {
                        if (!g) return {};
                        var i, s, n = e ? ee([], rn, t || []) : [],
                            [o, a] = function(e) {
                                for (var t = 0; t < ri.length; t++) {
                                    var [i, s] = ri[t], r = i.exec(e), n = r && (F(s) ? s(r, e) : s);
                                    if (n) return n
                                }
                                return ["", ""]
                            }(g);
                        return Z(er({
                            $os: o,
                            $os_version: a,
                            $browser: s9(g, navigator.vendor),
                            $device: rs(g),
                            $device_type: (s = rs(g)) === sk || s === sS || "Kobo" === s || "Kindle Fire" === s || s === sZ ? sw : s === sj || s === sU || s === sz || s === sK ? "Console" : s === sx ? "Wearable" : s ? sy : "Desktop",
                            $timezone: rg(),
                            $timezone_offset: function() {
                                try {
                                    return (new Date).getTimezoneOffset()
                                } catch (e) {
                                    return
                                }
                            }()
                        }), {
                            $current_url: th(null == d ? void 0 : d.href, n, ra),
                            $host: null == d ? void 0 : d.host,
                            $pathname: null == d ? void 0 : d.pathname,
                            $raw_user_agent: g.length > 1e3 ? g.substring(0, 997) + "..." : g,
                            $browser_version: rt(g, navigator.vendor),
                            $browser_language: rd(),
                            $browser_language_prefix: "string" == typeof(i = rd()) ? i.split("-")[0] : void 0,
                            $screen_height: null == r ? void 0 : r.screen.height,
                            $screen_width: null == r ? void 0 : r.screen.width,
                            $viewport_height: null == r ? void 0 : r.innerHeight,
                            $viewport_width: null == r ? void 0 : r.innerWidth,
                            $lib: "web",
                            $lib_version: v.LIB_VERSION,
                            $insert_id: Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10),
                            $time: Date.now() / 1e3
                        })
                    }(this.config.mask_personal_data_properties, this.config.custom_personal_data_properties);
                    if (this.sessionManager) {
                        var {
                            sessionId: _,
                            windowId: p
                        } = this.sessionManager.checkAndGetSessionAndWindowId();
                        a.$session_id = _, a.$window_id = p
                    }
                    this.sessionPropsManager && Z(a, this.sessionPropsManager.getSessionProps());
                    try {
                        this.sessionRecording && Z(a, this.sessionRecording.sdkDebugProperties), a.$sdk_debug_retry_queue_size = null == (n = this._retryQueue) ? void 0 : n.length
                    } catch (e) {
                        a.$sdk_debug_error_capturing_properties = String(e)
                    }
                    if (this.requestRouter.region === r2.CUSTOM && (a.$lib_custom_api_host = this.config.api_host), c = "$pageview" === e ? this.pageViewManager.doPageView(i, s) : "$pageleave" === e ? this.pageViewManager.doPageLeave(i) : this.pageViewManager.doEvent(), a = Z(a, c), "$pageview" === e && u && (a.title = u.title), !$(o)) {
                        var f = i.getTime() - o;
                        a.$duration = parseFloat((f / 1e3).toFixed(3))
                    }
                    g && this.config.opt_out_useragent_filter && (a.$browser_type = this._is_bot() ? "bot" : "browser"), (a = Z({}, h, this.persistence.properties(), this.sessionPersistence.properties(), a)).$is_identified = this._isIdentified(), P(this.config.property_denylist) ? Q(this.config.property_denylist, function(e) {
                        delete a[e]
                    }) : j.error("Invalid value for property_denylist config: " + this.config.property_denylist + " or property_blacklist config: " + this.config.property_blacklist);
                    var m = this.config.sanitize_properties;
                    m && (j.error("sanitize_properties is deprecated. Use before_send instead"), a = m(a, e));
                    var y = this._hasPersonProcessing();
                    return a.$process_person_profile = y, y && this._requirePersonProcessing("_calculate_event_properties"), a
                }
                _calculate_set_once_properties(e) {
                    if (!this.persistence || !this._hasPersonProcessing() || this._personProcessingSetOncePropertiesSent) return e;
                    var t, i = Z({}, this.persistence.get_initial_props(), (null == (t = this.sessionPropsManager) ? void 0 : t.getSetOnceProps()) || {}, e || {}),
                        s = this.config.sanitize_properties;
                    return s && (j.error("sanitize_properties is deprecated. Use before_send instead"), i = s(i, "$set_once")), this._personProcessingSetOncePropertiesSent = !0, T(i) ? void 0 : i
                }
                register(e, t) {
                    var i;
                    null == (i = this.persistence) || i.register(e, t)
                }
                register_once(e, t, i) {
                    var s;
                    null == (s = this.persistence) || s.register_once(e, t, i)
                }
                register_for_session(e) {
                    var t;
                    null == (t = this.sessionPersistence) || t.register(e)
                }
                unregister(e) {
                    var t;
                    null == (t = this.persistence) || t.unregister(e)
                }
                unregister_for_session(e) {
                    var t;
                    null == (t = this.sessionPersistence) || t.unregister(e)
                }
                _register_single(e, t) {
                    this.register({
                        [e]: t
                    })
                }
                getFeatureFlag(e, t) {
                    return this.featureFlags.getFeatureFlag(e, t)
                }
                getFeatureFlagPayload(e) {
                    var t = this.featureFlags.getFeatureFlagPayload(e);
                    try {
                        return JSON.parse(t)
                    } catch (e) {
                        return t
                    }
                }
                isFeatureEnabled(e, t) {
                    return this.featureFlags.isFeatureEnabled(e, t)
                }
                reloadFeatureFlags() {
                    this.featureFlags.reloadFeatureFlags()
                }
                updateEarlyAccessFeatureEnrollment(e, t) {
                    this.featureFlags.updateEarlyAccessFeatureEnrollment(e, t)
                }
                getEarlyAccessFeatures(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        i = arguments.length > 2 ? arguments[2] : void 0;
                    return this.featureFlags.getEarlyAccessFeatures(e, t, i)
                }
                on(e, t) {
                    return this._internalEventEmitter.on(e, t)
                }
                onFeatureFlags(e) {
                    return this.featureFlags.onFeatureFlags(e)
                }
                onSurveysLoaded(e) {
                    return this.surveys.onSurveysLoaded(e)
                }
                onSessionId(e) {
                    var t, i;
                    return null != (t = null == (i = this.sessionManager) ? void 0 : i.onSessionId(e)) ? t : () => {}
                }
                getSurveys(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    this.surveys.getSurveys(e, t)
                }
                getActiveMatchingSurveys(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    this.surveys.getActiveMatchingSurveys(e, t)
                }
                renderSurvey(e, t) {
                    this.surveys.renderSurvey(e, t)
                }
                canRenderSurvey(e) {
                    return this.surveys.canRenderSurvey(e)
                }
                canRenderSurveyAsync(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    return this.surveys.canRenderSurveyAsync(e, t)
                }
                identify(e, t, i) {
                    if (!this.__loaded || !this.persistence) return j.uninitializedWarning("posthog.identify");
                    if (D(e) && (e = e.toString(), j.warn("The first argument to posthog.identify was a number, but it should be a string. It has been converted to a string.")), e) {
                        if (["distinct_id", "distinctid"].includes(e.toLowerCase())) j.critical('The string "'.concat(e, '" was set in posthog.identify which indicates an error. This ID should be unique to the user and not a hardcoded string.'));
                        else if (this._requirePersonProcessing("posthog.identify")) {
                            var s = this.get_distinct_id();
                            this.register({
                                $user_id: e
                            }), this.get_property("$device_id") || this.register_once({
                                $had_persisted_distinct_id: !0,
                                $device_id: s
                            }, ""), e !== s && e !== this.get_property(ec) && (this.unregister(ec), this.register({
                                distinct_id: e
                            }));
                            var r = "anonymous" === (this.persistence.get_property(eD) || "anonymous");
                            e !== s && r ? (this.persistence.set_property(eD, "identified"), this.setPersonPropertiesForFlags(V(V({}, i || {}), t || {}), !1), this.capture("$identify", {
                                distinct_id: e,
                                $anon_distinct_id: s
                            }, {
                                $set: t || {},
                                $set_once: i || {}
                            }), this._cachedPersonProperties = r4(e, t, i), this.featureFlags.setAnonymousDistinctId(s)) : (t || i) && this.setPersonProperties(t, i), e !== s && (this.reloadFeatureFlags(), this.unregister(eL))
                        }
                    } else j.error("Unique user id has not been set in posthog.identify")
                }
                setPersonProperties(e, t) {
                    if ((e || t) && this._requirePersonProcessing("posthog.setPersonProperties")) {
                        var i = r4(this.get_distinct_id(), e, t);
                        this._cachedPersonProperties !== i ? (this.setPersonPropertiesForFlags(V(V({}, t || {}), e || {})), this.capture("$set", {
                            $set: e || {},
                            $set_once: t || {}
                        }), this._cachedPersonProperties = i) : j.info("A duplicate setPersonProperties call was made with the same properties. It has been ignored.")
                    }
                }
                group(e, t, i) {
                    if (e && t) {
                        if (this._requirePersonProcessing("posthog.group")) {
                            var s = this.getGroups();
                            s[e] !== t && this.resetGroupPropertiesForFlags(e), this.register({
                                $groups: V(V({}, s), {}, {
                                    [e]: t
                                })
                            }), i && (this.capture("$groupidentify", {
                                $group_type: e,
                                $group_key: t,
                                $group_set: i
                            }), this.setGroupPropertiesForFlags({
                                [e]: i
                            })), s[e] === t || i || this.reloadFeatureFlags()
                        }
                    } else j.error("posthog.group requires a group type and group key")
                }
                resetGroups() {
                    this.register({
                        $groups: {}
                    }), this.resetGroupPropertiesForFlags(), this.reloadFeatureFlags()
                }
                setPersonPropertiesForFlags(e) {
                    var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    this.featureFlags.setPersonPropertiesForFlags(e, t)
                }
                resetPersonPropertiesForFlags() {
                    this.featureFlags.resetPersonPropertiesForFlags()
                }
                setGroupPropertiesForFlags(e) {
                    var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    this._requirePersonProcessing("posthog.setGroupPropertiesForFlags") && this.featureFlags.setGroupPropertiesForFlags(e, t)
                }
                resetGroupPropertiesForFlags(e) {
                    this.featureFlags.resetGroupPropertiesForFlags(e)
                }
                reset(e) {
                    if (j.info("reset"), !this.__loaded) return j.uninitializedWarning("posthog.reset");
                    var t, i, s, r, n = this.get_property("$device_id");
                    if (this.consent.reset(), null == (t = this.persistence) || t.clear(), null == (i = this.sessionPersistence) || i.clear(), this.surveys.reset(), null == (s = this.persistence) || s.set_property(eD, "anonymous"), null == (r = this.sessionManager) || r.resetSessionId(), this._cachedPersonProperties = null, this.config.__preview_experimental_cookieless_mode) this.register_once({
                        distinct_id: eW,
                        $device_id: null
                    }, "");
                    else {
                        var o = this.config.get_device_id(tE());
                        this.register_once({
                            distinct_id: o,
                            $device_id: e ? o : n
                        }, "")
                    }
                    this.register({
                        $last_posthog_reset: (new Date).toISOString()
                    }, 1)
                }
                get_distinct_id() {
                    return this.get_property("distinct_id")
                }
                getGroups() {
                    return this.get_property("$groups") || {}
                }
                get_session_id() {
                    var e, t;
                    return null != (e = null == (t = this.sessionManager) ? void 0 : t.checkAndGetSessionAndWindowId(!0).sessionId) ? e : ""
                }
                get_session_replay_url(e) {
                    if (!this.sessionManager) return "";
                    var {
                        sessionId: t,
                        sessionStartTimestamp: i
                    } = this.sessionManager.checkAndGetSessionAndWindowId(!0), s = this.requestRouter.endpointFor("ui", "/project/".concat(this.config.token, "/replay/").concat(t));
                    if (null != e && e.withTimestamp && i) {
                        var r, n = null != (r = e.timestampLookBack) ? r : 10;
                        if (!i) return s;
                        var o = Math.max(Math.floor(((new Date).getTime() - i) / 1e3) - n, 0);
                        s += "?t=".concat(o)
                    }
                    return s
                }
                alias(e, t) {
                    return e === this.get_property(el) ? (j.critical("Attempting to create alias for existing People user - aborting."), -2) : this._requirePersonProcessing("posthog.alias") ? ($(t) && (t = this.get_distinct_id()), e !== t ? (this._register_single(ec, e), this.capture("$create_alias", {
                        alias: e,
                        distinct_id: t
                    })) : (j.warn("alias matches current distinct_id - skipping api call."), this.identify(e), -1)) : void 0
                }
                set_config(e) {
                    var t, i, s, r, n = V({}, this.config);
                    R(e) && (Z(this.config, no(e)), null == (t = this.persistence) || t.update_config(this.config, n), this.sessionPersistence = "sessionStorage" === this.config.persistence || "memory" === this.config.persistence ? this.persistence : new rC(V(V({}, this.config), {}, {
                        persistence: "sessionStorage"
                    })), tR.is_supported() && "true" === tR.get("ph_debug") && (this.config.debug = !0), this.config.debug && (v.DEBUG = !0, j.info("set_config", JSON.stringify({
                        config: e,
                        oldConfig: n,
                        newConfig: V({}, this.config)
                    }, null, 2))), null == (i = this.sessionRecording) || i.startIfEnabledOrStop(), null == (s = this.autocapture) || s.startIfEnabled(), null == (r = this.heatmaps) || r.startIfEnabled(), this.surveys.loadIfEnabled(), this._sync_opt_out_with_persistence())
                }
                startSessionRecording(e) {
                    var t, i, s, r, n, o = !0 === e,
                        a = {
                            sampling: o || !(null == e || !e.sampling),
                            linked_flag: o || !(null == e || !e.linked_flag),
                            url_trigger: o || !(null == e || !e.url_trigger),
                            event_trigger: o || !(null == e || !e.event_trigger)
                        };
                    Object.values(a).some(Boolean) && (null == (t = this.sessionManager) || t.checkAndGetSessionAndWindowId(), a.sampling && (null == (i = this.sessionRecording) || i.overrideSampling()), a.linked_flag && (null == (s = this.sessionRecording) || s.overrideLinkedFlag()), a.url_trigger && (null == (r = this.sessionRecording) || r.overrideTrigger("url")), a.event_trigger && (null == (n = this.sessionRecording) || n.overrideTrigger("event"))), this.set_config({
                        disable_session_recording: !1
                    })
                }
                stopSessionRecording() {
                    this.set_config({
                        disable_session_recording: !0
                    })
                }
                sessionRecordingStarted() {
                    var e;
                    return !(null == (e = this.sessionRecording) || !e.started)
                }
                captureException(e, t) {
                    var i = Error("PostHog syntheticException");
                    this.exceptions.sendExceptionEvent(V(V({}, function(e, t) {
                        var {
                            error: i,
                            event: s
                        } = e, r = {
                            $exception_list: []
                        }, n = i || s;
                        if (tJ(n) || tV(n, "DOMException")) {
                            if ("stack" in n) r = ie(n, t);
                            else {
                                var o = n.name || (tJ(n) ? "DOMError" : "DOMException"),
                                    a = n.message ? "".concat(o, ": ").concat(n.message) : o,
                                    l = tJ(n) ? "DOMError" : "DOMException";
                                r = it(a, V(V({}, t), {}, {
                                    overrideExceptionType: l,
                                    defaultExceptionMessage: a
                                }))
                            }
                            return "code" in n && (r.$exception_DOMException_code = "".concat(n.code)), r
                        }
                        if (tV(n, "ErrorEvent") && n.error) return ie(n.error, t);
                        if (tG(n)) return ie(n, t);
                        if (tV(n, "Object") || tU(n)) return function(e, t) {
                            var i, s, r, n = null == (s = null == t ? void 0 : t.handled) || s,
                                o = null == (r = null == t ? void 0 : t.synthetic) || r,
                                a = {
                                    type: null != t && t.overrideExceptionType ? t.overrideExceptionType : tU(e) ? e.constructor.name : "Error",
                                    value: "Non-Error 'exception' captured with keys: ".concat(function(e) {
                                        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 40,
                                            i = Object.keys(e);
                                        if (i.sort(), !i.length) return "[object has no keys]";
                                        for (var s = i.length; s > 0; s--) {
                                            var r = i.slice(0, s).join(", ");
                                            if (!(r.length > t)) return s === i.length || r.length <= t ? r : "".concat(r.slice(0, t), "...")
                                        }
                                        return ""
                                    }(e)),
                                    mechanism: {
                                        handled: n,
                                        synthetic: o
                                    }
                                };
                            if (null != t && t.syntheticException) {
                                var l = t7(null == t ? void 0 : t.syntheticException, 1);
                                l.length && (a.stacktrace = {
                                    frames: l,
                                    type: "raw"
                                })
                            }
                            return {
                                $exception_list: [a],
                                $exception_level: O(i = e.level) && !A(i) && b.indexOf(i) >= 0 ? e.level : "error"
                            }
                        }(n, t);
                        if ($(i) && O(s)) {
                            var c = "Error",
                                u = s,
                                d = s.match(t8);
                            return d && (c = d[1], u = d[2]), it(u, V(V({}, t), {}, {
                                overrideExceptionType: c,
                                defaultExceptionMessage: u
                            }))
                        }
                        return it(n, t)
                    }(e instanceof Error ? {
                        error: e,
                        event: e.message
                    } : {
                        event: e
                    }, {
                        syntheticException: i
                    })), t))
                }
                loadToolbar(e) {
                    return this.toolbar.loadToolbar(e)
                }
                get_property(e) {
                    var t;
                    return null == (t = this.persistence) ? void 0 : t.props[e]
                }
                getSessionProperty(e) {
                    var t;
                    return null == (t = this.sessionPersistence) ? void 0 : t.props[e]
                }
                toString() {
                    var e, t = null != (e = this.config.name) ? e : ns;
                    return t !== ns && (t = ns + "." + t), t
                }
                _isIdentified() {
                    var e, t;
                    return "identified" === (null == (e = this.persistence) ? void 0 : e.get_property(eD)) || "identified" === (null == (t = this.sessionPersistence) ? void 0 : t.get_property(eD))
                }
                _hasPersonProcessing() {
                    var e, t, i, s;
                    return !("never" === this.config.person_profiles || "identified_only" === this.config.person_profiles && !this._isIdentified() && T(this.getGroups()) && (null == (e = this.persistence) || null == (t = e.props) || !t[ec]) && (null == (i = this.persistence) || null == (s = i.props) || !s[ez]))
                }
                _shouldCapturePageleave() {
                    return !0 === this.config.capture_pageleave || "if_capture_pageview" === this.config.capture_pageleave && (!0 === this.config.capture_pageview || "history_change" === this.config.capture_pageview)
                }
                createPersonProfile() {
                    this._hasPersonProcessing() || this._requirePersonProcessing("posthog.createPersonProfile") && this.setPersonProperties({}, {})
                }
                _requirePersonProcessing(e) {
                    return "never" === this.config.person_profiles ? (j.error(e + ' was called, but process_person is set to "never". This call will be ignored.'), !1) : (this._register_single(ez, !0), !0)
                }
                _sync_opt_out_with_persistence() {
                    var e, t, i, s, r = this.consent.isOptedOut(),
                        n = this.config.opt_out_persistence_by_default,
                        o = this.config.disable_persistence || r && !!n;
                    (null == (e = this.persistence) ? void 0 : e.disabled) !== o && (null == (i = this.persistence) || i.set_disabled(o)), (null == (t = this.sessionPersistence) ? void 0 : t.disabled) !== o && (null == (s = this.sessionPersistence) || s.set_disabled(o))
                }
                opt_in_capturing(e) {
                    var t;
                    this.consent.optInOut(!0), this._sync_opt_out_with_persistence(), ($(null == e ? void 0 : e.captureEventName) || null != e && e.captureEventName) && this.capture(null != (t = null == e ? void 0 : e.captureEventName) ? t : "$opt_in", null == e ? void 0 : e.captureProperties, {
                        send_instantly: !0
                    }), this.config.capture_pageview && this._captureInitialPageview()
                }
                opt_out_capturing() {
                    this.consent.optInOut(!1), this._sync_opt_out_with_persistence()
                }
                has_opted_in_capturing() {
                    return this.consent.isOptedIn()
                }
                has_opted_out_capturing() {
                    return this.consent.isOptedOut()
                }
                clear_opt_in_out_capturing() {
                    this.consent.reset(), this._sync_opt_out_with_persistence()
                }
                _is_bot() {
                    return c ? r6(c, this.config.custom_blocked_useragents) : void 0
                }
                _captureInitialPageview() {
                    u && !this._initialPageviewCaptured && (this._initialPageviewCaptured = !0, this.capture("$pageview", {
                        title: u.title
                    }, {
                        send_instantly: !0
                    }))
                }
                debug(e) {
                    !1 === e ? (null == r || r.console.log("You've disabled debug mode."), localStorage && localStorage.removeItem("ph_debug"), this.set_config({
                        debug: !1
                    })) : (null == r || r.console.log("You're now in debug mode. All calls to PostHog will be logged in your console.\nYou can disable this with `posthog.debug(false)`."), localStorage && localStorage.setItem("ph_debug", "true"), this.set_config({
                        debug: !0
                    }))
                }
                _runBeforeSend(e) {
                    if (L(this.config.before_send)) return e;
                    var t = P(this.config.before_send) ? this.config.before_send : [this.config.before_send],
                        i = e;
                    for (var s of t) {
                        if (L(i = s(i))) {
                            var r = "Event '".concat(e.event, "' was rejected in beforeSend function");
                            return B(e.event) ? j.warn("".concat(r, ". This can cause unexpected behavior.")) : j.info(r), null
                        }
                        i.properties && !T(i.properties) || j.warn("Event '".concat(e.event, "' has no properties after beforeSend function, this is likely an error."))
                    }
                    return i
                }
                getPageViewId() {
                    var e;
                    return null == (e = this.pageViewManager._currentPageview) ? void 0 : e.pageViewId
                }
                captureTraceFeedback(e, t) {
                    this.capture("$ai_feedback", {
                        $ai_trace_id: String(e),
                        $ai_feedback_text: t
                    })
                }
                captureTraceMetric(e, t, i) {
                    this.capture("$ai_metric", {
                        $ai_trace_id: String(e),
                        $ai_metric_name: t,
                        $ai_metric_value: String(i)
                    })
                }
            }! function(e, t) {
                for (var i = 0; i < t.length; i++) e.prototype[t[i]] = es(e.prototype[t[i]])
            }(nl, ["identify"]),
            function(e) {
                e.Button = "button", e.Tab = "tab", e.Selector = "selector"
            }(nc || (nc = {})),
            function(e) {
                e.Left = "left", e.Center = "center", e.Right = "right", e.NextToTrigger = "next_to_trigger"
            }(nu || (nu = {})),
            function(e) {
                e.Popover = "popover", e.API = "api", e.Widget = "widget"
            }(nd || (nd = {})),
            function(e) {
                e.Open = "open", e.MultipleChoice = "multiple_choice", e.SingleChoice = "single_choice", e.Rating = "rating", e.Link = "link"
            }(nh || (nh = {})),
            function(e) {
                e.NextQuestion = "next_question", e.End = "end", e.ResponseBased = "response_based", e.SpecificQuestion = "specific_question"
            }(n_ || (n_ = {})),
            function(e) {
                e.Once = "once", e.Recurring = "recurring", e.Always = "always"
            }(np || (np = {}));
            var nc, nu, nd, nh, n_, np, ng, nf = (ng = nt[ns] = new nl, function() {
                function e() {
                    e.done || (e.done = !0, nr = !1, Q(nt, function(e) {
                        e._dom_loaded()
                    }))
                }
                null != u && u.addEventListener ? "complete" === u.readyState ? e() : ea(u, "DOMContentLoaded", e, {
                    capture: !1
                }) : r && j.error("Browser doesn't support `document.addEventListener` so PostHog couldn't be initialized")
            }(), ng)
        }
    }
]);